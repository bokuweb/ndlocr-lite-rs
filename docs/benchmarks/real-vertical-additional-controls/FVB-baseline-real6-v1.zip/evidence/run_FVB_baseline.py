from pathlib import Path
import csv,gzip,hashlib,json,os,platform,subprocess,sys,zipfile
from PIL import Image
sys.path.insert(0,'tools')
import vertical_page_matrix as matrix
from additional_real_diagnostic import image_manifest
from verify_low_stop_evidence import metric_values
root=Path(__file__).resolve().parent;repo=Path.cwd();baseline=json.loads((root/'FVB-e559-baseline-frozen.json').read_text())
ci=json.loads(subprocess.check_output(['gh','run','view','39547797390','--json','headSha,conclusion,jobs'],text=True));assert ci['conclusion']=='success' and ci['headSha']=='e559efb7976226da4a1a9ad9c7cefe848248ea69' and len(ci['jobs'])==5 and all(j['conclusion']=='success' for j in ci['jobs'])
index_path=repo/'docs/benchmarks/real-vertical-additional-controls/index.json';index=json.loads(index_path.read_text());archive=index_path.parent/index['archive'];assert matrix.sha(archive.read_bytes())==index['sha256']
output=root/'FVB-baseline-real6-v1';output.mkdir();work=output/'work';work.mkdir()
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(index['members'])
 for n,h in index['members'].items():
  data=z.read(n);assert len(data)==h['bytes'] and matrix.sha(data)==h['sha256']
 master_member='tmp/real-vertical-additional-controls/additional-controls-manifest-v1.json';master=json.loads(z.read(master_member));assert len(master['inputs'])==6 and len(master['scoring_inputs'])==11
 needed={r[k] for r in master['inputs'] for k in ['image','rgb']}|{r['truth'] for r in master['scoring_inputs']}
 for name in needed:
  p=work/matrix.safe_member(name);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 for row in master['inputs']:
  png=work/row['image'];rgb=(work/row['rgb']).read_bytes();im=Image.open(png).convert('RGB');assert (im.width,im.height)==(row['width'],row['height']);assert im.tobytes()==rgb and matrix.sha(rgb)==row['rgb_sha256'];assert matrix.sha(png.read_bytes())==row['image_sha256']
 for row in master['scoring_inputs']:assert matrix.sha((work/row['truth']).read_bytes())==row['truth_sha256']
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets'];models=repo/'models'
for asset in assets.values():assert matrix.sha((models/asset['name']).read_bytes())==asset['sha256']
for n,h in baseline['source_files'].items():assert matrix.sha((repo/n).read_bytes())==h
for binary in baseline['binaries'].values():assert matrix.sha(Path(binary['path']).read_bytes())==binary['sha256']
manifest=output/'NN-images-only.json';matrix.write_json(manifest,image_manifest(master,work))
target=Path(baseline['binaries']['cli']['compiler_artifact']['executable']).parent
library_dirs=[target,target/'deps']+list((target/'build').glob('ort-sys-*/out/onnxruntime/lib'))
variable='DYLD_LIBRARY_PATH' if sys.platform=='darwin' else 'LD_LIBRARY_PATH';env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1',variable:os.pathsep.join(str(p) for p in library_dirs)}
meta={'complete':False,'baseline':baseline,'baseline_CI':ci,'controls_index_sha256':matrix.sha(index_path.read_bytes()),'master_sha256':matrix.sha(z.read(master_member)) if False else index['members'][master_member]['sha256'],'assets':assets,'commands':[],'runtime_environment':env,'driver_sha256':matrix.sha(Path(__file__).read_bytes()),'manifest_sha256':matrix.sha(manifest.read_bytes()),'internal_forward_calls':None,'CLI_model_session_loads':None,'successful_PageRecognizer_loads':0,'successful_Page_model_session_loads':0,'successful_Page_API_results':0,'successful_CLI_processes':0,'target_image_results':48,'target_CSV_rows':264,'adoption_comparison':False}
matrix.write_json(output/'before-NN.json',meta);matrix.write_json(output/'job.json',meta)
try:
 predictions={};page_records={}
 for model in ['30','50','100']:
  directory=output/'page'/model;argv=[baseline['binaries']['page']['path'],'--manifest',str(manifest),'--det-model',str(models/assets['deim']['name']),'--parseq-model',str(models/assets[model]['name']),'--charset',str(models/assets['charset']['name']),'--label','runtime'+model,'--output-dir',str(directory)]
  matrix.run_command(argv,'page'+model,output,meta,env)
  rows=matrix.read_page_results(directory,model,master['inputs'])
  for route,values in rows.items():predictions[route]={i:r['text'] for i,r in values.items()};page_records[route]=values
  meta['successful_PageRecognizer_loads']+=1;meta['successful_Page_model_session_loads']+=2;meta['successful_Page_API_results']+=12;matrix.write_json(output/'job.json',meta)
 for mode in ['deim','bands']:
  directory=output/'cli'/mode;directory.mkdir(parents=True);values={}
  for row in master['inputs']:
   ident=row['id'];body=directory/(ident+'.txt');label='cli-'+mode+'-'+ident;argv=matrix.cli_command(baseline['binaries']['cli']['path'],work/row['image'],models,assets,mode,body);matrix.run_command(argv,label,output,meta,env);values[ident]=matrix.read_cli_result(output/'commands'/(label+'.stdout'),body);meta['successful_CLI_processes']+=1;matrix.write_json(output/'job.json',meta)
  predictions['cli_'+mode]=values
 assert len(predictions)==8
 metric_root=output/'metrics';truth=metric_root/'truth';truth.mkdir(parents=True);systems={}
 for row in master['scoring_inputs']:(truth/(row['id']+'.txt')).write_bytes((work/row['truth']).read_bytes())
 for route,values in predictions.items():
  mapped=matrix.map_predictions(master['scoring_inputs'],values);directory=metric_root/route;directory.mkdir();systems[route]=directory
  for ident,text in mapped.items():(directory/(ident+'.txt')).write_bytes(text.encode())
 verified=0;totals=[];per_input=[]
 for mode in ['none','width','strict']:
  table=metric_root/(mode+'.csv');argv=[sys.executable,str(repo/'tools/eval_ocr_metrics.py'),'--truth-dir',str(truth)]
  for name,directory in systems.items():argv+=['--system',name+'='+str(directory)]
  argv+=['--normalize',mode,'--require-all','--output-csv',str(table)];matrix.run_command(argv,'metrics-'+mode,output,meta)
  rows=list(csv.DictReader(table.open()));assert len(rows)==88 and len({(r['system'],r['file']) for r in rows})==88
  for row in rows:
   expected=metric_values((truth/row['file']).read_text(),(systems[row['system']]/row['file']).read_text(),mode);assert tuple(int(row[k]) for k in ['char_errors','char_total','word_errors','word_total'])==expected;verified+=1;per_input.append({'mode':mode,**row})
  for name in systems:
   selected=[r for r in rows if r['system']==name];totals.append({'mode':mode,'route':name,**{k:sum(int(r[k]) for r in selected) for k in ['char_errors','char_total','word_errors','word_total']}})
 for n,h in baseline['source_files'].items():assert matrix.sha((repo/n).read_bytes())==h
 for binary in baseline['binaries'].values():assert matrix.sha(Path(binary['path']).read_bytes())==binary['sha256']
 for asset in assets.values():assert matrix.sha((models/asset['name']).read_bytes())==asset['sha256']
 for row in master['inputs']:
  for k in ['image','rgb']:assert matrix.sha((work/row[k]).read_bytes())==row[k+'_sha256']
 for row in master['scoring_inputs']:assert matrix.sha((work/row['truth']).read_bytes())==row['truth_sha256']
 meta.update({'complete':True,'frozen_materials_after_unchanged':True,'verified_CSV_rows':verified,'image_results':meta['successful_Page_API_results']+meta['successful_CLI_processes'],'totals':totals});assert verified==264 and meta['image_results']==48
 matrix.write_json(output/'per-input-metrics.json',per_input);matrix.write_json(output/'summary.json',{k:v for k,v in meta.items() if k not in ['baseline','commands','baseline_CI']})
 print(json.dumps({'complete':True,'Page_API_results':36,'CLI_processes':12,'image_results':48,'verified_CSV_rows':verified,'PageRecognizer_loads':3,'Page_model_session_loads':6,'internal_forward_calls':None,'totals_none':[r for r in totals if r['mode']=='none']},ensure_ascii=False,indent=2))
except Exception as error:
 meta['error']=repr(error);raise
finally:matrix.write_json(output/'job.json',meta)
