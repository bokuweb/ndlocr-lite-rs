from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
from additional_real_diagnostic import text_diagnosis
import vertical_page_matrix as matrix
root=Path('tmp/real-vertical-additional-controls');run=root/'FVB-baseline-real6-v1';master=json.loads((root/'additional-controls-manifest-v1.json').read_text());official=json.loads((run/'per-input-metrics.json').read_text());expected={(r['system'],r['file']):r for r in official if r['mode']=='none'}
entries=[]
for route in sorted({r['system'] for r in official}):
 for alias in master['scoring_inputs']:
  name=alias['id']+'.txt';truth=(run/'metrics/truth'/name).read_text();prediction=(run/'metrics'/route/name).read_text();diagnosis=text_diagnosis(truth,prediction)
  assert diagnosis['raw']=={k:int(expected[route,name][k]) for k in diagnosis['raw']}
  entries.append({'route':route,'scoring_id':alias['id'],'physical_id':alias['physical_id'],'truth':truth,'prediction':prediction,'truth_sha256':matrix.sha(truth.encode()),'prediction_sha256':matrix.sha(prediction.encode()),**diagnosis})
page={route:{r['id']:r for r in json.loads((run/'page'/model/('runtime'+model+'_'+setting)/'results.json').read_text())} for model in ['30','50','100'] for setting in ['eval','default'] for route in [model+'_'+setting]}
comparisons=[]
for row in master['inputs']:
 ident=row['id'];a=page['50_eval'][ident];b=page['100_eval'][ident];comparisons.append({'id':ident,'model50_100_text_equal':a['text']==b['text'],'model50_100_bbox_equal':[r['bbox'] for r in a['lines']]==[r['bbox'] for r in b['lines']],'model50_100_confidences_equal':[r['confidence'] for r in a['lines']]==[r['confidence'] for r in b['lines']],'page50_lines':a['lines'],'page30_lines':page['30_eval'][ident]['lines']})
summary={'image_results':48,'scoring_alias_diagnoses':len(entries),'all_raw_counts_match_official':True,'adoption_comparison':False,'NFC_is_diagnostic_only':True,'per_physical_Page_comparisons':comparisons,'per_route':[{'route':route,'raw_char_errors':sum(e['raw']['char_errors'] for e in entries if e['route']==route),'NFC_diagnostic_char_errors':sum(e['nfc_diagnostic_only']['char_errors'] for e in entries if e['route']==route),'prediction_ASCII_spaces_alias_weighted':sum(e['prediction_ascii_spaces'] for e in entries if e['route']==route)} for route in page.keys()|{'cli_deim','cli_bands'}]}
summary['per_route'].sort(key=lambda r:r['route']);matrix.write_json(run/'text-diagnosis-v1.json',{'summary':summary,'entries':entries});print(json.dumps(summary,ensure_ascii=False,indent=2))
