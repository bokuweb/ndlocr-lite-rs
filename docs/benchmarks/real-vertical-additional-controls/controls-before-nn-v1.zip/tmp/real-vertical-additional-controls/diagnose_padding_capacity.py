from pathlib import Path
from collections import Counter
import datetime,hashlib,json,sys
sys.path.insert(0,'tools')
from verify_low_stop_evidence import Packet,metric_values,verify_native
root=Path('tmp/real-vertical-additional-controls');packet=Packet('docs/benchmarks/vertical-low-stop-development/index.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
models={m['label']:m for m in packet.json('tmp/vertical-output-capacity/metadata/results.json')}
assets=json.loads(Path('docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets']
for key in ['30','50','100','charset']:assert sha((Path('models')/assets[key]['name']).read_bytes())==assets[key]['sha256']
rows=[];candidates=[];validations={}
for phase,prefix in [('Q','tmp/vertical-unique-insertion'),('S','tmp/vertical-low-stop-recovery')]:
 validations[phase]=verify_native(packet,prefix)
 manifest=packet.json(prefix+'/new-manifest.json')['inputs']
 complete=packet.json(prefix+'/native-preflight-complete.json')
 source_checks=0
 for path,h in complete['files_sha256'].items():
  name=packet.logical_path(path)
  if '/baseline-source/' in name and (name.endswith('.rs') or Path(name).name.startswith('Cargo.')):
   assert sha(packet.read(name))==h;source_checks+=1
 assert source_checks>=278
 for label,model in models.items():
  values={r['id']:r for r in packet.json(prefix+'/native-new72/baseline/'+label+'/results.json')}
  iw,ih=model['inputs'][0]['dimensions'][3],model['inputs'][0]['dimensions'][2];limit=model['outputs'][0]['dimensions'][1]
  assert limit==model['outputs'][0]['max_raw_scalars_from_static_shape']
  for item in manifest:
   data=values[item['id']];raw=data['raw_auto']['text'];fragment=data['fragment_auto']['text'];w,h=item['width'],item['height']
   truth=packet.read(packet.logical_path(item['truth'])).decode();near=limit-1<=len(raw)<=limit;trailing=bool(raw and raw[-1].isspace());aspect=h*ih>w*iw*2
   row={'phase':phase,'id':item['id'],'model':label,'cohort':item['cohort'],'width':w,'height':h,'input_width':iw,'input_height':ih,'declared_T':limit,'raw_scalars':len(raw),'raw_trailing_whitespace':trailing,'near_declared_T':near,'passes_original_integer_aspect_guard':aspect,'raw':raw,'fragment':fragment,'GT':truth,'raw_errors_none':metric_values(truth,raw,'none')[0],'fragment_errors_none':metric_values(truth,fragment,'none')[0],'actual_H_or_T_matching_flag_directly_observed':False}
   rows.append(row)
   if near and not trailing and not aspect:candidates.append(row)
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'spec_sha256':sha(Path('docs/vertical_padding_capacity_diagnostic.md').read_bytes()),'packet_index_sha256':sha(Path('docs/benchmarks/vertical-low-stop-development/index.json').read_bytes()),'raw_input_model_pairs':len(rows),'inputs':144,'models':3,'candidate_pairs':len(candidates),'candidate_cohorts':dict(Counter(x['cohort'] for x in candidates)),'candidates':candidates,'saved_native_revalidations':validations,'new_NN_calls':0,'model_loads':0,'new_inference_policy':False,'adoption_gate_pass':False,'source_classification_only_not_runtime_adoption_trace':True}
(root/'padding-capacity-diagnostic.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(root/'padding-capacity-all-pairs.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
