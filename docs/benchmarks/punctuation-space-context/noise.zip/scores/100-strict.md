# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1718`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| raw | 1718 | 0 | 0.0319 | 0.0419 |
| component | 1718 | 0 | 0.0319 | 0.0419 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
