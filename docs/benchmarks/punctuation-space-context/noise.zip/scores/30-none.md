# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1718`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 1718 | 0 | 0.1676 | 0.7512 |
| raw | 1718 | 0 | 0.1707 | 0.7740 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
