# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1718`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 1718 | 0 | 0.1946 | 0.8261 |
| raw | 1718 | 0 | 0.1952 | 0.8287 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
