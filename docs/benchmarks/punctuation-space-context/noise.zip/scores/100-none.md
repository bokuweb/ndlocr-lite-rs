# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1718`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 1718 | 0 | 0.1125 | 0.5729 |
| raw | 1718 | 0 | 0.1155 | 0.5883 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
