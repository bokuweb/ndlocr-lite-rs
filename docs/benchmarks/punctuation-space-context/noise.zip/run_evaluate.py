from pathlib import Path
import json,subprocess,os,hashlib
r=Path('tmp/punct-large-noise');meta=json.loads((r/'evaluate-command.json').read_text())
for p,h in meta['sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
for model in ['30','50','100']:
 assert json.loads((r/'new'/(model+'-command.json')).read_text())['exit_code']==0
before=(r/'geometry.json').read_bytes()
for i,argv in enumerate(meta['steps']):
 p=subprocess.run(argv,capture_output=True,env=os.environ|meta['env']);(r/('evaluation-step'+str(i)+'.stdout')).write_bytes(p.stdout);(r/('evaluation-step'+str(i)+'.stderr')).write_bytes(p.stderr);print(i,p.returncode,p.stdout.decode()[-300:],flush=True);assert p.returncode==0
 if i==1:assert(r/'geometry.json').read_bytes()==before
print('all evaluation processes terminal success',flush=True)
