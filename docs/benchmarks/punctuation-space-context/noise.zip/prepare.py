from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import json,hashlib,PIL,shutil
r=Path('tmp/punct-large-noise');parent=Path('tmp/punctuation-space-components');sha=lambda b:hashlib.sha256(b).hexdigest();root=r/'corpus';root.mkdir()
for d in ['png','rgb','truth']:(root/d).mkdir()
# Prior inputs remain byte-identical; local copies give the frozen Rust probe a standalone manifest.
prior=json.loads((parent/'evaluation-manifest.json').read_text());inputs=[]
for x in prior['inputs']:
 row={**x,'cohort':'prior_'+x['cohort']}
 for kind,d,suffix in [('image','png','.png'),('rgb','rgb','.rgb'),('truth','truth','.txt')]:
  data=Path(x[kind]).read_bytes();assert sha(data)==x[kind+'_sha256'];p=root/d/(x['id']+suffix);p.write_bytes(data);row[kind]=str(p)
 inputs.append(row)
new=r/'new/data';new.mkdir(parents=True);(new/'images').mkdir();(new/'truth').mkdir();fonts=json.loads((parent/'new/data/evaluation-manifest.json').read_text())['fonts'][:3];rows=[];coverage=[]
for f in fonts:
 path=Path(f['path']);assert sha(path.read_bytes())==f['sha256'];font=ImageFont.truetype(str(path),24);key=lambda m:(m.size,bytes(m));missing=key(font.getmask(chr(0x10ffff)));chars=sorted(set('審査内容公開先点検時期対応方法、。'));assert all(key(font.getmask(c))!=missing for c in chars);assert font.getlength(' ')>0;coverage.append({'font':f['id'],'characters':chars,'all_masks_present':True,'space_advance':font.getlength(' ')})
 for size in [24,40]:
  font=ImageFont.truetype(str(path),size)
  for tid,(prefix,punct,suffix)in enumerate([('審査内容','、','公開先'),('点検時期','。','対応方法')]):
   for spaces in [0,1,2]:
    text=prefix+punct+' '*spaces+suffix;x0,y0,x1,y1=font.getbbox(text);im=Image.new('RGB',(x1-x0+4,y1-y0+4),'white');ImageDraw.Draw(im).text((2-x0,2-y0),text,font=font,fill='black');columns=[any(sum(im.getpixel((x,y)))<660 for y in range(im.height))for x in range(im.width)];xs=[x for x,v in enumerate(columns)if v];gaps=[];start=None
    for x in range(xs[0],xs[-1]+1):
     if not columns[x]and start is None:start=x
     if columns[x]and start is not None:gaps.append((start,x));start=None
    gap=max(gaps,key=lambda t:t[1]-t[0])if gaps else(im.width//2,im.width//2);center=(gap[0]+gap[1])//2
    for context,bw,bh,both in [('paper12',0,0,False),('top4x4',4,4,False),('both4x4',4,4,True),('top6x6',6,6,False),('top8x2',8,2,False)]:
     image=Image.new('RGB',(im.width,im.height+24),'white');image.paste(im,(0,12));bounds=[]
     if bw:
      bx=max(0,min(image.width-bw,center-bw//2))
      for by in ([0,image.height-bh]if both else[0]):
       box=(bx,by,bx+bw,by+bh);image.paste((0,0,0),box);bounds.append(box);assert by+bh<=12 or by>=12+im.height
     for fmt in ['png','jpeg75']:
      id=f'n_t{tid}_sp{spaces}_{f["id"]}_{size}_{context}_{fmt}';original=new/'images'/(id+('.png'if fmt=='png'else'.jpg'));image.save(original,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(original).convert('RGB');rgb=root/'rgb'/(id+'.rgb');rgb.write_bytes(decoded.tobytes());png=root/'png'/(id+'.png');decoded.save(png);gt=root/'truth'/(id+'.txt');gt.write_text(text);(new/'truth'/(id+'.txt')).write_bytes(gt.read_bytes());row={'id':id,'cohort':'new_control','width':decoded.width,'height':decoded.height,'image':str(png),'image_sha256':sha(png.read_bytes()),'rgb':str(rgb),'rgb_sha256':sha(rgb.read_bytes()),'truth':str(gt),'truth_sha256':sha(gt.read_bytes()),'original':str(original),'original_sha256':sha(original.read_bytes()),'context':context,'noise_bounds':bounds,'spaces':spaces,'font':f['id'],'size':size,'format':fmt};rows.append(row);inputs.append(row)
assert len(rows)==360 and len(inputs)==1718
variants=[];tiles=[];x=y=row_h=0;maxw=0
for row in rows:
 im=Image.open(row['image']).convert('RGB')
 for label,xp,yp in [('base',0,0),('x2y0',2,0),('x2y1',2,1),('x2y2',2,2)]:
  tile=Image.new('RGB',(im.width+2*xp,im.height+2*yp),'white');tile.paste(im,(xp,yp))
  if x and x+tile.width>2048:y+=row_h+4;x=0;row_h=0
  variants.append({'id':row['id']+'_'+label,'base_id':row['id'],'variant':label,'bounds':[x,y,x+tile.width,y+tile.height],'dimensions':tile.size,'rgb_sha256':sha(tile.tobytes())});tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for v,t in zip(variants,tiles):atlas.paste(t,(v['bounds'][0],v['bounds'][1]))
atlas.save(new/'atlas.png');(new/'lines.json').write_text(json.dumps([{'id':v['id'],'bounds':v['bounds']}for v in variants],indent=2)+'\n');spec=Path('docs/punctuation_space_noise_controls.md');meta={'inputs':rows,'variants':variants,'fonts':fonts,'font_coverage':coverage,'generator_sha256':sha(Path(__file__).read_bytes()),'spec_sha256':sha(spec.read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((new/'atlas.png').read_bytes()),'lines_sha256':sha((new/'lines.json').read_bytes())};(new/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(r/'evaluation-manifest.json').write_text(json.dumps({'inputs':inputs,'parent_manifest_sha256':sha((parent/'evaluation-manifest.json').read_bytes()),'spec_sha256':meta['spec_sha256'],'new_manifest_sha256':sha((new/'evaluation-manifest.json').read_bytes())},ensure_ascii=False,indent=2)+'\n');shutil.copy2(spec,r/'capture-spec.md');shutil.copy2(parent/'native-rows.json',r/'frozen-native.json');shutil.copy2(parent/'parent-raw-capture.json',r/'parent-raw-capture.json');print('1718 total /360 fresh /1440 new native crops fixed',atlas.size,flush=True)
