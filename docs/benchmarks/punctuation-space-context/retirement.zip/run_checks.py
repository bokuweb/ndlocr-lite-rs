from pathlib import Path
import subprocess,os,json,hashlib,concurrent.futures,re
r=Path('tmp/punct-reject');line=next(x.strip()[5:]for x in Path('.github/workflows/ci.yml').read_text().splitlines()if x.strip().startswith('run: cargo test --features onnx --lib'));env={'NDLOCR_TEST_PARSEQ_MODEL':'models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_TEST_DEIM_MODEL':'models/deim-s-1024x1024.onnx','NDLOCR_TEST_REPEAT_IMAGE':'tests/fixtures/parseq_unprocessed/repeated_digits.png','NDLOCR_INTRA_THREADS':'1'};checks=[('default',['cargo','test'],{'CARGO_TARGET_DIR':str(r/'check-default-target')}),('native',line.split(),env|{'CARGO_TARGET_DIR':str(r/'check-onnx-target')}),('clippy',['cargo','clippy','--features','onnx','--lib','--tests','--examples'],{'CARGO_TARGET_DIR':str(r/'check-onnx-target')}),('examples',['cargo','test','--features','onnx','--examples'],{'CARGO_TARGET_DIR':str(r/'check-onnx-target')})]
meta={'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in list(Path('src').rglob('*.rs'))+list(Path('tests/support').glob('*.rs'))+list(Path('examples').rglob('*.rs'))},'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks};(r/'checks-command.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(check):
 name,argv,extra=check
 with(r/(name+'-tests.log')).open('wb')as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=os.environ|extra)
 (r/(name+'-exit.json')).write_text(json.dumps({'exit_code':p.returncode})+'\n');assert p.returncode==0,name;print(name,'terminal success',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,checks))
