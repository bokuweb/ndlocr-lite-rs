from pathlib import Path
import hashlib,json,zipfile,subprocess
r=Path('tmp/punct-reject');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for folder in ['red-source','green-source','cli']:
 for p in(r/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.jsonl','.py','.rs','.log','.stdout','.stderr']:files[p.name]=p.read_bytes()
for name in ['src/infer/cached.rs','src/infer/parseq.rs','src/infer/mod.rs','src/infer/visible_repetitions.rs']:
 files['baseline-source/'+name]=subprocess.run(['git','show','9fc4528:'+name],capture_output=True,check=True).stdout
for p in Path('tests/fixtures/punctuation_context').iterdir():
 if p.is_file():files['fixtures/'+p.name]=p.read_bytes()
files['spec-results.md']=Path('docs/punctuation_space_rejection.md').read_bytes()
seen={};unique={};aliases={}
for key,b in sorted(files.items()):
 h=sha(b)
 if h in seen:aliases[key]={'source':seen[h],'sha256':h}
 else:unique[key]=b;seen[h]=key
unique['aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode();path=out/'retirement.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for key,b in sorted(unique.items()):
  info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
(out/'retirement.json').write_text(json.dumps({'stage':'F/G rejected;production restored to9fc','sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':len(files),'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n');print('retirement packet',len(unique),len(files),path.stat().st_size,flush=True)
