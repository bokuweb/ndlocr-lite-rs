use ndlocr_lite_rs::infer::cached::ParseqSession;
use std::path::Path;
fn main(){for (label,name) in [
("30","parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx"),
("50","parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx"),
("100","parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx")]{
let s=ParseqSession::load(&Path::new("models").join(name),Path::new("models/NDLmoji.yaml")).unwrap();
println!("{label} {:?} batch={}",s.input_dimensions(),s.supports_batch());}}
