# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `158`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 158 | 0 | 0.0904 | 0.7704 |
| before | 158 | 0 | 0.0978 | 0.8016 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
