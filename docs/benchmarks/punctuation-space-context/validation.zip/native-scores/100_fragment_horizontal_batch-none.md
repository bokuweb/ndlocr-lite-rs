# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `158`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 158 | 0 | 0.1015 | 0.7626 |
| before | 158 | 0 | 0.1426 | 1.0117 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
