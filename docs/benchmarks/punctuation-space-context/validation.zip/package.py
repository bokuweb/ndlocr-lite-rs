from pathlib import Path
import hashlib,json,zipfile

r=Path('tmp/punct-f-api');out=Path('docs/benchmarks/punctuation-space-context')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={};directories=[];bodies={}
for name in ['native','page']:
 a=json.loads((r/(name+'-audit.json')).read_text())
 assert not a['char_regressions']and not a['word_regressions']
 for p in(r/(name+'-scores')).iterdir():files[str(p.relative_to(r))]=p.read_bytes()
for model in ['30','50','100']:
 for phase in ['before','after']:
  assert json.loads((r/(phase+'-native'+model+'-command.json')).read_text())['exit_code']==0
  for directory in(r/('native-'+phase)/model).iterdir():
   records=json.loads((directory/'results.json').read_text());assert len(records)==158
   key=str(directory.relative_to(r));directories.append(key);files[key+'/results.json']=(directory/'results.json').read_bytes()
   for x in records:
    body=(directory/(x['id']+'.txt')).read_bytes();assert body==x['text'].encode();bodies[key+'/'+x['id']+'.txt']=sha(body)
for x in json.loads((r/'native-manifest.json').read_text())['inputs']:
 for k,suffix in [('image','.png'),('rgb','.rgb'),('truth','.txt')]:
  body=Path(x[k]).read_bytes();assert sha(body)==x[k+'_sha256'];files['native-inputs/'+k+'/'+x['id']+suffix]=body
 files['native-truth/'+x['id']+'.txt']=Path(x['truth']).read_bytes()
manifest=json.loads((r/'page-after/evaluation-manifest.json').read_text())
assert len(manifest['inputs'])==287
for x in manifest['inputs']:
 for k in ['image','truth']:assert sha(Path(x[k]).read_bytes())==x[k+'_sha256']
 files['images/'+x['id']+Path(x['image']).suffix]=Path(x['image']).read_bytes()
 files['page-truth/'+x['id']+'.txt']=Path(x['truth']).read_bytes()
files['page-after/evaluation-manifest.json']=(r/'page-after/evaluation-manifest.json').read_bytes()
for mode in ['deim','bands','runtime30_eval','runtime30_default','runtime50_eval','runtime50_default','runtime100_eval','runtime100_default']:
 for phase in ['before','after']:
  src=r/'page-before'/mode if phase=='before'else(r/'cli-after'/mode if mode in ['deim','bands']else r/'page-after'/('primary50'if mode.startswith('runtime50')else'after')/mode)
  key=str(src.relative_to(r));directories.append(key)
  if(src/'results.json').exists():data=(src/'results.json').read_bytes();records=json.loads(data)
  else:
   records=[{'id':x['id'],'text':(src/(x['id']+'.txt')).read_text()}for x in manifest['inputs']]
   data=(json.dumps(records,ensure_ascii=False,indent=2)+'\n').encode()
  assert len(records)==287;files[key+'/results.json']=data
  for x in records:
   body=(src/(x['id']+'.txt')).read_bytes();assert body==x['text'].encode();bodies[key+'/'+x['id']+'.txt']=sha(body)
for name in ['page30-100-command.json','page50-command.json']:
 assert json.loads((r/name).read_text())['exit_code']==0
assert json.loads((r/'cli-runs.json').read_text())['fresh_processes']==574
for name in ['default','native','examples','clippy']:assert json.loads((r/(name+'-exit.json')).read_text())['exit_code']==0
for directory in ['source','line-cli']:
 for p in(r/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for directory in ['before-src']:
 for p in(Path('tmp/punct-integration')/directory).rglob('*'):
  if p.is_file():files['source-before/'+str(p.relative_to(Path('tmp/punct-integration')/directory))]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.py','.log','.stdout','.stderr','.jsonl','.md']and p.name!='pr-before.json':files[p.name]=p.read_bytes()
for p in(r/'cli-after').glob('*/*'):
 if p.suffix!='.txt':files[str(p.relative_to(r))]=p.read_bytes()
for p in(r/'meta-probe').rglob('*'):
 if p.is_file():files['meta-probe/'+str(p.relative_to(r/'meta-probe'))]=p.read_bytes()
for name in ['F-policy-red.log','F-policy-green.log','F-native-green.log','F-native-initial-pin-failure.log']:
 p=Path('tmp/punct-integration')/name
 if p.exists():files['tdd/'+name]=p.read_bytes()
# Preserve the exact earlier TDD/source witnesses, including failed native pins.
for root in [Path('tmp/punct-integration'),Path('tmp/punct-width')]:
 for p in root.iterdir():
  if p.is_file()and('f-'in p.name.lower() or'advance-'in p.name or'condensed-space'in p.name)and p.suffix in ['.log','.json','.patch']:
   files['tdd/'+root.name+'/'+p.name]=p.read_bytes()
for name in ['punctuation_space_advance_integration.md','punctuation_space_context_integration.md']:
 files['spec/'+name]=Path('docs',name).read_bytes()
files['source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes()
files['materialize.json']=(json.dumps({'hypothesis':'F','record_directories':directories,'actual_body_sha256':bodies},indent=2)+'\n').encode()
seen={};unique={};aliases={}
for key,body in sorted(files.items()):
 h=sha(body)
 if h in seen:aliases[key]={'source':seen[h],'sha256':h}
 else:unique[key]=body;seen[h]=key
unique['aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode()
path=out/'validation.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for key,body in sorted(unique.items()):
  info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body)
(out/'validation.json').write_text(json.dumps({'hypothesis':'F','sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':len(files),'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n')
print('F validation evidence',len(unique),len(files),path.stat().st_size,flush=True)
