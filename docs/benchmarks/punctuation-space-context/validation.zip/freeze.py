from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/punct-f-api');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=json.loads((r/'source.json').read_text())
for p,h in source['sha256'].items():assert sha(r/'source'/p)==h,p
binaries={}
for log in ['lib-build.jsonl','page-build.jsonl']:
 for line in(r/log).read_text().splitlines():
  x=json.loads(line)
  if x.get('reason')!='compiler-artifact'or not x.get('executable'):continue
  key='lib'if x['target']['kind']==['lib']else('cli'if x['target']['name']=='ndlocr-lite-rs'else'page50')
  path=r/(key+'-binary');shutil.copy2(x['executable'],path);binaries[key]={'sha256':sha(path),'source_executable':x['executable']}
assert set(binaries)=={'lib','cli','page50'}
prior=json.loads(Path('tmp/punct-integration/native-capture-command.json').read_text());old=Path('tmp/punct-integration/before-native-binary');assert sha(old)==prior['before']['binary_sha256'];shutil.copy2(old,r/'before-native-binary')
models=prior['models']|{'models/deim-s-1024x1024.onnx':sha('models/deim-s-1024x1024.onnx')}
for p,h in models.items():assert sha(p)==h
for manifest in [r/'native-manifest.json',Path('tmp/punct-integration/page-after/evaluation-manifest.json')]:
 for x in json.loads(manifest.read_text())['inputs']:
  for k in ['image','truth']:assert sha(x[k])==x[k+'_sha256']
meta={'stage':'F','source':source,'binaries':binaries,'before_native':prior['before'],'models':models,'native_manifest_sha256':sha(r/'native-manifest.json'),'page_manifest_sha256':sha('tmp/punct-integration/page-after/evaluation-manifest.json'),'freeze_sha256':sha(__file__)};(r/'capture-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('F binaries/source/assets/inputs frozen',flush=True)
