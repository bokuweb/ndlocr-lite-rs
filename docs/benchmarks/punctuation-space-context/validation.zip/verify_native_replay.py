from pathlib import Path
import json,struct,hashlib
r=Path('tmp/punct-f-api');parent=Path('tmp/punct-width');f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0];records={(x['id'],x['model']):x for x in json.loads((parent/'production-replay/records.json').read_text())};rows=json.loads((r/'native-manifest.json').read_text())['inputs'];ids={x['id']for x in rows};proof=[]
for phase in ['before','after']:
 for model in ['30','50','100']:
  assert json.loads((r/(phase+'-native'+model+'-command.json')).read_text())['exit_code']==0
  root=r/('native-'+phase)/model;assert len(list(root.iterdir()))==8
  for route in root.iterdir():
   actual=json.loads((route/'results.json').read_text());assert len(actual)==len(ids);assert {x['id']for x in actual}==ids
   for x in actual:
    old=records[x['id'],model]
    if route.name=='raw_session':text=old['raw']['text'];mean=old['raw']['mean_confidence']
    else:
     policy='fragment'if route.name=='fragment_horizontal_batch'else'single';text=old['policies'][policy][phase];mean=old['raw'if phase=='before'else'result']['mean_confidence']
    assert x['text']==text,(phase,model,route.name,x['id'],text,x['text']);assert f32(x['mean_confidence'])==f32(mean),(phase,model,route.name,x['id'],'mean');assert(route/(x['id']+'.txt')).read_bytes()==text.encode()
   proof.append({'phase':phase,'model':model,'route':route.name,'images':len(actual),'all_text_and_f32_confidence_equal_replay':True})
(r/'native-replay-parity.json').write_text(json.dumps({'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fresh_actual_records':len(rows)*3*8*2,'comparisons':proof},indent=2)+'\n');print('all',len(rows)*3*8*2,'fresh actual text/f32 confidence records equal Rust policy replay',flush=True)
