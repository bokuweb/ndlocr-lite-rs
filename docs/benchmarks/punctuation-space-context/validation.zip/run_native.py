from pathlib import Path
import json,hashlib,subprocess,os,concurrent.futures
r=Path('tmp/punct-f-api');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'capture-command.json').read_text());assert sha(r/'lib-binary')==meta['binaries']['lib']['sha256'];assert sha(r/'before-native-binary')==meta['before_native']['binary_sha256'];assert sha(r/'native-manifest.json')==meta['native_manifest_sha256'];n=len(json.loads((r/'native-manifest.json').read_text())['inputs']);models={m:next(p for p in meta['models']if '-'+m+'-tiny-'in p)for m in ['30','50','100']}
for p,h in meta['models'].items():assert sha(p)==h
(r/'native-driver.json').write_text(json.dumps({'driver_sha256':sha(__file__),'images':n,'scope':'fresh before/F; all selected IDs plus documented negatives, not the entire3446 NN rerun'},indent=2)+'\n')
for phase in ['before','after']:(r/('native-'+phase)).mkdir()
def run(job):
 phase,model=job;binary=r/('before-native-binary'if phase=='before'else'lib-binary');env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_TEST_PARSEQ_MODEL':models[model],'NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_LINE_MATRIX_MANIFEST':str(r/'native-manifest.json'),'NDLOCR_LINE_MATRIX_OUTPUT':str(r/('native-'+phase)/model)};argv=[str(binary.resolve()),'infer::cached::punctuation_context_capture::capture_line_matrix','--exact','--ignored','--nocapture'];record={'argv':argv,'env':env};cmd=r/(phase+'-native'+model+'-command.json');cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(phase+'-native'+model+'.stdout')).open('wb')as stdout,(r/(phase+'-native'+model+'.stderr')).open('wb')as stderr:p=subprocess.run(argv,stdout=stdout,stderr=stderr,env=os.environ|env)
 record['exit_code']=p.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert p.returncode==0
 for d in(r/('native-'+phase)/model).iterdir():assert len(json.loads((d/'results.json').read_text()))==n
 print(phase,model,'fresh controls terminal success',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,[(phase,model)for phase in ['before','after']for model in ['30','50','100']]))
print('all fresh F native control processes terminal success',flush=True)
