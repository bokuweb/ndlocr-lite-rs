from pathlib import Path
import hashlib,json,math
r=Path('tmp/punct-f-api');changes=[];count=0;shape=0
for mode in ['runtime30_eval','runtime30_default','runtime50_eval','runtime50_default','runtime100_eval','runtime100_default']:
 before=r/'page-before'/mode/'results.json';after=r/'page-after'/('primary50'if mode.startswith('runtime50')else'after')/mode/'results.json'
 b={x['id']:x for x in json.loads(before.read_text())};a={x['id']:x for x in json.loads(after.read_text())};assert len(b)==len(a)==287 and set(b)==set(a)
 for id,x in b.items():
  y=a[id];count+=1;assert len(x['lines'])==len(y['lines'])
  assert x.get('context_attempts')==y.get('context_attempts')
  for xx,yy in zip(x['lines'],y['lines']):
   assert xx['bbox']==yy['bbox'];shape+=1
   assert math.isfinite(yy['confidence'])and 0<=yy['confidence']<=1
  if x!=y:
   assert mode in ['runtime30_eval','runtime30_default']and id=='dense_observations_maru24_half'
   assert x['text'].replace('、 ', '、')==y['text']and x['text']!=y['text']
   changes.append({'mode':mode,'id':id,'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(after.read_bytes()).hexdigest()})
assert len(changes)==2
cli_unchanged=0
for mode in ['deim','bands']:
 for p in(r/'page-before'/mode).glob('*.txt'):
  assert p.read_bytes()==(r/'cli-after'/mode/p.name).read_bytes();cli_unchanged+=1
assert cli_unchanged==574
(r/'page-structure-audit.json').write_text(json.dumps({'api_pairs':count,'line_bboxes_unchanged':shape,'only_two_text_and_confidence_changes':changes,'cli_body_pairs_byte_equal':cli_unchanged},indent=2)+'\n')
print(count,'API pairs: all line counts/bboxes unchanged;2 expected changes;',cli_unchanged,'CLI bodies unchanged',flush=True)
