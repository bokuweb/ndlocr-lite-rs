from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/punct-integration');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={};dirs=[];bodies={}
for phase in ['before','after']:
 for model in ['30','50','100']:
  assert json.loads((r/(phase+'-native'+model+'-command.json')).read_text())['exit_code']==0
  for directory in(r/('native-'+phase)/model).iterdir():
   records=json.loads((directory/'results.json').read_text());assert len(records)==1358;key=str(directory.relative_to(r));dirs.append(key);files[key+'/results.json']=(directory/'results.json').read_bytes()
   for x in records:
    b=(directory/(x['id']+'.txt')).read_bytes();assert b==x['text'].encode();bodies[key+'/'+x['id']+'.txt']=sha(b)
for directory in ['native-scores','D-fixtures']:
 for p in(r/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for phase in ['before','after']:
 for p in(r/(phase+'-src')).rglob('*'):
  if p.is_file():files['source/'+phase+'/'+str(p.relative_to(r/(phase+'-src')))]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and(p.name.startswith(('before-native','after-native','helper-','native-','whole-roi-'))or p.name in ['native-capture-command.json','freeze_native.py','run_native.py','score_matrix.py','native-audit.json','native-score-command.json','native-scoring.log','capture-spec.md','final-refactor.patch','refactor-source.json','refactor-tests.log','refactor-with-cascade-tests.log','condensed-space-red.log']):
  if p.suffix in ['.json','.jsonl','.py','.log','.md','.stdout','.stderr','.patch']:files[p.name]=p.read_bytes()
files['materialize.json']=(json.dumps({'hypothesis':'D, rejected on later aspect controls','record_directories':dirs,'actual_body_sha256':bodies},indent=2)+'\n').encode();files['package_native.py']=Path(__file__).read_bytes();path=out/'native.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for k,b in sorted(files.items()):
  info=zipfile.ZipInfo(k,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
(out/'native.json').write_text(json.dumps({'hypothesis':'D (rejected)','sha256':sha(path.read_bytes()),'member_count':len(files),'members':{k:sha(b)for k,b in sorted(files.items())}},indent=2)+'\n');print('D native evidence',len(files),path.stat().st_size)
