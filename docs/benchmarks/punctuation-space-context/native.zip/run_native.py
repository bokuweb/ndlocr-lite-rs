from pathlib import Path
import json,hashlib,os,subprocess,concurrent.futures
r=Path('tmp/punct-integration');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'native-capture-command.json').read_text());assert sha(__file__)==meta['driver_sha256']
for p,h in meta['models'].items():assert sha(p)==h
models={m:next(p for p in meta['models']if '-'+m+'-tiny-'in p)for m in ['30','50','100']}
for phase in ['before','after']:
 assert sha(r/(phase+'-native-binary'))==meta[phase]['binary_sha256'];(r/('native-'+phase)).mkdir(exist_ok=False)
def run(job):
 phase,model=job;out=r/('native-'+phase)/model;env={'NDLOCR_TEST_PARSEQ_MODEL':models[model],'NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_INTRA_THREADS':'1','NDLOCR_LINE_MATRIX_MANIFEST':'tmp/punctuation-space-components/evaluation-manifest.json','NDLOCR_LINE_MATRIX_OUTPUT':str(out)};argv=[str((r/(phase+'-native-binary')).resolve()),'infer::cached::punctuation_context_capture::capture_line_matrix','--exact','--ignored','--nocapture'];cmd=r/(phase+'-native'+model+'-command.json');record={'argv':argv,'env':env};cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(phase+'-native'+model+'.stdout')).open('wb')as stdout,(r/(phase+'-native'+model+'.stderr')).open('wb')as stderr:p=subprocess.run(argv,stdout=stdout,stderr=stderr,env=os.environ|env)
 record['exit_code']=p.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert p.returncode==0,(phase,model)
 for d in out.iterdir():assert len(json.loads((d/'results.json').read_text()))==1358
 print(phase,model,'terminal success',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,[(phase,model)for phase in ['before','after']for model in ['30','50','100']]))
print('all six native captures terminal success',flush=True)
