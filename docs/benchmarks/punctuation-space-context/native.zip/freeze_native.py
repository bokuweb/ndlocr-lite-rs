from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/punct-integration');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta={}
for phase in ['before','after']:
 root=r/(phase+'-src');source=json.loads((r/(phase+'-source.json')).read_text())
 for p,h in source['sha256'].items():assert sha(root/p)==h,p
 artifacts=[x for l in(r/(phase+'-build.jsonl')).read_text().splitlines()if(x:=json.loads(l)).get('reason')=='compiler-artifact'and x.get('executable')];assert len(artifacts)==1
 binary=r/(phase+'-native-binary');shutil.copy2(artifacts[0]['executable'],binary);meta[phase]={'binary_sha256':sha(binary),'source':source}
assert meta['before']['binary_sha256']!=meta['after']['binary_sha256']
manifest=Path('tmp/punctuation-space-components/evaluation-manifest.json');m=json.loads(manifest.read_text())
meta['manifest_sha256']=sha(manifest);meta['inputs']={}
for x in m['inputs']:
 for k in ['image','rgb','truth']:assert sha(x[k])==x[k+'_sha256']
 meta['inputs'][x['id']]={k+'_sha256':x[k+'_sha256']for k in ['image','rgb','truth']}
meta['models']={p:sha(p)for p in ['models/NDLmoji.yaml','models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','models/parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx','models/parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx']};meta['freeze_sha256']=sha(__file__);meta['driver_sha256']=sha(r/'run_native.py');(r/'native-capture-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('native before/after source/binaries/assets frozen',flush=True)
