use super::*;

fn assets() -> Option<(std::path::PathBuf, std::path::PathBuf)> {
    Some((
        std::env::var_os("NDLOCR_TEST_PARSEQ_MODEL")?.into(),
        std::env::var_os("NDLOCR_TEST_CHARSET")?.into(),
    ))
}

fn images() -> (crate::io::RgbImageData, crate::io::RgbImageData) {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/punctuation_context");
    (
        crate::io::load_rgb_u8(&root.join("joined30.png")).unwrap(),
        crate::io::load_rgb_u8(&root.join("real_space30.png")).unwrap(),
    )
}

#[test]
#[ignore = "requires fixed PARSeq 30 assets"]
fn session_recovers_punctuation_context_without_reloading_and_preserves_raw() {
    let Some((model, charset)) = assets() else {
        return;
    };
    let (image, negative) = images();
    let temp = tempfile::tempdir().unwrap();
    let m = temp.path().join("model.onnx");
    let c = temp.path().join("chars.yaml");
    std::fs::copy(model, &m).unwrap();
    std::fs::copy(charset, &c).unwrap();
    let session = ParseqSession::load(&m, &c).unwrap();
    assert_eq!(session.input_dimensions(), (256, 24));
    std::fs::remove_file(m).unwrap();
    std::fs::remove_file(c).unwrap();
    let raw = session
        .recognize_rgb_u8_unprocessed(&image.data, image.width, image.height)
        .unwrap();
    assert_eq!(raw.text, "受付番地、 通知先");
    let candidates = session
        .recognize_rgb_u8_candidates_with_orientation(
            &image.data,
            image.width,
            image.height,
            ParseqOrientation::Auto,
            2,
        )
        .unwrap();
    assert_eq!(candidates.recognition.text, raw.text);
    assert!(session.recognize_rgb_u8(&[], 0, 0).is_err());
    let got = session
        .recognize_rgb_u8(&image.data, image.width, image.height)
        .unwrap();
    assert_eq!(got.text, "受付番地、通知先");
    assert!(got.mean_confidence > raw.mean_confidence);
    let again = session
        .recognize_rgb_u8_unprocessed(&image.data, image.width, image.height)
        .unwrap();
    assert_eq!(again.text, raw.text);
    assert_eq!(again.mean_confidence, raw.mean_confidence);
    let after = session
        .recognize_rgb_u8_candidates_with_orientation(
            &image.data,
            image.width,
            image.height,
            ParseqOrientation::Auto,
            2,
        )
        .unwrap();
    assert_eq!(candidates.recognition.text, after.recognition.text);
    assert_eq!(
        candidates.recognition.mean_confidence,
        after.recognition.mean_confidence
    );
    assert_eq!(candidates.steps, after.steps);
    assert_eq!(candidates.stop_reason, after.stop_reason);
    let raw_negative = session
        .recognize_rgb_u8_unprocessed(&negative.data, negative.width, negative.height)
        .unwrap();
    let got_negative = session
        .recognize_rgb_u8(&negative.data, negative.width, negative.height)
        .unwrap();
    assert_eq!(got_negative.text, "受付番地、 通知先");
    assert_eq!(got_negative.mean_confidence, raw_negative.mean_confidence);
}

#[test]
#[ignore = "requires fixed PARSeq 30 assets"]
fn session_batch_and_both_pool_policies_recover_the_same_candidate() {
    let Some((model, charset)) = assets() else {
        return;
    };
    let (image, negative) = images();
    let items = [
        (&image.data[..], image.width, image.height),
        (&negative.data[..], negative.width, negative.height),
    ];
    let verify = |out: Vec<RecognizeResult>| {
        assert_eq!(out.len(), 2);
        assert_eq!(out[0].text, "受付番地、通知先");
        assert_eq!(out[1].text, "受付番地、 通知先");
    };
    let session = ParseqSession::load(&model, &charset).unwrap();
    verify(session.recognize_batch_rgb_u8(&items).unwrap());
    for fragment in [false, true] {
        let pool = if fragment {
            ParseqPool::load_for_fragments(&model, &charset, 2)
        } else {
            ParseqPool::load(&model, &charset, 2)
        }
        .unwrap();
        assert!(pool.recognize_rgb_u8(&[], 0, 0).is_err());
        assert_eq!(
            pool.recognize_rgb_u8(&image.data, image.width, image.height)
                .unwrap()
                .text,
            "受付番地、通知先"
        );
        verify(pool.recognize_batch_single_session_rgb_u8(&items).unwrap());
        verify(pool.recognize_batch_rgb_u8(&items).unwrap());
        verify(
            pool.recognize_batch_single_session_horizontal_rgb_u8(&items)
                .unwrap(),
        );
    }
}

#[test]
#[ignore = "requires fixed PARSeq 30 assets"]
fn standalone_recovers_context_and_leaves_unprocessed_output_unchanged() {
    let Some((model, charset)) = assets() else {
        return;
    };
    let (image, negative) = images();
    let raw = super::super::parseq::recognize_rgb_u8_with_score_unprocessed(
        &model,
        &image.data,
        image.width,
        image.height,
        &charset,
    )
    .unwrap();
    assert_eq!(raw.text, "受付番地、 通知先");
    let got = super::super::parseq::recognize_rgb_u8_with_score(
        &model,
        &image.data,
        image.width,
        image.height,
        &charset,
    )
    .unwrap();
    assert_eq!(got.text, "受付番地、通知先");
    assert!(got.mean_confidence > raw.mean_confidence);
    assert_eq!(
        super::super::parseq::recognize_rgb_u8_with_score(
            &model,
            &negative.data,
            negative.width,
            negative.height,
            &charset
        )
        .unwrap()
        .text,
        "受付番地、 通知先"
    );
}
