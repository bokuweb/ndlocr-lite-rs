# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1358`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 1358 | 0 | 0.1670 | 0.7342 |
| before | 1358 | 0 | 0.1709 | 0.7628 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
