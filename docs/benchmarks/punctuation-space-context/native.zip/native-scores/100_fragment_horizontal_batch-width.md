# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1358`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 1358 | 0 | 0.1152 | 0.5223 |
| before | 1358 | 0 | 0.1190 | 0.5416 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
