# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1358`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 1358 | 0 | 0.1889 | 0.7675 |
| after | 1358 | 0 | 0.1889 | 0.7675 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
