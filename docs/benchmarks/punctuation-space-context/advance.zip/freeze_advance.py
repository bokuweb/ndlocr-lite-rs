from pathlib import Path
import json,hashlib,shutil,subprocess,os
r=Path('tmp/punct-width');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=[x for l in(r/'advance-build.jsonl').read_text().splitlines()if(x:=json.loads(l)).get('reason')=='compiler-artifact'and x.get('executable')];assert len(a)==1;shutil.copy2(a[0]['executable'],r/'advance-binary');paths=list(Path('src').rglob('*.rs'))+[Path(p)for p in ['tests/support/punctuation_space_advance.rs','tests/support/punctuation_space_width.rs','tests/support/punctuation_space_components.rs','tests/support/ink_height_space.rs','Cargo.toml','Cargo.lock','docs/punctuation_space_advance_support.md']];source={}
for p in paths:
 dst=r/'advance-source'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);source[str(p)]=sha(p)
meta={'binary_sha256':sha(r/'advance-binary'),'sha256':source,'manifest_sha256':sha(r/'evaluation-manifest.json'),'spec_sha256':sha('docs/punctuation_space_advance_support.md'),'command':[str(r/'advance-binary'),'infer::punctuation_space_advance_tests::record_punctuation_space_advance_geometry','--exact','--ignored','--nocapture'],'env':{'NDLOCR_ADVANCE_SPACE_ROOT':str(r)}};(r/'advance-command.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copy2('docs/punctuation_space_advance_support.md',r/'capture-spec-advance.md');p=subprocess.run(meta['command'],capture_output=True,env=os.environ|meta['env']);(r/'advance-capture.stdout').write_bytes(p.stdout);(r/'advance-capture.stderr').write_bytes(p.stderr);assert p.returncode==0
old={x['id']:x for x in json.loads((r/'geometry.json').read_text())};new=json.loads((r/'geometry-advance.json').read_text());assert len(old)==len(new)==3446
for x in new:
 g=old[x['id']];assert x['body_height']==g['body_height']and x['max_blank_gap']==g['max_blank_gap'];assert not any(x['support_by_length'].values())or g['supported']
print('F frozen,3446 images measured',meta['binary_sha256'],flush=True)
