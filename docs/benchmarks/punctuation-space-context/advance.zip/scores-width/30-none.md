# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `3446`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| width_support | 3446 | 0 | 0.1317 | 0.7038 |
| raw | 3446 | 0 | 0.1329 | 0.7130 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
