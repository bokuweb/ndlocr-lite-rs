# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `3446`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| width_support | 3446 | 0 | 0.1023 | 0.5874 |
| raw | 3446 | 0 | 0.1035 | 0.5963 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
