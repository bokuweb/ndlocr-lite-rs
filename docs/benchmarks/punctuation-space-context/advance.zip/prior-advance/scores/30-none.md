# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2294`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| advance_support | 2294 | 0 | 0.1476 | 0.7219 |
| raw | 2294 | 0 | 0.1497 | 0.7372 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
