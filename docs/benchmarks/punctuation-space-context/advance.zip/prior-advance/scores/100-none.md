# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2294`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| advance_support | 2294 | 0 | 0.1034 | 0.5505 |
| raw | 2294 | 0 | 0.1060 | 0.5668 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
