# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `3446`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| raw | 3446 | 0 | 0.0388 | 0.0534 |
| advance_support | 3446 | 0 | 0.0388 | 0.0534 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
