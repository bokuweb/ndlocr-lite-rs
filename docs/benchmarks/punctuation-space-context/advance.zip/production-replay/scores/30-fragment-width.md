# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `3446`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 3446 | 0 | 0.1244 | 0.6996 |
| before | 3446 | 0 | 0.1259 | 0.7112 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
