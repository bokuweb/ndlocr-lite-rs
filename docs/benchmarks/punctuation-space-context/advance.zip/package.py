from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/punct-width');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={};m=json.loads((r/'evaluation-manifest.json').read_text())
for x in m['inputs']:
 if x['cohort']!='new_control':continue
 for k in ['image','rgb','truth']:
  p=Path(x[k]);b=p.read_bytes();assert sha(b)==x[k+'_sha256'];files[str(p.relative_to(r))]=b
for directory in ['new/data','geometry-source','advance-source','whole-roi-source','production-source']:
 for p in(r/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for p in(r/'new').iterdir():
 if p.is_file()and p.suffix in ['.json','.stdout','.stderr']:files[str(p.relative_to(r))]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.py','.md','.log','.stdout','.stderr','.txt']:files[p.name]=p.read_bytes()
for directory in ['scores-width','scores-advance','production-replay/scores']:
 for p in(r/directory).iterdir():files[str(p.relative_to(r))]=p.read_bytes()
for name in ['production-replay/records.json','production-replay/audit.json','new/whole-rgb-capture/inputs.json']:files[name]=(r/name).read_bytes()
for directory in ['prior','prior-advance']:
 for p in(r/directory).rglob('*'):
  if p.is_file()and not any(x in p.relative_to(r/directory).parts for x in ['predictions','corpus','truth']):files[str(p.relative_to(r))]=p.read_bytes()
fixture=Path('tests/fixtures/line_segment/jma-notice-body.png');files['production-source/'+str(fixture)]=fixture.read_bytes()
files['source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes();logical=len(files);seen={};unique={};aliases={}
for k,b in sorted(files.items()):
 h=sha(b)
 if h in seen:aliases[k]={'source':seen[h],'sha256':h}
 else:unique[k]=b;seen[h]=k
unique['aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode();path=out/'advance.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for k,b in sorted(unique.items()):
  info=zipfile.ZipInfo(k,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
(out/'advance.json').write_text(json.dumps({'hypotheses':['E','F'],'sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':logical,'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n');print('E/F evidence',len(unique),logical,path.stat().st_size,flush=True)
