import math,unittest
from matched import matched_gain
class MatchedGain(unittest.TestCase):
 def test_overall_gain_from_omitting_a_weak_space_does_not_suffice(self):
  self.assertFalse(matched_gain(.9994,[.999,.9991,.9992]))
 def test_all_three_candidates_must_improve_the_same_body(self):
  self.assertTrue(matched_gain(.995,[.999,.998,.997]))
  for values in [[.999,.995,.999],[.999,.994,.999]]:self.assertFalse(matched_gain(.995,values))
 def test_missing_or_invalid_means_do_not_support_selection(self):
  for body in [None,math.nan,math.inf,-.01,1.01]:self.assertFalse(matched_gain(body,[.999]*3))
  for values in [[],[.999],[.999]*4,[math.nan,.999,.999],[1.01,.999,.999]]:self.assertFalse(matched_gain(.99,values))
if __name__=='__main__':unittest.main()
