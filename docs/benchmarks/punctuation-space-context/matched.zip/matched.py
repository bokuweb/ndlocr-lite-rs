import math
def matched_gain(original_body_mean,candidate_means):
 return original_body_mean is not None and math.isfinite(original_body_mean)and 0<=original_body_mean<=1 and len(candidate_means)==3 and all(math.isfinite(x)and 0<=x<=1 and x>original_body_mean for x in candidate_means)
