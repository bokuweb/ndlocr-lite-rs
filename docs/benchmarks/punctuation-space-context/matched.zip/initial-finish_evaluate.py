from pathlib import Path
import hashlib,json,subprocess,sys,os
r=Path('tmp/punct-matched');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'evaluate-command.json').read_text())
for p,h in meta['source_sha256'].items():assert sha(p)==h,p
for label in ['base','new']:
 for model in ['30','50','100']:assert json.loads((r/label/(model+'-command.json')).read_text())['exit_code']==0
for name in ['verify_capture','assemble','evaluate']:
 argv=[sys.executable,str(r/(name+'.py'))];record={'argv':argv,'env':{'PYTHONUTF8':'1'},'driver_sha256':sha(__file__)};p=r/(name+'-command.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as out,(r/(name+'.stderr')).open('wb')as err:done=subprocess.run(argv,stdout=out,stderr=err,env=os.environ|record['env'])
 record['exit_code']=done.returncode;p.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name
 print(name,'terminal0',flush=True)
print('G all diagnostic evaluation processes terminal0',flush=True)
