from pathlib import Path
from PIL import Image
import hashlib,json
r=Path('tmp/punct-matched');sha=lambda b:hashlib.sha256(b).hexdigest();proof={'model_roi_counts':[],'captured_rgb':[]}
for label,count in [('base',4022),('new',2304)]:
 root=r/label;m=json.loads((root/'data/evaluation-manifest.json').read_text());variants={x['id']:x for x in m['variants']};assert len(variants)==count
 for model in ['30','50','100']:
  command=json.loads((root/(model+'-command.json')).read_text());assert command['exit_code']==0 and '--whole-roi'in command['argv'];rows=json.loads((root/(model+'-export.json')).read_text());assert len(rows)==count and {x['id']for x in rows}==set(variants)
  assert all(len(x['chunks'])==1 and x['chunks'][0]['x_range']==[0,variants[x['id']]['dimensions'][0]]for x in rows)
  proof['model_roi_counts'].append({'dataset':label,'model':model,'whole_roi_count':count})
 capture=root/'whole-rgb-capture';data=json.loads((capture/'inputs.json').read_text());assert len(data['chunks'])==count and data['model_input_dimensions']==[256,24]
 assert {x['line_id']for x in data['chunks']}==set(variants)
 for x in data['chunks']:
  p=capture/x['image'];im=Image.open(p).convert('RGB');v=variants[x['line_id']]
  assert x['chunk_index']==0 and x['dimensions']==list(im.size)==v['dimensions']and x['x_range']==[0,im.width]
  assert sha(im.tobytes())==v['rgb_sha256'];proof['captured_rgb'].append({'dataset':label,'id':x['line_id'],'png_sha256':sha(p.read_bytes()),'rgb_sha256':sha(im.tobytes())})
assert len(proof['captured_rgb'])==6326
proof['driver_sha256']=sha(Path(__file__).read_bytes());(r/'actual-input-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('all18978 whole forwards and6326 actual forward RGBs verified',flush=True)
