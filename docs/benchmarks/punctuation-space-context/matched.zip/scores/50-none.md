# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `4598`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| matched_support | 4598 | 0 | 0.1394 | 0.7835 |
| raw | 4598 | 0 | 0.1396 | 0.7837 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
