# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `4598`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| raw | 4598 | 0 | 0.0400 | 0.0413 |
| matched_support | 4598 | 0 | 0.0400 | 0.0413 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
