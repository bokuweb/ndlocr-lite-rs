from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/punct-matched');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for x in json.loads((r/'new/data/evaluation-manifest.json').read_text())['inputs']:
 for key in ['image','rgb','truth']:
  p=Path(x[key]);b=p.read_bytes();assert sha(b)==x[key+'_sha256'];files[str(p.relative_to(r))]=b
for folder in ['new/data','base/data','geometry-source','whole-roi-source','scores']:
 for p in(r/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for label in ['base','new']:
 for p in(r/label).iterdir():
  if p.is_file()and p.suffix in ['.json','.stdout','.stderr']:files[str(p.relative_to(r))]=p.read_bytes()
 files[label+'/whole-rgb-capture/inputs.json']=(r/label/'whole-rgb-capture/inputs.json').read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.py','.swift','.md','.log','.stdout','.stderr']and p.name!='STATE.md':files[p.name]=p.read_bytes()
files['contact.png']=(r/'contact.png').read_bytes();files['source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes();files['spec-results.md']=Path('docs/punctuation_space_matched_confidence.md').read_bytes()
seen={};unique={};aliases={}
for key,b in sorted(files.items()):
 h=sha(b)
 if h in seen:aliases[key]={'source':seen[h],'sha256':h}
 else:unique[key]=b;seen[h]=key
unique['aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode();path=out/'matched.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for key,b in sorted(unique.items()):
  info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
(out/'matched.json').write_text(json.dumps({'hypothesis':'G rejected; diagnostic only','sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':len(files),'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n');print('G matched packet',len(unique),len(files),path.stat().st_size,flush=True)
