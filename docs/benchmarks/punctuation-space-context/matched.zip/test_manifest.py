from pathlib import Path
from PIL import Image
import hashlib,itertools,json,unittest

class FixedManifest(unittest.TestCase):
 def test_all_pre_registered_cases_and_rgb_variants_are_present(self):
  r=Path('tmp/punct-matched');m=json.loads((r/'new/data/evaluation-manifest.json').read_text())
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[18,30],[0,1],[0,1,2],[60,90],[0,10],['png','jpeg75']))
  self.assertEqual(len(m['inputs']),576)
  self.assertEqual({(x['text_id'],x['font'],x['size'],x['palt'],x['spaces'],x['horizontal_percent'],x['paper'],x['format'])for x in m['inputs']},expected)
  sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
  byid={x['id']:x for x in m['inputs']}
  for x in m['inputs']:
   for key in ['image','rgb','truth','original']:self.assertEqual(sha(x[key]),x[key+'_sha256'])
   im=Image.open(x['image']).convert('RGB');self.assertEqual(im.size,(x['width'],x['height']));self.assertEqual(im.tobytes(),Path(x['rgb']).read_bytes())
   left,punct,right=[('作業内容','、','確認先'),('実施日時','。','連絡窓口')][x['text_id']]
   self.assertEqual(Path(x['truth']).read_text(),left+punct+' '*x['spaces']+right)
  self.assertEqual(len(m['variants']),2304)
  atlas=Image.open(r/'new/data/atlas.png').convert('RGB')
  for v in m['variants']:
   x=byid[v['base_id']];im=Image.open(x['image']).convert('RGB');xp=0 if v['variant']=='base'else 2;yp={'base':0,'x2y0':0,'x2y1':1,'x2y2':2}[v['variant']]
   expected_image=Image.new('RGB',(im.width+2*xp,im.height+2*yp),'white');expected_image.paste(im,(xp,yp));actual=atlas.crop(v['bounds'])
   self.assertEqual(actual.tobytes(),expected_image.tobytes());self.assertEqual(hashlib.sha256(actual.tobytes()).hexdigest(),v['rgb_sha256'])

if __name__=='__main__':unittest.main()
