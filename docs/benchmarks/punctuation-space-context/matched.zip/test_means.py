import struct,unittest
from means import emitted_means
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def row(chars,probabilities,stop=None):
 text=''.join(chars);cursor=0;steps=[]
 for ch,p in zip(chars,probabilities):
  end=cursor+len(ch.encode());steps.append({'byte_range':[cursor,end],'candidates':[{'character':ch,'probability':f32(p)}]});cursor=end
 steps.append({'byte_range':None,'candidates':[{'character':stop,'probability':.999}]})
 return {'text':text,'chunks':[{'text':text,'inserted_space_before':False,'steps':steps}]}
class EmittedMeans(unittest.TestCase):
 def test_only_actual_ascii_spaces_are_omitted_from_the_comparison(self):
  for stop in [None,'丙']:
   # Each emitted addition rounds to binary32; a double-precision sum gives the adjacent lower bit.
   full,body=emitted_means(row(['甲',' ','乙'],[.8,.1,1],stop));self.assertEqual(full,struct.unpack('<f',struct.pack('<I',0x3f222223))[0]);self.assertEqual(body,f32(f32(f32(.8)+1)/2))
  full,body=emitted_means(row(['甲','　','乙'],[.8,.1,1]));self.assertEqual(full,body)
 def test_empty_and_space_only_outputs_have_no_body_mean(self):
  self.assertEqual(emitted_means(row([],[])),(0,None));self.assertEqual(emitted_means(row([' '],[.2])),(f32(.2),None))
 def test_broken_mapping_and_split_regions_are_rejected(self):
  x=row(['甲'],[.9]);x['chunks'][0]['steps'][0]['byte_range']=[0,1]
  with self.assertRaises(AssertionError):emitted_means(x)
  x=row(['甲'],[.9]);x['chunks']*=2
  with self.assertRaises(AssertionError):emitted_means(x)
if __name__=='__main__':unittest.main()
