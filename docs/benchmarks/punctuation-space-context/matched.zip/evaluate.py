from pathlib import Path
import json,math,sys,csv,subprocess
from matched import matched_gain
r=Path(sys.argv[1]if len(sys.argv)>1 else'tmp/punct-matched');m=json.loads((r/'evaluation-manifest.json').read_text());images={x['id']:x for x in m['inputs']};assert len(images)==4598
geometry={x['id']:x for x in json.loads((r/'geometry-advance.json').read_text())};native=json.loads((r/'native-rows.json').read_text());assert len(native)==13794
frozen_f={(x['id'],x['model']):x['selected']for x in json.loads((r/'frozen-f-selection.json').read_text())};assert len(frozen_f)==12066
def japanese(c):
 return c in '、。'or any(lo<=ord(c)<=hi for lo,hi in [(0x3040,0x30ff),(0x3400,0x4dbf),(0x4e00,0x9fff),(0xf900,0xfaff)])
decisions=[]
for row in native:
 id=row['id'];text=row['base']['text'];base=row['base']['mean_confidence'];alts=row['candidates'];nonspace=text.replace(' ','');im=images[id];n=len(nonspace);g=geometry[id];left,sep,right=text.partition(' ')
 checks={'single_internal_space':text.count(' ')==1 and not text.startswith(' ')and not text.endswith(' '),'japanese_only':all(japanese(c)for c in nonspace),'length6to12':6<=n<=12,'consensus':all(x['text']==nonspace for x in alts),'confidences':all(math.isfinite(x['mean_confidence'])and .98<=x['mean_confidence']<=1 for x in alts),'strict_gain':alts[0]['mean_confidence']>base,'punctuation_boundary':bool(sep)and left[-1:]in ['、','。']and bool(right)and right[0]not in '、。 'and japanese(right[0]),'finite_base':math.isfinite(base)and 0<=base<=1,'horizontal_auto':5*im['height']<=4*im['width'],'native_capacity':(im['width']+4)*24<=im['height']*{'30':256,'50':384,'100':768}[row['model']],'geometry':g['support_by_length'].get(str(n),False)}
 f_eligible=all(checks.values())
 if(id,row['model'])in frozen_f:assert f_eligible==frozen_f[id,row['model']],(id,row['model'],'F predicate changed')
 checks['matched_body_gain']=matched_gain(row['nonspace_mean_confidence'],[x['mean_confidence']for x in alts]);selected=all(checks.values());assert not selected or f_eligible
 decisions.append({'id':id,'model':row['model'],'checks':checks,'f_eligible':f_eligible,'selected':selected})
 for label,pred in [('raw',text),('matched_support',alts[0]['text']if selected else text)]:
  p=r/'predictions'/row['model']/label/(id+'.txt');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(pred.encode())
(r/'decisions.json').write_text(json.dumps(decisions,indent=2)+'\n');scores=r/'scores';scores.mkdir(exist_ok=True);scorer=Path(sys.argv[2]if len(sys.argv)>2 else'tools/eval_ocr_metrics.py');audit={'images':4598,'native_pairs':13794,'comparisons_per_metric':41382,'changes':[],'char_regressions':[],'word_regressions':[],'summary':[]}
for model in ['30','50','100']:
 for norm in ['none','width','strict']:
  table=scores/(model+'-'+norm+'.csv');report=table.with_suffix('.md');subprocess.run([sys.executable,str(scorer),'--truth-dir',str(r/'corpus/truth'),'--system','raw='+str(r/'predictions'/model/'raw'),'--system','matched_support='+str(r/'predictions'/model/'matched_support'),'--normalize',norm,'--require-all','--output-csv',str(table),'--output-md',str(report)],capture_output=True,check=True);table.write_bytes(table.read_bytes().replace(b'\r\n',b'\n'));report.write_bytes((report.read_text().rstrip()+'\n').encode());rows=list(csv.DictReader(table.open()));before={x['file']:x for x in rows if x['system']=='raw'};after={x['file']:x for x in rows if x['system']=='matched_support'};assert len(before)==len(after)==4598;stat={'model':model,'normalization':norm,'images':4598,'char_improvements':0,'word_improvements':0,'exact_improvements':0,'changes':0}
  for id in before:
   bc,ac=int(before[id]['char_errors']),int(after[id]['char_errors']);bw,aw=int(before[id]['word_errors']),int(after[id]['word_errors']);changed=(r/'predictions'/model/'raw'/id).read_bytes()!=(r/'predictions'/model/'matched_support'/id).read_bytes();stat['char_improvements']+=ac<bc;stat['word_improvements']+=aw<bw;stat['exact_improvements']+=bc>0 and ac==0;stat['changes']+=changed
   if changed:audit['changes'].append([model,norm,id,bc,ac,bw,aw])
   if ac>bc:audit['char_regressions'].append([model,norm,id,bc,ac])
   if aw>bw:audit['word_regressions'].append([model,norm,id,bw,aw])
  audit['summary'].append(stat)
(r/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print('G41382 comparisons; regressions',len(audit['char_regressions']),len(audit['word_regressions']),flush=True)
