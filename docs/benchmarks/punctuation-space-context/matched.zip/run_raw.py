from pathlib import Path
import json,hashlib,subprocess,os,concurrent.futures
r=Path('tmp/punct-matched');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();binary=r/'raw-binary';source=json.loads((r/'parent-raw-capture.json').read_text());assert sha(binary)==source['binary_sha256']
for p,h in source['models'].items():assert sha(p)==h
datasets={}
for label,count in [('base',4022),('new',2304)]:
 root=r/label/'data';m=json.loads((root/'evaluation-manifest.json').read_text());assert len(m['variants'])==count
 assert sha(root/'atlas.png')==m['atlas_sha256']and sha(root/'lines.json')==m['lines_sha256']
 datasets[label]={'roi_count':count,'manifest_sha256':sha(root/'evaluation-manifest.json'),'atlas_sha256':sha(root/'atlas.png'),'lines_sha256':sha(root/'lines.json')}
meta={'scope':'old4022 original ROIs plus new576*4 ROIs;G fixed before nonspace mean analysis','source':source,'driver_sha256':sha(__file__),'datasets':datasets,'geometry':json.loads((r/'geometry-command.json').read_text()),'spec_sha256':sha(r/'capture-spec.md')};(r/'raw-command.json').write_text(json.dumps(meta,indent=2)+'\n')
models={'30':'parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','50':'parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx','100':'parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx'}
def run(model):
 for label,spec in datasets.items():
  root=r/label;data=root/'data';out=root/(model+'-export.json');argv=[str(binary.resolve()),'--image',str(data/'atlas.png'),'--model','models/'+models[model],'--charset','models/NDLmoji.yaml','--manifest',str(data/'lines.json'),'--output',str(out),'--top-k','2','--whole-roi']
  if model=='30':argv+=['--chunk-input-dir',str(root/'whole-rgb-capture')]
  record={'argv':argv,'env':{'NDLOCR_INTRA_THREADS':'1'}};command=root/(model+'-command.json');assert not command.exists();command.write_text(json.dumps(record,indent=2)+'\n')
  with(root/(model+'.stdout')).open('wb')as stdout,(root/(model+'.stderr')).open('wb')as stderr:done=subprocess.run(argv,stdout=stdout,stderr=stderr,env=os.environ|record['env'])
  record['exit_code']=done.returncode;command.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0
  rows=json.loads(out.read_text());assert len(rows)==spec['roi_count']and all(len(x['chunks'])==1 for x in rows)
  print(model,label,spec['roi_count'],'whole ROIs terminal0',flush=True)
 return model
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,models))
print('all18978 forwards terminal0',flush=True)
