from pathlib import Path
from PIL import Image
import hashlib,json,unittest
class BaseAtlas(unittest.TestCase):
 def test_every_existing_base_is_one_exact_rgb_roi(self):
  r=Path('tmp/punct-matched/base/data');m=json.loads((r/'evaluation-manifest.json').read_text());original=json.loads(Path('tmp/punct-proportional/evaluation-manifest.json').read_text());byid={x['id']:x for x in original['inputs']};self.assertEqual(len(m['variants']),4022);self.assertEqual({x['base_id']for x in m['variants']},set(byid));atlas=Image.open(r/'atlas.png').convert('RGB')
  for v in m['variants']:
   x=byid[v['base_id']];tile=atlas.crop(v['bounds']);self.assertEqual(tile.size,(x['width'],x['height']));self.assertEqual(hashlib.sha256(tile.tobytes()).hexdigest(),x['rgb_sha256'])
if __name__=='__main__':unittest.main()
