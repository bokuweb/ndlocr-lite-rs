from pathlib import Path
import json,struct,hashlib
from means import emitted_means
r=Path('tmp/punct-matched');f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
old=json.loads((r/'frozen-native.json').read_text());assert len(old)==12066
bykey={(x['id'],x['model']):x for x in old};base_means={};new_reads={}
for model in ['30','50','100']:
 for label,count in [('base',4022),('new',2304)]:
  assert json.loads((r/label/(model+'-command.json')).read_text())['exit_code']==0
  rows=json.loads((r/label/(model+'-export.json')).read_text());assert len(rows)==count
  if label=='base':
   for x in rows:
    assert x['id'].endswith('_base');id=x['id'][:-5];full,body=emitted_means(x);before=bykey[id,model]['base']
    assert x['text']==before['text']and full==f32(before['mean_confidence']),(model,id,'original RR changed')
    assert(id,model)not in base_means;base_means[id,model]=body
  else:
   for x in rows:
    full,body=emitted_means(x);assert(x['id'],model)not in new_reads;new_reads[x['id'],model]=({'text':x['text'],'mean_confidence':full},body)
assert len(base_means)==12066 and len(new_reads)==6912
native=[{**x,'nonspace_mean_confidence':base_means[x['id'],x['model']]}for x in old]
fresh=json.loads((r/'new/data/evaluation-manifest.json').read_text())['inputs'];assert len(fresh)==576
for model in ['30','50','100']:
 for x in fresh:
  id=x['id'];base,body=new_reads[id+'_base',model];candidates=[new_reads[id+'_'+v,model][0]for v in ['x2y0','x2y1','x2y2']]
  native.append({'id':id,'model':model,'base':base,'nonspace_mean_confidence':body,'candidates':candidates})
assert len(native)==13794 and len({(x['id'],x['model'])for x in native})==13794
(r/'native-rows.json').write_text(json.dumps(native,ensure_ascii=False,indent=2)+'\n')
(r/'base-parity.json').write_text(json.dumps({'original_pairs':12066,'all_text_and_f32_original_means_bit_equal':True,'prior_native_sha256':hashlib.sha256((r/'frozen-native.json').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'emitted_mean_source_sha256':hashlib.sha256((r/'means.py').read_bytes()).hexdigest()},indent=2)+'\n')
print('all12066 old base RRs bit-equal;13794 native pairs assembled with nonspace means',flush=True)
