from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/punct-matched/base/data');r.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest();parent=Path('tmp/punct-proportional/evaluation-manifest.json');m=json.loads(parent.read_text());assert len(m['inputs'])==4022
variants=[];tiles=[];x=y=row_h=0;maxw=0
for row in m['inputs']:
 p=Path(row['image']);assert sha(p.read_bytes())==row['image_sha256'];tile=Image.open(p).convert('RGB');assert tile.size==(row['width'],row['height'])and sha(tile.tobytes())==row['rgb_sha256']
 if x and x+tile.width>4096:y+=row_h+4;x=0;row_h=0
 variants.append({'id':row['id']+'_base','base_id':row['id'],'variant':'base','bounds':[x,y,x+tile.width,y+tile.height],'dimensions':tile.size,'rgb_sha256':sha(tile.tobytes())});tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for v,t in zip(variants,tiles):atlas.paste(t,(v['bounds'][0],v['bounds'][1]))
atlas.save(r/'atlas.png');(r/'lines.json').write_text(json.dumps([{'id':v['id'],'bounds':v['bounds']}for v in variants],indent=2)+'\n')
(r/'evaluation-manifest.json').write_text(json.dumps({'variants':variants,'parent_manifest_sha256':sha(parent.read_bytes()),'generator_sha256':sha(Path(__file__).read_bytes()),'atlas_sha256':sha((r/'atlas.png').read_bytes()),'lines_sha256':sha((r/'lines.json').read_bytes())},indent=2)+'\n')
print('4022 original base ROIs fixed',atlas.size,flush=True)
