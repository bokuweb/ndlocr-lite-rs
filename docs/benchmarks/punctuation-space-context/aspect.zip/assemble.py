from pathlib import Path
import json,struct,sys
r=Path(sys.argv[1]if len(sys.argv)>1 else'tmp/punct-aspect')
m=json.loads((r/'evaluation-manifest.json').read_text())
geometry=json.loads((r/'geometry.json').read_text())
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def mean(chunk):
 values=[f32(s['candidates'][0]['probability'])for s in chunk['steps']if s['byte_range']is not None];total=f32(0)
 for p in values:total=f32(total+p)
 return f32(total/f32(len(values)))if values else 0.0
native=json.loads((r/'frozen-native.json').read_text());assert len(native)==5154
for model in ['30','50','100']:
 rows=json.loads((r/'new'/(model+'-export.json')).read_text());assert len(rows)==2304 and all(len(x['chunks'])==1 for x in rows);byid={x['id']:{'text':x['text'],'mean_confidence':mean(x['chunks'][0])}for x in rows}
 for item in [x for x in m['inputs']if x['cohort']=='new_control']:
  id=item['id'];native.append({'model':model,'id':id,'base':byid[id+'_base'],'candidates':[byid[id+'_'+v]for v in ['x2y0','x2y1','x2y2']]})
assert len(native)==6882 and len(geometry)==2294
(r/'native-rows.json').write_text(json.dumps(native,ensure_ascii=False,indent=2)+'\n');print('assembled',len(native),'native pairs')
