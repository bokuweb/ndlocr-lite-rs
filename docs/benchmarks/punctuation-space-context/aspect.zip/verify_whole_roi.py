from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/punct-aspect');sha=lambda b:hashlib.sha256(b).hexdigest();manifest=json.loads((r/'new/data/evaluation-manifest.json').read_text());variants={x['id']:x for x in manifest['variants']};proof={'models':[],'captured_rgb':[]}
for model in ['30','50','100']:
 assert json.loads((r/'new'/(model+'-command.json')).read_text())['exit_code']==0
 old=json.loads((r/'initial-chunked/new'/(model+'-export.json')).read_text());new=json.loads((r/'new'/(model+'-export.json')).read_text());assert len(old)==len(new)==2304;byid={x['id']:x for x in new};assert all(len(x['chunks'])==1 for x in new);compared=0;changed_input=[]
 for x in old:
  if len(x['chunks'])==1:assert x==byid[x['id']],(model,x['id']);compared+=1
  else:changed_input.append(x['id'])
 proof['models'].append({'model':model,'compared_identical_full_roi_rows':compared,'initial_split_rows':changed_input})
capture=r/'new/whole-rgb-capture';inputs=json.loads((capture/'inputs.json').read_text());assert inputs['model_input_dimensions']==[256,24];assert len(inputs['chunks'])==2304
for x in inputs['chunks']:
 p=capture/x['image'];im=Image.open(p).convert('RGB');v=variants[x['line_id']];assert x['chunk_index']==0 and x['dimensions']==list(im.size)==v['dimensions'];assert x['x_range']==[0,im.width];assert sha(im.tobytes())==v['rgb_sha256'];proof['captured_rgb'].append({'id':x['line_id'],'image':x['image'],'png_sha256':sha(p.read_bytes()),'rgb_sha256':sha(im.tobytes())})
proof['driver_sha256']=sha(Path(__file__).read_bytes());(r/'whole-roi-replay.json').write_text(json.dumps(proof,indent=2)+'\n');print('all2304 actual forward RGBs match;6898 prior full ROI rows bit/value identical',flush=True)
