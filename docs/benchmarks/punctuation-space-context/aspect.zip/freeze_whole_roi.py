from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/punct-aspect');b=Path('tmp/punct-integration');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();art=[x for l in(b/'whole-roi-build.jsonl').read_text().splitlines()if(x:=json.loads(l)).get('reason')=='compiler-artifact'and x.get('executable')];assert len(art)==1;shutil.copy2(art[0]['executable'],r/'new/export-binary')
paths=list(Path('src').rglob('*.rs'))+[Path(p)for p in ['examples/export_parseq_candidates.rs','examples/support/candidate_regions.rs','examples/support/candidate_export.rs','examples/support/chunk_capture.rs','Cargo.toml','Cargo.lock','docs/whole_roi_candidate_export.md']];source={}
for p in paths:
 dst=r/'whole-roi-source'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);source[str(p)]=sha(p)
prior=json.loads((r/'initial-chunked/parent-raw-capture.json').read_text());meta={'binary_sha256':sha(r/'new/export-binary'),'source_base':'9fc4528 + uncommitted whole-roi diagnostic; exact sources included','source_root':'whole-roi-source','source_sha256':source,'models':prior['models'],'whole_roi':True,'freeze_sha256':sha(__file__)}
for p,h in meta['models'].items():assert sha(p)==h
(r/'parent-raw-capture.json').write_text(json.dumps(meta,indent=2)+'\n');print('whole ROI exporter frozen',meta['binary_sha256'],flush=True)
