# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2294`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 2294 | 0 | 0.1701 | 0.8050 |
| raw | 2294 | 0 | 0.1706 | 0.8070 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
