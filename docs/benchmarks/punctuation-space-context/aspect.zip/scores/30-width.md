# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2294`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 2294 | 0 | 0.1474 | 0.7194 |
| raw | 2294 | 0 | 0.1497 | 0.7372 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
