from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/punct-integration');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={};m=json.loads((r/'page-after/evaluation-manifest.json').read_text());directories=[];bodies={}
for x in m['inputs']:
 for k in ['image','truth']:assert sha(Path(x[k]).read_bytes())==x[k+'_sha256']
 files['images/'+x['id']+Path(x['image']).suffix]=Path(x['image']).read_bytes();files['page-truth/'+x['id']+'.txt']=Path(x['truth']).read_bytes()
files['page-after/evaluation-manifest.json']=(r/'page-after/evaluation-manifest.json').read_bytes()
for mode in ['deim','bands','runtime30_eval','runtime30_default','runtime50_eval','runtime50_default','runtime100_eval','runtime100_default']:
 for phase in ['before','after']:
  src=r/'page-before'/mode if phase=='before'else(r/'cli-after'/mode if mode in ['deim','bands']else r/'page-after'/('primary50'if mode.startswith('runtime50')else'after')/mode)
  target='page-before/'+mode if phase=='before'else('cli-after/'+mode if mode in ['deim','bands']else'page-after/'+('primary50'if mode.startswith('runtime50')else'after')+'/'+mode)
  if(src/'results.json').exists():data=(src/'results.json').read_bytes();records=json.loads(data)
  else:
   records=[{'id':x['id'],'text':(src/(x['id']+'.txt')).read_text()}for x in m['inputs']];data=(json.dumps(records,ensure_ascii=False,indent=2)+'\n').encode()
  assert len(records)==287;directories.append(target);files[target+'/results.json']=data
  for x in records:
   body=(src/(x['id']+'.txt')).read_bytes();assert body==x['text'].encode();bodies[target+'/'+x['id']+'.txt']=sha(body)
for p in(r/'page-scores').iterdir():files['page-scores/'+p.name]=p.read_bytes()
for name in ['page-audit.json','page-baseline.json','page-capture-command.json','page-score-command.json','page-binaries.json','score_matrix.py','run_pages.py','prepare_pages.py','cli-runs.json','page30-100-command.json','page30-100.stdout','page30-100.stderr','page50-command.json','page50.stdout','page50.stderr','page-scoring.log']:
 files[name]=(r/name).read_bytes()
for p in(r/'cli-after').glob('*/*'):
 if p.suffix!='.txt':files[str(p.relative_to(r))]=p.read_bytes()
files['materialize.json']=(json.dumps({'hypothesis':'D; rejected on later aspect controls','record_directories':directories,'actual_body_sha256':bodies},indent=2)+'\n').encode()
# Actual measurement sources, including the test-only trace path; never substitute current source.
for phase in ['before','after']:
 for p in(r/(phase+'-src')).rglob('*'):
  if p.is_file():files['source/'+phase+'/'+str(p.relative_to(r/(phase+'-src')))]=p.read_bytes()
 files[phase+'-source.json']=(r/(phase+'-source.json')).read_bytes()
attribution=Path('docs/benchmarks/page-word-reaudit');index=json.loads((attribution/'data.json').read_text());assert sha((attribution/'data.zip').read_bytes())==index['sha256']
with zipfile.ZipFile(attribution/'data.zip')as z:
 for key in z.namelist():
  if key.startswith('attribution/'):
   data=z.read(key);assert sha(data)==index['members'][key];files[key]=data
for name in ['tests/fixtures/eval/README.md','tests/fixtures/line_segment/README.md','docs/evaluation.md']:
 p=Path(name)
 if p.exists():files['attribution/'+name]=p.read_bytes()
files['source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes();files['package_page.py']=Path(__file__).read_bytes();path=out/'page.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for key,data in sorted(files.items()):
  info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
(out/'page.json').write_text(json.dumps({'hypothesis':'D (rejected)','sha256':sha(path.read_bytes()),'member_count':len(files),'members':{k:sha(b)for k,b in sorted(files.items())}},indent=2)+'\n');print('page evidence',len(files),path.stat().st_size)
