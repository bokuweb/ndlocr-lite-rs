from pathlib import Path
import json,hashlib,os,subprocess,concurrent.futures
r=Path('tmp/punct-integration');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();b=json.loads((r/'page-binaries.json').read_text());n=json.loads((r/'native-capture-command.json').read_text());baseline=json.loads((r/'page-baseline.json').read_text());manifest=r/'page-after/evaluation-manifest.json';assert sha(manifest)==baseline['manifest_sha256'];rows=json.loads(manifest.read_text())['inputs']
for key in ['cli','page50']:assert sha(r/(key+'-after-binary'))==b[key]['binary_sha256']
assert sha(r/'after-native-binary')==n['after']['binary_sha256'];models=n['models']|{'models/deim-s-1024x1024.onnx':sha('models/deim-s-1024x1024.onnx')}
for p,h in models.items():assert sha(p)==h
for row in rows:
 for k in ['image','truth']:assert sha(row[k])==row[k+'_sha256']
meta={'binaries':b,'libtest_binary_sha256':sha(r/'after-native-binary'),'native_source':n['after']['source'],'models':models,'manifest_sha256':sha(manifest),'baseline_capture_sha256':sha(r/'page-baseline.json'),'driver_sha256':sha(__file__)};(r/'page-capture-command.json').write_text(json.dumps(meta,indent=2)+'\n');env={'NDLOCR_INTRA_THREADS':'1'}
def execute(name,argv,extra={}):
 record={'argv':argv,'env':env|extra};p=r/(name+'-command.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as stdout,(r/(name+'.stderr')).open('wb')as stderr:process=subprocess.run(argv,stdout=stdout,stderr=stderr,env=os.environ|record['env'])
 record['exit_code']=process.returncode;p.write_text(json.dumps(record,indent=2)+'\n');assert process.returncode==0,name;return record
def api():
 execute('page30-100',[str((r/'after-native-binary').resolve()),'infer::page_pool::missing_context_tests::record_missing_context_runtime_matrix','--exact','--ignored','--nocapture'],{'NDLOCR_CONTEXT_MATRIX_ROOT':str(r/'page-after'),'NDLOCR_CONTEXT_CAPTURE':'1'});print('page30/100 terminal success',flush=True)
def primary50():
 execute('page50',[str((r/'page50-after-binary').resolve()),'--manifest',str(manifest),'--det-model','models/deim-s-1024x1024.onnx','--parseq-model',next(p for p in models if '-50-tiny-'in p),'--charset','models/NDLmoji.yaml','--label','runtime50','--output-dir',str(r/'page-after/primary50')]);print('page50 terminal success',flush=True)
def cli():
 root=r/'cli-after';root.mkdir()
 for mode in ['deim','bands']:(root/mode).mkdir()
 def run(job):
  row,mode=job;out=root/mode/(row['id']+'.txt');argv=[str((r/'cli-after-binary').resolve()),'recognize-page','--image',row['image'],'--charset','models/NDLmoji.yaml','--use-deim-detection',str(mode=='deim').lower(),'--output-txt',str(out)];record=execute('cli-after/'+mode+'/'+row['id'],argv);record['output_sha256']=sha(out);return record
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(run,[(row,mode)for row in rows for mode in ['deim','bands']]))
 (r/'cli-runs.json').write_text(json.dumps({'fresh_processes':len(results),'runs':results},indent=2)+'\n');print('574 CLI processes terminal success',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(lambda f:f(),[api,primary50,cli]))
print('all eight fresh page routes terminal success',flush=True)
