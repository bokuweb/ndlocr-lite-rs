from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
r=Path('tmp/punct-integration');sha=lambda b:hashlib.sha256(b).hexdigest();root=r/'page-after';root.mkdir();manifest=Path('tmp/page-word-reaudit/evaluation-manifest.json');m=json.loads(manifest.read_text());assert len(m['inputs'])==287
(root/'evaluation-manifest.json').write_bytes(manifest.read_bytes());base=r/'page-before';base.mkdir();meta={'archives':{},'manifest_sha256':sha(manifest.read_bytes()),'sources':{}}
for x in m['inputs']:
 for k in ['image','truth']:assert sha(Path(x[k]).read_bytes())==x[k+'_sha256']
for name in ['page-word-reaudit/data','page-word-reaudit/diagnostics','primary50-and-spaces/evidence']:
 stem=Path('docs/benchmarks')/name;index=json.loads(stem.with_suffix('.json').read_text());zpath=stem.with_suffix('.zip');assert sha(zpath.read_bytes())==index['sha256'];meta['archives'][name]={'archive_sha256':index['sha256'],'members':{}}
 with zipfile.ZipFile(zpath)as z:
  def read(key):
   data=z.read(key);assert sha(data)==index['members'][key],key;meta['archives'][name]['members'][key]=index['members'][key];return data
  if name.endswith('/data'):
   for mode in ['deim','bands','runtime30_eval','runtime30_default','runtime100_eval','runtime100_default']:
    d=base/mode;d.mkdir()
    for x in m['inputs']:(d/(x['id']+'.txt')).write_bytes(read('candidate/'+mode+'/'+x['id']+'.txt'))
   for x in m['inputs']:
    assert read('truth/'+x['id']+'.txt')==Path(x['truth']).read_bytes()
  elif name.endswith('/diagnostics'):
   for mode in ['runtime30_eval','runtime30_default','runtime100_eval','runtime100_default']:
    (base/mode/'results.json').write_bytes(read('candidate/after/'+mode+'/results.json'))
   cap=json.loads(read('candidate/capture-command.json'));meta['sources']['page30_100']=cap
   for p,h in cap['sha256'].items():
    if p.startswith('src/'):
     data=read('candidate/source/'+p);assert sha(data)==h;assert data==subprocess.run(['git','show','9fc4528:'+p],capture_output=True,check=True).stdout,p
  else:
   for mode in ['runtime50_eval','runtime50_default']:
    d=base/mode;d.mkdir()
    for x in m['inputs']:(d/(x['id']+'.txt')).write_bytes(read('page/after/'+mode+'/'+x['id']+'.txt'))
    (d/'results.json').write_bytes(read('page/after/'+mode+'/results.json'))
   for p in subprocess.run(['git','ls-files','src'],capture_output=True,text=True,check=True).stdout.splitlines():assert read('source/after/'+p)==subprocess.run(['git','show','9fc4528:'+p],capture_output=True,check=True).stdout,p
# The baselines are pinned prior captures, not fresh before runs.
meta['baseline_scope']='reused exact 9fc production outputs: 6 routes from4ba and primary50 two routes from4ba, verified production source against9fc; all8 after routes will be fresh'
(r/'page-baseline.json').write_text(json.dumps(meta,indent=2)+'\n');print('pinned287x8 before outputs and production sources verified')
