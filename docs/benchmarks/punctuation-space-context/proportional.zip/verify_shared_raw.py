from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/punct-proportional');sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'new/data/evaluation-manifest.json').read_text());variants={x['id']:x for x in m['variants']};assert len(variants)==2304;proof={'models':[],'captured_rgb':[]}
for model in ['30','50','100']:
 cmd=json.loads((r/'new'/(model+'-command.json')).read_text());assert cmd['exit_code']==0 and '--whole-roi'in cmd['argv'];a=json.loads((r/'new'/(model+'-export.json')).read_text());assert len(a)==2304 and {x['id']for x in a}==set(variants)
 assert all(len(x['chunks'])==1 and x['chunks'][0]['x_range']==[0,variants[x['id']]['dimensions'][0]]for x in a);proof['models'].append({'model':model,'single_full_roi_rows':len(a)})
c=r/'new/whole-rgb-capture';capture=json.loads((c/'inputs.json').read_text());assert capture['model_input_dimensions']==[256,24]and len(capture['chunks'])==2304;assert {x['line_id']for x in capture['chunks']}==set(variants)
for x in capture['chunks']:
 p=c/x['image'];im=Image.open(p).convert('RGB');v=variants[x['line_id']];assert x['chunk_index']==0 and x['dimensions']==list(im.size)==v['dimensions']and x['x_range']==[0,im.width];assert sha(im.tobytes())==v['rgb_sha256'];proof['captured_rgb'].append({'id':x['line_id'],'png_sha256':sha(p.read_bytes()),'rgb_sha256':sha(im.tobytes())})
source=json.loads((r/'parent-raw-capture.json').read_text())
for p,h in source['models'].items():assert sha(Path(p).read_bytes())==h
proof['driver_sha256']=sha(Path(__file__).read_bytes());(r/'shared-raw-replay.json').write_text(json.dumps(proof,indent=2)+'\n');print('F proportional6912 forwards; all2304 captured RGBs identical',flush=True)
