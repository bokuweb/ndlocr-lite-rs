from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib,shutil,subprocess,PIL
r=Path('tmp/punct-proportional');parent=Path('tmp/punct-width');sha=lambda b:hashlib.sha256(b).hexdigest()
root=r/'corpus';root.mkdir()
for folder in ['png','rgb','truth']:(root/folder).mkdir()
prior=json.loads((parent/'evaluation-manifest.json').read_text());inputs=[]
for x in prior['inputs']:
 row={**x,'cohort':'prior_'+x['cohort']}
 for kind,folder,suffix in [('image','png','.png'),('rgb','rgb','.rgb'),('truth','truth','.txt')]:
  b=Path(x[kind]).read_bytes();assert sha(b)==x[kind+'_sha256'];p=root/folder/(x['id']+suffix);p.write_bytes(b);row[kind]=str(p)
 inputs.append(row)
new=r/'new/data';new.mkdir(parents=True)
for d in ['images','truth','native-render']:(new/d).mkdir()
fonts=json.loads((parent/'new/data/evaluation-manifest.json').read_text())['fonts'];rows=[];traces=[]
probe=json.loads((r/'probe-results.json').read_text());assert len(probe['fonts'])==3
for x in probe['fonts']:assert x['measure']['palt']['width']<x['measure']['default']['width']
for f in fonts:
 assert sha(Path(f['path']).read_bytes())==f['sha256']
 for size in [20,32]:
  for tid,(prefix,punct,suffix)in enumerate([('調査結果','、','提出先'),('利用時間','。','受付窓口')]):
   for palt in [0,1]:
    for spaces in [0,1,2]:
     text=prefix+punct+' '*spaces+suffix;base_id=f'p_t{tid}_sp{spaces}_{f["id"]}_{size}_palt{palt}';rendered=new/'native-render'/(base_id+'.png')
     argv=[str(r/'render'),f['path'],str(size),str(palt),text,str(rendered)];done=subprocess.run(argv,capture_output=True,check=True);trace=json.loads(done.stdout);assert Path(trace['font_file']).samefile(f['path'])
     for run in trace['runs']:
      assert Path(run['font_file']).samefile(f['path'])and run['font']==trace['font'];assert 0 not in run['glyphs']
     assert sorted(i for run in trace['runs']for i in run['string_indices'])==list(range(len(text)))
     (new/'native-render'/(base_id+'.json')).write_bytes(done.stdout+b'\n');traces.append({'id':base_id,'argv':argv,'exit_code':done.returncode,'rendered_sha256':sha(rendered.read_bytes()),'trace_sha256':sha(done.stdout+b'\n')})
     full=Image.open(rendered).convert('RGB');bbox=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();assert bbox
     box=(bbox[0]-2,bbox[1]-2,bbox[2]+2,bbox[3]+2);assert min(box[:2])>=0 and box[2]<=full.width and box[3]<=full.height;original_image=full.crop(box)
     for percent in [70,100]:
      im=original_image.resize((max(1,original_image.width*percent//100),original_image.height),Image.Resampling.BILINEAR)
      for paper in [0,8]:
       image=Image.new('RGB',(im.width,im.height+paper*2),'white');image.paste(im,(0,paper))
       for fmt in ['png','jpeg75']:
        id=base_id+f'_x{percent}_paper{paper}_{fmt}';original=new/'images'/(id+('.png'if fmt=='png'else'.jpg'));image.save(original,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(original).convert('RGB');rgb=root/'rgb'/(id+'.rgb');rgb.write_bytes(decoded.tobytes());png=root/'png'/(id+'.png');decoded.save(png);gt=root/'truth'/(id+'.txt');gt.write_text(text);(new/'truth'/(id+'.txt')).write_bytes(gt.read_bytes())
        row={'id':id,'cohort':'new_control','text_id':tid,'font':f['id'],'size':size,'palt':palt,'spaces':spaces,'horizontal_percent':percent,'paper':paper,'format':fmt,'width':decoded.width,'height':decoded.height,'native_id':base_id,'native_crop':box}
        for k,p in [('image',png),('rgb',rgb),('truth',gt),('original',original)]:row[k]=str(p);row[k+'_sha256']=sha(p.read_bytes())
        rows.append(row);inputs.append(row)
assert len(rows)==576 and len(inputs)==4022 and len(traces)==72
variants=[];tiles=[];x=y=row_h=0;maxw=0
for row in rows:
 im=Image.open(row['image']).convert('RGB')
 for label,xp,yp in [('base',0,0),('x2y0',2,0),('x2y1',2,1),('x2y2',2,2)]:
  tile=Image.new('RGB',(im.width+2*xp,im.height+2*yp),'white');tile.paste(im,(xp,yp))
  if x and x+tile.width>2048:y+=row_h+4;x=0;row_h=0
  variants.append({'id':row['id']+'_'+label,'base_id':row['id'],'variant':label,'bounds':[x,y,x+tile.width,y+tile.height],'dimensions':tile.size,'rgb_sha256':sha(tile.tobytes())});tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for v,t in zip(variants,tiles):atlas.paste(t,(v['bounds'][0],v['bounds'][1]))
atlas.save(new/'atlas.png');(new/'lines.json').write_text(json.dumps([{'id':v['id'],'bounds':v['bounds']}for v in variants],indent=2)+'\n')
spec=Path('docs/punctuation_space_proportional_controls.md');meta={'inputs':rows,'variants':variants,'fonts':fonts,'native_render_commands':traces,'generator_sha256':sha(Path(__file__).read_bytes()),'spec_sha256':sha(spec.read_bytes()),'renderer_source_sha256':sha((r/'render.swift').read_bytes()),'renderer_binary_sha256':sha((r/'render').read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((new/'atlas.png').read_bytes()),'lines_sha256':sha((new/'lines.json').read_bytes())}
(new/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(r/'evaluation-manifest.json').write_text(json.dumps({'inputs':inputs,'parent_manifest_sha256':sha((parent/'evaluation-manifest.json').read_bytes()),'spec_sha256':meta['spec_sha256'],'new_manifest_sha256':sha((new/'evaluation-manifest.json').read_bytes())},ensure_ascii=False,indent=2)+'\n')
shutil.copy2(spec,r/'capture-spec.md');shutil.copy2(parent/'native-rows.json',r/'frozen-native.json');shutil.copy2(parent/'parent-raw-capture.json',r/'parent-raw-capture.json')
print('4022 total /576 new /2304 whole ROIs fixed',atlas.size,flush=True)
