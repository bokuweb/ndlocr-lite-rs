# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `4022`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 4022 | 0 | 0.0277 | 0.0457 |
| after | 4022 | 0 | 0.0277 | 0.0457 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
