# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `4022`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 4022 | 0 | 0.1000 | 0.5918 |
| before | 4022 | 0 | 0.1015 | 0.6006 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
