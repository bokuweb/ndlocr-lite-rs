# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `4022`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| advance_support | 4022 | 0 | 0.1437 | 0.7884 |
| raw | 4022 | 0 | 0.1440 | 0.7898 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
