from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/punct-proportional');out=Path('docs/benchmarks/punctuation-space-context');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for x in json.loads((r/'new/data/evaluation-manifest.json').read_text())['inputs']:
 for key in ['image','rgb','truth']:
  p=Path(x[key]);b=p.read_bytes();assert sha(b)==x[key+'_sha256'];files[str(p.relative_to(r))]=b
for folder in ['new/data','geometry-source','whole-roi-source','scores-advance','production-replay/scores']:
 for p in(r/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(r))]=p.read_bytes()
for p in(r/'new').iterdir():
 if p.is_file()and p.suffix in ['.json','.stdout','.stderr']:files[str(p.relative_to(r))]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.py','.swift','.md','.log','.stdout','.stderr']:files[p.name]=p.read_bytes()
for name in ['new/whole-rgb-capture/inputs.json','production-replay/records.json','production-replay/audit.json','contact.png']:files[name]=(r/name).read_bytes()
files['source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes()
files['spec-results.md']=Path('docs/punctuation_space_proportional_controls.md').read_bytes()
seen={};unique={};aliases={}
for key,b in sorted(files.items()):
 h=sha(b)
 if h in seen:aliases[key]={'source':seen[h],'sha256':h}
 else:unique[key]=b;seen[h]=key
unique['aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode();path=out/'proportional.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for key,b in sorted(unique.items()):
  info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
(out/'proportional.json').write_text(json.dumps({'hypothesis':'F rejected on proportional controls','sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':len(files),'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n');print('F proportional packet',len(unique),len(files),path.stat().st_size,flush=True)
