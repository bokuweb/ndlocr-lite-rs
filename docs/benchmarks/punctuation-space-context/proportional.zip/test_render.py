from pathlib import Path
from PIL import Image
import json,subprocess,tempfile,unittest

class RenderFixture(unittest.TestCase):
 def test_renders_ink_with_margin_and_exact_requested_font(self):
  fonts=json.loads(Path('tmp/punct-width/new/data/evaluation-manifest.json').read_text())['fonts']
  with tempfile.TemporaryDirectory()as temp:
   for font in fonts:
    for palt in [0,1]:
     with self.subTest(font=font['id'],palt=palt):
      out=Path(temp)/'render.png';args=['tmp/punct-proportional/render',font['path'],'20',str(palt),'調査結果、 提出先',str(out)]
      data=json.loads(subprocess.run(args,capture_output=True,check=True).stdout);im=Image.open(out).convert('RGB')
      pixels=im.load();ink=[(x,y)for y in range(im.height)for x in range(im.width)if sum(pixels[x,y])<660]
      self.assertTrue(ink,'actual Japanese glyph ink is required')
      self.assertGreaterEqual(min(x for x,y in ink),4);self.assertLess(max(x for x,y in ink),im.width-4)
      self.assertGreaterEqual(min(y for x,y in ink),4);self.assertLess(max(y for x,y in ink),im.height-4)
      self.assertEqual(im.size,(data['width'],data['height']))
      self.assertTrue(Path(data['font_file']).samefile(font['path']))
      for run in data['runs']:
       self.assertEqual(run['font'],data['font']);self.assertTrue(Path(run['font_file']).samefile(font['path']))
       self.assertNotIn(0,run['glyphs'])

 def test_ascii_spaces_keep_their_advance_and_glyphs(self):
  fonts=json.loads(Path('tmp/punct-width/new/data/evaluation-manifest.json').read_text())['fonts']
  with tempfile.TemporaryDirectory()as temp:
   for font in fonts:
    for palt in [0,1]:
     data=[]
     for spaces in [0,1,2]:
      args=['tmp/punct-proportional/render',font['path'],'20',str(palt),'調査結果、'+' '*spaces+'提出先',str(Path(temp)/'image.png')]
      x=json.loads(subprocess.run(args,capture_output=True,check=True).stdout)
      entries=sorted((i,g,p[0],a[0])for run in x['runs']for i,g,p,a in zip(run['string_indices'],run['glyphs'],run['positions'],run['advances']))
      self.assertEqual([e[0]for e in entries],list(range(8+spaces)))
      data.append((x,entries))
     step=data[1][1][5][3];self.assertGreater(step,0)
     for spaces in [1,2]:
      self.assertAlmostEqual(data[spaces][0]['typographic_width']-data[0][0]['typographic_width'],spaces*step,places=5)
      entries=data[spaces][1];without=entries[:5]+entries[5+spaces:]
      self.assertEqual([e[1]for e in without],[e[1]for e in data[0][1]])
      self.assertAlmostEqual(entries[5+spaces][2]-data[0][1][5][2],spaces*step,places=5)

if __name__=='__main__':unittest.main()
