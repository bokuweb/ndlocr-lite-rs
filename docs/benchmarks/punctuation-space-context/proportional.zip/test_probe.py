from pathlib import Path
import json,subprocess,unittest

class ProportionalProbe(unittest.TestCase):
 def test_punctuation_advance_changes_without_font_fallback(self):
  fonts=json.loads(Path('tmp/punct-width/new/data/evaluation-manifest.json').read_text())['fonts']
  for font in fonts:
   with self.subTest(font=font['id']):
    data=json.loads(subprocess.run(['tmp/punct-proportional/probe',font['path']],capture_output=True,check=True).stdout)
    self.assertTrue(Path(data['font_file']).samefile(font['path']))
    self.assertLess(data['palt']['width'],data['default']['width'])
    self.assertGreater(data['palt']['width'],0)
    self.assertEqual(data['default']['fonts'],[data['font']])
    self.assertEqual(data['palt']['fonts'],[data['font']])

if __name__=='__main__':unittest.main()
