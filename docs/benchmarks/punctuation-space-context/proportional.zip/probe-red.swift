import Foundation
import CoreText

let url = URL(fileURLWithPath: CommandLine.arguments[1])
let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as! [CTFontDescriptor]
let base = CTFontCreateWithFontDescriptor(descriptors[0], 24, nil)
func measure(_ font: CTFont, _ text: String) -> [String: Any] {
    let attrs = [NSAttributedString.Key(kCTFontAttributeName as String): font]
    let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attrs))
    let runs = CTLineGetGlyphRuns(line) as! [CTRun]
    return ["width": CTLineGetTypographicBounds(line, nil, nil, nil),
            "fonts": runs.map { run in
                let attr = CTRunGetAttributes(run) as NSDictionary
                return CTFontCopyPostScriptName(attr[kCTFontAttributeName] as! CTFont) as String
            }]
}
var result: [String: Any] = ["font": CTFontCopyPostScriptName(base) as String]
result["default"] = measure(base, "、")
result["palt"] = measure(base, "、")
let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
FileHandle.standardOutput.write(data)
