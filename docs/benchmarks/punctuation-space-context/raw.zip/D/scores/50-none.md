# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1358`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| component | 1358 | 0 | 0.2195 | 0.8326 |
| raw | 1358 | 0 | 0.2203 | 0.8360 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
