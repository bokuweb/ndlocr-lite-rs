# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1358`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| raw | 1358 | 0 | 0.1240 | 0.0449 |
| component | 1358 | 0 | 0.1240 | 0.0449 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
