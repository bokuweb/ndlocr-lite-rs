from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import PIL,json,hashlib,math,shutil
r=Path('tmp/punctuation-space-components');parent=Path('tmp/ink-height-space');sha=lambda b:hashlib.sha256(b).hexdigest();root=r/'corpus';root.mkdir(exist_ok=False)
for name in ['png','rgb','truth']:(root/name).mkdir()
prior=json.loads((parent/'evaluation-manifest.json').read_text());inputs=[]
for row in prior['inputs']:
 id='prior_'+row['id'];out={**row,'id':id,'cohort':'prior_'+row['cohort'],'parent_id':row['id']}
 for kind,directory,suffix in [('image','png','.png'),('rgb','rgb','.rgb'),('truth','truth','.txt')]:
  src=Path(row[kind]);b=src.read_bytes();assert sha(b)==row[kind+'_sha256'];p=root/directory/(id+suffix);p.write_bytes(b);out[kind]=str(p);out[kind+'_sha256']=sha(b)
 inputs.append(out)
cached=[{**x,'id':'prior_'+x['id']}for x in json.loads((parent/'native-rows.json').read_text())];assert len(inputs)==782 and len(cached)==2346
fonts=json.loads((parent/'new/data/evaluation-manifest.json').read_text())['fonts'];myungjo=Path('/System/Library/Fonts/Supplemental/AppleMyungjo.ttf');fonts.append({'id':'myungjo','path':str(myungjo),'sha256':sha(myungjo.read_bytes())});new=r/'new';new.mkdir(exist_ok=False);(new/'data').mkdir();(new/'data/images').mkdir();(new/'data/truth').mkdir();rows=[];coverage=[]
for f in fonts:
 p=Path(f['path']);assert sha(p.read_bytes())==f['sha256'];font=ImageFont.truetype(str(p),24);key=lambda m:(m.size,bytes(m));missing=key(font.getmask(chr(0x10ffff)));chars=sorted(set('受付番地通知先開催日時集合場所、。 '));absent=[c for c in chars if key(font.getmask(c))==missing];assert not absent,(f['id'],absent);coverage.append({'font':f['id'],'name':font.getname(),'checked_characters':chars,'missing':absent})
 for size in [24,40]:
  font=ImageFont.truetype(str(p),size)
  for tid,(prefix,suffix)in enumerate([('受付番地','通知先'),('開催日時','集合場所')]):
   for punct_id,punct in [('comma','、'),('period','。')]:
    for spaces in [0,1,2]:
     text=prefix+punct+' '*spaces+suffix;x0,y0,x1,y1=font.getbbox(text);im=Image.new('RGB',(x1-x0+4,y1-y0+4),'white');ImageDraw.Draw(im).text((2-x0,2-y0),text,font=font,fill='black');cols=[any(sum(im.getpixel((x,y)))<660 for y in range(im.height))for x in range(im.width)];xs=[x for x,v in enumerate(cols)if v];gaps=[];start=None
     for x in range(xs[0],xs[-1]+1):
      if not cols[x]and start is None:start=x
      if cols[x]and start is not None:gaps.append((start,x));start=None
     chosen=max(gaps,key=lambda q:q[1]-q[0])if gaps else(im.width//2,im.width//2);dot_x=(chosen[0]+chosen[1])//2
     for context,yp,dots in [('paper0',0,False),('paper10',10,False),('dots10',10,True)]:
      image=Image.new('RGB',(im.width,im.height+2*yp),'white');image.paste(im,(0,yp))
      if dots:image.putpixel((dot_x,0),(0,0,0));image.putpixel((dot_x,image.height-1),(0,0,0))
      for fmt in ['png','jpeg75']:
       id=f'd_t{tid}_{punct_id}_sp{spaces}_{f["id"]}_{size}_{context}_{fmt}';orig=new/'data/images'/(id+('.png'if fmt=='png'else'.jpg'));image.save(orig,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(orig).convert('RGB');b=decoded.tobytes();png=root/'png'/(id+'.png');decoded.save(png);rgb=root/'rgb'/(id+'.rgb');rgb.write_bytes(b);gt=root/'truth'/(id+'.txt');gt.write_text(text);gt2=new/'data/truth'/(id+'.txt');gt2.write_bytes(gt.read_bytes());row={'id':id,'cohort':'new_control','width':decoded.width,'height':decoded.height,'image':str(png),'image_sha256':sha(png.read_bytes()),'rgb':str(rgb),'rgb_sha256':sha(b),'truth':str(gt),'truth_sha256':sha(gt.read_bytes()),'original':str(orig),'original_sha256':sha(orig.read_bytes()),'font':f['id'],'size':size,'context':context,'punctuation':punct,'spaces':spaces,'dot_x':dot_x,'format':fmt};inputs.append(row);rows.append(row)
assert len(rows)==576 and len(inputs)==1358 and len({x['id']for x in inputs})==1358
variants=[];tiles=[]
for row in rows:
 im=Image.open(row['image']).convert('RGB')
 for label,xp,yp in [('base',0,0),('x2y0',2,0),('x2y1',2,1),('x2y2',2,2)]:
  tile=Image.new('RGB',(im.width+2*xp,im.height+2*yp),'white');tile.paste(im,(xp,yp));assert tile.crop((xp,yp,xp+im.width,yp+im.height)).tobytes()==im.tobytes();variants.append({'id':row['id']+'_'+label,'base_id':row['id'],'variant':label,'dimensions':tile.size,'rgb_sha256':sha(tile.tobytes())});tiles.append(tile)
cw=max(t.width for t in tiles)+4;ch=max(t.height for t in tiles)+4;atlas=Image.new('RGB',(4*cw,math.ceil(len(tiles)/4)*ch),'white');lines=[]
for i,(v,tile)in enumerate(zip(variants,tiles)):
 x=(i%4)*cw;y=(i//4)*ch;atlas.paste(tile,(x,y));v['bounds']=[x,y,x+tile.width,y+tile.height];lines.append({'id':v['id'],'bounds':v['bounds']})
atlas.save(new/'data/atlas.png');(new/'data/lines.json').write_text(json.dumps(lines,indent=2)+'\n');meta={'inputs':rows,'variants':variants,'fonts':fonts,'font_coverage':coverage,'generator_sha256':sha(Path(__file__).read_bytes()),'spec_sha256':sha(Path('docs/punctuation_space_component_context.md').read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((new/'data/atlas.png').read_bytes()),'lines_sha256':sha((new/'data/lines.json').read_bytes())};(new/'data/evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(r/'evaluation-manifest.json').write_text(json.dumps({'inputs':inputs,'parent_manifest_sha256':sha((parent/'evaluation-manifest.json').read_bytes()),'spec_sha256':meta['spec_sha256'],'generator_sha256':meta['generator_sha256'],'new_manifest_sha256':sha((new/'data/evaluation-manifest.json').read_bytes())},ensure_ascii=False,indent=2)+'\n');(r/'frozen-native.json').write_text(json.dumps(cached,ensure_ascii=False,indent=2)+'\n');(r/'capture-spec.md').write_bytes(Path('docs/punctuation_space_component_context.md').read_bytes());shutil.copy2(parent/'parent-raw-capture.json',r/'parent-raw-capture.json');print('frozen782 old+576 new;2304 native crops',atlas.size)
