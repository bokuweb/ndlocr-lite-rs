# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `782`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| ink | 782 | 0 | 0.1046 | 0.7913 |
| raw | 782 | 0 | 0.1056 | 0.7927 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
