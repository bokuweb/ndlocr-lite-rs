# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `782`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| ink | 782 | 0 | 0.1871 | 0.7370 |
| raw | 782 | 0 | 0.1925 | 0.7694 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
