from pathlib import Path
import json,math,struct,sys,hashlib,subprocess,csv,zipfile
r=Path(sys.argv[1]if len(sys.argv)>1 else'tmp/ink-height-space');m=json.loads((r/'evaluation-manifest.json').read_text());geometry={x['id']:x for x in json.loads((r/'geometry.json').read_text())};f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def mean(chunk):
 values=[f32(s['candidates'][0]['probability'])for s in chunk['steps']if s['byte_range']is not None];total=f32(0)
 for p in values:total=f32(total+p)
 return f32(total/f32(len(values)))if values else 0.0
def japanese(c):
 return c in '、。'or any(lo<=ord(c)<=hi for lo,hi in [(0x3040,0x30ff),(0x3400,0x4dbf),(0x4e00,0x9fff),(0xf900,0xfaff)])
def choose(base,alts,g):
 text=base['text'];nonspace=text.replace(' ','');checks={'single_internal_space':text.count(' ')==1 and not text.startswith(' ')and not text.endswith(' '),'japanese_only':all(japanese(c)for c in nonspace),'length6to12':6<=len(nonspace)<=12,'consensus':all(a['text']==nonspace for a in alts),'confidences':all(math.isfinite(a['mean_confidence'])and .98<=a['mean_confidence']<=1 for a in alts),'strict_gain':alts[0]['mean_confidence']>base['mean_confidence']};a=all(checks.values());return a and g['supported'],checks
native=json.loads((r/'frozen-native.json').read_text());assert len(native)==906
for model in ['30','50','100']:
 rows=json.loads((r/'new'/(model+'-export.json')).read_text());assert len(rows)==1920 and all(len(x['chunks'])==1 for x in rows);byid={x['id']:{'text':x['text'],'mean_confidence':mean(x['chunks'][0])}for x in rows}
 for item in [x for x in m['inputs']if x['cohort']=='new_control']:
  id=item['id'];native.append({'model':model,'id':id,'base':byid[id+'_base'],'candidates':[byid[id+'_'+v]for v in ['x2y0','x2y1','x2y2']]})
assert len(native)==2346 and len(geometry)==782
scorer=r/'source/eval_ocr_metrics.py'
if not scorer.exists():scorer=Path('tools/eval_ocr_metrics.py')
truth=r/'truth';truth.mkdir(exist_ok=True)
for row in m['inputs']:
 p=r/'corpus/truth'/(row['id']+'.txt');assert hashlib.sha256(p.read_bytes()).hexdigest()==row['truth_sha256'];(truth/p.name).write_bytes(p.read_bytes())
decisions=[]
for row in native:
 id=row['id'];selected,checks=choose(row['base'],row['candidates'],geometry[id]);decisions.append({'model':row['model'],'id':id,'checks':checks,'selected':selected,'geometry':geometry[id]})
 for policy,text in [('raw',row['base']['text']),('ink',row['candidates'][0]['text']if selected else row['base']['text'])]:
  p=r/'predictions'/row['model']/policy/(id+'.txt');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(text.encode())
(r/'native-rows.json').write_text(json.dumps(native,ensure_ascii=False,indent=2)+'\n');(r/'decisions.json').write_text(json.dumps(decisions,indent=2)+'\n');scores=r/'scores';scores.mkdir(exist_ok=True);audit={'images':782,'native_pairs':2346,'comparisons_per_metric':7038,'changes':[],'char_regressions':[],'word_regressions':[],'summary':[]}
for model in ['30','50','100']:
 for norm in ['none','width','strict']:
  table=scores/(model+'-'+norm+'.csv');report=table.with_suffix('.md');cmd=[sys.executable,str(scorer),'--truth-dir',str(truth),'--system','raw='+str(r/'predictions'/model/'raw'),'--system','ink='+str(r/'predictions'/model/'ink'),'--normalize',norm,'--require-all','--output-csv',str(table),'--output-md',str(report)];subprocess.run(cmd,check=True,capture_output=True);table.write_bytes(table.read_bytes().replace(b'\r\n',b'\n'));report.write_bytes((report.read_text(encoding='utf-8').rstrip()+'\n').encode());rows=list(csv.DictReader(table.open()));b={x['file']:x for x in rows if x['system']=='raw'};a={x['file']:x for x in rows if x['system']=='ink'};assert len(a)==len(b)==782;stat={'model':model,'normalization':norm,'images':782,'char_improvements':0,'word_improvements':0,'byte_changes':0,'exact_improvements':0}
  for id in a:
   bc,ac=int(b[id]['char_errors']),int(a[id]['char_errors']);bw,aw=int(b[id]['word_errors']),int(a[id]['word_errors']);changed=(r/'predictions'/model/'raw'/id).read_bytes()!=(r/'predictions'/model/'ink'/id).read_bytes();stat['char_improvements']+=ac<bc;stat['word_improvements']+=aw<bw;stat['byte_changes']+=changed;stat['exact_improvements']+=bc>0 and ac==0
   if changed:audit['changes'].append([model,norm,id,bc,ac,bw,aw])
   if ac>bc:audit['char_regressions'].append([model,norm,id,bc,ac])
   if aw>bw:audit['word_regressions'].append([model,norm,id,bw,aw])
  audit['summary'].append(stat)
(r/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print('comparisons',audit['comparisons_per_metric'],'char regressions',len(audit['char_regressions']),'word regressions',len(audit['word_regressions']),flush=True)
