from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/ink-height-space');m=json.loads((r/'new/data/evaluation-manifest.json').read_text());atlas=Image.open(r/'new/data/atlas.png').convert('RGB');assert atlas.getchannel('R').tobytes()==atlas.getchannel('G').tobytes()==atlas.getchannel('B').tobytes();originals={x['id']:Image.open(x['image']).convert('RGB')for x in m['inputs']};white=((255,255),)*3
for v in m['variants']:
 tile=atlas.crop(v['bounds']);assert hashlib.sha256(tile.tobytes()).hexdigest()==v['rgb_sha256'];src=originals[v['base_id']];xp=0 if v['variant']=='base'else 2;yp={'base':0,'x2y0':0,'x2y1':1,'x2y2':2}[v['variant']];assert tile.crop((xp,yp,xp+src.width,yp+src.height)).tobytes()==src.tobytes()
 if xp:assert tile.crop((0,0,xp,tile.height)).getextrema()==white and tile.crop((tile.width-xp,0,tile.width,tile.height)).getextrema()==white
 if yp:assert tile.crop((0,0,tile.width,yp)).getextrema()==white and tile.crop((0,tile.height-yp,tile.width,tile.height)).getextrema()==white
(r/'new-rgb-replay.json').write_text(json.dumps({'crops':len(m['variants']),'all_original_pixels_preserved':True,'all_extra_pixels_pure_white':True,'atlas_grayscale':True},indent=2)+'\n');print('verified1920 native crops')
