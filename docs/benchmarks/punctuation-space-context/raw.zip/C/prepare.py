from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import PIL,json,hashlib,zipfile,io,math
r=Path('tmp/ink-height-space');sha=lambda b:hashlib.sha256(b).hexdigest();root=r/'corpus';root.mkdir(exist_ok=False)
for name in ['png','rgb','truth']:(root/name).mkdir()
parent=Path('docs/benchmarks/primary50-and-spaces');idx=json.loads((parent/'evidence.json').read_text());assert sha((parent/'evidence.zip').read_bytes())==idx['sha256'];inputs=[];cached=[]
with zipfile.ZipFile(parent/'evidence.zip')as z:
 def read(key):
  data=z.read(key);assert sha(data)==idx['members'][key],key;return data
 for stage in ['first','positions','paper']:
  p='raw/'+stage+'/';m=json.loads(read(p+'data/evaluation-manifest.json'));atlas=Image.open(io.BytesIO(read(p+'data/atlas.png'))).convert('RGB');variants={x['base_id']:x for x in m['variants']if x['variant']=='base'}
  for row in m['inputs']:
   id='old_'+stage+'_'+row['id'];v=variants[row['id']];im=atlas.crop(v['bounds']);b=im.tobytes();assert sha(b)==v['rgb_sha256']==row['rgb_sha256'];png=root/'png'/(id+'.png');im.save(png);rgb=root/'rgb'/(id+'.rgb');rgb.write_bytes(b);truth=read(p+'data/truth/'+row['id']+'.txt');assert sha(truth)==row['truth_sha256'];gt=root/'truth'/(id+'.txt');gt.write_bytes(truth);inputs.append({'id':id,'cohort':'reused_'+stage,'width':im.width,'height':im.height,'image':str(png),'image_sha256':sha(png.read_bytes()),'rgb':str(rgb),'rgb_sha256':sha(b),'truth':str(gt),'truth_sha256':sha(truth),'parent_id':row['id'],'parent_stage':stage})
  for row in json.loads(read(p+'native-rows.json')):cached.append({**row,'id':'old_'+stage+'_'+row['id']})
 fonts=json.loads(read('raw/first/data/evaluation-manifest.json'))['fonts'];capture=json.loads(read('raw/first/capture-command.json'))
assert len(inputs)==302 and len(cached)==906
new=r/'new';new.mkdir(exist_ok=False);(new/'data').mkdir();(new/'data/images').mkdir();(new/'data/truth').mkdir();rows=[]
for f in fonts:
 path=Path(f['path']);assert sha(path.read_bytes())==f['sha256']
 for size in [20,32]:
  font=ImageFont.truetype(str(path),size)
  for tid,(prefix,suffix)in enumerate([('検査結果','担当課'),('登録内容','保存先')]):
   forms={'joined':prefix+'、'+suffix,'after1':prefix+'、 '+suffix,'after2':prefix+'、  '+suffix,'before1':prefix+' 、'+suffix,'words':prefix+' '+suffix}
   for form,text in forms.items():
    x0,y0,x1,y1=font.getbbox(text);im=Image.new('RGB',(x1-x0+4,y1-y0+4),'white');ImageDraw.Draw(im).text((2-x0,2-y0),text,font=font,fill='black')
    for context,yp,dots in [('paper0',0,False),('paper4',4,False),('paper12',12,False),('dots12',12,True)]:
     image=Image.new('RGB',(im.width,im.height+2*yp),'white');image.paste(im,(0,yp))
     if dots:image.putpixel((2,0),(0,0,0));image.putpixel((image.width-3,image.height-1),(0,0,0))
     for fmt in ['png','jpeg75']:
      id=f'new_t{tid}_{form}_{f["id"]}_{size}_{context}_{fmt}';orig=new/'data/images'/(id+('.png'if fmt=='png'else'.jpg'));image.save(orig,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(orig).convert('RGB');b=decoded.tobytes();png=root/'png'/(id+'.png');decoded.save(png);rgb=root/'rgb'/(id+'.rgb');rgb.write_bytes(b);gt=root/'truth'/(id+'.txt');gt.write_text(text);gt2=new/'data/truth'/(id+'.txt');gt2.write_bytes(gt.read_bytes());row={'id':id,'cohort':'new_control','width':decoded.width,'height':decoded.height,'image':str(png),'image_sha256':sha(png.read_bytes()),'rgb':str(rgb),'rgb_sha256':sha(b),'truth':str(gt),'truth_sha256':sha(gt.read_bytes()),'original':str(orig),'original_sha256':sha(orig.read_bytes()),'font':f['id'],'size':size,'context':context,'form':form,'format':fmt};inputs.append(row);rows.append(row)
assert len(rows)==480 and len(inputs)==782 and len({x['id']for x in inputs})==782
variants=[];tiles=[]
for row in rows:
 im=Image.open(row['image']).convert('RGB')
 for label,xp,yp in [('base',0,0),('x2y0',2,0),('x2y1',2,1),('x2y2',2,2)]:
  tile=Image.new('RGB',(im.width+2*xp,im.height+2*yp),'white');tile.paste(im,(xp,yp));assert tile.crop((xp,yp,xp+im.width,yp+im.height)).tobytes()==im.tobytes();variants.append({'id':row['id']+'_'+label,'base_id':row['id'],'variant':label,'dimensions':tile.size,'rgb_sha256':sha(tile.tobytes())});tiles.append(tile)
cw=max(t.width for t in tiles)+4;ch=max(t.height for t in tiles)+4;atlas=Image.new('RGB',(4*cw,math.ceil(len(tiles)/4)*ch),'white');lines=[]
for i,(v,tile)in enumerate(zip(variants,tiles)):
 x=(i%4)*cw;y=(i//4)*ch;atlas.paste(tile,(x,y));v['bounds']=[x,y,x+tile.width,y+tile.height];lines.append({'id':v['id'],'bounds':v['bounds']})
atlas.save(new/'data/atlas.png');(new/'data/lines.json').write_text(json.dumps(lines,indent=2)+'\n');nm={'inputs':rows,'variants':variants,'fonts':fonts,'generator_sha256':sha(Path(__file__).read_bytes()),'spec_sha256':sha(Path('docs/ink_height_space_support.md').read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((new/'data/atlas.png').read_bytes()),'lines_sha256':sha((new/'data/lines.json').read_bytes())};(new/'data/evaluation-manifest.json').write_text(json.dumps(nm,ensure_ascii=False,indent=2)+'\n');(r/'frozen-native.json').write_text(json.dumps(cached,ensure_ascii=False,indent=2)+'\n');(r/'evaluation-manifest.json').write_text(json.dumps({'inputs':inputs,'parent_archive_sha256':idx['sha256'],'spec_sha256':nm['spec_sha256'],'generator_sha256':nm['generator_sha256'],'new_manifest_sha256':sha((new/'data/evaluation-manifest.json').read_bytes())},ensure_ascii=False,indent=2)+'\n');(r/'capture-spec.md').write_bytes(Path('docs/ink_height_space_support.md').read_bytes());(r/'parent-raw-capture.json').write_text(json.dumps(capture,indent=2)+'\n');print('frozen302 old+480 new inputs;1920 new RGB crops',atlas.size)
