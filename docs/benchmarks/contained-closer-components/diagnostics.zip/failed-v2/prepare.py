from pathlib import Path
import json,hashlib,zipfile,shutil
r=Path('tmp/contained-closer-spaces-wide');parent=Path('tmp/contained-closer-components');old=json.loads((parent/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();inputs=[]
for x in old['inputs']:
 id=x['id'];p=r/'inputs'/(id+Path(x['image']).suffix);p.parent.mkdir(exist_ok=True);b=Path(x['image']).read_bytes();assert sha(b)==x['image_sha256'];p.write_bytes(b);gt=r/'truth'/(id+'.txt');gt.parent.mkdir(exist_ok=True);b=Path(x['truth']).read_bytes();assert sha(b)==x['truth_sha256'];gt.write_bytes(b);inputs.append({**x,'image':str(p),'truth':str(gt),'v1_source':x['source'],'source':'reused_raw'})
shutil.copy2(parent/'probe.json',r/'frozen-probe.json')
f=Path('tests/fixtures/wide_cell_closer_spaces');m=json.loads((f/'manifest.json').read_text());assert sha((f/'corpus.zip').read_bytes())==m['archive_sha256'];assert sha((f/'generate.py').read_bytes())==m['generator_sha256']
with zipfile.ZipFile(f/'corpus.zip')as z:
 for x in m['rows']:
  id='widecell_'+x['id'];p=r/'inputs'/Path(x['image_member']).name;b=z.read(x['image_member']);assert sha(b)==x['image_sha256'];p.write_bytes(b);gt=r/'truth'/(id+'.txt');b=z.read(x['truth_member']);assert sha(b)==x['truth_sha256'];gt.write_bytes(b);inputs.append({**x,'id':id,'image':str(p),'truth':str(gt),'cohort':'wide_cell_closer_spaces','source':'fresh_holdout'})
assert len(inputs)==2551
manifest={**old,'inputs':inputs,'parent_probe_sha256':sha((r/'frozen-probe.json').read_bytes()),'parent_manifest_sha256':sha((parent/'evaluation-manifest.json').read_bytes()),'fixture_archive_sha256':m['archive_sha256'],'fixture_manifest_sha256':sha((f/'manifest.json').read_bytes()),'reused_raw':6693,'fresh_raw_forwards':960,'fresh_processed_forwards':960};(r/'evaluation-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('prepared2551 before v2 corpus evaluation')
for name in ['before-ndlocr','before-cli-binary.json']:shutil.copy2(parent/name,r/name)
s=(parent/'evaluate.py').read_text().replace('CONTAINED_CLOSER_EVAL_ROOT','CONTAINED_WIDE_CLOSER_EVAL_ROOT').replace('tmp/contained-closer-components','tmp/contained-closer-spaces-wide').replace("'prototype','fragment'","'prototype','contained_only','fragment'").replace('2231','2551').replace('20079','22959');(r/'evaluate.py').write_text(s);s=(parent/'cli.py').read_text().replace('tmp/contained-closer-components','tmp/contained-closer-spaces-wide').replace('len(selected)>=352','len(selected)>=320');(r/'cli.py').write_text(s)
