from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/contained-closer-cell-aware');out=Path('docs/benchmarks/contained-closer-components');out.mkdir(parents=True,exist_ok=True);buckets={k:{}for k in ['images','diagnostics','text']};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(kind,name,p):
 p=Path(p);assert p.is_file(),p;assert all(name not in b for b in buckets.values()),name;buckets[kind][name]=p.read_bytes()
for n in ['evaluation-manifest.json','frozen-probe.json','probe.json','audit.json','after-api.json','before-cli-binary.json','after-cli-binary.json','after-api-binary.json','probe-binary.json','capture-driver.rs','capture-visible.rs','capture-Cargo.toml','capture-Cargo.lock','spec-before.md','product-driver.rs','product-visible.rs','product-contained.rs','product-Cargo.toml','product-Cargo.lock','prepare.py','evaluate.py','cli.py','cli-selection.json','cli-before-runs.json','cli-after-runs.json','dispatch-length-audit.json','distance-change-summary.json','validation.json','package.py']:
 add('diagnostics',n,r/n)
for folder in ['truth','metrics','cli-before','cli-after']:
 for p in (r/folder).rglob('*'):
  if p.is_file():add('text',str(p.relative_to(r)),p)
for p in (r/'decoded').glob('*.png'):add('images','decoded/'+p.name,p)
for p in r.glob('*.log'):
 if not p.name.startswith('package'):add('diagnostics','logs/'+p.name,p)
m=json.loads((r/'evaluation-manifest.json').read_text())
for x in m['inputs']:
 p=Path(x['image']);assert sha(p.read_bytes())==x['image_sha256'];add('images','inputs/'+x['id']+p.suffix,p)
for label,folder in [('failed-v1','tmp/contained-closer-components'),('failed-v2','tmp/contained-closer-spaces-wide')]:
 root=Path(folder)
 for name in ['evaluation-manifest.json','frozen-probe.json','probe.json','audit.json','probe-binary.json','capture-driver.rs','capture-visible.rs','spec-before.md','prepare.py','evaluate.py']:
  add('diagnostics',label+'/'+name,root/name)
 for name in ['frozen-after-api.json','capture-Cargo.toml','capture-Cargo.lock']:
  if(root/name).is_file():add('diagnostics',label+'/'+name,root/name)
 for sub in ['truth','metrics']:
  for p in (root/sub).rglob('*'):
   if p.is_file():add('text',label+'/'+str(p.relative_to(root)),p)
 for p in root.glob('*.log'):add('diagnostics',label+'/logs/'+p.name,p)
for name in ['contained_closer_components','wide_cell_closer_spaces','cell_aware_closer_spaces']:
 for p in (Path('tests/fixtures')/name).iterdir():
  if p.is_file():add('images','fixtures/'+name+'/'+p.name,p)
add('diagnostics','specs/contained_closer_components.md','docs/contained_closer_components.md');add('diagnostics','tools/eval_ocr_metrics.py','tools/eval_ocr_metrics.py');add('diagnostics','ci-parent.json','tmp/contained-closer-components/ci-parent.json')
# The first trial predates the Unicode dependency; recover its immutable lock from the parent evidence.
parent=Path('docs/benchmarks/leading-closer-space');idx=json.loads((parent/'evidence.json').read_text());assert sha((parent/'evidence.zip').read_bytes())==idx['sha256']
with zipfile.ZipFile(parent/'evidence.zip')as z:b=z.read('Cargo.lock')
assert sha(b)==idx['members']['Cargo.lock'];assert sha(b)==json.loads((Path('tmp/contained-closer-components')/'probe-binary.json').read_text())['source_sha256']['Cargo.lock'];buckets['diagnostics']['failed-v1/Cargo.lock']=b
for kind,files in buckets.items():
 archive=out/(kind+'.zip')
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,b in sorted(files.items()):
   info=zipfile.ZipInfo(name,date_time=(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 assert archive.stat().st_size<95*1024*1024,(kind,archive.stat().st_size)
 (out/(kind+'.json')).write_text(json.dumps({'sha256':sha(archive.read_bytes()),'members':{k:sha(v)for k,v in sorted(files.items())}},indent=2)+'\n');print(kind,len(files),'members',archive.stat().st_size,'bytes')
