use super::*;
fn maximal_component_indices(boxes: &[(usize, usize, usize, usize)]) -> Vec<usize> {
    boxes
        .iter()
        .enumerate()
        .filter(|(_, child)| {
            !boxes.iter().any(|outer| {
                outer.0 < child.0 && child.1 < outer.1 && outer.2 < child.2 && child.3 < outer.3
            })
        })
        .map(|(i, _)| i)
        .collect()
}
fn collect_contained_view(rgb: &[u8], w: usize, h: usize) -> Option<(Vec<Component>, usize)> {
    let (components, height) = collect_components(rgb, w, h)?;
    let boxes: Vec<_> = components
        .iter()
        .map(|c| (c.x0, c.x1, c.y0, c.y1))
        .collect();
    let indices = maximal_component_indices(&boxes);
    let roots = components
        .into_iter()
        .enumerate()
        .filter_map(|(i, c)| indices.contains(&i).then_some(c))
        .collect();
    Some((roots, height))
}
fn grouped_edge_space(
    fragment: &str,
    components: &[Component],
    height: usize,
    leading: bool,
) -> Option<String> {
    let closer = if leading {
        fragment.chars().next()?
    } else {
        fragment.chars().last()?
    };
    if !matches!(closer, ')' | '）' | '」' | '』' | '】') {
        return None;
    }
    let body = if leading {
        let tail = &fragment[closer.len_utf8()..];
        tail.strip_prefix(' ').unwrap_or(tail)
    } else {
        let head = &fragment[..fragment.len() - closer.len_utf8()];
        head.strip_suffix(' ').unwrap_or(head)
    };
    if body.chars().count() < 3
        || body
            .chars()
            .any(|c| c.is_whitespace() || matches!(c, ')' | '）' | '」' | '』' | '】'))
    {
        return None;
    }
    let compact = if leading {
        format!("{closer}{body}")
    } else {
        format!("{body}{closer}")
    };
    let n = compact.chars().count();
    if !(supports_collected(components, height, n, None)
        || supports_collected(components, height, n, Some(&compact)))
    {
        return None;
    }
    let boxes: Vec<_> = components
        .iter()
        .map(|c| (c.x0, c.x1, c.y0, c.y1))
        .collect();
    if leading {
        compact_leading_space_from_boxes(fragment, &boxes)
    } else {
        trailing_space_from_boxes(fragment, &boxes)
    }
}
fn prototype_contained_closers(
    raw: &str,
    rgb: &[u8],
    w: usize,
    h: usize,
    orientation: ParseqOrientation,
) -> String {
    let current = sanitize_visible_single_line(raw, rgb, w, h, orientation);
    let original = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, true);
    let fragment = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, false);
    if !raw
        .chars()
        .any(|c| matches!(c, ')' | '）' | '」' | '』' | '】'))
        || fragment.chars().count() <= original.chars().count()
        || !(orientation == ParseqOrientation::Horizontal || h as u128 * 5 <= w as u128 * 4)
        || w == 0
        || h == 0
        || w.checked_mul(h).and_then(|n| n.checked_mul(3)) != Some(rgb.len())
    {
        return current;
    }
    let Some((components, height)) = collect_contained_view(rgb, w, h) else {
        return current;
    };
    if let Some(spaced) = grouped_edge_space(&fragment, &components, height, false)
        .or_else(|| grouped_edge_space(&fragment, &components, height, true))
    {
        return spaced;
    }
    if !fragment.chars().any(char::is_whitespace)
        && (supports_glyph_count(rgb, w, h, fragment.chars().count())
            || supports_collected(
                &components,
                height,
                fragment.chars().count(),
                Some(&fragment),
            ))
    {
        fragment
    } else {
        current
    }
}

#[test]
fn strict_containment_removes_only_internal_components() {
    let outer = (8, 32, 8, 36);
    let inner = (14, 22, 14, 20);
    let separate = (40, 60, 8, 36);
    assert_eq!(
        maximal_component_indices(&[outer, inner, separate]),
        vec![0, 2]
    );
    assert_eq!(
        maximal_component_indices(&[inner, (10, 30, 10, 32), outer]),
        vec![2]
    );
    assert_eq!(maximal_component_indices(&[]), Vec::<usize>::new());
    for touch in [
        (8, 22, 14, 20),
        (14, 32, 14, 20),
        (14, 22, 8, 20),
        (14, 22, 14, 36),
        (14, 35, 14, 20),
        (14, 22, 0, 4),
        outer,
    ] {
        assert_eq!(maximal_component_indices(&[outer, touch]), vec![0, 1]);
    }
    let partial = (24, 48, 8, 36);
    assert_eq!(
        maximal_component_indices(&[outer, partial, (27, 30, 14, 20)]),
        vec![0, 1]
    );
}

use proptest::prelude::*;
proptest! {
    #![proptest_config(proptest::test_runner::Config::with_cases(64))]
    #[test]
    fn containment_is_invariant_to_component_order_scale_and_translation(scale in 1usize..4,dx in 0usize..20,dy in 0usize..20,reverse in any::<bool>()) {
        let mut boxes:Vec<_>=[(8,32,8,36),(14,22,14,20),(40,64,8,36),(47,53,16,22)].into_iter().map(|(a,b,c,d)|(a*scale+dx,b*scale+dx,c*scale+dy,d*scale+dy)).collect();
        if reverse{boxes.reverse();}let mut kept:Vec<_>=maximal_component_indices(&boxes).into_iter().map(|i|boxes[i]).collect();kept.sort();
        prop_assert_eq!(kept,vec![(8*scale+dx,32*scale+dx,8*scale+dy,36*scale+dy),(40*scale+dx,64*scale+dx,8*scale+dy,36*scale+dy)]);
    }
    #[test]
    fn contained_strokes_support_closers_without_changing_rgb_or_fragment(scale in 1usize..4,dx in 0usize..8,dy in 0usize..8,tone in 0u8..180,leading in any::<bool>()) {
        let (w,h)=(140*scale+dx,48*scale+dy);let mut rgb=vec![255;w*h*3];
        let body_start=if leading{30}else{8};
        let mut fill=|x0:usize,x1:usize,y0:usize,y1:usize|{for y in y0*scale+dy..y1*scale+dy{for x in x0*scale+dx..x1*scale+dx{rgb[(y*w+x)*3..(y*w+x+1)*3].fill(tone);}}};
        for i in 0..3{let x=body_start+i*24;fill(x,x+20,8,9);fill(x,x+20,31,32);fill(x,x+1,8,32);fill(x+19,x+20,8,32);fill(x+6,x+10,15,19);}
        let close_x=if leading{8}else{body_start+2*24+20+14};fill(close_x,close_x+8,14,30);
        let original=rgb.clone();let raw=if leading{")ABC"}else{"ABC)"};let expected=if leading{") ABC"}else{"ABC )"};
        let (all,_)=collect_components(&rgb,w,h).unwrap();let (view,_)=collect_contained_view(&rgb,w,h).unwrap();prop_assert_eq!(all.len(),7);prop_assert_eq!(view.len(),4);
        prop_assert!(!supports_glyph_count(&rgb,w,h,4));prop_assert_eq!(prototype_contained_closers(raw,&rgb,w,h,ParseqOrientation::Auto),expected);
        prop_assert_eq!(sanitize_visible_repetitions(raw,&rgb,w,h,ParseqOrientation::Auto),raw);prop_assert_eq!(&rgb,&original);
    }
}

#[test]
fn contained_body_parts_can_support_a_nonspaced_two_character_body() {
    let (w, h) = (90, 48);
    let mut rgb = vec![255; w * h * 3];
    let mut fill = |x0: usize, x1: usize, y0: usize, y1: usize| {
        for y in y0..y1 {
            for x in x0..x1 {
                rgb[(y * w + x) * 3..(y * w + x + 1) * 3].fill(0);
            }
        }
    };
    for x in [8, 32] {
        fill(x, x + 20, 8, 9);
        fill(x, x + 20, 31, 32);
        fill(x, x + 1, 8, 32);
        fill(x + 19, x + 20, 8, 32);
        fill(x + 6, x + 10, 15, 19);
    }
    fill(56, 64, 14, 30);
    assert_eq!(
        sanitize_visible_single_line("AB)", &rgb, w, h, ParseqOrientation::Auto),
        "AB"
    );
    assert_eq!(
        prototype_contained_closers("AB)", &rgb, w, h, ParseqOrientation::Auto),
        "AB)"
    );
}

#[cfg(feature = "onnx")]
#[test]
#[ignore = "diagnostic; explicit frozen leading-space root"]
fn capture_contained_closer_components() {
    use crate::infer::cached::ParseqSession;
    use std::path::Path;
    let Ok(root) = std::env::var("NDLOCR_CONTAINED_CLOSER_ROOT") else {
        return;
    };
    let root = Path::new(&root);
    let read = |name: &str| -> serde_json::Value {
        serde_json::from_slice(&std::fs::read(root.join(name)).unwrap()).unwrap()
    };
    let m = read("evaluation-manifest.json");
    let frozen = read("frozen-probe.json");
    let frozen_actual = read("frozen-after-api.json");
    let inputs = m["inputs"].as_array().unwrap();
    assert_eq!(inputs.len(), 2231);
    let mut all = Vec::new();
    for (index, file) in [
        "parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx",
    ]
    .iter()
    .enumerate()
    {
        let session = ParseqSession::load(
            &Path::new("models").join(file),
            Path::new("models/NDLmoji.yaml"),
        )
        .unwrap();
        let mut rows = Vec::new();
        let mut fresh = 0;
        for input in inputs {
            let id = input["id"].as_str().unwrap();
            let image =
                crate::io::load_rgb_u8(Path::new(input["image"].as_str().unwrap())).unwrap();
            let record = if input["source"] == "fresh_holdout" {
                fresh += 1;
                let d = session
                    .recognize_rgb_u8_candidates_with_orientation(
                        &image.data,
                        image.width,
                        image.height,
                        ParseqOrientation::Auto,
                        2,
                    )
                    .unwrap();
                serde_json::json!({"raw":d.recognition.text,"mean_confidence":d.recognition.mean_confidence,"stop_reason":format!("{:?}",d.stop_reason),"steps":d.steps.iter().map(|s|serde_json::json!({"timestep":s.timestep,"range":s.text_range.as_ref().map(|r|[r.start,r.end]),"candidates":s.candidates.iter().map(|c|serde_json::json!({"token_id":c.token_id,"char":c.character,"probability":c.probability})).collect::<Vec<_>>()})).collect::<Vec<_>>()})
            } else {
                frozen["models"][index]["rows"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|x| x["id"] == id)
                    .unwrap()
                    .clone()
            };
            let raw = record["raw"].as_str().unwrap();
            let current = sanitize_visible_single_line(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            if input["source"] == "fresh_holdout" {
                let actual = session
                    .recognize_rgb_u8(&image.data, image.width, image.height)
                    .unwrap();
                assert_eq!(actual.text, current);
                assert_eq!(
                    actual.mean_confidence.to_bits(),
                    (record["mean_confidence"].as_f64().unwrap() as f32).to_bits()
                );
            } else {
                assert_eq!(current, record["prototype"].as_str().unwrap());
                let actual = frozen_actual["models"][index]["actual"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|x| x["id"] == id)
                    .unwrap();
                assert_eq!(current, actual["text"].as_str().unwrap());
                assert_eq!(
                    (record["mean_confidence"].as_f64().unwrap() as f32).to_bits(),
                    (actual["mean_confidence"].as_f64().unwrap() as f32).to_bits()
                );
            }
            let prototype = prototype_contained_closers(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            let fragment = sanitize_visible_repetitions(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            if input["source"] != "fresh_holdout" {
                assert_eq!(fragment, record["fragment"].as_str().unwrap());
            }
            let (original_components, max_height) =
                collect_components(&image.data, image.width, image.height).unwrap_or_default();
            let (contained_components, contained_height) =
                collect_contained_view(&image.data, image.width, image.height).unwrap_or_default();
            assert_eq!(max_height, contained_height);
            let compact: String = fragment.chars().filter(|c| !c.is_whitespace()).collect();
            let boxes =
                super::geometry_probe::frozen_glyph_boxes(&image.data, image.width, image.height);
            let png = root.join("decoded").join(format!("{id}.png"));
            if !png.exists() {
                std::fs::create_dir_all(png.parent().unwrap()).unwrap();
                image::RgbImage::from_raw(
                    image.width as u32,
                    image.height as u32,
                    image.data.clone(),
                )
                .unwrap()
                .save(&png)
                .unwrap();
            }
            assert_eq!(crate::io::load_rgb_u8(&png).unwrap().data, image.data);
            let truth =
                std::fs::read_to_string(Path::new(input["truth"].as_str().unwrap())).unwrap();
            rows.push(serde_json::json!({"id":id,"source":input["source"],"cohort":input["cohort"],"truth":truth,"raw":raw,"mean_confidence":record["mean_confidence"],"stop_reason":record["stop_reason"],"steps":record["steps"],"current":current,"prototype":prototype,"component_details":original_components.iter().map(|c|[c.x0,c.x1,c.y0,c.y1,c.area]).collect::<Vec<_>>(),"contained_boxes":contained_components.iter().map(|c|[c.x0,c.x1,c.y0,c.y1]).collect::<Vec<_>>(),"contained_body_support":supports_collected(&contained_components,max_height,compact.chars().count(),Some(&compact)),"legacy_support":supports_glyph_count(&image.data,image.width,image.height,fragment.chars().count()),"fragment":fragment,"text_only":sanitize_recognized_text(raw),"boxes":boxes,"width":image.width,"height":image.height}));
        }
        assert_eq!(fresh, 352);
        all.push(serde_json::json!({"label":format!("single{}",[30,50,100][index]),"model":file,"rows":rows,"fresh_raw_forwards":352,"fresh_processed_forwards":352,"reused_raw":1879}));
    }
    std::fs::write(
        root.join("probe.json"),
        serde_json::to_vec_pretty(&serde_json::json!({"models":all})).unwrap(),
    )
    .unwrap();
}
