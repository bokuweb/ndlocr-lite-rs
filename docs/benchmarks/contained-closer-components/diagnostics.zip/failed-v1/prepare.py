from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/contained-closer-components');parent=Path('docs/benchmarks/leading-closer-space');index=json.loads((parent/'evidence.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();assert sha((parent/'evidence.zip').read_bytes())==index['sha256'];inputs=[]
with zipfile.ZipFile(parent/'evidence.zip')as z:
 def read(name):
  b=z.read(name);assert sha(b)==index['members'][name],name;return b
 old=json.loads(read('evaluation-manifest.json'))
 for name,source in [('frozen-probe.json','probe.json'),('frozen-after-api.json','after-api.json')]: (r/name).write_bytes(read(source))
 for x in old['inputs']:
  id=x['id'];name='inputs/'+id+Path(x['image']).suffix;b=read(name);assert sha(b)==x['image_sha256'];p=r/name;p.parent.mkdir(exist_ok=True);p.write_bytes(b);gt=r/'truth'/(id+'.txt');gt.parent.mkdir(exist_ok=True);b=read('truth/'+id+'.txt');assert sha(b)==x['truth_sha256'];gt.write_bytes(b);inputs.append({**x,'image':str(p),'truth':str(gt),'parent_source':x['source'],'source':'reused_raw'})
f=Path('tests/fixtures/contained_closer_components');m=json.loads((f/'manifest.json').read_text());assert sha((f/'corpus.zip').read_bytes())==m['archive_sha256'];assert sha((f/'generate.py').read_bytes())==m['generator_sha256']
with zipfile.ZipFile(f/'corpus.zip')as z:
 for x in m['rows']:
  id='contained_'+x['id'];p=r/'inputs'/Path(x['image_member']).name;b=z.read(x['image_member']);assert sha(b)==x['image_sha256'];p.write_bytes(b);gt=r/'truth'/(id+'.txt');b=z.read(x['truth_member']);assert sha(b)==x['truth_sha256'];gt.write_bytes(b);inputs.append({**x,'id':id,'image':str(p),'truth':str(gt),'cohort':'contained_closer_components','source':'fresh_holdout'})
assert len(inputs)==2231
manifest={'baseline_commit':'ed453b927a08d4cfc3d51f03ffe11ca448953928','inputs':inputs,'models':old['models'],'charset_sha256':old['charset_sha256'],'parent_archive_sha256':index['sha256'],'parent_probe_sha256':sha((r/'frozen-probe.json').read_bytes()),'parent_actual_sha256':sha((r/'frozen-after-api.json').read_bytes()),'fixture_archive_sha256':m['archive_sha256'],'fixture_manifest_sha256':sha((f/'manifest.json').read_bytes()),'reused_raw':5637,'fresh_raw_forwards':1056,'fresh_processed_forwards':1056};(r/'evaluation-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('prepared2231 inputs before containment candidate evaluation')
