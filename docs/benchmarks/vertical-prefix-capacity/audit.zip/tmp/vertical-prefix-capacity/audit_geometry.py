from pathlib import Path
from PIL import Image
import json, hashlib, csv, collections

root=Path('tmp/vertical-prefix-capacity')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={row['id']:row for row in json.loads((root/'all-manifest.json').read_text())['inputs']}
records=json.loads((root/'geometry/records.json').read_text())
assert len(records)==342 and len({(row['id'],row['model']) for row in records})==342
for row in inputs.values():
    for kind in ('rgb','image','truth'):
        assert sha(row[kind])==row[kind+'_sha256']
    image=Image.open(row['image']).convert('RGB')
    assert image.size==(row['width'],row['height']) and image.tobytes()==Path(row['rgb']).read_bytes()
cuts=[]
csvrows=[]
chunk_count=0
for record in records:
    source=inputs[record['id']]
    count=0
    cut_count=0
    if record['plan']:
        image=Image.open(source['image']).convert('RGB').transpose(Image.Transpose.ROTATE_90)
        assert len(record['routes'])==2
        assert [[part['x_range'] for part in route] for route in record['routes']][0] != [[part['x_range'] for part in route] for route in record['routes']][1]
        for route,chunks in enumerate(record['routes']):
            assert len(chunks)>=2
            cursor=0
            for part in chunks:
                x0,x1=part['x_range']
                assert x0==cursor and x1>x0 and not part['space_before']
                assert (part['width'],part['height'])==(x1-x0,image.height)
                assert image.crop((x0,0,x1,image.height)).tobytes()==(root/'geometry'/part['file']).read_bytes()
                cursor=x1
                count+=1
                for glyph,box in enumerate(source.get('glyph_boxes',[])):
                    if box is not None:
                        for boundary in (x0,x1):
                            if box[1]<boundary<box[3]:
                                cuts.append({'id':source['id'],'model':record['model'],'route':route,'glyph':glyph,'bbox':box,'boundary':boundary})
                                cut_count+=1
            assert cursor==image.width
    chunk_count+=count
    csvrows.append({'id':source['id'],'model':record['model'],'cohort':source['cohort'],
                    'geometry_plan_with_dummy_capacity_text':record['plan'],
                    'routes':2 if record['plan'] else 0,'chunks':count,'glyph_cut_events':cut_count})
original=(root/'geometry/glyph-cuts.json').read_bytes()
assert cuts==json.loads(original)
assert json.dumps(cuts,indent=2,sort_keys=True,ensure_ascii=False).encode()==original
with(root/'geometry-pairs.csv').open('w',newline='')as f:
    writer=csv.DictWriter(f,fieldnames=list(csvrows[0]));writer.writeheader();writer.writerows(csvrows)
unique={tuple((row[k] for k in ('id','model','route','glyph','boundary'))) for row in cuts}
summary={'pairs':342,'source_images':114,'new_unrecognized_source_images':60,'geometry_plans_with_dummy_text':sum(row['plan'] for row in records),
         'crop_rgb_byte_verified':chunk_count,'glyph_cut_events':len(cuts),'distinct_model_route_glyph_cuts':len(unique),
         'source_rgb_with_cuts':sorted({row['id'] for row in cuts}),
         'models_loaded':0,'new_nn_calls':0,'baseline_api_calls':0,
         'decision':'reject whole prefix extension proposal before NN; production unchanged',
         'cuts_by_model':dict(collections.Counter(row['model'] for row in cuts))}
(root/'geometry-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
