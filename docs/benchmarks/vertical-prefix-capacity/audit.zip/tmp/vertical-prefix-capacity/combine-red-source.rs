//! Test-only proposal; never connected to a production recognition route.
use crate::infer::parseq::RecognizeResult;

fn combine(
    _base: &str,
    _limit: usize,
    _primary: &[RecognizeResult],
    _secondary: &[RecognizeResult],
) -> Option<RecognizeResult> {
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    fn part(text: &str, mean_confidence: f32) -> RecognizeResult {
        RecognizeResult {
            text: text.into(),
            mean_confidence,
        }
    }

    #[test]
    fn agreement_extends_the_whole_prefix_and_weights_only_the_primary_partition() {
        let primary = [part("ABCD", 0.95), part("EFGH", 0.97), part("IJ", 0.91)];
        let secondary = [
            part("AB", 0.9),
            part("CD", 1.0),
            part("EF", 0.9),
            part("GH", 1.0),
            part("IJ", 1.0),
        ];
        let actual = combine("ABCDEF", 7, &primary, &secondary).unwrap();
        assert_eq!(actual.text, "ABCDEFGHIJ");
        let expected =
            ((f64::from(0.95_f32) * 4.0 + f64::from(0.97_f32) * 4.0 + f64::from(0.91_f32) * 2.0)
                / 10.0) as f32;
        assert_eq!(actual.mean_confidence.to_bits(), expected.to_bits());
    }

    #[test]
    fn agreement_cannot_change_prefix_whitespace_or_accept_saturated_and_bad_chunks() {
        let primary = [part("ABCD", 0.95), part("EFGH", 0.97), part("IJ", 0.91)];
        for secondary in [
            vec![part("ABCD", 1.0), part("EFGHIX", 1.0)],
            vec![part("ABCD", 1.0), part("EFGHIJ", f32::NAN)],
            vec![part("ABC", 1.0), part("DEFGHIJ", 1.0)],
            vec![part("ABCDEF", 1.0), part("GHIJ", 0.899)],
            vec![part("ABCD", 1.01), part("EFGHIJ", 1.0)],
        ] {
            assert!(combine("ABCDEF", 7, &primary, &secondary).is_none());
        }
        assert!(combine("ABCDEX", 7, &primary, &primary).is_none());
        let spaces = [part("ABCD", 1.0), part("EFGHIJ ", 1.0)];
        assert!(combine("ABCDEF", 8, &spaces, &spaces).is_none());
        let same = [part("ABC", 1.0), part("DEF", 1.0)];
        assert!(combine("ABCDEF", 7, &same, &same).is_none());
        let only_spaces = [part("ABCD", 1.0), part(" ", 1.0), part("EFGHIJ", 1.0)];
        assert!(combine("ABCDEF", 7, &only_spaces, &only_spaces).is_none());
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(64))]
        #[test]
        fn prefix_and_unicode_whitespace_are_invariant(
            suffix in proptest::collection::vec(prop_oneof![Just('字'),Just('カ'),Just('。'),Just(' '),Just('\u{3000}')],1..5),
            confidence in 900u16..1001,
        ) {
            let suffix: String = suffix.into_iter().collect();
            let base = "ABCD日本語文";
            let tail = format!("日本語文{suffix}");
            let mean = confidence as f32 / 1000.0;
            let a = [part("ABCD",mean),part(&tail,mean)];
            let b = [part("AB",mean),part("CD",mean),part(&tail,mean)];
            let actual = combine(base,9,&a,&b);
            prop_assert_eq!(actual.is_some(), !suffix.chars().any(char::is_whitespace));
            if let Some(actual) = actual {
                prop_assert!(actual.text.starts_with(base));
                prop_assert_eq!(actual.text,format!("{base}{suffix}"));
            }
        }
    }
}
