from pathlib import Path
import json, hashlib, zipfile

root=Path('tmp/vertical-prefix-capacity')
public=Path('docs/benchmarks/vertical-prefix-capacity')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
selected={p for p in root.rglob('*') if p.is_file() and '__pycache__'not in p.parts
          and p.name not in ['geometry-binary','pack.stdout','pack.stderr']}
for row in json.loads((root/'all-manifest.json').read_text())['inputs']:
    selected.update(Path(row[k]) for k in ('rgb','image','truth'))
selected.update(map(Path,['docs/vertical_prefix_capacity_proposal.md',
                         'docs/benchmarks/vertical-prefix-capacity/reproduce.py',
                         'docs/benchmarks/vertical-prefix-capacity/test_reproduce.py',
                         'docs/benchmarks/vertical-prefix-capacity/README.md',
                         'tmp/vertical-output-capacity/metadata/results.json',
                         'tmp/vertical-output-capacity/models-before-load.json',
                         'proptest-regressions/infer/vertical_capacity/prefix.txt']))
assert all(not p.is_symlink() and p.suffix not in ['.onnx','.ttf','.ttc'] and p.stat().st_size<20_000_000 for p in selected)
archive=public/'audit.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
    for path in sorted(selected):
        info=zipfile.ZipInfo(path.as_posix(),date_time=(2026,10,20,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        zipped.writestr(info,path.read_bytes())
assert archive.stat().st_size<50*1024*1024
index={'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
       'uncompressed_bytes':sum(p.stat().st_size for p in selected),
       'files_sha256':{p.as_posix():sha(p)for p in sorted(selected)},
       'excluded':['ONNX models','fonts','binaries','Cargo target caches'],
       'models_loaded':0,'new_nn_calls':0,'decision':'rejected before NN: 24 glyph-cut events in five images'}
(public/'archive.json').write_text(json.dumps(index,indent=2)+'\n')
print(len(selected),'files;',archive.stat().st_size,'compressed bytes')
