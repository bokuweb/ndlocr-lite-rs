from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import hashlib, json, datetime, unicodedata, re

root = Path('tmp/vertical-prefix-capacity')
data = root / 'inputs'
data.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
texts = [
    (31, '朝の港では小さな船が静かに岸を離れ漁師たちは沖に向かって手を振っていました。'),
    (35, '図書室の窓から庭の木々を眺めました。　新しい本の題名を帳面に書き友人と話しました。'),
    (47, '公園の入口には三本の大きな木があり二人の子どもが落ち葉を集めていました。風が吹くたびに黄色い葉が道に舞います。'),
    (51, '午後になると雨が上がり商店街には買物をする人々が戻ってきました。店の前で花を選んだ後に広場の椅子で休みました。'),
    (63, '山道を歩く間に見つけた鳥の姿と川の流れる音を日記に記しました。帰りは別の道を通り古い橋の上から夕日の色を見ました。家では温かいお茶を飲み写真を整理しました。'),
    (103, '海沿いの町で開かれた小さな展覧会を訪ねました。入口で案内図を受け取り最初の部屋から順に作品を見て回りました。二階の窓からは遠くの灯台が見えました。帰る前に展示の感想を帳面へ書き込み駅まで歩きました。途中でパンを買い電車の席に座って今日見た景色を思い出しました。'),
]
fonts = [('arial',Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))]
for label, name in [('bold','ヒラギノ角ゴシック W6.ttc'),('serif','ヒラギノ明朝 ProN.ttc')]:
    path, = [p for p in Path('/System/Library/Fonts').iterdir() if unicodedata.normalize('NFC',p.name)==name]
    fonts.append((label,path))
assert len(texts)==6 and all(len(text)>=length for length,text in texts)
config = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'font_size':48,'advance':52,
          'fonts':[{'label':label,'path':str(path),'sha256':sha(path),'index':0} for label,path in fonts],
          'text_rule':'first N Unicode scalars, no changes after inference',
          'paragraphs':[{'length':length,'source':text,'truth':text[:length]} for length,text in texts],
          'padding':[0,8], 'negative_groups':[35,65], 'negative_advance':56,
          'negative_patterns':['zigzag','brush','cross','ladder'],
          'backgrounds':{'white':[255,255,255],'warm':[245,238,219],'gray':[190,190,190]},
          'spec_sha256':sha('docs/vertical_prefix_capacity_proposal.md'), 'generator_sha256':sha(__file__),
          'image_nn_calls_so_far':0}
(root/'generation-before-render.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
inputs=[]
def save(name,image,truth,cohort,**extra):
    png,rgb,txt=[data/(name+suffix) for suffix in ('.png','.rgb','.txt')]
    image.save(png)
    rgb.write_bytes(image.tobytes())
    txt.write_text(truth)
    assert Image.open(png).convert('RGB').tobytes()==rgb.read_bytes()
    inputs.append({'id':name,'image':str(png),'image_sha256':sha(png),'rgb':str(rgb),'rgb_sha256':sha(rgb),
                   'truth':str(txt),'truth_sha256':sha(txt),'width':image.width,'height':image.height,
                   'cohort':cohort,**extra})

for label,path in fonts:
    font=ImageFont.truetype(str(path),48,index=0)
    for length,source in texts:
        truth=source[:length]
        for padding in (0,8):
            w,h=56+2*padding,length*52+16+2*padding
            image=Image.new('RGB',(w,h),'white')
            boxes=[]
            for index,char in enumerate(truth):
                glyph=Image.new('L',(w,64),0)
                ink=ImageDraw.Draw(glyph)
                box=font.getbbox(char)
                gw,gh=box[2]-box[0],box[3]-box[1]
                assert gw<=48 and gh<=52,(label,char,box)
                ink.text(((w-gw)//2-box[0],-box[1]),char,font=font,fill=255)
                actual=glyph.getbbox()
                top=8+padding+index*52
                if actual:
                    image.paste((0,0,0),(0,top),glyph)
                    boxes.append([actual[0],actual[1]+top,actual[2],actual[3]+top])
                else:
                    assert char.isspace(),(char,label)
                    boxes.append(None)
            save(f'prefix_{label}_{length}_pad{padding}',image,truth,'new_known_font_text',font=label,
                 font_sha256=sha(path),glyph_boxes=boxes,padding=padding)

for background,color in config['backgrounds'].items():
    for groups in (35,65):
        for pattern in config['negative_patterns']:
            image=Image.new('RGB',(56,groups*56+16),tuple(color))
            draw=ImageDraw.Draw(image)
            for group in range(groups):
                y=8+group*56
                if pattern=='zigzag':
                    draw.line([(8,y),(47,y+14),(8,y+29),(47,y+45)],fill=(35,39,43),width=3)
                elif pattern=='brush':
                    draw.line([(8,y+2),(17,y+15),(30,y+22),(41,y+33),(47,y+45)],fill=(35,39,43),width=5)
                    draw.line([(11,y+4),(10,y+36),(36,y+42)],fill=(35,39,43),width=3)
                elif pattern=='cross':
                    draw.line([(8,y),(47,y+45)],fill=(35,39,43),width=3)
                    draw.line([(47,y),(8,y+45)],fill=(35,39,43),width=3)
                    draw.line([(8,y+22),(47,y+22)],fill=(35,39,43),width=2)
                else:
                    draw.line([(8,y),(8,y+45),(47,y+45),(47,y)],fill=(35,39,43),width=3)
                    for offset in (0,12,24,36):
                        draw.line([(8,y+offset),(47,y+offset)],fill=(35,39,43),width=2)
            save(f'prefix_{background}_{pattern}_{groups}',image,'','new_drawn_diagnostic_negative',
                 background=background,pattern=pattern,groups=groups,truth_convention='empty text for drawn non-letter controls')
assert len(inputs)==60 and sum(row['cohort']=='new_known_font_text' for row in inputs)==36
old_hashes=set()
checked=[]
for path in sorted(Path('docs/benchmarks').rglob('*.json')):
    old_hashes.update(re.findall(r'\b[0-9a-f]{64}\b',path.read_text()))
    checked.append({'path':str(path),'sha256':sha(path)})
for path in sorted(Path('tests/fixtures').rglob('*.png')):
    old_hashes.add(sha(path))
    old_hashes.add(hashlib.sha256(Image.open(path).convert('RGB').tobytes()).hexdigest())
    checked.append({'path':str(path),'sha256':sha(path)})
new_hashes=[row[k] for row in inputs for k in ('image_sha256','rgb_sha256')]
assert len(set(new_hashes))==120 and not set(new_hashes)&old_hashes
(root/'new-manifest.json').write_text(json.dumps({'inputs':inputs},ensure_ascii=False,indent=2)+'\n')
old=json.loads(Path('tmp/vertical-output-capacity/stop-audit/prepared/manifest-30.json').read_text())['inputs']
for row in old:
    row.pop('expected_raw')
assert len(old)==54
(root/'all-manifest.json').write_text(json.dumps({'inputs':old+inputs},ensure_ascii=False,indent=2)+'\n')
(root/'generation-complete.json').write_text(json.dumps({'new_inputs':60,'new_text':36,'new_shapes':24,
    'known_inputs':54,'total':114,'all_png_rgb_byte_equal':True,'prior_index_and_fixture_files':checked,
    'prior_sha_values':len(old_hashes),'new_image_rgb_sha_duplicates':0,'new_nn_calls':0},indent=2)+'\n')
contact=Image.new('RGB',(960,1640),'white')
draw=ImageDraw.Draw(contact)
for index,row in enumerate(inputs):
    x,y=(index%12)*80,(index//12)*328
    draw.text((x+2,y+2),row['id'].replace('prefix_','')[:12],fill='black')
    image=Image.open(row['image'])
    image.thumbnail((74,300))
    contact.paste(image,(x+(80-image.width)//2,y+22))
contact.save(root/'contact.png')
print('60 new RGB inputs and GT frozen before NN; 36 text,24 shapes; all114 retained')
