from pathlib import Path
import json, subprocess, hashlib, shutil, os, datetime, time

root=Path('tmp/vertical-prefix-capacity')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='447532b57adb528ad83467ee41c259cc2a24255c'
for path in subprocess.check_output(['git','ls-files','src','tests','examples'],text=True).splitlines():
    if path.endswith('.rs'):
        actual=Path(path).read_bytes()
        if path=='src/infer/vertical_capacity.rs':
            declaration=b'#[cfg(test)]\nmod prefix;\n'
            assert actual.count(declaration)==1
            actual=actual.replace(declaration,b'',1)
        assert actual==subprocess.check_output(['git','show','HEAD:'+path]),path
manifest=root/'all-manifest.json'
inputs=json.loads(manifest.read_text())['inputs']
assert len(inputs)==114
for row in inputs:
    for kind in ('rgb','image','truth'):
        assert sha(row[kind])==row[kind+'_sha256']
events=[json.loads(line) for line in (root/'geometry-build.jsonl').read_text().splitlines()]
assert any(x.get('reason')=='build-finished' and x['success'] for x in events)
exe,=[x['executable'] for x in events if x.get('reason')=='compiler-artifact' and x.get('executable') and 'lib'in x['target']['kind']]
binary=root/'geometry-binary'
shutil.copy2(exe,binary)
files={str(p) for directory in ('src','tests','examples') for p in Path(directory).rglob('*.rs')}
files.update(str(root/x) for x in ('generate.py','generation-before-render.json','generation-complete.json','new-manifest.json','all-manifest.json','run_geometry.py'))
files.update(['Cargo.toml','Cargo.lock','docs/vertical_prefix_capacity_proposal.md',str(binary),
              'tmp/vertical-output-capacity/metadata/results.json'])
for row in inputs:
    files.update(row[k] for k in ('rgb','image','truth'))
hashes={path:sha(path) for path in sorted(files)}
freeze={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'files_sha256':hashes,
        'production_sources_identical_except_cfg_test_declaration':True,'all114_input_hashes_verified':True,
        'contact_review':'all60 fixed text/shape layouts reviewed before geometry and NN',
        'model_loads':0,'session_run_calls':0,'image_recognition_calls':0}
(root/'freeze-before-geometry.json').write_text(json.dumps(freeze,indent=2)+'\n')
argv=[str(binary.resolve()),'infer::vertical_capacity::prefix::capture::record_two_partition_geometry_without_nn','--exact','--ignored','--nocapture']
env={'NDLOCR_PREFIX_MANIFEST':str(manifest),'NDLOCR_PREFIX_METADATA':'tmp/vertical-output-capacity/metadata/results.json',
     'NDLOCR_PREFIX_OUTPUT':str(root/'geometry')}
started=time.monotonic()
with(root/'geometry.stdout').open('wb')as out,(root/'geometry.stderr').open('wb')as err:
    process=subprocess.run(argv,env=os.environ|env,stdout=out,stderr=err)
assert all(sha(p)==h for p,h in hashes.items())
receipt={'argv':argv,'env':env,'exit_code':process.returncode,'seconds':time.monotonic()-started,
         'all_inputs_sources_unchanged':True,'model_loads':0,'session_run_calls':0,'image_recognition_calls':0}
(root/'geometry-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(process.returncode)
