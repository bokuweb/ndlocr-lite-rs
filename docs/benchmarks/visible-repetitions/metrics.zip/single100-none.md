# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `263`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 263 | 0 | 0.7868 | 0.7747 |
| before | 263 | 0 | 0.8028 | 0.8118 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
