# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `263`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 263 | 0 | 0.9148 | 0.8792 |
| before | 263 | 0 | 0.9342 | 0.9292 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
