# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 287 | 0 | 0.1869 | 0.5638 |
| before | 287 | 0 | 0.1937 | 0.6107 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
