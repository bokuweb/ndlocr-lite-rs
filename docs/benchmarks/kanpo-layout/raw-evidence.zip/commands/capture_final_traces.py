from pathlib import Path
import json,hashlib,subprocess
root=Path('/Volumes/ssd/ndlocr-kanpo-layout-evidence');out=root/'after-traces';out.mkdir()
sources=[('manifest.json','adaptive-run'),('confirmation-manifest.json','adaptive-confirmation-run'),('final-holdout-manifest.json','independent-adaptive-run')]
audit=[]
for manifest_name,run in sources:
 m=json.loads((Path('tests/fixtures/kanpo_layout')/manifest_name).read_text())
 for sample in m['samples']:
  stem=out/sample['id'];command=['tmp/kanpo-layout/adaptive-bin','recognize-page','--image',sample['image'],'--charset','models/NDLmoji.yaml','--structure-rules=false','--trace-json',str(stem)+'.json','--output-txt',str(stem)+'.txt']
  r=subprocess.run(command,capture_output=True);Path(str(stem)+'.stdout').write_bytes(r.stdout);Path(str(stem)+'.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
  raw=Path(str(stem)+'.txt').read_bytes();expected=(root/run/f"{sample['id']}-ndlocr-0/recognized.txt").read_bytes();assert raw==expected,sample['id'];assert r.stdout==raw+b'\n'
  t=json.loads(Path(str(stem)+'.json').read_text());s=t['stages'];row={'sample':sample['id'],'command':command,'image_sha256':sample['sha256'],'prediction_sha256':hashlib.sha256(raw).hexdigest(),'reason':s['detection']['selection_reason'],'deim_candidates':len(s['detection']['lines']),'columns':s['horizontal_columns'],'stages':{k:len(v) for k,v in s.items() if isinstance(v,list)}}
  if 'truth' in sample:row['annotated_physical_lines']=len(sample['truth'].splitlines())
  audit.append(row);(out/'report.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print(row['sample'],row['reason'],row['stages']['prepared'],row.get('annotated_physical_lines'),flush=True)
control=root/'vertical-control';control.mkdir();image=Path('tests/fixtures/kanpo_layout/vertical-control.png');before=image.read_bytes();rows=[]
for name,binary in [('before','tmp/kanpo-layout/baseline-bin'),('after','tmp/kanpo-layout/adaptive-bin')]:
 command=[binary,'recognize-page','--image',str(image),'--charset','models/NDLmoji.yaml','--structure-rules=false','--output-txt',str(control/f'{name}.txt')]
 if name=='after':command+=['--trace-json',str(control/'after.json')]
 r=subprocess.run(command,capture_output=True);assert r.returncode==0,r.stderr
 (control/f'{name}.stdout').write_bytes(r.stdout);(control/f'{name}.stderr').write_bytes(r.stderr)
 rows.append({'name':name,'command':command,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'prediction_sha256':hashlib.sha256((control/f'{name}.txt').read_bytes()).hexdigest()})
assert (control/'before.txt').read_bytes()==(control/'after.txt').read_bytes();assert image.read_bytes()==before
(control/'report.json').write_text(json.dumps({'source_sha256':hashlib.sha256(before).hexdigest(),'byte_identical':True,'runs':rows},indent=2)+'\n');print('vertical control byte-identical',flush=True)
