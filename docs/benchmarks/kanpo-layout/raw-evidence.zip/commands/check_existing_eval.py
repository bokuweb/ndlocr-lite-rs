from pathlib import Path
import json, subprocess, hashlib, sys
sys.path.insert(0,'tools')
from eval_ocr_metrics import normalize_text, levenshtein
out=Path('/Volumes/ssd/ndlocr-kanpo-layout-evidence/existing-eval');out.mkdir()
rows=[]
for image in sorted(Path('tests/fixtures/eval/images').glob('*.png')):
 truth_path=Path('tests/fixtures/eval/truth')/(image.stem+'.txt')
 if not truth_path.exists(): print('missing truth',truth_path,flush=True);continue
 truth=truth_path.read_text()
 for mode,binary in [('baseline','tmp/kanpo-layout/baseline-bin'),('adaptive','tmp/kanpo-layout/adaptive-bin')]:
  stem=out/f'{image.stem}-{mode}'
  command=[binary,'recognize-page','--image',str(image),'--charset','models/NDLmoji.yaml','--structure-rules=false','--output-txt',str(stem)+'.txt']
  r=subprocess.run(command,capture_output=True);(Path(str(stem)+'.stdout')).write_bytes(r.stdout);(Path(str(stem)+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,r.stderr
  raw=Path(str(stem)+'.txt').read_bytes();prediction=raw.decode()
  row={'sample':image.stem,'mode':mode,'command':command,'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'truth_sha256':hashlib.sha256(truth_path.read_bytes()).hexdigest(),'prediction_sha256':hashlib.sha256(raw).hexdigest()}
  for normalize in ['none','strict']:
   a,b=normalize_text(truth,normalize),normalize_text(prediction,normalize);row[normalize]={'edits':levenshtein(list(a),list(b)),'characters':len(a)}
  rows.append(row);(out/'report.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(row['sample'],mode,row['strict'],flush=True)
