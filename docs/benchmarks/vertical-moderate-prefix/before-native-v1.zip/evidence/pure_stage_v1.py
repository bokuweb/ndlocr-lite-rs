from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys
repo=Path.cwd();p=Path(__file__).resolve().parent;src=p/'source-candidate';sys.path.insert(0,str(repo/'tools'));from root_source_coverage import source_files
stage=sys.argv[1];assert re.fullmatch('[a-z0-9-]+',stage);filter_name=sys.argv[2] if len(sys.argv)>2 else 'infer::vertical_capacity::prefix::';no_run='--no-run' in sys.argv
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();sources=source_files(src)
for name in sources:
 if name.endswith('.rs'):os.utime(src/name,None)
env=os.environ|{'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_TEST_STRIP':'none','CARGO_PROFILE_DEV_STRIP':'none'}
argv=['/Users/bokuweb/Library/Application Support/mbx/bin/cargo','test','--locked','--lib','--message-format=json']
if no_run:argv+=['--no-run']
else:argv += [filter_name,'--','--nocapture']
meta={'source_files':sources,'argv':argv,'helper_sha256':sha(__file__),'NN_calls':0,'complete':False};(p/(stage+'-before.json')).write_text(json.dumps(meta,indent=2)+'\n')
stdout=p/(stage+'.stdout');stderr=p/(stage+'.stderr')
with stdout.open('xb') as out,stderr.open('xb') as err:result=subprocess.run(argv,cwd=src,env=env,stdout=out,stderr=err)
meta.update(exit_code=result.returncode,source_files_after_unchanged=source_files(src)==sources)
if result.returncode==0:
 events=[json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')];own,=[e for e in events if e.get('reason')=='compiler-artifact' and e.get('manifest_path')==str(src/'Cargo.toml')];assert own['fresh'] is False and 'onnx' not in own['features']
 if not no_run:assert re.search(r'test result: ok\. [1-9][0-9]* passed; 0 failed;',stdout.read_text())
 executable=Path(own['executable']);dest=p/(stage+'-binary');assert not dest.exists();shutil.copy2(executable,dest);assert sha(dest)==sha(executable)
 meta.update(compiler_artifact=own,binary_path=str(dest),binary_sha256=sha(dest),binary_bytes=dest.stat().st_size,stdout_sha256=sha(stdout),complete=True)
assert meta['source_files_after_unchanged']
(p/(stage+'-frozen.json')).write_text(json.dumps(meta,indent=2)+'\n');assert result.returncode==0
print(json.dumps({'stage':stage,'source_files':len(sources),'own_fresh':False,'binary_sha256':meta['binary_sha256'],'NN_calls':0}),flush=True)
