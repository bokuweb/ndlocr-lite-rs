from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
repo=Path.cwd();p=Path(__file__).resolve().parent;sys.path.insert(0,str(repo/'tools'));from root_source_coverage import source_files
from moderate_prefix_matrix_scope import matrix_scope
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((p/'native-pair-frozen-v1.json').read_text());rows=json.loads((p/'new-manifest-v2.json').read_text())['inputs'];scope=matrix_scope([r['id'] for r in rows]);assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets']
models=[{'label':label,'path':str(repo/'models'/assets[label]['name']),'sha256':assets[label]['sha256']} for label in scope['models']]
manifest={'models':models,'expected_per_model':72,'cases':[{'id':r['id'],'label':m['label'],'rgb':r['rgb'],'width':r['width'],'height':r['height']} for m in models for r in rows]}
assert all(set(c)=={'id','label','rgb','width','height'} for c in manifest['cases'])
manifest_path=p/'native-manifest-v1.json';write(manifest_path,manifest);output=p/'native-matrix-v1'
bindings={}
for variant,meta in frozen.items():
 src=p/('source-'+variant);assert source_files(src)==meta['source_files']
 bindings.update({str(src/n):h for n,h in meta['source_files'].items()});bindings[meta['path']]=meta['sha256']
for m in models:bindings[m['path']]=m['sha256']
bindings[str(repo/'models'/assets['charset']['name'])]=assets['charset']['sha256']
for row in rows:
 for key in ['image','rgb','truth']:bindings[row[key]]=row[key+'_sha256']
extra=[Path(__file__),p/'native-pair-frozen-v1.json',manifest_path,p/'new-manifest-v2.json',repo/'docs/vertical_moderate_prefix_proposal.md',repo/'docs/vertical_moderate_prefix_native.md',repo/'docs/vertical_moderate_prefix_api_scope.md',repo/'tools/moderate_prefix_matrix_scope.py',repo/'tools/moderate_prefix_native_metrics.py',repo/'tools/eval_ocr_metrics.py',repo/'tools/verify_low_stop_evidence.py',repo/'docs/benchmarks/vertical-partition-agreement/fast_distance.py',p/'score_native_matrix_v1.py']
for path in extra:bindings[str(path)]=sha(path)
commands=[]
for variant in scope['variants']:
 for model in models:
  label=variant+'-'+model['label'];commands.append({'label':label,'variant':variant,'model':model['label'],'argv':[frozen[variant]['path'],'--ignored','--exact','infer::vertical_capacity::native::matrix::capture_all_uncertain_native_routes_without_gt','--nocapture','--test-threads=1'],'env':{'NDLOCR_UNCERTAIN_MATRIX_MANIFEST':str(manifest_path),'NDLOCR_UNCERTAIN_MATRIX_MODEL':model['label'],'NDLOCR_UNCERTAIN_MATRIX_OUTPUT':str(output/label),'NDLOCR_TEST_CHARSET':str(repo/'models'/assets['charset']['name']),'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1'}})
meta={'files_sha256':bindings,'scope':scope,'commands_planned':commands,'commands':[],'GT_or_expected_predictions_supplied_to_recognizer':False,'NN_calls_at_freeze':0,'internal_session_run_calls':None,'complete':False}
if '--prepare' in sys.argv:
 assert all(sha(n)==h for n,h in bindings.items());write(p/'native-before-NN-v1.json',meta);print(json.dumps({'prepared':True,'commands':6,'image_results':3456,'NN_calls':0}));sys.exit(0)
pre=json.loads((p/'native-before-NN-v1.json').read_text());assert pre==meta and all(sha(n)==h for n,h in bindings.items())
assert not output.exists();output.mkdir();print(json.dumps({'started':True,'scope':scope}),flush=True)
def run(command):
 assert all(sha(n)==h for n,h in bindings.items());started=time.monotonic();label=command['label']
 with (output/(label+'.stdout')).open('xb') as out,(output/(label+'.stderr')).open('xb') as err:result=subprocess.run(command['argv'],cwd=repo,env=os.environ|command['env'],stdout=out,stderr=err)
 receipt=command|{'exit_code':result.returncode,'seconds':time.monotonic()-started,'frozen_files_after_unchanged':all(sha(n)==h for n,h in bindings.items())};write(output/(label+'-command.json'),receipt);return receipt
try:
 with ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(run,c) for c in commands]
  for future in as_completed(futures):
   receipt=future.result();meta['commands'].append(receipt);write(p/'native-job-v1.json',meta);print(json.dumps({'finished':receipt['label'],'exit_code':receipt['exit_code']}),flush=True)
 assert len(meta['commands'])==6 and all(c['exit_code']==0 and c['frozen_files_after_unchanged'] for c in meta['commands'])
 for command in commands:
  summary=json.loads((output/command['label']/'summary.json').read_text());assert summary['inputs']==72 and summary['image_results']==576 and summary['outer_image_API_calls']==434 and summary['API_errors']==0 and summary['fragment_single_batch_exclusive_equal'];assert '1 passed; 0 failed;' in (output/(command['label']+'.stdout')).read_text()
 meta['complete']=True
finally:write(p/'native-job-v1.json',meta)
print(json.dumps({'complete':True,'image_results':3456,'outer_APIs':2604,'internal_session_run_calls':None}),flush=True)
