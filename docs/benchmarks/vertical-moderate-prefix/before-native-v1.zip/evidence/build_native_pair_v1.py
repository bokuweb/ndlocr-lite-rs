from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
repo=Path.cwd();p=Path(__file__).resolve().parent;sys.path.insert(0,str(repo/'tools'));from root_source_coverage import source_files
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();copy=json.loads((p/'source-copies-before-implementation-v1.json').read_text());assert copy['Root_all5success']
env=os.environ|{'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_TEST_STRIP':'none','CARGO_PROFILE_DEV_STRIP':'none'}
frozen={}
for variant in ['baseline','candidate']:
 src=p/('source-'+variant);sources=source_files(src)
 if variant=='baseline':assert sources==copy['source_files']
 for name in sources:
  if name.endswith('.rs'):os.utime(src/name,None)
 argv=['/Users/bokuweb/Library/Application Support/mbx/bin/cargo','test','--locked','--features','onnx','--lib','--no-run','--message-format=json'];stdout=p/f'native-{variant}-build-v1.jsonl';stderr=p/f'native-{variant}-build-v1.stderr'
 (p/f'native-{variant}-before-build-v1.json').write_text(json.dumps({'source_files':sources,'argv':argv,'NN_calls':0},indent=2)+'\n')
 with stdout.open('xb') as out,stderr.open('xb') as err:subprocess.run(argv,cwd=src,env=env,stdout=out,stderr=err,check=True)
 events=[json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')];own,=[e for e in events if e.get('reason')=='compiler-artifact' and e.get('manifest_path')==str(src/'Cargo.toml')];assert own['fresh'] is False and 'onnx' in own['features'] and own['executable']
 executable=Path(own['executable']);dest=p/f'native-{variant}-binary-v1';assert not dest.exists();shutil.copy2(executable,dest);assert sha(executable)==sha(dest) and source_files(src)==sources
 frozen[variant]={'source_files':sources,'compiler_artifact':own,'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'build_stdout_sha256':sha(stdout),'NN_calls':0}
 (p/'native-pair-frozen-progress-v1.json').write_text(json.dumps(frozen,indent=2)+'\n')
assert frozen['baseline']['sha256']!=frozen['candidate']['sha256']
(p/'native-pair-frozen-v1.json').write_text(json.dumps(frozen,indent=2)+'\n');print(json.dumps({v:{k:m[k] for k in ['bytes','sha256']} for v,m in frozen.items()}),flush=True)
