use super::*;

fn column() -> (Vec<u8>, usize, usize) {
    let (width, height) = (14, 43 * 14 + 16);
    let mut rgb = vec![255; width * height * 3];
    for group in 0..43 {
        for y in 8 + group * 14..18 + group * 14 {
            for x in 2..12 {
                let p = (y * width + x) * 3;
                rgb[p..p + 3].copy_from_slice(&[group as u8, 40, 60]);
            }
        }
    }
    (rgb, width, height)
}

fn plan() -> (Vec<u8>, usize, Plans) {
    let (rgb, width, height) = column();
    let base = RecognizeResult {
        text: "ABCDEF".into(),
        mean_confidence: 1.0,
    };
    let plan = plans(&base, &rgb, (width, height), (256, 24), Some(7)).unwrap();
    (rgb, width, plan)
}

#[test]
fn shared_reader_visits_both_routes_once_in_order_with_original_rgb() {
    let (rgb, width, plan) = plan();
    let expected: Vec<_> = plan
        .routes
        .iter()
        .flat_map(|chunks| chunks.iter())
        .collect();
    let mut calls = 0;
    let parts = read_plan_parts(&plan, |pixels, cw, ch| {
        let chunk = expected[calls];
        assert_eq!((cw, ch), (chunk.x1 - chunk.x0, width));
        for y in 0..ch {
            for x in 0..cw {
                let source = ((chunk.x0 + x) * width + (width - 1 - y)) * 3;
                let target = (y * cw + x) * 3;
                assert_eq!(&pixels[target..target + 3], &rgb[source..source + 3]);
            }
        }
        let text = format!("part{calls}");
        calls += 1;
        Ok(RecognizeResult {
            text,
            mean_confidence: 0.95,
        })
    })
    .unwrap();
    assert_eq!(parts.each_ref().map(Vec::len), [3, 5]);
    assert_eq!(calls, 8);
    assert_eq!(
        parts
            .into_iter()
            .flatten()
            .map(|r| r.text)
            .collect::<Vec<_>>(),
        (0..8).map(|i| format!("part{i}")).collect::<Vec<_>>()
    );
}

#[test]
fn shared_reader_stops_at_the_first_error_without_later_callbacks() {
    let (_, _, plan) = plan();
    let mut calls = 0;
    let result = read_plan_parts(&plan, |_, _, _| {
        calls += 1;
        if calls == 4 {
            return Err(anyhow::anyhow!("recorded part error"));
        }
        Ok(RecognizeResult {
            text: "part".into(),
            mean_confidence: 0.95,
        })
    });
    assert!(result.is_none());
    assert_eq!(calls, 4);
}

#[test]
fn invalid_crop_never_calls_the_reader() {
    let (_, _, mut plan) = plan();
    plan.column.original.truncate(5);
    let mut calls = 0;
    let result = read_plan_parts(&plan, |_, _, _| {
        calls += 1;
        Ok(RecognizeResult {
            text: "part".into(),
            mean_confidence: 0.95,
        })
    });
    assert!(result.is_none());
    assert_eq!(calls, 0);
}
