use super::*;
use crate::infer::parseq::RecognizeResult;

#[test]
fn first_success_preserves_h_then_o_then_r_priority_without_later_attempts() {
    for accepted in [
        RecoveryStage::Short,
        RecoveryStage::Capacity,
        RecoveryStage::Moderate,
    ] {
        let mut attempts = Vec::new();
        let result = recover_in_order(true, |stage| {
            attempts.push(stage);
            (stage == accepted).then(|| RecognizeResult {
                text: format!("{stage:?}"),
                mean_confidence: 0.95,
            })
        })
        .unwrap();
        assert_eq!(result.text, format!("{accepted:?}"));
        let expected = match accepted {
            RecoveryStage::Short => vec![RecoveryStage::Short],
            RecoveryStage::Capacity => vec![RecoveryStage::Short, RecoveryStage::Capacity],
            RecoveryStage::Moderate => vec![
                RecoveryStage::Short,
                RecoveryStage::Capacity,
                RecoveryStage::Moderate,
            ],
        };
        assert_eq!(attempts, expected);
    }
}

#[test]
fn unavailable_frame_shape_keeps_h_but_never_attempts_o_or_r() {
    let mut attempts = Vec::new();
    let result = recover_in_order(false, |stage| {
        attempts.push(stage);
        None
    });
    assert!(result.is_none());
    assert_eq!(attempts, [RecoveryStage::Short]);
    let result = recover_in_order(false, |stage| {
        assert_eq!(stage, RecoveryStage::Short);
        Some(RecognizeResult {
            text: "short".into(),
            mean_confidence: 0.95,
        })
    });
    assert_eq!(result.unwrap().text, "short");
}

#[test]
fn fragment_bridge_delegates_to_moderate_recovery_with_the_borrowed_callback() {
    let (width, height) = (14, 43 * 14 + 16);
    let mut rgb = vec![255; width * height * 3];
    for group in 0..43 {
        for y in 8 + group * 14..18 + group * 14 {
            for x in 2..12 {
                let p = (y * width + x) * 3;
                rgb[p..p + 3].fill(0);
            }
        }
    }
    let raw = RecognizeResult {
        text: "ABCDEFGHIJKLMNOPQ".into(),
        mean_confidence: 0.95,
    };
    let texts = [
        "ABCDEFGH", "IJKLMNOP", "QRSTUVWX", "ABCD", "EFGHI", "JKLMN", "OPQRS", "TUVWX",
    ];
    let mut calls = 0;
    let result = recover_moderate(
        &raw,
        &rgb,
        (width, height),
        (256, 24),
        Some(31),
        |_, _, _| {
            let text = texts[calls].to_owned();
            calls += 1;
            Ok(RecognizeResult {
                text,
                mean_confidence: 0.95,
            })
        },
    )
    .unwrap();
    assert_eq!(result.text, "ABCDEFGHIJKLMNOPQRSTUVWX");
    assert_eq!(calls, 8);
    assert_eq!(result.mean_confidence.to_bits(), 0.95f32.to_bits());
}
