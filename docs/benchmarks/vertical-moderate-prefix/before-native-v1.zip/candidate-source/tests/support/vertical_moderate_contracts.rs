use super::*;
use proptest::prelude::*;

fn base(text: String, mean_confidence: f32) -> RecognizeResult {
    RecognizeResult {
        text,
        mean_confidence,
    }
}

#[test]
fn moderate_raw_range_starts_after_h_and_stops_before_o() {
    for (count, expected) in [
        (16, None),
        (17, Some(40)),
        (20, Some(40)),
        (21, Some(42)),
        (29, Some(58)),
        (30, None),
        (31, None),
    ] {
        let rule = moderate_rule(&base("界".repeat(count), 0.95), Some(31));
        assert_eq!(rule.as_ref().map(|r| r.minimum_anchors), expected);
        if let Some(rule) = rule {
            assert_eq!((rule.minimum, rule.maximum), (17, 29));
        }
    }
    for limit in [None, Some(0), Some(1), Some(2), Some(18)] {
        assert!(moderate_rule(&base("界".repeat(17), 0.95), limit).is_none());
    }
    let rule = moderate_rule(&base("界".repeat(17), 0.95), Some(19)).unwrap();
    assert_eq!(
        (rule.minimum, rule.maximum, rule.minimum_anchors),
        (17, 17, 40)
    );
}

#[test]
fn invalid_raw_confidence_and_trailing_unicode_whitespace_are_rejected() {
    for mean in [f32::NAN, f32::INFINITY, f32::NEG_INFINITY, -0.01, 1.01] {
        assert!(moderate_rule(&base("界".repeat(17), mean), Some(31)).is_none());
    }
    for trailing in [' ', '\n', '\u{3000}', '\u{a0}'] {
        assert!(
            moderate_rule(
                &base(format!("{}{trailing}", "界".repeat(16)), 0.95),
                Some(31)
            )
            .is_none()
        );
    }
    for mean in [0.0, 1.0] {
        assert!(moderate_rule(&base("界".repeat(17), mean), Some(31)).is_some());
    }
}

#[test]
fn anchor_requirement_checks_multiplication_before_using_the_count() {
    assert_eq!(minimum_required_anchors(0), Some(40));
    assert_eq!(minimum_required_anchors(20), Some(40));
    assert_eq!(minimum_required_anchors(21), Some(42));
    assert_eq!(
        minimum_required_anchors(usize::MAX / 2),
        Some(usize::MAX - 1)
    );
    assert_eq!(minimum_required_anchors(usize::MAX / 2 + 1), None);
    assert_eq!(minimum_required_anchors(usize::MAX), None);
}

fn column(groups: usize) -> (Vec<u8>, usize, usize) {
    let (width, height) = (14, groups * 14 + 16);
    let mut rgb = vec![255; width * height * 3];
    for group in 0..groups {
        for y in 8 + group * 14..18 + group * 14 {
            for x in 2..12 {
                let p = (y * width + x) * 3;
                rgb[p..p + 3].copy_from_slice(&[group as u8, 40, 60]);
            }
        }
    }
    (rgb, width, height)
}

#[test]
fn moderate_plans_need_at_least_forty_and_double_the_raw_glyph_anchors() {
    for (count, groups, expected) in [
        (17, 39, false),
        (17, 40, true),
        (21, 41, false),
        (21, 42, true),
    ] {
        let (rgb, width, height) = column(groups);
        let old = base("界".repeat(30), 0.95);
        assert!(
            plans(&old, &rgb, (width, height), (256, 24), Some(31)).is_some(),
            "existing O support must be valid before testing the extra R gate"
        );
        let raw = base("界".repeat(count), 0.95);
        let rule = moderate_rule(&raw, Some(31)).unwrap();
        let plan = plans_for_rule(&raw, &rgb, (width, height), (256, 24), rule);
        assert_eq!(plan.is_some(), expected, "raw={count} anchors={groups}");
    }
}

#[test]
fn moderate_plans_retain_invalid_rgb_uniform_and_input_geometry_rejections() {
    let (rgb, width, height) = column(43);
    let raw = base("界".repeat(17), 0.95);
    let rule = moderate_rule(&raw, Some(31)).unwrap();
    assert!(
        plans_for_rule(
            &raw,
            &rgb[..rgb.len() - 1],
            (width, height),
            (256, 24),
            rule
        )
        .is_none()
    );
    assert!(
        plans_for_rule(
            &raw,
            &vec![255; rgb.len()],
            (width, height),
            (256, 24),
            rule
        )
        .is_none()
    );
    assert!(plans_for_rule(&raw, &rgb, (usize::MAX, 1), (256, 24), rule).is_none());
    for input in [(0, 24), (256, 0), (usize::MAX, usize::MAX)] {
        assert!(plans_for_rule(&raw, &rgb, (width, height), input, rule).is_none());
    }
}

fn parts(text: &str, cut: usize, confidence: f32) -> Vec<RecognizeResult> {
    let chars: Vec<_> = text.chars().collect();
    vec![
        base(chars[..cut].iter().collect(), confidence),
        base(chars[cut..].iter().collect(), confidence),
    ]
}

#[test]
fn moderate_consensus_preserves_unicode_prefix_spaces_and_primary_scalar_weights() {
    let raw = base("AB CD語𠮷uvwxyz1234".into(), 0.95);
    assert_eq!(raw.text.chars().count(), 17);
    let rule = moderate_rule(&raw, Some(31)).unwrap();
    let target = format!("{}末尾XYZ", raw.text);
    let mut primary = parts(&target, 8, 0.9);
    primary[1].mean_confidence = 1.0;
    let secondary = parts(&target, 11, 0.99);
    let result = combine_for_rule(&raw.text, 31, rule, &primary, &secondary).unwrap();
    assert_eq!(result.text, target);
    let expected = ((8.0 * f64::from(0.9f32) + 14.0) / 22.0) as f32;
    assert_eq!(result.mean_confidence.to_bits(), expected.to_bits());
}

#[test]
fn moderate_consensus_rejects_disagreement_internal_insertions_spaces_and_saturation() {
    let raw = base("ABCDEFGHIJKLMNOPQ".into(), 0.95);
    let rule = moderate_rule(&raw, Some(31)).unwrap();
    let target = format!("{}RSTU", raw.text);
    let primary = parts(&target, 10, 0.95);
    let mut different = parts(&target, 11, 0.95);
    different[1].text.push('X');
    assert!(combine_for_rule(&raw.text, 31, rule, &primary, &different).is_none());
    for changed in [
        format!("ABX{}", &target[2..]),
        format!("{target} "),
        raw.text.clone(),
    ] {
        let values = parts(&changed, 8, 0.95);
        assert!(combine_for_rule(&raw.text, 31, rule, &values, &values).is_none());
    }
    let saturated = vec![
        base(format!("{}{}", raw.text, "Z".repeat(14)), 0.95),
        base("W".into(), 0.95),
    ];
    assert!(combine_for_rule(&raw.text, 31, rule, &saturated, &saturated).is_none());
    assert!(combine_for_rule(&raw.text, 31, rule, &[], &primary).is_none());
    let one = vec![base(target, 0.95)];
    assert!(combine_for_rule(&raw.text, 31, rule, &one, &one).is_none());
    for confidence in [f32::NAN, f32::INFINITY, f32::NEG_INFINITY, 0.8999, 1.0001] {
        let mut values = parts("ABCDEFGHIJKLMNOPQRSTU", 10, 0.95);
        values[0].mean_confidence = confidence;
        assert!(combine_for_rule(&raw.text, 31, rule, &values, &values).is_none());
    }
}

#[test]
fn moderate_combine_rechecks_range_and_cannot_accept_whitespace_only_parts_or_three_types() {
    let rule = moderate_rule(&base("A".repeat(17), 0.95), Some(31)).unwrap();
    for count in [16, 30] {
        let raw = "A".repeat(count);
        let values = parts(&format!("{raw}BCDE"), 10, 0.95);
        assert!(combine_for_rule(&raw, 31, rule, &values, &values).is_none());
    }
    let raw = format!("{} ", "A".repeat(16));
    let values = parts(&format!("{raw}BCDE"), 10, 0.95);
    assert!(combine_for_rule(&raw, 31, rule, &values, &values).is_none());
    let raw = format!("  {}", "A".repeat(15));
    let values = parts(&format!("{raw}BCDE"), 2, 0.95);
    assert!(combine_for_rule(&raw, 31, rule, &values, &values).is_none());
    let raw = "A".repeat(17);
    let values = parts(&format!("{raw}BC"), 10, 0.95);
    assert!(combine_for_rule(&raw, 31, rule, &values, &values).is_none());
}

fn route_texts(text: &str, count: usize) -> Vec<String> {
    let chars: Vec<_> = text.chars().collect();
    (0..count)
        .map(|i| {
            chars[i * chars.len() / count..(i + 1) * chars.len() / count]
                .iter()
                .collect()
        })
        .collect()
}

#[test]
fn moderate_recovery_reads_original_parts_once_and_extends_only_the_complete_prefix() {
    let (rgb, width, height) = column(43);
    let raw = base("ABCDEFGHIJKLMNOPQ".into(), 0.95);
    let rule = moderate_rule(&raw, Some(31)).unwrap();
    let plan = plans_for_rule(&raw, &rgb, (width, height), (256, 24), rule).unwrap();
    let target = "ABCDEFGHIJKLMNOPQRSTUVWX";
    let texts: Vec<_> = plan
        .routes
        .iter()
        .flat_map(|route| route_texts(target, route.len()))
        .collect();
    let chunks: Vec<_> = plan.routes.iter().flatten().collect();
    let mut calls = 0;
    let result = recover_moderate(
        &raw,
        &rgb,
        (width, height),
        (256, 24),
        Some(31),
        |pixels, cw, ch| {
            let chunk = chunks[calls];
            assert_eq!((cw, ch), (chunk.x1 - chunk.x0, width));
            for y in 0..ch {
                for x in 0..cw {
                    let source = ((chunk.x0 + x) * width + (width - 1 - y)) * 3;
                    let destination = (y * cw + x) * 3;
                    assert_eq!(
                        &pixels[destination..destination + 3],
                        &rgb[source..source + 3]
                    );
                }
            }
            let value = base(texts[calls].clone(), 0.95);
            calls += 1;
            Ok(value)
        },
    )
    .unwrap();
    assert_eq!(result.text, target);
    assert_eq!(calls, texts.len());
    assert_eq!(calls, 8);
}

fn no_calls(
    raw: &RecognizeResult,
    rgb: &[u8],
    dimensions: (usize, usize),
    input: (usize, usize),
    limit: Option<usize>,
) {
    let mut calls = 0;
    let result = recover_moderate(raw, rgb, dimensions, input, limit, |_, _, _| {
        calls += 1;
        Ok(base("unexpected".into(), 0.95))
    });
    assert!(result.is_none());
    assert_eq!(calls, 0);
}

#[test]
fn moderate_ineligibility_never_reaches_the_recognition_callback() {
    let (rgb, width, height) = column(43);
    let raw = base("界".repeat(17), 0.95);
    for limit in [None, Some(0), Some(18)] {
        no_calls(&raw, &rgb, (width, height), (256, 24), limit);
    }
    for count in [0, 16, 30, 31] {
        no_calls(
            &base("界".repeat(count), 0.95),
            &rgb,
            (width, height),
            (256, 24),
            Some(31),
        );
    }
    no_calls(
        &base("界".repeat(17), f32::NAN),
        &rgb,
        (width, height),
        (256, 24),
        Some(31),
    );
    no_calls(
        &raw,
        &rgb[..rgb.len() - 1],
        (width, height),
        (256, 24),
        Some(31),
    );
    no_calls(&raw, &rgb, (width, height), (0, 24), Some(31));
    let (short, sw, sh) = column(39);
    no_calls(&raw, &short, (sw, sh), (256, 24), Some(31));
}

#[test]
fn moderate_part_error_and_nan_are_rejections_after_real_callbacks() {
    let (rgb, width, height) = column(43);
    let raw = base("ABCDEFGHIJKLMNOPQ".into(), 0.95);
    let rule = moderate_rule(&raw, Some(31)).unwrap();
    let plan = plans_for_rule(&raw, &rgb, (width, height), (256, 24), rule).unwrap();
    let texts: Vec<_> = plan
        .routes
        .iter()
        .flat_map(|route| route_texts("ABCDEFGHIJKLMNOPQRSTUVWX", route.len()))
        .collect();
    let mut calls = 0;
    let result = recover_moderate(
        &raw,
        &rgb,
        (width, height),
        (256, 24),
        Some(31),
        |_, _, _| {
            calls += 1;
            Err(anyhow::anyhow!("recorded part error"))
        },
    );
    assert!(result.is_none());
    assert_eq!(calls, 1);
    calls = 0;
    let result = recover_moderate(
        &raw,
        &rgb,
        (width, height),
        (256, 24),
        Some(31),
        |_, _, _| {
            let value = base(
                texts[calls].clone(),
                if calls == 1 { f32::NAN } else { 0.95 },
            );
            calls += 1;
            Ok(value)
        },
    );
    assert!(result.is_none());
    assert!(calls > 0);
    assert_eq!(raw.text, "ABCDEFGHIJKLMNOPQ");
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(128))]
    #[test]
    fn raw_range_counts_scalars_instead_of_utf8_bytes(
        count in 0usize..160,
        limit in 0usize..130,
        character in prop::sample::select(vec!['A', '界', 'é', '𠮷']),
    ) {
        let text = character.to_string().repeat(count);
        let rule = moderate_rule(&base(text, 0.95), Some(limit));
        let eligible = limit >= 19 && count >= 17 && count <= limit - 2;
        prop_assert_eq!(rule.is_some(), eligible);
        if let Some(rule) = rule {
            prop_assert_eq!(rule.minimum_anchors, 40.max(count * 2));
        }
    }

    #[test]
    fn literal_unicode_prefix_and_whitespace_survive_both_partitions(
        prefix in prop::collection::vec(prop::sample::select(vec!['界', 'A', 'é', '𠮷', ' ', '\u{3000}', '\u{301}', '😀']), 16..29)
    ) {
        let mut text: String = prefix.into_iter().collect();
        text.push('A');
        let raw = base(text, 0.95);
        let rule = moderate_rule(&raw, Some(31)).unwrap();
        let target = format!("{}末XYZ", raw.text);
        let cut = target.chars().count() / 2;
        let primary = parts(&target, cut, 0.95);
        let secondary = parts(&target, cut + 1, 0.95);
        let result = combine_for_rule(&raw.text, 31, rule, &primary, &secondary).unwrap();
        prop_assert_eq!(result.text, target);
        prop_assert_eq!(result.mean_confidence.to_bits(), 0.95f32.to_bits());
    }
}
