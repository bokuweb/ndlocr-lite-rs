from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;out=repo/'docs/benchmarks/vertical-moderate-prefix';sha=lambda b:hashlib.sha256(b).hexdigest();frozen=json.loads((p/'native-pair-frozen-v1.json').read_text());data={};changed=[]
for name,digest in frozen['candidate']['source_files'].items():
 if frozen['baseline']['source_files'].get(name)!=digest:
  raw=(p/'source-candidate'/name).read_bytes();assert sha(raw)==digest;data['candidate-source/'+name]=raw;changed.append(name)
assert len(changed)==6
names=['native-pair-frozen-v1.json','native-manifest-v1.json','native-before-NN-v1.json','native-before-NN-draft-v1.json','new-manifest-v2.json','source-copies-before-implementation-v1.json','native-build-driver-v1.stdout','native-build-driver-v1.stderr','build_native_pair_v1.py','run_native_matrix_v1.py','score_native_matrix_v1.py','candidate-onnx-clippy-v1.stdout','candidate-onnx-clippy-v1.stderr','native-candidate-nonignored-v1.stdout','native-candidate-nonignored-v1.stderr','pure_stage_v1.py']
for variant in ['baseline','candidate']:names += [f'native-{variant}-build-v1.jsonl',f'native-{variant}-build-v1.stderr',f'native-{variant}-before-build-v1.json']
for path in p.iterdir():
 if path.is_file() and path.suffix in ['.stdout','.stderr','.json','.jsonl','.py'] and any(x in path.name for x in ['common-reader','moderate-rule','moderate-plans','moderate-combine','moderate-recover','recovery-order','moderate-bridge','matrix-scope','native-metrics']):names.append(path.name)
for name in sorted(set(names)):data['evidence/'+name]=(p/name).read_bytes()
root_names=['docs/vertical_moderate_prefix_proposal.md','docs/vertical_moderate_prefix_native.md','docs/vertical_moderate_prefix_api_scope.md','docs/vertical_moderate_prefix_before_native_packet.md','tools/moderate_prefix_matrix_scope.py','tools/moderate_prefix_native_metrics.py','tests/test_moderate_prefix_matrix_scope.py','tests/test_moderate_prefix_native_metrics.py','tools/eval_ocr_metrics.py','tools/verify_low_stop_evidence.py','docs/benchmarks/vertical-partition-agreement/fast_distance.py']
for name in root_names:data[name]=(repo/name).read_bytes()
archive=out/'before-native-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in data.items():z.writestr(name,raw)
root_packet=json.loads((repo/'docs/benchmarks/vertical-cli-fallback-v2/root-bridge-v1/completed-local-v2.index.json').read_text());nn0=json.loads((out/'nn0-v1.index.json').read_text());index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in data.items()},'Root_completed_packet_sha256':root_packet['sha256'],'NN0_controls_packet_sha256':nn0['sha256'],'candidate_changed_files':changed,'native_bytes_in_packet':False,'NN_calls_in_replay':0}
(out/'before-native-v1.index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='members'}))
