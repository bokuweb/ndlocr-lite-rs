from pathlib import Path
from collections import Counter
from PIL import Image,ImageDraw,ImageFont
import datetime,hashlib,json,subprocess,sys
repo=Path.cwd();root=Path(__file__).resolve().parent;out=root/'inputs-v2';out.mkdir();sys.path.insert(0,str(repo/'tools'))
from moderate_prefix_controls import control_plan,assert_font_covers,PARAGRAPH
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
fonts=json.loads((repo/'tmp/vertical-prefix-capacity/generation-before-render.json').read_text())['fonts'];plan=control_plan([r['label'] for r in fonts]);spec=repo/'docs/vertical_moderate_prefix_proposal.md';charset=repo/'models/NDLmoji.yaml'
config={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fonts':fonts,'paragraph':PARAGRAPH,'font_size':44,'advance':52,'padding':[4,16],'portrait_row_advance':64,'shape_width':71,'shape_advance':62,'backgrounds':{'white':[255,255,255],'warm':[246,233,209],'gray':[175,183,192]},'plan':plan,'generator_sha256':sha(__file__),'helper_sha256':sha(repo/'tools/moderate_prefix_controls.py'),'spec_sha256':sha(spec),'charset_sha256':sha(charset),'Pillow':__import__('PIL').__version__,'NN_calls':0,'model_loads':0,'R_policy_started':False}
(root/'generation-before-render-v2.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
ruby='value=YAML.safe_load(File.read(ARGV[0])).fetch("model").fetch("charset_train"); abort "bad charset" unless value.is_a?(String) || (value.is_a?(Array) && value.all?{|x|x.is_a?(String)}); puts JSON.generate(value.is_a?(Array) ? value.join : value)'
charset_text=json.loads(subprocess.check_output(['ruby','-rjson','-ryaml','-e',ruby,str(charset)],text=True));needed={c for r in plan for c in r['text'] if not c.isspace()};assert needed<=set(charset_text),sorted(needed-set(charset_text))
loaded={}
for info in fonts:
 assert sha(info['path'])==info['sha256'];font=ImageFont.truetype(info['path'],44,index=info['index']);assert_font_covers(font,''.join(r['text'] for r in plan if r.get('font')==info['label']));loaded[info['label']]=font
rows=[];glyphs=0
def save(row,image,**meta):
 paths={k:out/(row['id']+ext) for k,ext in [('image','.png'),('rgb','.rgb'),('truth','.txt')]};image.save(paths['image']);paths['rgb'].write_bytes(image.tobytes());paths['truth'].write_bytes(row['text'].encode());assert Image.open(paths['image']).convert('RGB').tobytes()==paths['rgb'].read_bytes()
 rows.append(row|{k:str(path) for k,path in paths.items()}|{k+'_sha256':sha(path) for k,path in paths.items()}|{'width':image.width,'height':image.height}|meta)
for row in plan:
 cohort=row['cohort']
 if cohort in ['body','repeated']:
  font=loaded[row['font']];padding=row['padding'];width=54+2*padding;height=len(row['text'])*52+24+2*padding;image=Image.new('RGB',(width,height),'white');independent=image.copy();boxes=[];last=0
  for index,char in enumerate(row['text']):
   bounds=font.getbbox(char);gw=bounds[2]-bounds[0];mask=Image.new('L',(width,100),0);ImageDraw.Draw(mask).text(((width-gw)//2-bounds[0],-bounds[1]),char,font=font,fill=255);box=mask.getbbox();assert box and box[3]<=52
   top=12+padding+index*52;box=[box[0],top+box[1],box[2],top+box[3]];assert box[1]>=last and box[3]<=height;last=box[3];boxes.append(box);image.paste((0,0,0),(0,top),mask);glyphs+=1
   direct=font.getmask(char,mode='L');direct=Image.frombytes('L',direct.size,bytes(direct));independent.paste((0,0,0),((width-gw)//2,top),direct)
  assert image.tobytes()==independent.tobytes();save(row,image,glyph_boxes=boxes,font_size=44,advance=52)
 elif cohort=='portrait':
  font=loaded[row['font']];bounds=font.getbbox(row['row_text']);width=bounds[2]-bounds[0]+32;height=row['rows']*64+32;assert height>=8*width
  image=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(image)
  for index in range(row['rows']):draw.text((16-bounds[0],16+index*64-bounds[1]),row['row_text'],font=font,fill='black')
  save(row,image,font_size=44,row_advance=64)
 else:
  image=Image.new('RGB',(71,row['groups']*62+32),tuple(config['backgrounds'][row['background']]));draw=ImageDraw.Draw(image)
  for index in range(row['groups']):
   y=16+index*62;shift=index%4-1;ink=(23,31,47)
   if row['pattern']=='open_slant_hexagon':
    draw.line([(11,y+21),(23,y+2),(49,y+6),(58,y+28),(41,y+49),(17,y+39)],fill=ink,width=2);draw.line([(18,y+10),(45,y+36+shift)],fill=ink,width=3);draw.ellipse((32,y+13,36,y+17),fill=ink)
   else:
    draw.line([(10,y+37),(14,y+8),(30,y+25),(46,y+3),(59,y+41),(18,y+48)],fill=ink,width=2);draw.line([(20,y+41),(44,y+16+shift)],fill=ink,width=2);draw.line([(41,y+49),(58,y+49)],fill=ink,width=3)
  save(row,image,truth_convention='empty for drawn nonletter diagnostics')
assert len(rows)==72 and glyphs==5256
known=json.loads((repo/'docs/benchmarks/vertical-cli-fallback-v2/full-matrix-v1/bundle.json').read_text())['physical_inputs'];assert len(known)==1311
old={r[k] for r in known for k in ['image_sha256','rgb_sha256']};new=[r[k] for r in rows for k in ['image_sha256','rgb_sha256']];assert len(set(new))==144 and not old.intersection(new)
(root/'new-manifest-v2.json').write_text(json.dumps({'inputs':rows},ensure_ascii=False,indent=2)+'\n');summary={'new_inputs':72,'cohorts':dict(Counter(r['cohort'] for r in rows)),'independently_reconstructed_glyphs':glyphs,'PNG_RGB_exact':True,'known1311_hash_overlap':0,'model_charset_covers_all_declared_nonspace_scalars':True,'font_missing_glyph_signature_rejected':True,'NN_calls':0,'model_loads':0,'R_policy_started':False};(root/'generation-complete-v2.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
sheet=Image.new('RGB',(12*120,6*320),(231,233,236));draw=ImageDraw.Draw(sheet)
for index,row in enumerate(rows):
 image=Image.open(row['image']).convert('RGB');pieces=[]
 for top in [0,max(0,image.height//2-45),max(0,image.height-90)]:pieces.append(image.crop((0,top,image.width,min(image.height,top+90))))
 strip=Image.new('RGB',(image.width,270),'white')
 for i,piece in enumerate(pieces):strip.paste(piece,(0,90*i))
 if strip.width>112:strip=strip.resize((112,round(strip.height*112/strip.width)))
 x=(index%12)*120;y=(index//12)*320;sheet.paste(strip,(x+4,y+40));draw.text((x+3,y+3),row['id'].replace('r1_','')[:18],fill='black');draw.text((x+3,y+18),row['id'].replace('r1_','')[18:36],fill='black')
sheet.save(root/'contact-sheet-v2.png')
