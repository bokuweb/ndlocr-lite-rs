from pathlib import Path
import hashlib,json,os,subprocess,datetime,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;old=repo/'tmp/real-vertical-primary-partition-probe';sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((old/'geometry-binary-frozen-v1.json').read_text());assert frozen['compiler_artifact']['fresh'] is False and 'onnx' not in frozen['compiler_artifact']['features'];assert sha(old/'geometry-binary')==frozen['binary_sha256'];assert all(sha(repo/n)==h for n,h in frozen['source_files'].items())
rows=json.loads((p/'new-manifest-v2.json').read_text())['inputs'];assert len(rows)==72
archive=p/'geometry-original-RGB-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in rows:
  assert sha(row['image'])==row['image_sha256'] and sha(row['rgb'])==row['rgb_sha256'] and sha(row['truth'])==row['truth_sha256'];z.writestr(row['id']+'.rgb',Path(row['rgb']).read_bytes())
items=[];refs=[]
for model,iw in [('30',256),('50',384),('100',768)]:
 for row in rows:
  ident=hashlib.sha256(f'{model}:{row["id"]}'.encode()).hexdigest();items.append({'id':ident,'archive':str(archive),'member':row['id']+'.rgb','width':row['width'],'height':row['height'],'input':[iw,24]});refs.append({'id':ident,'model':model,'physical_id':row['id'],'glyph_boxes':row.get('glyph_boxes')})
manifest=p/'geometry-manifest-v1.json';write(manifest,{'items':items});write(p/'geometry-references-v1.json',refs)
bindings={str(repo/n):h for n,h in frozen['source_files'].items()}
for path in [Path(__file__),old/'geometry-binary',old/'geometry-binary-frozen-v1.json',p/'new-manifest-v2.json',p/'generation-before-render-v2.json',p/'generation-complete-v2.json',archive,manifest,p/'geometry-references-v1.json',repo/'docs/vertical_moderate_prefix_geometry_preflight.md']:bindings[str(path)]=sha(path)
argv=[str(old/'geometry-binary'),'--ignored','--exact','infer::vertical_capacity::primary_partition_geometry::record_all_primary_partitions_without_nn','--nocapture','--test-threads=1'];env={'NDLOCR_PRIMARY_PARTITION_MANIFEST':str(manifest),'NDLOCR_PRIMARY_PARTITION_OUTPUT':str(p/'geometry-v1')};meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files_sha256':bindings,'argv':argv,'env':env,'NN_calls':0,'model_loads':0,'complete':False};assert all(sha(n)==h for n,h in bindings.items());write(p/'geometry-before-v1.json',meta)
try:
 with (p/'geometry-v1.stdout').open('xb') as stdout,(p/'geometry-v1.stderr').open('xb') as stderr:result=subprocess.run(argv,cwd=repo,env=os.environ|env,stdout=stdout,stderr=stderr)
 meta.update(exit_code=result.returncode,frozen_files_after_unchanged=all(sha(n)==h for n,h in bindings.items()));assert result.returncode==0 and meta['frozen_files_after_unchanged'];meta['complete']=True
finally:write(p/'geometry-command-v1.json',meta)
print(json.dumps({'geometry_inputs':216,'NN_calls':0,'complete':True}),flush=True)
