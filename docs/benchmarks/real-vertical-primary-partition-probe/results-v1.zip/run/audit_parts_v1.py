from pathlib import Path
from collections import Counter
import csv,hashlib,json,struct,subprocess,sys,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;sys.path.insert(0,str(repo/'tools'));from verify_additional_real_partition_probe import is_subsequence
from verify_low_stop_evidence import metric_values
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
job=json.loads((p/'part-job-v1.json').read_text());assert job['complete'] and job['frozen_files_after_unchanged'] and all(sha(n)==h for n,h in job['files_sha256'].items())
refs=json.loads((p/'part-references-v1.json').read_text());values={};stop=Counter()
with zipfile.ZipFile(p/'geometry-v1/parts.zip') as source:
 for model in ['30','50','100']:
  manifest=json.loads((p/f'NN-{model}-v1.json').read_text());results=json.loads((p/f'part-results-{model}-v1/results.json').read_text());assert len(results)==manifest['expected_items'] and [r['id'] for r in results]==[r['id'] for r in manifest['items']]
  with zipfile.ZipFile(p/f'part-results-{model}-v1/actual-rgb-inputs.zip') as actual:
   for row,item in zip(results,manifest['items'],strict=True):
    assert 'error' not in row and actual.read(row['id']+'.rgb')==source.read(item['member']);values[row['id']]=row;stop[row['stop_reason']]+=1
records=[];predictions={}
for parent in refs['all_primary_inputs']:
 model=parent['model'];ident=parent['origins'][0].split('_eval_',1)[1];routes=[[values[r['id']] for r in refs['parts'] if r['parent_id']==parent['id'] and r['route']==i] for i in [0,1]];joined=[''.join(r['text'] for r in rows) for rows in routes]
 entry={'id':parent['id'],'physical_id':ident,'model':model,'origins':parent['origins'],'raw':parent['raw'],'raw_mean_bits':parent['mean_bits'],'joined':joined,'partition_agreement':joined[0]==joined[1],'raw_prefix':[j.startswith(parent['raw']) for j in joined],'raw_subsequence':[is_subsequence(parent['raw'],j) for j in joined],'minimum_part_mean':[min(struct.unpack('!f',struct.pack('!I',r['mean_bits']))[0] for r in rows) for rows in routes]};records.append(entry)
 for key,text in [('raw'+model,parent['raw']),('parts0_'+model,joined[0]),('parts1_'+model,joined[1])]:predictions.setdefault(key,{})[ident]=text
assert len(values)==117 and len(records)==18 and len(predictions)==9
write(p/'partition-diagnosis-v1.json',records)
master=json.loads((repo/'tmp/real-vertical-additional-controls/additional-controls-manifest-v1.json').read_text());metrics=p/'metrics-v1';metrics.mkdir();truth=metrics/'truth';truth.mkdir()
for row in master['scoring_inputs']:(truth/(row['id']+'.txt')).write_bytes((repo/row['truth']).read_bytes())
for system,body in predictions.items():
 directory=metrics/system;directory.mkdir()
 for row in master['scoring_inputs']:(directory/(row['id']+'.txt')).write_text(body[row['physical_id']])
commands=[];verified=0
for mode in ['none','width','strict']:
 table=metrics/(mode+'.csv');argv=[sys.executable,str(repo/'tools/eval_ocr_metrics.py'),'--truth-dir',str(truth)]
 for system in predictions:argv+=['--system',system+'='+str(metrics/system)]
 argv+=['--normalize',mode,'--require-all','--output-csv',str(table)]
 with (metrics/(mode+'.stdout')).open('xb') as stdout,(metrics/(mode+'.stderr')).open('xb') as stderr:process=subprocess.run(argv,stdout=stdout,stderr=stderr)
 commands.append({'argv':argv,'exit_code':process.returncode});assert process.returncode==0
 rows=list(csv.DictReader(table.open()));assert len(rows)==99 and len({(r['system'],r['file']) for r in rows})==99
 for row in rows:
  expected=metric_values((truth/row['file']).read_text(),(metrics/row['system']/row['file']).read_text(),mode);assert tuple(int(row[k]) for k in ['char_errors','char_total','word_errors','word_total'])==expected;verified+=1
assert verified==297 and all(sha(n)==h for n,h in job['files_sha256'].items())
summary={'complete':True,'raw_API_calls':117,'API_errors':0,'primary_model_RGB_inputs':18,'original_Page_routes':36,'model_session_loads':3,'internal_forward_calls':None,'stop_counts':dict(stop),'independent_CSV_rows':verified,'all_frozen_files_after_unchanged':True,'metric_commands':commands,'model30_agreeing_partitions':sum(r['model']=='30' and r['partition_agreement'] for r in records),'model30_agreement_with_full_raw_prefix_extension':sum(r['model']=='30' and r['partition_agreement'] and all(r['raw_prefix']) and len(r['joined'][0])>len(r['raw']) for r in records),'new_accuracy_gain':False,'production_policy_changed':False,'audit_script_sha256':sha(__file__)}
write(p/'partition-summary-v1.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='metric_commands'},ensure_ascii=False,indent=2))
