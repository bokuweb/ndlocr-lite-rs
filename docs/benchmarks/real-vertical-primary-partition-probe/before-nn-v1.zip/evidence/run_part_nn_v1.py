from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();meta=json.loads((p/'before-part-NN-v1.json').read_text());bindings=meta['files_sha256'];assert all(sha(n)==h for n,h in bindings.items());assert not (p/'part-job-v1.json').exists();meta['executed_commands']=[]
try:
 for command in meta['commands']:
  model=command['model'];started=time.monotonic()
  with (p/f'part-run-{model}-v1.stdout').open('xb') as stdout,(p/f'part-run-{model}-v1.stderr').open('xb') as stderr:process=subprocess.run(command['argv'],cwd=command['cwd'],env=os.environ|command['env'],stdout=stdout,stderr=stderr)
  receipt=command|{'exit_code':process.returncode,'seconds':time.monotonic()-started,'frozen_files_after_unchanged':all(sha(n)==h for n,h in bindings.items())};meta['executed_commands'].append(receipt);assert process.returncode==0 and receipt['frozen_files_after_unchanged'];print(json.dumps({'model':model,'exit_code':process.returncode}),flush=True)
 meta.update(complete=True,frozen_files_after_unchanged=all(sha(n)==h for n,h in bindings.items()))
except Exception as error:meta['error']=repr(error);raise
finally:(p/'part-job-v1.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
