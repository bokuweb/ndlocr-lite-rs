from pathlib import Path
from collections import Counter
import datetime,hashlib,json,sys,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;old=repo/'tmp/vertical-unique-insertion';stop=repo/'tmp/real-vertical-additional-stop-probe';sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((p/'geometry-binary-frozen-v1.json').read_text());geometry=json.loads((p/'geometry-command-v1.json').read_text());assert geometry['complete'] and geometry['NN_calls']==geometry['model_loads']==0 and all(sha(n)==h for n,h in geometry['files_sha256'].items())
refs=json.loads((stop/'references-v1.json').read_text());inputs={r['id']:r for r in refs['unique_inputs']};rows=json.loads((p/'geometry-v1/records.json').read_text());assert len(rows)==18 and {r['id'] for r in rows}==set(inputs)
parts=[];pixels=0
with zipfile.ZipFile(p/'original-primary-v1.zip') as original,zipfile.ZipFile(p/'geometry-v1/parts.zip') as archive:
 for row in rows:
  ref=inputs[row['id']];assert row['error'] is None and len(row['routes'])==2
  rgb=original.read(ref['rgb_sha256']+'.rgb');w,h=ref['width'],ref['height'];assert hashlib.sha256(rgb).hexdigest()==ref['rgb_sha256']
  for route,values in enumerate(row['routes']):
   for index,part in enumerate(values):
    raw=archive.read(part['file']);left,right=part['range'];assert 0<=left<right<=h and (part['width'],part['height'])==(right-left,w) and not part['space_before'] and len(raw)==part['width']*part['height']*3
    for y in range(w):
     for x in range(right-left):
      a=(y*(right-left)+x)*3;b=((left+x)*w+(w-1-y))*3;assert raw[a:a+3]==rgb[b:b+3];pixels+=1
    ident=hashlib.sha256(f'{ref["model"]}:{row["id"]}:{route}:{index}'.encode()).hexdigest()
    parts.append({'id':ident,'model':ref['model'],'parent_id':row['id'],'origins':ref['origins'],'route':route,'part_index':index,'range':part['range'],'member':part['file'],'width':part['width'],'height':part['height'],'rgb_sha256':hashlib.sha256(raw).hexdigest()})
assert len(parts)==117 and len({r['id'] for r in parts})==117
write(p/'part-references-v1.json',{'parts':parts,'all_primary_inputs':refs['unique_inputs']})
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets'];commands=[]
for model,iw in [('30',256),('50',384),('100',768)]:
 selected=[r for r in parts if r['model']==model];manifest={'items':[{'id':r['id'],'archive':str(p/'geometry-v1/parts.zip'),'member':r['member'],'sha256':r['rgb_sha256'],'width':r['width'],'height':r['height']} for r in selected],'expected_items':len(selected),'model':{'label':model,'path':str(repo/'models'/assets[model]['name']),'sha256':assets[model]['sha256']},'input_dimensions':[iw,24]}
 path=p/f'NN-{model}-v1.json';write(path,manifest);commands.append({'model':model,'argv':[str(old/'native-baseline-binary'),'--ignored','--exact','infer::vertical_capacity::prefix::capture::capture_all_frozen_verified_chunks_with_raw_candidates','--nocapture','--test-threads=1'],'env':{'NDLOCR_VERIFIED_NN_MANIFEST':str(path),'NDLOCR_VERIFIED_NN_OUTPUT':str(p/f'part-results-{model}-v1'),'NDLOCR_TEST_CHARSET':str(repo/'models'/assets['charset']['name']),'NDLOCR_INTRA_THREADS':'1'},'cwd':str(repo)})
bindings={str(repo/n):h for n,h in frozen['source_files'].items()};old_source=json.loads((old/'baseline-source-bindings.json').read_text());bindings.update({str(old/'baseline-source'/n):h for n,h in old_source.items()})
artifact=json.loads((old/'native-baseline-artifact.json').read_text());assert artifact['artifact']['fresh'] is False and sha(old/'native-baseline-binary')==artifact['binary_sha256']
for asset in ['30','50','100','charset']:bindings[str(repo/'models'/assets[asset]['name'])]=assets[asset]['sha256']
files=[Path(__file__),p/'run_part_nn_v1.py',p/'part-references-v1.json',p/'geometry-binary-frozen-v1.json',p/'geometry-command-v1.json',p/'geometry-manifest-v1.json',p/'geometry-v1/parts.zip',p/'geometry-v1/records.json',p/'original-primary-v1.zip',old/'native-baseline-binary',old/'native-baseline-artifact.json',old/'native-baseline-build.jsonl',old/'baseline-source-bindings.json',repo/'docs/real_vertical_primary_partition_probe.md',repo/'docs/real_vertical_primary_partition_controls.md']+[p/f'NN-{m}-v1.json' for m in ['30','50','100']]
for path in files:bindings[str(path)]=sha(path)
assert all(sha(n)==h for n,h in bindings.items())
unique={(r['model'],r['width'],r['height'],r['rgb_sha256']) for r in parts};write(p/'before-part-NN-v1.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete':False,'files_sha256':bindings,'commands':commands,'primary_inputs':18,'original_Page_routes':36,'raw_API_calls_planned':117,'unique_model_RGB_inputs':len(unique),'repeated_part_calls':117-len(unique),'per_model':dict(Counter(r['model'] for r in parts)),'model_session_loads_planned':3,'independent_crop_pixels':pixels,'NN_calls_at_freeze':0,'GT_or_raw_expectations_passed':False,'new_inference_policy':False})
print({'raw_API_calls_planned':117,'unique_model_RGB_inputs':len(unique),'repeated_part_calls':117-len(unique),'NN_calls':0,'independent_pixels':pixels})
