from pathlib import Path
import datetime,hashlib,json,os,subprocess,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;stop=repo/'tmp/real-vertical-additional-stop-probe';sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((p/'geometry-binary-frozen-v1.json').read_text());assert frozen['compiler_artifact']['fresh'] is False and 'onnx' not in frozen['compiler_artifact']['features'];assert sha(p/'geometry-binary')==frozen['binary_sha256'];assert all(sha(repo/n)==h for n,h in frozen['source_files'].items())
assert '442 passed; 0 failed; 39 ignored;' in (p/'default-full-v1.stdout').read_text()
refs=json.loads((stop/'references-v1.json').read_text());originals={r['origin']:r for r in refs['all_original_routes']};items=[];seen={};archive=p/'original-primary-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in refs['unique_inputs']:
  ref=originals[row['origins'][0]]
  with zipfile.ZipFile(ref['trace_zip']) as source:rgb=source.read(ref['primary_member'])
  assert hashlib.sha256(rgb).hexdigest()==row['rgb_sha256'] and len(rgb)==row['width']*row['height']*3
  member=row['rgb_sha256']+'.rgb'
  if member not in seen:z.writestr(member,rgb);seen[member]=rgb
  else:assert seen[member]==rgb
  items.append({'id':row['id'],'archive':str(archive),'member':member,'width':row['width'],'height':row['height'],'input':[{'30':256,'50':384,'100':768}[row['model']],24]})
assert len(items)==18 and len(seen)==6
manifest=p/'geometry-manifest-v1.json';write(manifest,{'items':items})
bindings={str(repo/n):h for n,h in frozen['source_files'].items()}
for path in [Path(__file__),p/'geometry-binary',p/'geometry-binary-frozen-v1.json',p/'default-full-v1.stdout',p/'default-full-v1.stderr',manifest,archive,stop/'references-v1.json',repo/'docs/real_vertical_primary_partition_probe.md']:
 bindings[str(path)]=sha(path)
argv=[str(p/'geometry-binary'),'--ignored','--exact','infer::vertical_capacity::primary_partition_geometry::record_all_primary_partitions_without_nn','--nocapture','--test-threads=1'];env={'NDLOCR_PRIMARY_PARTITION_MANIFEST':str(manifest),'NDLOCR_PRIMARY_PARTITION_OUTPUT':str(p/'geometry-v1')}
meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files_sha256':bindings,'argv':argv,'env':env,'NN_calls':0,'model_loads':0,'complete':False};assert all(sha(n)==h for n,h in bindings.items());write(p/'geometry-before-v1.json',meta)
try:
 with (p/'geometry-v1.stdout').open('xb') as stdout,(p/'geometry-v1.stderr').open('xb') as stderr:process=subprocess.run(argv,cwd=repo,env=os.environ|env,stdout=stdout,stderr=stderr)
 meta.update(exit_code=process.returncode,frozen_files_after_unchanged=all(sha(n)==h for n,h in bindings.items()));assert process.returncode==0 and meta['frozen_files_after_unchanged'];meta['complete']=True
finally:write(p/'geometry-command-v1.json',meta)
rows=json.loads((p/'geometry-v1/records.json').read_text());assert len(rows)==18 and [r['id'] for r in rows]==[r['id'] for r in items];print({'complete':True,'primary_model_RGB_inputs':len(rows),'errors':sum(r['error'] is not None for r in rows),'parts':sum(len(parts) for r in rows if r['routes'] for parts in r['routes']),'NN_calls':0})
