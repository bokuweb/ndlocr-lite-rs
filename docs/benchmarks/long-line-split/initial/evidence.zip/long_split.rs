//! 長行の中央再認識で、近い白列と単語空白を保持する。

use super::{BlankGap, LineChunk, blank_gaps, underlines};

/// 中央近くの字形間または単語空白へ切断位置を移し、全RGBの二分を返す。
pub(crate) fn split_long_line_near_center(
    rgb: &[u8],
    width: usize,
    height: usize,
    threshold: u8,
) -> Result<Option<[LineChunk; 2]>, String> {
    if width == 0
        || height == 0
        || width.checked_mul(height).and_then(|n| n.checked_mul(3)) != Some(rgb.len())
    {
        return Err("invalid RGB line dimensions".into());
    }
    if !height
        .checked_mul(4)
        .is_some_and(|minimum| width >= minimum)
    {
        return Ok(None);
    }
    if let Some(chunks) = nearest_gap(&blank_gaps(rgb, width, height, threshold), width, height) {
        return Ok(Some(chunks));
    }
    Ok(
        underlines::mask_supported_underline(rgb, (width, height), threshold).and_then(|masked| {
            nearest_gap(
                &blank_gaps(&masked, width, height, threshold),
                width,
                height,
            )
        }),
    )
}

fn nearest_gap(gaps: &[BlankGap], width: usize, height: usize) -> Option<[LineChunk; 2]> {
    let mid = width / 2;
    let (column, gap) = gaps
        .iter()
        .filter(|gap| !gap.internal_glyph_gap)
        .filter_map(|gap| {
            let start = gap.midpoint - gap.width / 2;
            let column = if (start..=start + gap.width).contains(&mid) {
                mid
            } else {
                gap.midpoint
            };
            (column > 0 && column < width && column.abs_diff(mid) <= height)
                .then_some((column, gap))
        })
        .min_by_key(|(column, _)| (column.abs_diff(mid), *column))?;
    Some([
        LineChunk {
            x0: 0,
            x1: column,
            space_before: false,
            gap_before: 0,
        },
        LineChunk {
            x0: column,
            x1: width,
            space_before: gap.word_space,
            gap_before: gap.width,
        },
    ])
}

#[cfg(test)]
#[path = "../../../tests/support/long_line_split_policy.rs"]
mod tests;

#[cfg(all(test, feature = "onnx"))]
#[path = "../../../tests/support/long_line_model_probe.rs"]
mod model_tests;
