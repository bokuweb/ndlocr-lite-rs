from pathlib import Path

def empty_output(path):
    return path

def relative_member(name):
    return Path(name)
