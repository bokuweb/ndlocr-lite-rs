from pathlib import Path
import json, hashlib, zipfile

root = Path('tmp/vertical-output-capacity')
audit = root / 'stop-audit'
public = Path('docs/benchmarks/vertical-output-capacity')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
selected = set()
for directory in [root / 'source-before-load', audit]:
    for path in directory.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.name != 'raw-stop-binary':
            selected.add(path)
for name in ['spec-before-load.md', 'bound-overflow-red.stderr', 'clippy-audit.stderr',
             'bound-red.stdout', 'metadata.stdout', 'lib-green.stdout', 'lib-green.stderr',
             'bound-red.stderr', 'bound-green.stdout', 'bound-green.stderr',
             'bound-overflow-red.stdout', 'bound-red-source.rs', 'bound-before-green.rs',
             'freeze-before-load.json', 'metadata-command.json', 'models-before-load.json',
             'run_metadata.py', 'clippy-audit.json', 'audit_clippy.py']:
    selected.add(root / name)
selected.update((root / 'metadata').rglob('*.json'))
for row in json.loads((audit / 'prepared/manifest-30.json').read_text())['inputs']:
    for kind in ['rgb', 'image', 'truth', 'source_image', 'source_truth']:
        if kind in row:
            selected.add(Path(row[kind]))
selected.update(map(Path, ['tools/eval_ocr_metrics.py', 'proptest-regressions/infer/output_capacity.txt',
    'tests/fixtures/long_vertical/manifest.json', 'tests/fixtures/vertical_handwriting/truth.txt',
    'tmp/vertical-capacity/vertical-regression/manifest.json', 'docs/vertical_output_capacity_audit.md',
    'docs/benchmarks/vertical-output-capacity/reproduce.py',
    'docs/benchmarks/vertical-output-capacity/test_reproduce.py']))
selected = sorted(selected)
assert all(p.is_file() and not p.is_symlink() and p.suffix != '.onnx' and p.stat().st_size < 20_000_000 for p in selected)
archive = public / 'audit.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path in selected:
        info = zipfile.ZipInfo(path.as_posix(), date_time=(2026, 10, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, path.read_bytes())
index = {'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
         'files_sha256': {p.as_posix(): sha(p) for p in selected},
         'excluded': ['ONNX model bodies', 'compiled binaries', 'Cargo target caches'],
         'api_calls': 162, 'model_loads_for_raw': 3, 'metadata_only_model_loads': 3,
         'internal_session_run_calls_for_raw': None}
(public / 'archive.json').write_text(json.dumps(index, indent=2) + '\n')
print(len(selected), 'files;', archive.stat().st_size, 'compressed bytes')
