from pathlib import Path
import json, struct, collections, sys, csv
sys.path.insert(0, str(Path('tools').resolve()))
from eval_ocr_metrics import levenshtein

root = Path('tmp/vertical-output-capacity/stop-audit')
f32 = lambda x: struct.unpack('<f', struct.pack('<f', x))[0]
bits = lambda x: struct.unpack('<I', struct.pack('<f', x))[0]
checks, summary, output = [], [], []
for label, limit in [('30', 31), ('50', 51), ('100', 101)]:
    inputs = json.loads((root / f'prepared/manifest-{label}.json').read_text())['inputs']
    rows = json.loads((root / f'raw-{label}/results.json').read_text())
    assert [x['id'] for x in inputs] == [x['id'] for x in rows]
    prior_pairs, page_pairs, page_text_changed = 0, 0, 0
    for source, row in zip(inputs, rows):
        assert 'error' not in row, row
        text_bytes, cursor, total, emitted = row['text'].encode(), 0, 0.0, 0
        steps = row['steps']
        assert 0 < len(steps) <= limit
        for timestep, step in enumerate(steps):
            assert step['timestep'] == timestep and len(step['candidates']) == 1
            candidate, span = step['candidates'][0], step['text_range']
            assert bits(candidate['probability']) == candidate['probability_bits']
            probability = candidate['probability']
            assert 0 <= probability <= 1
            if span is not None:
                assert span[0] == cursor and len(candidate['character']) == 1
                assert text_bytes[span[0]:span[1]].decode() == candidate['character']
                assert candidate['token_id'] > 0
                assert emitted < 2 or probability >= f32(0.35)
                cursor = span[1]
                emitted += 1
                total = f32(total + probability)
            else:
                assert timestep == len(steps) - 1
        assert cursor == len(text_bytes) and emitted == len(row['text'])
        assert bits(f32(total / emitted) if emitted else 0) == row['mean_bits']
        last = steps[-1]
        if row['stop_reason'] == 'EndOfSequence':
            assert last['text_range'] is None and last['candidates'][0]['token_id'] == 0
        elif row['stop_reason'] == 'LowConfidence':
            assert last['text_range'] is None and last['candidates'][0]['token_id'] > 0
            assert last['candidates'][0]['probability'] < f32(0.35) and emitted >= 2
        else:
            assert row['stop_reason'] == 'TimestepsExhausted' and len(steps) == emitted == limit
        old = source['expected_raw']
        page = source.get('previous_page', {}).get(label)
        if old is not None:
            assert (old['text'], old['mean_bits']) == (row['text'], row['mean_bits'])
            prior_pairs += 1
        if page:
            assert bits(page['confidence']) == row['mean_bits']
            page_pairs += 1
            page_text_changed += row['text'] != page['text']
        truth = Path(source['truth']).read_text()
        output.append({'model': label, 'id': row['id'], 'cohort': source['cohort'],
                       'static_T': limit, 'steps': len(steps), 'emitted_scalars': emitted,
                       'stop_reason': row['stop_reason'], 'gt_scalars': len(truth),
                       'raw_char_errors': levenshtein(list(truth), list(row['text'])),
                       'at_final_frame': len(steps) == limit,
                       'page_text_differs': bool(page and page['text'] != row['text']),
                       'raw_text': row['text']})
    assert prior_pairs == 42 and page_pairs == 12
    checks.append({'model': label, 'prior_raw_exact_text_f32_pairs': prior_pairs,
                   'page_exact_f32_pairs': page_pairs, 'page_raw_text_differences': page_text_changed,
                   'step_utf8_ranges_stop_rules_probability_bits_and_mean_f32_verified': 54})
    counts = collections.Counter(row['stop_reason'] for row in rows)
    final = [row['id'] for row in rows if len(row['steps']) == limit]
    summary.append({'model': label, 'stop_counts': dict(counts), 'stop_at_final_frame': final})
with (root / 'raw-stops.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(output[0]))
    writer.writeheader()
    writer.writerows(output)
(root / 'analysis.json').write_text(json.dumps({'checks': checks, 'summary': summary,
    'all162_success': True, 'api_calls': 162, 'internal_session_run_calls': None,
    'timesteps_exhausted': 0}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': checks, 'summary': summary}, ensure_ascii=False, indent=2))
