def truth_columns(text, count):
    return []

def stable_boxes(routes):
    return []

def crop_rgb(raw, width, height, box):
    return b''
