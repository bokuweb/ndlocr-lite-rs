def truth_columns(text, count):
    columns = text.split('\n')
    if len(columns) != count or any(not column for column in columns):
        raise ValueError('GT lines must correspond exactly; do not trim whitespace')
    return columns

def stable_boxes(routes):
    boxes = [[line['bbox'] for line in route] for route in routes]
    if len(boxes) != 6 or not boxes[0] or any(row != boxes[0] for row in boxes):
        raise ValueError('all three model/two setting crops must agree in physical order')
    return boxes[0]

def crop_rgb(raw, width, height, box):
    x0, y0, x1, y1 = box
    if len(raw) != width * height * 3 or not (0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height):
        raise ValueError('RGB length or half-open bbox is invalid')
    return b''.join(raw[(y * width + x0) * 3:(y * width + x1) * 3] for y in range(y0, y1))

def main():
    from pathlib import Path
    import hashlib, json, datetime
    from PIL import Image, ImageDraw
    root = Path('tmp/vertical-output-capacity/stop-audit')
    data = root / 'prepared'
    data.mkdir()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    manifest_path = Path('tmp/vertical-capacity/vertical-regression/manifest.json')
    original = json.loads(manifest_path.read_text())['inputs']
    routes = {}
    for model in ('30', '50', '100'):
        for setting in ('eval', 'default'):
            path = Path(f'tmp/vertical-capacity/vertical-regression/after/api-{model}/runtime{model}_{setting}/results.json')
            routes[model, setting] = {row['id']: row for row in json.loads(path.read_text())}
    rows = []
    previews = []
    for page in original:
        assert sha(page['image']) == page['image_sha256']
        assert sha(page['truth']) == page['truth_sha256']
        boxes = stable_boxes([route[page['id']]['lines'] for route in routes.values()])
        truths = truth_columns(Path(page['truth']).read_text(), len(boxes))
        image = Image.open(page['image']).convert('RGB')
        raw = image.tobytes()
        if len(boxes) > 1:
            assert all(a[0] > b[0] for a, b in zip(boxes, boxes[1:])), 'right-to-left column order'
        for index, (box, truth) in enumerate(zip(boxes, truths)):
            name = f"{page['id']}_crop{index+1}"
            w, h = box[2] - box[0], box[3] - box[1]
            piece = crop_rgb(raw, image.width, image.height, box)
            assert piece == image.crop(box).tobytes(), 'independent PIL crop agreement'
            rgb_path, png_path, truth_path = [data / (name + ext) for ext in ('.rgb', '.png', '.txt')]
            rgb_path.write_bytes(piece)
            crop = Image.frombytes('RGB', (w, h), piece)
            crop.save(png_path)
            truth_path.write_text(truth)
            rows.append({'id': name, 'parent_id': page['id'], 'column_index': index, 'bbox': box,
                         'rgb': str(rgb_path), 'rgb_sha256': sha(rgb_path), 'width': w, 'height': h,
                         'image': str(png_path), 'image_sha256': sha(png_path),
                         'truth': str(truth_path), 'truth_sha256': sha(truth_path),
                         'source_image': page['image'], 'source_image_sha256': sha(page['image']),
                         'source_truth': page['truth'], 'source_truth_sha256': sha(page['truth']),
                         'cohort': 'known_vertical_development_page_crop',
                         'previous_page': {model: routes[model, 'eval'][page['id']]['lines'][index] for model in ('30','50','100')}})
            previews.append((name, crop))
    assert len(original) == 7 and len(rows) == 12
    existing = json.loads(Path('tmp/vertical-capacity/controls/candidate-evaluation-manifest.json').read_text())['inputs']
    assert len(existing) == 42
    for row in existing:
        for kind in ('rgb', 'image', 'truth'):
            assert sha(row[kind]) == row[kind + '_sha256']
    combined = existing + rows
    assert len({r['id'] for r in combined}) == 54
    for model in ('30', '50', '100'):
        old = json.loads(Path(f'tmp/vertical-capacity/policy/fragment-api-manifests/{model}.json').read_text())['inputs']
        expected = {r['id']: r['raw'] for r in old}
        assert len(expected) == 42
        inputs = [{**row, 'expected_raw': expected.get(row['id'])} for row in combined]
        (data / f'manifest-{model}.json').write_text(json.dumps({'inputs': inputs}, ensure_ascii=False, indent=2) + '\n')
    contact = Image.new('RGB', (720, 1380), 'white')
    draw = ImageDraw.Draw(contact)
    for index, (name, image) in enumerate(previews):
        x, y = (index % 6) * 120, (index // 6) * 690
        draw.text((x + 2, y + 2), name.replace('vertical_', '')[:18], fill='black')
        image.thumbnail((112, 650))
        contact.paste(image, (x + (120-image.width)//2, y + 28))
    contact.save(data / 'crop-contact.png')
    (root / 'preparation.json').write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'known_pages': 7, 'new_crops': 12, 'old_original_rgb': 42, 'total': 54,
        'all_six_model_setting_bbox_sequences_identical': True, 'pil_crop_byte_agreement': True,
        'preparation_tests': '3 passed after 3 failure Red', 'additional_nn_calls': 0,
        'files_sha256': {str(p): sha(p) for p in data.iterdir()}}, indent=2) + '\n')
    print('54 original RGB inputs frozen: existing42 + all12 crops of known7 pages; no NN')

if __name__ == '__main__':
    main()
