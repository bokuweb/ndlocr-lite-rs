import unittest
from prepare import truth_columns, stable_boxes, crop_rgb

class PreparationTests(unittest.TestCase):
    def test_gt_preserves_spaces_and_rejects_unremoved_terminal_lf(self):
        self.assertEqual(truth_columns(' 春。 \n夏。', 2), [' 春。 ', '夏。'])
        self.assertEqual(truth_columns(' 春。 ', 1), [' 春。 '])
        for text, count in [('春。\n夏。\n', 2), ('春。', 2), ('春。\n\n夏。', 2)]:
            with self.assertRaises(ValueError):
                truth_columns(text, count)

    def test_model_setting_bbox_changes_cannot_be_silently_discarded(self):
        original = [{'bbox': [4, 0, 6, 8]}, {'bbox': [0, 1, 2, 7]}]
        self.assertEqual(stable_boxes([original] * 6), [[4, 0, 6, 8], [0, 1, 2, 7]])
        for changed in [original[::-1], original[:1], [{'bbox': [4, 0, 6, 7]}, original[1]]]:
            with self.assertRaises(ValueError):
                stable_boxes([original] * 5 + [changed])

    def test_crop_half_open_bounds_preserve_original_rgb_without_resizing(self):
        raw = bytes(range(4 * 3 * 3))
        self.assertEqual(crop_rgb(raw, 4, 3, [1, 1, 3, 3]), raw[15:21] + raw[27:33])
        self.assertEqual(crop_rgb(raw, 4, 3, [0, 0, 4, 3]), raw)
        for box in [[0, 0, 0, 2], [-1, 0, 2, 2], [0, 0, 5, 2], [0, 0, 3, 4]]:
            with self.assertRaises(ValueError):
                crop_rgb(raw, 4, 3, box)

if __name__ == '__main__':
    unittest.main()
