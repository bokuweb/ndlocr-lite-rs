from pathlib import Path
import hashlib, json, subprocess, os, shutil, time, datetime

root = Path('tmp/vertical-output-capacity/stop-audit')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'f3f828d057e6668b8df200285b6a3b37cc1356db'
suffixes = {'src/infer/mod.rs': '\n#[cfg(test)]\nmod output_capacity;\n',
            'src/infer/cached.rs': '\n#[cfg(test)]\n#[path = "../../tests/support/output_capacity_metadata.rs"]\nmod output_capacity_metadata;\n'}
for path in subprocess.check_output(['git', 'ls-files', 'src', 'tests', 'examples'], text=True).splitlines():
    if path.endswith('.rs'):
        assert Path(path).read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:' + path]) + suffixes.get(path, '').encode(), path
events = [json.loads(line) for line in (root / 'build.jsonl').read_text().splitlines()]
assert any(x.get('reason') == 'build-finished' and x['success'] for x in events)
exe, = [x['executable'] for x in events if x.get('reason') == 'compiler-artifact' and x.get('executable') and 'lib' in x['target']['kind']]
binary = root / 'raw-stop-binary'
shutil.copy2(exe, binary)
models = json.loads(Path('tmp/vertical-output-capacity/models-before-load.json').read_text())['models']
files = {*[str(p) for p in Path('src').rglob('*.rs')], *[str(p) for p in Path('tests').rglob('*.rs')],
         'Cargo.toml', 'Cargo.lock', 'models/NDLmoji.yaml', __file__, str(binary),
         'docs/vertical_output_capacity_audit.md'}
files.update(str(p) for p in (root / 'prepared').iterdir())
for model in models:
    assert sha(model['path']) == model['sha256']
    files.add(model['path'])
for row in json.loads((root / 'prepared/manifest-30.json').read_text())['inputs']:
    for kind in ('rgb', 'image', 'truth'):
        assert sha(row[kind]) == row[kind + '_sha256']
        files.add(row[kind])
sources = {path: sha(path) for path in sorted(files)}
freeze = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head,
          'production_sources_identical_except_cfg_test_declarations': True,
          'files_sha256': sources, 'orientation': 'Auto', 'top_k': 1,
          'planned_api_calls': 162, 'internal_session_run_calls': None,
          'crop_contact_review': 'all12 physical columns correspond to fixed GT; glyph/punctuation clipping remains diagnostic data'}
(root / 'freeze-before-raw.json').write_text(json.dumps(freeze, indent=2) + '\n')
snapshot = root / 'source-before-raw'
for path in ('src/infer/cached.rs', 'src/infer/mod.rs', 'src/infer/output_capacity.rs',
             'tests/support/output_capacity_metadata.rs', 'docs/vertical_output_capacity_audit.md'):
    target = snapshot / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
commands = []
for model in models:
    label = model['label']
    argv = [str(binary.resolve()), 'infer::cached::output_capacity_metadata::capture_raw_stops_for_all_frozen_vertical_inputs', '--exact', '--ignored', '--nocapture']
    env = {'NDLOCR_RAW_STOP_MANIFEST': str(root / f'prepared/manifest-{label}.json'),
           'NDLOCR_RAW_STOP_OUTPUT': str(root / f'raw-{label}'), 'NDLOCR_TEST_PARSEQ_MODEL': model['path'],
           'NDLOCR_TEST_CHARSET': 'models/NDLmoji.yaml', 'NDLOCR_INTRA_THREADS': '1'}
    started = time.monotonic()
    with (root / f'raw-{label}.stdout').open('wb') as stdout, (root / f'raw-{label}.stderr').open('wb') as stderr:
        result = subprocess.run(argv, env=os.environ | env, stdout=stdout, stderr=stderr)
    command = {'model': label, 'argv': argv, 'env': env, 'exit_code': result.returncode, 'seconds': time.monotonic() - started}
    commands.append(command)
    (root / 'raw-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0, command
    rows = json.loads((root / f'raw-{label}/results.json').read_text())
    assert len(rows) == 54
    print(label, 'captured', len(rows), 'errors', sum('error' in row for row in rows), flush=True)
assert all(sha(path) == checksum for path, checksum in sources.items())
(root / 'raw-complete.json').write_text(json.dumps({'exit_code': 0, 'api_calls': 162,
    'all_files_unchanged': True, 'internal_session_run_calls': None, 'model_loads': 3,
    'commands': commands}, indent=2) + '\n')
