from pathlib import Path
import json,hashlib,subprocess,os,shutil,datetime,time
r=Path('tmp/vertical-output-capacity');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='f3f828d057e6668b8df200285b6a3b37cc1356db'
expected={'src/infer/mod.rs':'\n#[cfg(test)]\nmod output_capacity;\n','src/infer/cached.rs':'\n#[cfg(test)]\n#[path = "../../tests/support/output_capacity_metadata.rs"]\nmod output_capacity_metadata;\n'}
for p,suffix in expected.items():
 original=subprocess.check_output(['git','show','HEAD:'+p]);assert Path(p).read_bytes()==original+suffix.encode(),p
for p in subprocess.check_output(['git','ls-files','src','tests','examples'],text=True).splitlines():
 if p.endswith('.rs')and p not in expected:assert Path(p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p]),p
models=json.loads(Path('tmp/vertical-capacity/policy/product-freeze.json').read_text())['models'];assert all(sha(p)==h for p,h in models.items());manifest=r/'models-before-load.json';selected=[{'label':label,'path':next(p for p in models if '-'+label+'-tiny-'in p)}for label in ('30','50','100')]
for x in selected:x['sha256']=sha(x['path'])
manifest.write_text(json.dumps({'models':selected},indent=2)+'\n');events=[]
for line in (r/'build.jsonl').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
assert any(x.get('reason')=='build-finished' and x.get('success')for x in events);exes=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and 'lib'in x['target']['kind']];assert len(exes)==1;binary=r/'metadata-binary';shutil.copy2(exes[0],binary);sources={str(p):sha(p)for p in [*Path('src').rglob('*.rs'),*Path('tests').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock')]};snapshot=r/'source-before-load'
for p in sources:
 target=snapshot/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'published_base':head,'production_sources_byte_identical_except_cfg_test_declarations':True,'models':models,'source_sha256':sources,'binary_sha256':sha(binary),'manifest_sha256':sha(manifest),'spec_sha256':sha('docs/vertical_output_capacity_audit.md'),'driver_sha256':sha(__file__),'session_run_calls':0,'image_recognition_calls':0};(r/'freeze-before-load.json').write_text(json.dumps(meta,indent=2)+'\n');argv=[str(binary.resolve()),'infer::cached::output_capacity_metadata::capture_output_capacity_metadata_without_nn','--exact','--ignored','--nocapture'];env={'NDLOCR_OUTPUT_CAPACITY_MODEL_MANIFEST':str(manifest),'NDLOCR_OUTPUT_CAPACITY_OUTPUT':str(r/'metadata'),'NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_INTRA_THREADS':'1'};t=time.monotonic()
with(r/'metadata.stdout').open('wb')as a,(r/'metadata.stderr').open('wb')as b:d=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=b)
assert d.returncode==0;rows=json.loads((r/'metadata/results.json').read_text());assert len(rows)==3 and [x['label']for x in rows]==['30','50','100'];assert all(x['session_run_calls']==x['image_recognition_calls']==0 for x in rows);assert all(sha(p)==h for p,h in models.items());assert all(sha(p)==h for p,h in sources.items());meta.update(exit_code=0,argv=argv,env=env,seconds=time.monotonic()-t,model_loads=3,all_sources_models_unchanged=True);(r/'metadata-command.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False,indent=2))
