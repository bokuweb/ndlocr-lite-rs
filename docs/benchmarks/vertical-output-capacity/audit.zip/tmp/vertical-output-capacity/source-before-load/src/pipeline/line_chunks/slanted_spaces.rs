use super::{BlankGap, blank_gaps_with_word_gap_limit};

/// 元画像の白列へ、強い傾き補正でも確認できる単語空白だけを加える。
pub(super) fn restore_slanted_word_spaces(
    rgb: &[u8],
    width: usize,
    height: usize,
    threshold: u8,
    gaps: &mut [BlankGap],
) {
    if width as u128 <= height as u128 * 8 || gaps.iter().all(|gap| gap.word_space) {
        return;
    }
    let mask: Vec<_> = rgb
        .chunks_exact(3)
        .map(|pixel| {
            u16::from(pixel[0]) + u16::from(pixel[1]) + u16::from(pixel[2])
                < u16::from(threshold) * 3
        })
        .collect();
    let Some(projected_width) = width.checked_add((height - 1) / 4) else {
        return;
    };
    let mut counts = vec![0usize; projected_width];
    let baseline = projection_score(&mask, width, height, 0, &mut counts);
    let mut best = baseline;
    let mut slope = 0;
    for candidate in [-8, -6, -4, -2, 2, 4, 6, 8] {
        let score = projection_score(&mask, width, height, candidate, &mut counts);
        if score > best {
            best = score;
            slope = candidate;
        }
    }
    if slope == 0 || best - baseline < baseline.div_ceil(10) {
        return;
    }
    let Some(size) = projected_width
        .checked_mul(height)
        .and_then(|n| n.checked_mul(3))
    else {
        return;
    };
    let mut projected = vec![255; size];
    for (y, row) in mask.chunks_exact(width).enumerate() {
        let offset = row_shift(y, height, slope);
        for (x, &ink) in row.iter().enumerate() {
            if ink {
                let index = (y * projected_width + x + offset) * 3;
                projected[index..index + 3].fill(0);
            }
        }
    }
    let supported = gaps.iter().filter(|gap| gap.word_space);
    let word_gap_limit = if supported.clone().count() >= 6 {
        supported.map(|gap| gap.width).min().unwrap_or(usize::MAX)
    } else {
        usize::MAX
    };
    let confirmed = blank_gaps_with_word_gap_limit(
        &projected,
        projected_width,
        height,
        threshold,
        word_gap_limit,
    );
    let center_shift = row_shift(height / 2, height, slope);
    let supported = |gap: &BlankGap| {
        let center = gap.midpoint + center_shift;
        confirmed.iter().any(|candidate| {
            let start = candidate.midpoint - candidate.width / 2;
            candidate.word_space && (start..start + candidate.width).contains(&center)
        })
    };
    // 弱い傾きは、投影と元白列の双方が6個以上の単語空白を支持するときだけ採る。
    if best - baseline < baseline.div_ceil(5)
        && gaps.iter().filter(|gap| supported(gap)).count() < 6
    {
        return;
    }
    for gap in gaps {
        gap.word_space |= supported(gap);
    }
}

/// 32分率の傾きを、画像外へ出ない非負の行オフセットへ変換する。
fn row_shift(y: usize, height: usize, slope: i32) -> usize {
    let row = if slope < 0 { height - 1 - y } else { y };
    row * slope.unsigned_abs() as usize / 32
}

/// 列ごとのインク数の二乗和により、画線が縦に揃う傾きを比較する。
fn projection_score(
    mask: &[bool],
    width: usize,
    height: usize,
    slope: i32,
    counts: &mut [usize],
) -> u128 {
    counts.fill(0);
    for (y, row) in mask.chunks_exact(width).enumerate() {
        let offset = row_shift(y, height, slope);
        for (x, &ink) in row.iter().enumerate() {
            counts[x + offset] += usize::from(ink);
        }
    }
    counts.iter().map(|&count| (count as u128).pow(2)).sum()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::pipeline::line_chunks::blank_gaps;

    /// 原寸の斜体行を一度だけ正規化し、画素変換の回帰へ共有する。
    fn punctuation_line() -> &'static (Vec<u8>, usize, usize) {
        static LINE: std::sync::OnceLock<(Vec<u8>, usize, usize)> = std::sync::OnceLock::new();
        LINE.get_or_init(|| {
            use crate::{
                io::load_rgb_u8,
                pipeline::{
                    background::normalize_chromatic_panels,
                    crop::{BBox, crop_rgb_u8},
                    line_segment::detect_textline_bands_naive,
                },
            };
            let image = load_rgb_u8(std::path::Path::new(
                "tests/fixtures/chromatic_text_contrast/page.png",
            ))
            .unwrap();
            let rgb = normalize_chromatic_panels(&image.data, image.width, image.height).unwrap();
            let bands = detect_textline_bands_naive(&rgb, image.width, image.height, 220);
            let [x0, y0, x1, y1] = bands[6];
            let line =
                crop_rgb_u8(&rgb, image.width, image.height, BBox::new(x0, y0, x1, y1)).unwrap();
            (line.data, line.width, line.height)
        })
    }

    /// 弱い擬似斜体でも、投影後に6実空白が確認できれば元境界を復元する。
    #[test]
    fn weak_slant_requires_six_confirmed_spaces() {
        use crate::{
            io::load_rgb_u8,
            pipeline::crop::{BBox, crop_rgb_u8},
        };
        let page = load_rgb_u8(std::path::Path::new(
            "tests/fixtures/font_emulation_context/page.png",
        ))
        .unwrap();
        let line = crop_rgb_u8(
            &page.data,
            page.width,
            page.height,
            BBox::new(204, 652, 1038, 686),
        )
        .unwrap();
        let mut gaps = blank_gaps(&line.data, line.width, line.height, 220);
        assert!(gaps.iter().all(|gap| !gap.word_space));
        let mut unsupported = blank_gaps(&line.data, line.width, line.height, 220);
        unsupported.retain(|gap| gap.midpoint != 94);
        restore_slanted_word_spaces(&line.data, line.width, line.height, 220, &mut unsupported);
        assert!(
            unsupported.iter().all(|gap| !gap.word_space),
            "five matches must not relax the slope gate"
        );
        let before: Vec<_> = gaps
            .iter()
            .map(|g| (g.midpoint, g.width, g.preferred_split))
            .collect();
        restore_slanted_word_spaces(&line.data, line.width, line.height, 220, &mut gaps);
        assert!(gaps.iter().find(|g| g.midpoint == 391).unwrap().word_space);
        assert!(gaps.iter().find(|g| g.midpoint == 604).unwrap().word_space);
        assert_eq!(gaps.iter().filter(|g| g.word_space).count(), 6);
        assert_eq!(
            gaps.iter()
                .map(|g| (g.midpoint, g.width, g.preferred_split))
                .collect::<Vec<_>>(),
            before
        );
    }

    proptest::proptest! {
        #![proptest_config(proptest::test_runner::Config::with_cases(12))]
        /// 弱い傾きの6空白支持を拡大・移動・反転でも確認し、既存境界は保存する。
        #[test]
        fn weak_slant_preserves_pixel_geometry(
            scale in 1usize..4, margin in 0usize..8, reflected in proptest::bool::ANY,
        ) {
            use crate::{io::load_rgb_u8, pipeline::crop::{BBox, crop_rgb_u8}};
            let page = load_rgb_u8(std::path::Path::new(
                "tests/fixtures/font_emulation_context/page.png",
            )).unwrap();
            let line = crop_rgb_u8(&page.data, page.width, page.height,
                BBox::new(204, 652, 1038, 686)).unwrap();
            let width = line.width * scale + margin * 2;
            let height = line.height * scale;
            let mut rgb = vec![255; width*height*3];
            for y in 0..height {
                for x in 0..line.width*scale {
                    let target = if reflected {width-1-margin-x} else {margin+x};
                    let source = ((y/scale)*line.width+x/scale)*3;
                    rgb[(y*width+target)*3..(y*width+target)*3+3]
                        .copy_from_slice(&line.data[source..source+3]);
                }
            }
            let mut gaps = blank_gaps(&rgb,width,height,220);
            let before:Vec<_>=gaps.iter().map(|g|(g.midpoint,g.width,g.preferred_split,g.word_space)).collect();
            restore_slanted_word_spaces(&rgb,width,height,220,&mut gaps);
            proptest::prop_assert_eq!(gaps.iter().filter(|gap| gap.word_space).count(),6);
            for (gap,(midpoint,gap_width,preferred,word)) in gaps.iter().zip(before) {
                proptest::prop_assert_eq!((gap.midpoint,gap.width,gap.preferred_split),(midpoint,gap_width,preferred));
                proptest::prop_assert!(!word || gap.word_space);
            }
        }
    }

    /// 元画像に6個の確認済み空白がある場合だけ、その幅を補正後へ引き継ぐ。
    #[test]
    fn punctuation_space_requires_original_gap_support() {
        let (rgb, width, height) = punctuation_line();
        for support in [5, 6] {
            let mut gaps = blank_gaps(rgb, *width, *height, 220);
            let mut retained = 0;
            for gap in &mut gaps {
                if gap.word_space {
                    retained += 1;
                    gap.word_space = retained <= support;
                }
            }
            restore_slanted_word_spaces(rgb, *width, *height, 220, &mut gaps);
            let target = gaps.iter().find(|gap| gap.midpoint == 1324).unwrap();
            assert_eq!(target.word_space, support == 6);
        }
    }

    proptest::proptest! {
        #![proptest_config(proptest::test_runner::Config::with_cases(12))]
        /// 拡大・移動・反転でも句読点後の空白を戻し、既存の白列と確認済み空白を保つ。
        #[test]
        fn punctuation_space_preserves_pixel_geometry(
            scale in 1usize..4, margin in 0usize..16, reflected in proptest::bool::ANY,
        ) {
            let (source, source_width, source_height) = punctuation_line();
            let width = source_width * scale + margin * 2;
            let height = source_height * scale;
            let mut rgb = vec![255; width * height * 3];
            for y in 0..height {
                for x in 0..source_width * scale {
                    let target = if reflected {width - 1 - margin - x} else {margin + x};
                    let i = ((y/scale) * source_width + x/scale) * 3;
                    rgb[(y*width+target)*3..(y*width+target)*3+3].copy_from_slice(&source[i..i+3]);
                }
            }
            let target = if reflected {width-margin-1324*scale} else {margin+1324*scale};
            let mut gaps = blank_gaps(&rgb,width,height,220);
            let before: Vec<_> = gaps.iter().map(|g|(g.midpoint,g.width,g.word_space,g.preferred_split,g.internal_glyph_gap)).collect();
            restore_slanted_word_spaces(&rgb,width,height,220,&mut gaps);
            let nearest = gaps.iter().min_by_key(|g|g.midpoint.abs_diff(target)).unwrap();
            proptest::prop_assert!(nearest.midpoint.abs_diff(target)<=scale);
            proptest::prop_assert!(nearest.word_space);
            for (gap, (midpoint,gap_width,word,preferred,internal)) in gaps.iter().zip(before) {
                proptest::prop_assert_eq!((gap.midpoint,gap.width,gap.preferred_split,gap.internal_glyph_gap),(midpoint,gap_width,preferred,internal));
                proptest::prop_assert!(!word || gap.word_space);
            }
        }
    }

    /// 字間は連結して見えるが、実単語間の白列が残る斜体行を作る。
    fn slanted_words(
        scale: usize,
        margin: usize,
        reflected: bool,
        slanted: bool,
    ) -> (Vec<u8>, usize, usize) {
        let height = 48 * scale;
        let width = 6 * (4 * 26 + 24) * scale + 2 * margin + 12 * scale;
        let mut rgb = vec![255; width * height * 3];
        for word in 0..6 {
            for letter in 0..4 {
                for y in 0..height {
                    let shift = if slanted { (height - 1 - y) / 4 } else { 0 };
                    let x0 = margin + (word * (4 * 26 + 24) + letter * 26) * scale + shift;
                    for x in x0..x0 + 18 * scale {
                        let x = if reflected { width - 1 - x } else { x };
                        rgb[(y * width + x) * 3..(y * width + x + 1) * 3].fill(0);
                    }
                }
            }
        }
        (rgb, width, height)
    }

    /// 重なった字間を空白にせず、元のモデル入力境界に残る実単語空白を復元する。
    #[test]
    fn slanted_projection_recovers_only_supported_word_spaces() {
        for reflected in [false, true] {
            let (rgb, width, height) = slanted_words(1, 7, reflected, true);
            let mut gaps = blank_gaps(&rgb, width, height, 220);
            assert_eq!(gaps.len(), 5);
            assert!(gaps.iter().all(|g| !g.word_space));
            restore_slanted_word_spaces(&rgb, width, height, 220, &mut gaps);
            assert!(gaps.iter().all(|g| g.word_space), "reflection={reflected}");
        }
    }

    /// 直立した字形は従来の判定を保ち、新しい空白を増やさない。
    #[test]
    fn upright_projection_preserves_existing_spaces() {
        let (rgb, width, height) = slanted_words(1, 11, false, false);
        let mut gaps = blank_gaps(&rgb, width, height, 220);
        let before: Vec<_> = gaps.iter().map(|g| g.word_space).collect();
        restore_slanted_word_spaces(&rgb, width, height, 220, &mut gaps);
        assert_eq!(
            before,
            gaps.iter().map(|g| g.word_space).collect::<Vec<_>>()
        );
    }

    proptest::proptest! {
        /// 拡大・移動・反転しても実空白を戻し、分割位置と字形保護属性を維持する。
        #[test]
        fn slanted_word_spaces_preserve_geometry(
            scale in 1usize..5, margin in 0usize..32, reflected in proptest::bool::ANY,
        ) {
            let (rgb,width,height)=slanted_words(scale,margin,reflected,true);
            let mut gaps=blank_gaps(&rgb,width,height,220);
            let before: Vec<_> = gaps.iter().map(|g|
                (g.midpoint,g.width,g.preferred_split,g.internal_glyph_gap)
            ).collect();
            proptest::prop_assert_eq!(gaps.len(),5);
            restore_slanted_word_spaces(&rgb,width,height,220,&mut gaps);
            proptest::prop_assert!(gaps.iter().all(|g|g.word_space));
            proptest::prop_assert_eq!(before,gaps.iter().map(|g|
                (g.midpoint,g.width,g.preferred_split,g.internal_glyph_gap)
            ).collect::<Vec<_>>());
        }
    }
}
