//! Load the pinned models and inspect metadata only; no image and no Session.run.
use super::*;

#[test]
#[ignore = "metadata diagnostic; requires model manifest and new output directory, no recognition"]
fn capture_output_capacity_metadata_without_nn() {
    let Some(path) = std::env::var_os("NDLOCR_OUTPUT_CAPACITY_MODEL_MANIFEST") else {
        return;
    };
    let manifest: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let out = std::path::PathBuf::from(std::env::var_os("NDLOCR_OUTPUT_CAPACITY_OUTPUT").unwrap());
    std::fs::create_dir(&out).unwrap();
    let charset_path = std::path::PathBuf::from(std::env::var_os("NDLOCR_TEST_CHARSET").unwrap());
    let charset =
        load_charset_from_yaml_str(&std::fs::read_to_string(charset_path).unwrap()).unwrap();
    let mut records = Vec::new();
    for model in manifest["models"].as_array().unwrap() {
        let session = build_session(Path::new(model["path"].as_str().unwrap()), 1).unwrap();
        let mut inputs = Vec::new();
        for input in session.inputs() {
            let dimensions = input.dtype().tensor_shape().map(|shape| {
                let dims: &[i64] = shape;
                dims.to_vec()
            });
            inputs.push(serde_json::json!({"name":input.name(),"dtype_debug":format!("{:?}",input.dtype()),"dimensions":dimensions}));
        }
        let mut outputs = Vec::new();
        for output in session.outputs() {
            let dimensions = output.dtype().tensor_shape().map(|shape| {
                let dims: &[i64] = shape;
                dims.to_vec()
            });
            let bound = dimensions.as_deref().and_then(|shape| {
                super::super::output_capacity::static_frame_limit(shape, charset.len())
            });
            outputs.push(serde_json::json!({"name":output.name(),"dtype_debug":format!("{:?}",output.dtype()),"dimensions":dimensions,"max_raw_scalars_from_static_shape":bound}));
        }
        records.push(serde_json::json!({"label":model["label"],"path":model["path"],"charset_scalars":charset.len(),"inputs":inputs,"outputs":outputs,"image_recognition_calls":0,"session_run_calls":0}));
    }
    std::fs::write(
        out.join("results.json"),
        serde_json::to_vec_pretty(&records).unwrap(),
    )
    .unwrap();
    println!(
        "{} models loaded; metadata inspected, no images or Session.run",
        records.len()
    );
}
