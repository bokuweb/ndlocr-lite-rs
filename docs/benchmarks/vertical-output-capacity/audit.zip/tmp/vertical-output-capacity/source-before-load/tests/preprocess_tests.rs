use ndlocr_lite_rs::infer::{deim, parseq};
use proptest::prelude::*;

/// 空の軸を持つ入力は、補間座標を作る前に明示エラーにする。
#[test]
fn parseq_preprocess_rejects_zero_source_dimensions() {
    for (width, height) in [(0, 0), (0, 8), (8, 0)] {
        assert!(parseq::preprocess_rgb_u8(&[], width, height, 2, 2).is_err());
    }
}

#[test]
fn parseq_preprocess_rotates_vertical_image_and_normalizes() {
    let rgb = vec![255_u8, 0, 0, 0, 0, 255];
    let out = parseq::preprocess_rgb_u8(&rgb, 1, 2, 2, 1).unwrap();
    // NCHW B,G,R（Python parseq.py の RGB→BGR と同じ並び）
    assert_eq!(out, vec![-1.0, 1.0, -1.0, -1.0, 1.0, -1.0]);
}

#[test]
fn parseq_preprocess_into_matches_allocating_output() {
    for &(width, height, input_width, input_height) in &[
        (7usize, 5usize, 13usize, 3usize),
        (5usize, 7usize, 13usize, 3usize),
    ] {
        let rgb = make_rgb(width, height);
        let allocating = parseq::preprocess_rgb_u8(&rgb, width, height, input_width, input_height)
            .expect("allocating preprocess should succeed");
        let mut into = vec![0.0f32; allocating.len()];
        parseq::preprocess_rgb_u8_into(&mut into, &rgb, width, height, input_width, input_height)
            .expect("direct preprocess should succeed");
        assert_eq!(into, allocating);
    }
}

#[test]
fn parseq_preprocess_into_rejects_wrong_output_size() {
    let rgb = vec![255_u8, 0, 0];
    let mut out = vec![0.0f32; 2];
    let err = parseq::preprocess_rgb_u8_into(&mut out, &rgb, 1, 1, 1, 1)
        .expect_err("must reject wrong output size");
    assert!(err.to_string().contains("output buffer length"));
}

#[test]
fn deim_preprocess_pads_to_square_and_returns_metadata() {
    let rgb = vec![255_u8, 255, 255, 0, 0, 0];
    let out = deim::preprocess_rgb_u8(&rgb, 2, 1, 2, 2).unwrap();
    assert_eq!(out.padded_wh, 2);
    assert_eq!(out.tensor.len(), 12);
}

#[test]
fn deim_preprocess_matches_direct_formula_for_padding_and_pixels() {
    let rgb = make_rgb(3, 2);
    let out = deim::preprocess_rgb_u8(&rgb, 3, 2, 5, 5).unwrap();
    let expected = reference_deim_preprocess(&rgb, 3, 2, 5, 5);
    assert_eq!(out.padded_wh, 3);
    assert_eq!(out.tensor, expected);
}

proptest! {
    #[test]
    fn parseq_preprocess_normalized_values_are_in_range(
        w in 1usize..5, h in 1usize..5,
        data in proptest::collection::vec(any::<u8>(), 3usize..300)
    ) {
        let needed = w*h*3;
        prop_assume!(data.len() >= needed);
        let out = parseq::preprocess_rgb_u8(&data[0..needed], w, h, w, h).unwrap();
        for &v in &out { prop_assert!(v >= -1.0 && v <= 1.0); }
    }
}

fn reference_deim_preprocess(
    rgb: &[u8],
    width: usize,
    height: usize,
    input_width: usize,
    input_height: usize,
) -> Vec<f32> {
    let max_wh = width.max(height);
    let mut out = vec![0.0_f32; 3 * input_width * input_height];
    let plane = input_width * input_height;
    let mean = [0.485_f32, 0.456_f32, 0.406_f32];
    let std = [0.229_f32, 0.224_f32, 0.225_f32];
    for y in 0..input_height {
        let sy = y * max_wh / input_height;
        let in_h = sy < height;
        for x in 0..input_width {
            let sx = x * max_wh / input_width;
            let i = y * input_width + x;
            if in_h && sx < width {
                let s = (sy * width + sx) * 3;
                out[i] = (rgb[s] as f32 / 255.0 - mean[0]) / std[0];
                out[plane + i] = (rgb[s + 1] as f32 / 255.0 - mean[1]) / std[1];
                out[plane * 2 + i] = (rgb[s + 2] as f32 / 255.0 - mean[2]) / std[2];
            } else {
                out[i] = -mean[0] / std[0];
                out[plane + i] = -mean[1] / std[1];
                out[plane * 2 + i] = -mean[2] / std[2];
            }
        }
    }
    out
}

fn make_rgb(w: usize, h: usize) -> Vec<u8> {
    let mut out = vec![0u8; w * h * 3];
    for y in 0..h {
        for x in 0..w {
            let i = (y * w + x) * 3;
            out[i] = ((x * 17 + y * 11) % 255) as u8;
            out[i + 1] = ((x * 7 + y * 13) % 255) as u8;
            out[i + 2] = ((x * 19 + y * 3) % 255) as u8;
        }
    }
    out
}

/// 公式1.3.1の方針に合わせ、ほぼ正方形の切り出しも反時計回りにする。
#[test]
fn parseq_rotates_nearly_square_crops_like_current_upstream() {
    for (width, height, rotate) in [(5, 4, false), (5, 5, true), (10, 8, false), (10, 9, true)] {
        let rgb = make_rgb(width, height);
        let expected_rgb = if rotate {
            let mut result = Vec::new();
            for y in 0..width {
                for x in 0..height {
                    let i = (x * width + width - 1 - y) * 3;
                    result.extend_from_slice(&rgb[i..i + 3]);
                }
            }
            result
        } else {
            rgb.clone()
        };
        let (out_w, out_h) = if rotate {
            (height, width)
        } else {
            (width, height)
        };
        let out = parseq::preprocess_rgb_u8(&rgb, width, height, out_w, out_h).unwrap();
        let expected: Vec<f32> = [2, 1, 0]
            .into_iter()
            .flat_map(|c| {
                expected_rgb
                    .chunks_exact(3)
                    .map(move |p| f32::from(p[c]) / 127.5 - 1.0)
            })
            .collect();
        assert_eq!(out, expected, "{width}x{height}");
    }
}

/// 横書き指定は正方形・縦長を含む全寸法で元画素の向きを保つ。
#[test]
fn horizontal_preprocess_preserves_pixel_orientation() {
    for (w, h) in [(5, 4), (5, 5), (10, 9), (1, 4), (46, 48)] {
        let rgb = make_rgb(w, h);
        let out = parseq::preprocess_rgb_u8_with_orientation(
            &rgb,
            w,
            h,
            w,
            h,
            parseq::ParseqOrientation::Horizontal,
        )
        .unwrap();
        let expected: Vec<f32> = [2, 1, 0]
            .into_iter()
            .flat_map(|c| {
                rgb.chunks_exact(3)
                    .map(move |p| f32::from(p[c]) / 127.5 - 1.0)
            })
            .collect();
        assert_eq!(out, expected);
    }
}

proptest! {
    /// 寸法が交互に変わっても方向指定と補間座標キャッシュを保持する。
    #[test]
    fn horizontal_scratch_matches_allocating_after_dimension_changes(
        dimensions in proptest::collection::vec((1usize..30, 1usize..30), 1..8),
    ) {
        let orientation = parseq::ParseqOrientation::Horizontal;
        let mut scratch = parseq::PreprocessScratch::with_orientation(orientation);
        for (w, h) in dimensions {
            let rgb = make_rgb(w, h);
            let expected = parseq::preprocess_rgb_u8_with_orientation(&rgb, w, h, 13, 3, orientation).unwrap();
            let mut actual = vec![0.; expected.len()];
            parseq::preprocess_rgb_u8_into_with_scratch(&mut actual, &rgb, w, h, 13, 3, &mut scratch).unwrap();
            prop_assert_eq!(actual, expected);
        }
    }
}

/// 横書き指定でも入力と出力寸法の検証を省略しない。
#[test]
fn horizontal_preprocess_rejects_invalid_buffers() {
    for (rgb, w, h, ow, oh) in [
        (&[][..], 0, 0, 2, 2),
        (&[0; 2][..], 1, 1, 2, 2),
        (&[0; 3][..], 1, 1, 0, 2),
    ] {
        assert!(
            parseq::preprocess_rgb_u8_with_orientation(
                rgb,
                w,
                h,
                ow,
                oh,
                parseq::ParseqOrientation::Horizontal
            )
            .is_err()
        );
    }
}
