# 縦書き残差の出力容量監査

## 追加実装・メタデータ読取・追加NN前の仕様

縦列容量回復f3f828dの前後比較を終えても、既知縦書き7入力のPageRecognizer30（eval）には
73/277 scalarの誤りが残る。ordinary 5、numerals 33、kana 13、手書き18、center_one 1、
center_two 1、center_three 2。既存の明示縦列APIの検査とは経路や紙準備が異なるため、
これを出力容量だけが原因だと断定しない。Hの固定条件を既知結果へ合わせて緩めない。

最初はモデルを変更せず、固定済み3モデルのinput/outputのdtype・次元とcharset長を記録する。
同じbackendへモデルをloadするが、Session.runや画像認識を呼ばない。モデルSHAを前後照合し、
動的/不明な次元もそのまま残す。モデル名の30/50/100から出力上限を推定しない。

既存decoderは[N,T,C]（または単件[T,C]）の各Tで最大1 Unicode scalarを追加し、EOSまたは
低confidenceで早期停止する。Tが正の固定値、Cがcharset長+1と一致する場合に限り、
raw出力scalar数の上限Tとして扱う。rank不一致、T/C不明、0、class不一致や変換overflowは
上限不明とし、仮の数字を埋めない。charset長+1とT*Cのusize計算もcheckedで扱う。batchの動的次元とTの動的次元を混同しない。

この静的上限の抽出は正/legacy2次元/動的batch、動的T/C・不正rank/class/0・overflowの
小さいRed→Greenを先行する。元worktreeの製品を変えず、別コピーへ診断だけを追加してよい。
これはメタデータ監査で、追加NNや精度改善には数えない。

次の段階で、上限到達・EOS・低confidence終了、検出crop、紙、内部白帯/分割境界を
既存保存データから区別する。新しい分割候補や閾値を試す場合は別仕様と未認識の対照を
先に固定し、全入力別文字・単語退行、余白/図形の安定性、実モデルRedを再確認する。
f3f828dの2採用・棄却例は開発回帰として保持する。新候補はこの文書時点で未実装である。
