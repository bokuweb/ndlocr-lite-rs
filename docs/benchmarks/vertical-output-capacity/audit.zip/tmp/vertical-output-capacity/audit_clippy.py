from pathlib import Path
import json
r=Path('tmp/vertical-output-capacity')
def warns(path):
 out={}
 for line in path.read_text().splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if x.get('reason')!='compiler-message'or x['message']['level']!='warning':continue
  m=x['message'];key=((m.get('code')or{}).get('code'),m['message'],tuple((p['file_name'],tuple((t['text'],t['highlight_start'],t['highlight_end'])for t in p['text']))for p in m['spans']if p['is_primary']));out[key]=m
 return out
old=warns(Path('tmp/narrow-round-profile/clippy-after-tests.log'));new=warns(r/'clippy.jsonl');added=[{'code':k[0],'message':k[1],'primary_source_spans':k[2]}for k in new.keys()-old.keys()];result={'key':'code,message,primary file and source text/highlight (line-independent)' ,'baseline_warning_locations':len(old),'current_warning_locations':len(new),'new_warnings':added};(r/'clippy-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not added
