use super::PreparedLineCrop;
use crate::infer::parseq::RecognizeResult;
use std::io::Write;
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};

pub(super) struct Trace {
    directory: Option<PathBuf>,
    sequence: AtomicUsize,
}
impl Trace {
    pub(super) fn new(directory: Option<PathBuf>) -> anyhow::Result<Self> {
        if let Some(path) = directory.as_ref() {
            std::fs::create_dir(path)?;
        }
        Ok(Self {
            directory,
            sequence: AtomicUsize::new(0),
        })
    }
    #[cfg(feature = "onnx")]
    pub(super) fn from_env() -> anyhow::Result<Self> {
        Self::new(std::env::var_os("NDLOCR_CLI_STAGE_TRACE_DIR").map(PathBuf::from))
    }
    pub(super) fn observe_batch<F>(
        &self,
        phase: &str,
        selected: (usize, usize),
        items: &[(usize, &PreparedLineCrop)],
        recognize: F,
    ) -> anyhow::Result<Vec<(usize, RecognizeResult)>>
    where
        F: FnOnce() -> anyhow::Result<Vec<(usize, RecognizeResult)>>,
    {
        let results = recognize()?;
        let observed: Vec<_> = results
            .iter()
            .map(|(index, result)| (*index, result))
            .collect();
        self.write_event("batch", phase, Some(selected), items, &observed)?;
        Ok(results)
    }
    pub(super) fn snapshot(
        &self,
        phase: &str,
        crops: &[PreparedLineCrop],
        results: &[RecognizeResult],
    ) -> anyhow::Result<()> {
        let items: Vec<_> = crops.iter().enumerate().collect();
        let observed: Vec<_> = results.iter().enumerate().collect();
        self.write_event("snapshot", phase, None, &items, &observed)
    }

    fn write_event(
        &self,
        kind: &str,
        phase: &str,
        selected: Option<(usize, usize)>,
        items: &[(usize, &PreparedLineCrop)],
        results: &[(usize, &RecognizeResult)],
    ) -> anyhow::Result<()> {
        let Some(directory) = &self.directory else {
            return Ok(());
        };
        let sequence = self.sequence.fetch_add(1, Ordering::Relaxed);
        let mut recorded_items = Vec::new();
        for (index, line) in items {
            let member = format!("{sequence:06}-{index}.rgb");
            let mut file = std::fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(directory.join(&member))?;
            file.write_all(&line.crop.data)?;
            recorded_items.push(serde_json::json!({
                "index": index, "bbox": line.bbox_xyxy,
                "pred_char_count_bits": line.pred_char_count.to_bits(),
                "det_confidence_bits": line.confidence.to_bits(), "is_vertical": line.is_vertical,
                "crop": {"file":member,"width":line.crop.width,"height":line.crop.height},
            }));
        }
        let recorded_results: Vec<_> = results.iter().map(|(index, result)| serde_json::json!({
            "index":index,"text":&result.text,"mean_confidence_bits":result.mean_confidence.to_bits(),
        })).collect();
        let event = serde_json::json!({"kind":kind,"phase":phase,"selected_pool_input":selected,"items":recorded_items,"results":recorded_results});
        let mut file = std::fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(directory.join(format!("{sequence:06}.json")))?;
        file.write_all(&serde_json::to_vec_pretty(&event)?)?;
        Ok(())
    }
}

#[cfg(test)]
#[path = "../../tests/support/cli_cascade_trace.rs"]
mod tests;
