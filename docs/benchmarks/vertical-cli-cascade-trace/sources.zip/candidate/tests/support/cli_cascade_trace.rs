use super::*;
fn line() -> PreparedLineCrop {
    PreparedLineCrop {
        crop: crate::pipeline::crop::CroppedImage {
            data: (0..36).collect(),
            width: 4,
            height: 3,
        },
        bbox_xyxy: [5, 7, 9, 10],
        confidence: 0.8,
        pred_char_count: 3.0,
        is_vertical: false,
    }
}
fn result() -> RecognizeResult {
    RecognizeResult {
        text: "朝\nA".into(),
        mean_confidence: 0.97,
    }
}
#[test]
fn disabled_observer_preserves_one_callback_result_error_and_pixels() {
    let trace = Trace::new(None).unwrap();
    let input = line();
    let original = input.crop.data.clone();
    let mut calls = 0;
    let values = trace
        .observe_batch("initial30", (256, 24), &[(7, &input)], || {
            calls += 1;
            Ok(vec![(7, result())])
        })
        .unwrap();
    assert_eq!(calls, 1);
    assert_eq!(values[0].0, 7);
    assert_eq!(values[0].1.text, result().text);
    assert_eq!(
        values[0].1.mean_confidence.to_bits(),
        result().mean_confidence.to_bits()
    );
    let error = trace
        .observe_batch("retry50", (384, 24), &[(7, &input)], || {
            calls += 1;
            anyhow::bail!("original model error")
        })
        .unwrap_err();
    assert_eq!(calls, 2);
    assert_eq!(error.to_string(), "original model error");
    assert_eq!(input.crop.data, original);
}
#[test]
fn enabled_observer_records_original_rgb_text_bits_and_selected_pool_dimensions() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("events");
    let trace = Trace::new(Some(path.clone())).unwrap();
    let input = line();
    let original = input.crop.data.clone();
    let mut calls = 0;
    let values = trace
        .observe_batch("../phase-is-data", (256, 24), &[(7, &input)], || {
            calls += 1;
            Ok(vec![(7, result())])
        })
        .unwrap();
    assert_eq!(calls, 1);
    assert_eq!(values[0].1.text, result().text);
    assert_eq!(input.crop.data, original);
    let event: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path.join("000000.json")).unwrap()).unwrap();
    assert_eq!(event["kind"], "batch");
    assert_eq!(event["phase"], "../phase-is-data");
    assert_eq!(event["selected_pool_input"], serde_json::json!([256, 24]));
    assert_eq!(event["items"][0]["index"], 7);
    assert_eq!(event["items"][0]["bbox"], serde_json::json!([5, 7, 9, 10]));
    assert_eq!(event["items"][0]["pred_char_count_bits"], 3.0f32.to_bits());
    assert_eq!(event["results"][0]["text"], result().text);
    assert_eq!(
        event["results"][0]["mean_confidence_bits"],
        result().mean_confidence.to_bits()
    );
    let member = event["items"][0]["crop"]["file"].as_str().unwrap();
    assert_eq!(member, "000000-7.rgb");
    assert_eq!(std::fs::read(path.join(member)).unwrap(), original);
}
#[test]
fn snapshot_is_separate_and_does_not_recognize_or_overwrite_an_earlier_event() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("events");
    let trace = Trace::new(Some(path.clone())).unwrap();
    let input = line();
    trace
        .observe_batch("initial30", (256, 24), &[(0, &input)], || {
            Ok(vec![(0, result())])
        })
        .unwrap();
    let first = std::fs::read(path.join("000000.json")).unwrap();
    trace
        .snapshot("page-batch-final", &[input], &[result()])
        .unwrap();
    assert_eq!(std::fs::read(path.join("000000.json")).unwrap(), first);
    let event: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path.join("000001.json")).unwrap()).unwrap();
    assert_eq!(event["kind"], "snapshot");
    assert!(event["selected_pool_input"].is_null());
    assert_eq!(event["results"][0]["text"], result().text);
}
#[test]
fn an_existing_trace_directory_is_rejected_without_touching_its_records() {
    let dir = tempfile::tempdir().unwrap();
    let sentinel = dir.path().join("keep");
    std::fs::write(&sentinel, b"original").unwrap();
    assert!(Trace::new(Some(dir.path().to_owned())).is_err());
    assert_eq!(std::fs::read(sentinel).unwrap(), b"original");
}
