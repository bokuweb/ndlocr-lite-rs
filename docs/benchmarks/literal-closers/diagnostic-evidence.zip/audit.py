from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
from eval_ocr_metrics import normalize_text,levenshtein
r=Path('tmp/literal-closers');data=json.loads((r/'raw.json').read_text());summary={};regressions=[];restored={};opener={'(':')','（':'）','「':'」','『':'』','【':'】'};closer={v:k for k,v in opener.items()}
for model in data['models']:
 label=model['label'];stats={'rows':len(model['rows']),'raw_exact':0,'raw_exact_lost_by_current':0,'raw_exact_restored_by_fragment':0,'raw_exact_restored_by_pixel':0,'unmatched_rows':0};restored[label]=[]
 for row in model['rows']:
  truth=row['truth'];raw=row['raw'];stack=[];unmatched=[];byte_offset=0;step_by_byte={s['range'][0]:s for s in row['steps']if s['range']is not None}
  for char in raw:
   if char in opener:stack.append(char)
   elif char in closer:
    if stack and stack[-1]==closer[char]:stack.pop()
    else:unmatched.append({'char':char,'probability':step_by_byte[byte_offset]['candidates'][0]['probability'],'offset':byte_offset})
   byte_offset+=len(char.encode())
  row['unmatched']=unmatched;stats['unmatched_rows']+=bool(unmatched)
  if raw==truth:
   stats['raw_exact']+=1
   if row['current']!=truth:
    stats['raw_exact_lost_by_current']+=1
    stats['raw_exact_restored_by_fragment']+=row['fragment']==truth
    stats['raw_exact_restored_by_pixel']+=row['pixel_candidate']==truth
    restored[label].append({'id':row['id'],'raw':raw,'current':row['current'],'fragment':row['fragment'],'pixel':row['pixel_candidate'],'unmatched':unmatched,'count_supported':row['count_supported'],'horizontal_auto':row['horizontal_auto']})
  candidates={'fragment':row['fragment'],'pixel':row['pixel_candidate']}
  for threshold in [.5,.7,.9,.99]:
   supported=row['count_supported']and row['horizontal_auto'];high=bool(unmatched)and all(x['probability']>=threshold for x in unmatched);candidates['pixel_or_p'+str(threshold)]=row['fragment']if supported or high else row['current']
  for name,candidate in candidates.items():
   s=stats.setdefault(name,{'improved':0,'equal':0,'worse':0,'word_worse':0,'old_regressions':0,'new_regressions':0})
   for norm in ['none','width','strict']:
    t,b,a=[normalize_text(x,norm)for x in [truth,row['current'],candidate]];before=levenshtein(list(t),list(b));after=before if b==a else levenshtein(list(t),list(a));s['improved'if after<before else'worse'if after>before else'equal']+=1
    if after>before:
     s['new_regressions'if row['cohort']=='literal_closers'else'old_regressions']+=1;regressions.append({'model':label,'policy':name,'id':row['id'],'normalization':norm,'truth':truth,'current':row['current'],'candidate':candidate,'before':before,'after':after,'unmatched':unmatched})
    if levenshtein(t.split(),a.split())>levenshtein(t.split(),b.split()):s['word_worse']+=1
 summary[label]=stats
(r/'audit.json').write_text(json.dumps({'summary':summary,'regressions':regressions,'raw_exact_lost':restored},ensure_ascii=False,indent=2)+'\n');(r/'annotated-raw.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2));print('first regressions',json.dumps(regressions[:8],ensure_ascii=False,indent=2))
