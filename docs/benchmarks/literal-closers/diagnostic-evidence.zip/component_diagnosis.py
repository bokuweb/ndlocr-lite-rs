"""Descriptive replay of the existing count test; does not propose a new policy."""
from pathlib import Path
import json,collections
from PIL import Image
import numpy as np
r=Path('tmp/literal-closers')
def explain(path,count):
 a=np.asarray(Image.open(path).convert('RGB'),dtype=np.uint16);h,w,_=a.shape;mask=a.sum(axis=2)<660;cs=[]
 for y in range(h):
  for x in range(w):
   if not mask[y,x]:continue
   mask[y,x]=False;q=[(x,y)];xs=[];ys=[]
   while q:
    xx,yy=q.pop();xs.append(xx);ys.append(yy)
    for ny in range(max(0,yy-1),min(h,yy+2)):
     for nx in range(max(0,xx-1),min(w,xx+2)):
      if mask[ny,nx]:mask[ny,nx]=False;q.append((nx,ny))
   if len(xs)>=3:cs.append({'x0':min(xs),'x1':max(xs)+1,'y0':min(ys),'y1':max(ys)+1,'area':len(xs)})
 if not cs:return {'supported':False,'reason':'no_components','components':[]}
 body=max(c['y1']-c['y0']for c in cs);cs=[c for c in cs if c['area']>=max(3,(body+1)//2)];cs.sort(key=lambda c:c['x0']);reason='supported'
 if len(cs)!=count:reason='component_count'
 elif(max(0,min(c['y1']for c in cs)-max(c['y0']for c in cs))*4<body*3):reason='common_height'
 elif any(c['x1']-c['x0']>body*2 for c in cs):reason='width'
 elif any(a['x1']>b['x0']for a,b in zip(cs,cs[1:])):reason='x_overlap'
 return {'supported':reason=='supported','reason':reason,'body_height':body,'expected_count':count,'components':cs}
d=json.loads((r/'raw.json').read_text());cache={};summary=collections.Counter();rows=[]
for m in d['models']:
 for x in m['rows']:
  if x['raw']!=x['truth']or x['current']==x['truth']or x['pixel_candidate']==x['truth']:continue
  key=(x['png'],len(x['fragment']))
  if key not in cache:cache[key]=explain(*key)
  out=cache[key];assert out['supported']==x['count_supported'];summary[out['reason']]+=1;rows.append({'model':m['label'],'id':x['id'],'raw':x['raw'],**out})
assert len(rows)==80
(r/'component-diagnosis.json').write_text(json.dumps({'raw_correct_remaining':len(rows),'reasons':summary,'rows':rows},ensure_ascii=False,indent=2)+'\n');print(summary)
