# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8188 | 0.6415 |
| pixel_or_p0.5 | 583 | 0 | 0.8195 | 0.6518 |
| pixel_or_p0.7 | 583 | 0 | 0.8208 | 0.6690 |
| pixel_or_p0.9 | 583 | 0 | 0.8212 | 0.6758 |
| before | 583 | 0 | 0.8215 | 0.6827 |
| pixel | 583 | 0 | 0.8215 | 0.6827 |
| strict_pixel | 583 | 0 | 0.8215 | 0.6827 |
| pixel_or_p0.99 | 583 | 0 | 0.8215 | 0.6827 |
| raw | 583 | 0 | 0.8341 | 0.6415 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
