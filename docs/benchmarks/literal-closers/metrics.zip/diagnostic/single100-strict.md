# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.7221 | 0.6432 |
| pixel_or_p0.5 | 583 | 0 | 0.7229 | 0.6569 |
| pixel_or_p0.7 | 583 | 0 | 0.7231 | 0.6621 |
| pixel_or_p0.9 | 583 | 0 | 0.7234 | 0.6655 |
| raw | 583 | 0 | 0.7240 | 0.6432 |
| pixel | 583 | 0 | 0.7241 | 0.6792 |
| strict_pixel | 583 | 0 | 0.7241 | 0.6792 |
| pixel_or_p0.99 | 583 | 0 | 0.7241 | 0.6792 |
| before | 583 | 0 | 0.7242 | 0.6827 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
