# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8274 | 0.8882 |
| pixel_or_p0.5 | 583 | 0 | 0.8276 | 0.8899 |
| pixel_or_p0.7 | 583 | 0 | 0.8282 | 0.8925 |
| pixel_or_p0.9 | 583 | 0 | 0.8288 | 0.8933 |
| pixel_or_p0.99 | 583 | 0 | 0.8294 | 0.9001 |
| pixel | 583 | 0 | 0.8296 | 0.8959 |
| strict_pixel | 583 | 0 | 0.8296 | 0.8959 |
| before | 583 | 0 | 0.8325 | 0.9246 |
| raw | 583 | 0 | 0.8446 | 0.9162 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
