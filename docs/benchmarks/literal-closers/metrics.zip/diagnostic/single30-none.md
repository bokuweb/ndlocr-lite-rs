# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8351 | 0.8603 |
| pixel_or_p0.5 | 583 | 0 | 0.8353 | 0.8603 |
| pixel_or_p0.7 | 583 | 0 | 0.8354 | 0.8611 |
| pixel_or_p0.9 | 583 | 0 | 0.8356 | 0.8577 |
| pixel_or_p0.99 | 583 | 0 | 0.8365 | 0.8654 |
| pixel | 583 | 0 | 0.8366 | 0.8730 |
| strict_pixel | 583 | 0 | 0.8366 | 0.8730 |
| before | 583 | 0 | 0.8398 | 0.9052 |
| raw | 583 | 0 | 0.8671 | 0.8628 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
