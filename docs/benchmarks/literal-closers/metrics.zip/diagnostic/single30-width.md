# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8298 | 0.8366 |
| pixel_or_p0.5 | 583 | 0 | 0.8300 | 0.8366 |
| pixel_or_p0.7 | 583 | 0 | 0.8301 | 0.8374 |
| pixel_or_p0.9 | 583 | 0 | 0.8306 | 0.8340 |
| pixel_or_p0.99 | 583 | 0 | 0.8320 | 0.8476 |
| pixel | 583 | 0 | 0.8335 | 0.8569 |
| strict_pixel | 583 | 0 | 0.8335 | 0.8569 |
| before | 583 | 0 | 0.8373 | 0.8950 |
| raw | 583 | 0 | 0.8618 | 0.8391 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
