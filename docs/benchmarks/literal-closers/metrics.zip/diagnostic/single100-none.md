# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.7232 | 0.7968 |
| pixel_or_p0.5 | 583 | 0 | 0.7235 | 0.7976 |
| pixel_or_p0.7 | 583 | 0 | 0.7235 | 0.7959 |
| pixel_or_p0.9 | 583 | 0 | 0.7235 | 0.7951 |
| pixel | 583 | 0 | 0.7236 | 0.8019 |
| strict_pixel | 583 | 0 | 0.7236 | 0.8019 |
| pixel_or_p0.99 | 583 | 0 | 0.7246 | 0.8061 |
| before | 583 | 0 | 0.7265 | 0.8307 |
| raw | 583 | 0 | 0.7410 | 0.8256 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
