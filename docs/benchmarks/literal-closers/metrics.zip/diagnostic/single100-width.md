# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.7179 | 0.7697 |
| pixel_or_p0.5 | 583 | 0 | 0.7182 | 0.7705 |
| pixel_or_p0.7 | 583 | 0 | 0.7184 | 0.7688 |
| pixel_or_p0.9 | 583 | 0 | 0.7191 | 0.7714 |
| pixel_or_p0.99 | 583 | 0 | 0.7205 | 0.7849 |
| pixel | 583 | 0 | 0.7209 | 0.7841 |
| strict_pixel | 583 | 0 | 0.7209 | 0.7841 |
| before | 583 | 0 | 0.7245 | 0.8205 |
| raw | 583 | 0 | 0.7357 | 0.7985 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
