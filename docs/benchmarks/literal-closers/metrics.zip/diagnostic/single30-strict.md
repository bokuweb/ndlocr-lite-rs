# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8229 | 0.5660 |
| pixel_or_p0.5 | 583 | 0 | 0.8234 | 0.5729 |
| pixel_or_p0.7 | 583 | 0 | 0.8240 | 0.5849 |
| pixel_or_p0.9 | 583 | 0 | 0.8251 | 0.6021 |
| pixel_or_p0.99 | 583 | 0 | 0.8270 | 0.6364 |
| pixel | 583 | 0 | 0.8280 | 0.6569 |
| strict_pixel | 583 | 0 | 0.8280 | 0.6569 |
| before | 583 | 0 | 0.8285 | 0.6672 |
| raw | 583 | 0 | 0.8442 | 0.5660 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
