# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 583 | 0 | 0.8324 | 0.9035 |
| pixel_or_p0.5 | 583 | 0 | 0.8327 | 0.9052 |
| pixel | 583 | 0 | 0.8329 | 0.9077 |
| strict_pixel | 583 | 0 | 0.8329 | 0.9077 |
| pixel_or_p0.7 | 583 | 0 | 0.8331 | 0.9060 |
| pixel_or_p0.9 | 583 | 0 | 0.8335 | 0.9069 |
| pixel_or_p0.99 | 583 | 0 | 0.8339 | 0.9119 |
| before | 583 | 0 | 0.8356 | 0.9348 |
| raw | 583 | 0 | 0.8496 | 0.9314 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
