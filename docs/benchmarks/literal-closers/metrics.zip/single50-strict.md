# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `583`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 583 | 0 | 0.8215 | 0.6827 |
| after | 583 | 0 | 0.8215 | 0.6827 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
