from pathlib import Path
import datetime,hashlib,json,sys,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;old=repo/'tmp/vertical-unique-insertion';trace=repo/'tmp/real-vertical-additional-primary-trace'
sys.path.insert(0,str(repo/'tools'))
from additional_real_stop_probe import unique_primary_inputs,rotate_primary
from verify_additional_real_primary_trace import verify
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
write=lambda path,value:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
verified=verify(repo/'docs/benchmarks/real-vertical-additional-primary-trace')
rows=[];bindings={};references=[]
for batch in [1,2]:
 directory=trace/f'batch{batch}-v1';manifest=json.loads((directory/'NN-images-only.json').read_text())
 for model in ['30','50','100']:
  for option in ['eval','default']:
   for item in manifest['inputs']:
    origin=f'{model}_{option}_{item["id"]}';path=directory/'results'/f'{model}-{option}-{item["id"]}.json';archive=path.with_suffix('.zip');record=json.loads(path.read_text())
    primary,=[e for e in record['events'] if e['kind']=='Page_primary_crop'];raw,=[e for e in record['events'] if e['kind']=='raw_before_H_O']
    assert raw['data']['orientation']=='Auto' and raw['image']=={**primary['image'],'file':raw['image']['file']}
    with zipfile.ZipFile(archive) as z:
     rgb=z.read(primary['image']['file']);assert rgb==z.read(raw['image']['file'])
    width,height=primary['image']['width'],primary['image']['height'];assert height*5>width*4
    rows.append({'origin':origin,'model':model,'width':width,'height':height,'rgb':rgb,'raw':raw['data']['text'],'mean_bits':raw['data']['mean_bits']})
    bindings[str(path)]=sha(path);bindings[str(archive)]=sha(archive);references.append({'origin':origin,'trace_json':str(path),'trace_zip':str(archive),'primary_member':primary['image']['file'],'raw_member':raw['image']['file']})
assert len(rows)==36
unique=unique_primary_inputs(rows);archive=p/'rotated-primary-v1.zip';items=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in unique:
  rotated,w,h=rotate_primary(row['rgb'],row['width'],row['height']);member=row['id']+'.rgb';z.writestr(member,rotated)
  items.append({k:v for k,v in row.items() if k!='rgb'}|{'rotated_width':w,'rotated_height':h,'rotated_rgb_sha256':hashlib.sha256(rotated).hexdigest(),'member':member})
write(p/'references-v1.json',{'all_original_routes':references,'unique_inputs':items})
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets'];commands=[]
for model,iw in [('30',256),('50',384),('100',768)]:
 selected=[r for r in items if r['model']==model];manifest={'items':[{'id':r['id'],'archive':str(archive),'member':r['member'],'sha256':r['rotated_rgb_sha256'],'width':r['rotated_width'],'height':r['rotated_height']} for r in selected],'expected_items':len(selected),'model':{'label':model,'path':str(repo/'models'/assets[model]['name']),'sha256':assets[model]['sha256']},'input_dimensions':[iw,24]}
 path=p/f'NN-{model}-v1.json';write(path,manifest);bindings[str(path)]=sha(path)
 commands.append({'model':model,'argv':[str(old/'native-baseline-binary'),'--ignored','--exact','infer::vertical_capacity::prefix::capture::capture_all_frozen_verified_chunks_with_raw_candidates','--nocapture','--test-threads=1'],'env':{'NDLOCR_VERIFIED_NN_MANIFEST':str(path),'NDLOCR_VERIFIED_NN_OUTPUT':str(p/f'results-{model}-v1'),'NDLOCR_TEST_CHARSET':str(repo/'models'/assets['charset']['name']),'NDLOCR_INTRA_THREADS':'1'},'cwd':str(repo)})
source=json.loads((old/'baseline-source-bindings.json').read_text());bindings.update({str(old/'baseline-source'/name):digest for name,digest in source.items()})
artifact=json.loads((old/'native-baseline-artifact.json').read_text());assert artifact['artifact']['fresh'] is False and 'onnx' in artifact['artifact']['features'];assert sha(old/'native-baseline-binary')==artifact['binary_sha256']=='d34d320f24e31d64a0dcdfd3a6566e38fa4b70dded84a1cfd2f21da258998962'
events=[json.loads(line) for line in (old/'native-baseline-build.jsonl').read_text().splitlines() if line.startswith('{')];assert artifact['artifact'] in events
source_bridge={}
for name,start,end in [('src/infer/cached.rs','    pub fn recognize_rgb_u8_candidates_with_orientation(','    ///'),('src/infer/parseq.rs','pub fn predict_text_from_flat_logits_with_confidence(','pub fn load_charset_from_yaml_str(')]:
 a=(old/'baseline-source'/name).read_text();b=(repo/name).read_text()
 if name.endswith('cached.rs'):
  extract=lambda text:text[text.index(start):text.index('\n    }',text.index(start))+6]
 else:extract=lambda text:text[text.index(start):text.index(end,text.index(start))]
 assert extract(a)==extract(b);source_bridge[name]=hashlib.sha256(extract(a).encode()).hexdigest()
for asset in ['30','50','100','charset']:bindings[str(repo/'models'/assets[asset]['name'])]=assets[asset]['sha256']
for path in [Path(__file__),p/'run_v1.py',p/'references-v1.json',archive,old/'baseline-source-bindings.json',old/'native-baseline-artifact.json',old/'native-baseline-build.jsonl',old/'native-baseline-binary',repo/'tools/additional_real_stop_probe.py',repo/'tests/test_additional_real_stop_probe.py',repo/'docs/real_vertical_additional_stop_probe.md',repo/'src/infer/cached.rs',repo/'src/infer/parseq.rs']:
 bindings[str(path)]=sha(path)
assert all(sha(name)==digest for name,digest in bindings.items())
write(p/'before-NN-v1.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete':False,'files_sha256':bindings,'commands':commands,'verified_trace':verified,'source_bridge':source_bridge,'original_Page_routes':36,'unique_raw_API_calls_planned':len(items),'per_model':{m:sum(r['model']==m for r in items) for m in ['30','50','100']},'model_session_loads_planned':3,'NN_calls_at_freeze':0,'new_inference_policy':False,'GT_passed':False})
print({'routes':36,'unique_model_RGB_inputs':len(items),'per_model':{m:sum(r['model']==m for r in items) for m in ['30','50','100']},'NN_calls':0})
