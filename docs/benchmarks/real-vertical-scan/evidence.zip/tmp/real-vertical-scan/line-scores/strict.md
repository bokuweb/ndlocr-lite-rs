# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `9`
- baseline system: `30_raw_session`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| 100_pool_batch | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_pool_one_batch | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_pool_single | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_raw_session | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_session_batch | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_session_single | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 100_standalone_score | 9 | 0 | 0.0259 | 0.6667 | -0.6632 | -0.3333 |
| 50_pool_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_pool_one_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_pool_single | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_raw_session | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_session_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_session_single | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 50_standalone_score | 9 | 0 | 0.0363 | 0.8889 | -0.6528 | -0.1111 |
| 30_pool_batch | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_pool_one_batch | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_pool_single | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_raw_session | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_session_batch | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_session_single | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 30_standalone_score | 9 | 0 | 0.6891 | 1.0000 | +0.0000 | +0.0000 |
| 50_fragment_horizontal_batch | 9 | 0 | 0.9974 | 1.0000 | +0.3083 | +0.0000 |
| 30_fragment_horizontal_batch | 9 | 0 | 1.0000 | 1.0000 | +0.3109 | +0.0000 |
| 100_fragment_horizontal_batch | 9 | 0 | 1.0000 | 1.0000 | +0.3109 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

