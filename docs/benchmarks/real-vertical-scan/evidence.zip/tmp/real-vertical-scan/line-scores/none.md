# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `9`
- baseline system: `30_raw_session`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| 100_pool_batch | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_pool_one_batch | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_pool_single | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_raw_session | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_session_batch | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_session_single | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 100_standalone_score | 9 | 0 | 0.0337 | 1.1111 | -0.6632 | -0.7778 |
| 50_pool_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_pool_one_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_pool_single | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_raw_session | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_session_batch | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_session_single | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 50_standalone_score | 9 | 0 | 0.0363 | 0.8889 | -0.6606 | -1.0000 |
| 30_pool_batch | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_pool_one_batch | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_pool_single | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_raw_session | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_session_batch | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_session_single | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 30_standalone_score | 9 | 0 | 0.6969 | 1.8889 | +0.0000 | +0.0000 |
| 50_fragment_horizontal_batch | 9 | 0 | 0.9974 | 1.0000 | +0.3005 | -0.8889 |
| 30_fragment_horizontal_batch | 9 | 0 | 1.0000 | 1.0000 | +0.3031 | -0.8889 |
| 100_fragment_horizontal_batch | 9 | 0 | 1.0000 | 1.0000 | +0.3031 | -0.8889 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

