from pathlib import Path
import json,zipfile,hashlib,os,shutil
r=Path('tmp/real-vertical-scan');out=Path('docs/benchmarks/real-vertical-scan');sha=lambda b:hashlib.sha256(b).hexdigest();files={};allowed={'.csv','.json','.jsonl','.png','.jpg','.jpeg','.rgb','.txt','.md','.py','.rs','.toml','.lock','.stderr','.stdout'}
for directory,dirs,names in os.walk(r):
 dirs[:]=[d for d in dirs if d not in {'__pycache__','restored','restored-raw','packet-initial','restored-final'}]
 for name in names:
  p=Path(directory)/name
  if p.suffix in allowed and name not in {'package.stdout','package.stderr','reproduce.stdout','reproduce.stderr'}:files[str(p)]=p
for p in [Path('docs/real_vertical_scan_audit.md'),Path('tools/eval_ocr_metrics.py')]:files[str(p)]=p
members={};aliases={};seen={};name='evidence'
with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for key,p in sorted(files.items()):
  b=p.read_bytes();h=sha(b)
  if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
  seen[h]=key;z.writestr(key,b);members[key]=h
 key=name+'-aliases.json';b=(json.dumps(aliases,indent=2)+'\n').encode();z.writestr(key,b);members[key]=sha(b)
p=out/(name+'.zip');assert p.stat().st_size<50*1024*1024;h=sha(p.read_bytes());(out/(name+'.json')).write_text(json.dumps({'sha256':h,'members':members},indent=2)+'\n');(out/'archives.json').write_text(json.dumps({'archives':{name:h},'files':len(files),'package_source_sha256':sha(Path(__file__).read_bytes())},indent=2)+'\n');print('archived',len(files),'files',len(aliases),'aliases',p.stat().st_size,'bytes')
