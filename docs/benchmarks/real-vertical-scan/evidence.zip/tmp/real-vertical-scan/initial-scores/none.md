# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `3`
- baseline system: `cli_deim`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| cli_deim | 3 | 0 | 0.0332 | 1.1111 | +0.0000 | +0.0000 |
| runtime100_eval | 3 | 0 | 0.0332 | 1.1111 | +0.0000 | +0.0000 |
| runtime100_default | 3 | 0 | 0.0332 | 1.1111 | +0.0000 | +0.0000 |
| runtime50_eval | 3 | 0 | 0.0357 | 0.8889 | +0.0026 | -0.2222 |
| runtime50_default | 3 | 0 | 0.0357 | 0.8889 | +0.0026 | -0.2222 |
| runtime30_eval | 3 | 0 | 0.6862 | 1.8889 | +0.6531 | +0.7778 |
| runtime30_default | 3 | 0 | 0.6862 | 1.8889 | +0.6531 | +0.7778 |
| cli_bands | 3 | 0 | 0.9694 | 1.0000 | +0.9362 | -0.1111 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

