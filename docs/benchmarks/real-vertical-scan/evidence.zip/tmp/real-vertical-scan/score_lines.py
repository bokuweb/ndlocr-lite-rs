from pathlib import Path
import json,subprocess,sys,csv,hashlib,struct
r=Path('tmp/real-vertical-scan');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert json.loads((r/'line-command.json').read_text())['exit_code']==0;cols=json.loads((r/'detected-columns/manifest.json').read_text())['inputs'];systems={};parity=[]
for model in ['30','50','100']:
 for folder in sorted((r/('line-'+model)).iterdir()):systems[model+'_'+folder.name]=folder
 raw={x['id']:x for x in json.loads((r/('line-'+model)/'raw_session/results.json').read_text())}
 pages=json.loads((r/('api-'+model)/('runtime'+model+'_eval')/'results.json').read_text());pages={x['id']:x for x in pages}
 for x in cols:
  a=raw[x['id']];b=pages[x['parent_id']]['lines'][x['column_index']];bits=lambda f:struct.unpack('<I',struct.pack('<f',f))[0];parity.append({'model':model,'id':x['id'],'raw':a['text'],'page':b['text'],'raw_mean_bits':bits(a['mean_confidence']),'page_mean_bits':bits(b['confidence']),'text_equal':a['text']==b['text'],'mean_bits_equal':bits(a['mean_confidence'])==bits(b['confidence'])})
out=r/'line-scores';out.mkdir();summaries=[]
for norm in ['none','width','strict']:
 table=out/(norm+'.csv');argv=[sys.executable,'tools/eval_ocr_metrics.py','--truth-dir',str(r/'detected-columns/truth')]
 for label,folder in systems.items():argv+=['--system',label+'='+str(folder)]
 argv+=['--normalize',norm,'--require-all','--baseline-system','30_raw_session','--output-csv',str(table),'--output-md',str(table.with_suffix('.md'))];done=subprocess.run(argv,capture_output=True);(out/(norm+'.stdout')).write_bytes(done.stdout);(out/(norm+'.stderr')).write_bytes(done.stderr);assert done.returncode==0;rows=list(csv.DictReader(table.open()));assert len(rows)==216
 for label in systems:
  xs=[x for x in rows if x['system']==label];assert len(xs)==9;summaries.append({'normalization':norm,'system':label,'pairs':9,'char_errors':sum(int(x['char_errors'])for x in xs),'word_errors':sum(int(x['word_errors'])for x in xs)})
result={'raw_page_pairs':27,'all_raw_page_text_equal':all(x['text_equal']for x in parity),'all_raw_page_mean_bits_equal':all(x['mean_bits_equal']for x in parity),'parity':parity,'summary':summaries,'new_nn_forwards':0,'driver_sha256':sha(__file__),'scorer_sha256':sha('tools/eval_ocr_metrics.py')};(r/'line-score-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in result.items()if k not in ['parity','summary']})
