from pathlib import Path
import json,hashlib,subprocess,os,shutil,concurrent.futures,time
r=Path('tmp/real-vertical-scan');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='b9b64efd9555a0e6b38085784691d9602c5d29a0';assert not subprocess.check_output(['git','diff','--name-only','--','*.rs'],text=True).strip();events=[json.loads(s)for s in(r/'page-capture-build.jsonl').read_text().splitlines()if s.startswith('{')];assert any(x.get('reason')=='build-finished'and x.get('success')for x in events);exes=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='capture_page_matrix'];assert len(exes)==1;api=r/'page-capture-binary';shutil.copy2(exes[0],api);cli=r/'cli-binary';shutil.copy2('tmp/latin-dotted-body/cli-binary',cli);old=json.loads(Path('tmp/latin-dotted-body/cli-command.json').read_text());assert sha(cli)==old['binary_sha256']
for p,h in old['sources_sha256'].items():
 if sha(p)!=h:
  assert p=='src/infer/visible_repetitions/dotted_body.rs';before=Path('tmp/latin-dotted-body/before-test-format.rs').read_text();after=Path(p).read_text();assert before.split('#[cfg(test)]')[0]==after.split('#[cfg(test)]')[0]
models={str(p):sha(p)for p in Path('models').iterdir()if p.suffix in['.onnx','.yaml']};assert models==old['models'];source={}
for p in [*Path('src').rglob('*.rs'),*Path('tests').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock')]:
 q=r/'initial-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);source[str(p)]=sha(p)
m=json.loads((r/'evaluation-manifest-before-nn.json').read_text());assert len(m['inputs'])==3
for x in m['inputs']:
 for k in ['original','image','rgb','truth']:assert sha(x[k])==x[k+'_sha256']
spec=Path('docs/real_vertical_scan_audit.md');s=spec.read_text();first=s[:s.index('\n## 初回実行の行列')];assert hashlib.sha256(first.encode()).hexdigest()==m['spec_sha256'];(r/'spec-before-first-freeze.md').write_text(first);(r/'initial-spec.md').write_text(s);meta={'baseline_commit':head,'api_binary_sha256':sha(api),'cli_binary_sha256':sha(cli),'cli_runtime_source_unchanged_after_test_only_format':True,'source_sha256':source,'models_sha256':models,'input_manifest_sha256':sha(r/'evaluation-manifest-before-nn.json'),'final_spec_sha256':sha(spec),'driver_sha256':sha(__file__),'api_page_calls':18,'cli_processes':6,'page_text_pairs':24,'internal_nn_forward_count':None,'internal_nn_forward_count_reason':'not instrumented; do not equate page/API/CLI counts with forwards'};(r/'initial-freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
start=time.monotonic();jobs=[('api',label)for label in ['30','50','100']]+[('cli',x,mode)for x in m['inputs']for mode in ['deim','bands']]
def run(job):
 if job[0]=='api':
  model=job[1];out=r/('api-'+model);argv=[str(api.resolve()),'--manifest',str(r/'evaluation-manifest-before-nn.json'),'--det-model','models/deim-s-1024x1024.onnx','--parseq-model',next(p for p in models if '-'+model+'-tiny-'in p),'--charset','models/NDLmoji.yaml','--label','runtime'+model,'--output-dir',str(out)];name='api-'+model
 else:
  _,x,mode=job;out=r/'cli'/mode/(x['id']+'.txt');out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();argv=[str(cli.resolve()),'recognize-page','--image',x['image'],'--charset','models/NDLmoji.yaml','--use-deim-detection',str(mode=='deim').lower(),'--output-txt',str(out)];name='cli-'+mode+'-'+x['id']
 env={'NDLOCR_INTRA_THREADS':'1'};record={'argv':argv,'env':env};t=time.monotonic()
 with(r/(name+'.stdout')).open('wb')as a,(r/(name+'.stderr')).open('wb')as b:done=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=b)
 record.update(exit_code=done.returncode,seconds=time.monotonic()-t);(r/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name
 if job[0]=='cli':assert(r/(name+'.stdout')).read_bytes()==out.read_bytes()+b'\n'
 print(name,'completed',round(record['seconds'],2),flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:records=list(pool.map(run,jobs))
for p,h in source.items():assert sha(p)==h,p
for p,h in models.items():assert sha(p)==h,p
for x in m['inputs']:
 for k in ['original','image','rgb','truth']:assert sha(x[k])==x[k+'_sha256']
assert sha(spec)==meta['final_spec_sha256'];meta.update(exit_code=0,seconds=time.monotonic()-start,all_source_models_inputs_unchanged_after=True,runs=records);(r/'initial-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('all24 page text pairs completed with fixed inputs, GT, source and models')
