from pathlib import Path
import json,hashlib,subprocess,os,time,concurrent.futures,shutil
r=Path('tmp/real-vertical-scan');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();b=r/'line-capture-binary';shutil.copy2('tmp/latin-dotted-body/native-binary',b);e=json.loads(Path('tmp/latin-dotted-body/api-command.json').read_text());assert sha(b)==e['binary_sha256'];m=r/'detected-columns/manifest.json';rows=json.loads(m.read_text())['inputs'];assert len(rows)==9;models=e['models'];assert all(sha(p)==h for p,h in models.items());sources={str(p):sha(p)for p in Path('src').rglob('*.rs')};spec=Path('docs/real_vertical_scan_audit.md');shutil.copy2(spec,r/'line-spec.md');record={'binary_sha256':sha(b),'source_provenance_sha256':sha('tmp/latin-dotted-body/api-command.json'),'model_sha256':models,'source_sha256':sources,'manifest_sha256':sha(m),'spec_sha256':sha(spec),'driver_sha256':sha(__file__),'api_image_route_pairs':216,'unprocessed_raw_pairs':27,'models_dynamic_batch':False,'internal_nn_forward_count':None};(r/'line-freeze.json').write_text(json.dumps(record,indent=2)+'\n')
for x in rows:
 for k in ['image','rgb','truth']:assert sha(x[k])==x[k+'_sha256']
start=time.monotonic()
def run(model):
 out=r/('line-'+model);argv=[str(b.resolve()),'infer::cached::punctuation_context_capture::capture_line_matrix','--exact','--ignored','--nocapture'];env={'NDLOCR_LINE_MATRIX_MANIFEST':str(m),'NDLOCR_LINE_MATRIX_OUTPUT':str(out),'NDLOCR_TEST_PARSEQ_MODEL':next(p for p in models if '-'+model+'-tiny-'in p),'NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_INTRA_THREADS':'1'};meta={'argv':argv,'env':env};t=time.monotonic()
 with(r/('line-'+model+'.stdout')).open('wb')as a,(r/('line-'+model+'.stderr')).open('wb')as c:d=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=c)
 meta.update(exit_code=d.returncode,seconds=time.monotonic()-t);(r/('line-'+model+'-command.json')).write_text(json.dumps(meta,indent=2)+'\n');assert d.returncode==0 and b'1 passed'in(r/('line-'+model+'.stdout')).read_bytes();dirs=list(out.iterdir());assert len(dirs)==8
 for folder in dirs:
  actual=json.loads((folder/'results.json').read_text());assert len(actual)==9 and {x['id']for x in actual}=={x['id']for x in rows}
 print(model,'8x9 API pairs completed',flush=True);return meta
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:runs=list(pool.map(run,['30','50','100']))
assert all(sha(p)==h for p,h in models.items());assert all(sha(p)==h for p,h in sources.items());assert sha(m)==record['manifest_sha256'] and sha(spec)==record['spec_sha256']
for x in rows:
 for k in ['image','rgb','truth']:assert sha(x[k])==x[k+'_sha256']
record.update(exit_code=0,seconds=time.monotonic()-start,runs=runs,all_source_models_inputs_unchanged_after=True);(r/'line-command.json').write_text(json.dumps(record,indent=2)+'\n');print('216 API pairs complete, including27 original unprocessed Auto reads')
