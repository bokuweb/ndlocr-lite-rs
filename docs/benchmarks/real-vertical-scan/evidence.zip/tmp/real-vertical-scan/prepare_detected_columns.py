from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/real-vertical-scan');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((r/'evaluation-manifest-before-nn.json').read_text());records=json.loads((r/'api-30/runtime30_eval/results.json').read_text());sources={(x['id']):x for x in m['inputs']};allroutes=[]
for label in ['30','50','100']:
 for mode in ['eval','default']:allroutes.append(json.loads((r/('api-'+label)/('runtime'+label+'_'+mode)/'results.json').read_text()))
out=r/'detected-columns';out.mkdir();(out/'images').mkdir();(out/'truth').mkdir();(out/'rgb').mkdir();rows=[]
for page in records:
 x=sources[page['id']];im=Image.open(x['image']).convert('RGB');assert sha(x['image'])==x['image_sha256'];assert len(page['lines'])==3
 for route in allroutes:
  y=next(y for y in route if y['id']==x['id']);assert [l['bbox']for l in y['lines']]==[l['bbox']for l in page['lines']]
 for index,line in enumerate(page['lines']):
  id=x['id']+'_column'+str(index+1);box=line['bbox'];assert 0<=box[0]<box[2]<=im.width and 0<=box[1]<box[3]<=im.height;crop=im.crop(box);p=out/'images'/(id+'.png');crop.save(p);rgb=out/'rgb'/(id+'.rgb');rgb.write_bytes(crop.tobytes());truth=out/'truth'/(id+'.txt');truth.write_bytes(x['text_columns'][index].encode());rows.append({'id':id,'parent_id':x['id'],'column_index':index,'bbox':box,'image':str(p),'image_sha256':sha(p),'rgb':str(rgb),'rgb_sha256':sha(rgb),'width':crop.width,'height':crop.height,'truth':str(truth),'truth_sha256':sha(truth)})
assert len(rows)==9;(out/'manifest.json').write_text(json.dumps({'inputs':rows,'parent_manifest_sha256':sha(r/'evaluation-manifest-before-nn.json'),'bbox_source_sha256':sha(r/'api-30/runtime30_eval/results.json'),'same_bbox_in_all_six_api_routes':True,'driver_sha256':sha(__file__)},indent=2)+'\n');print('all9 exact DEIM RGB crops with pre-existing column GT; all model/setting boxes equal')
