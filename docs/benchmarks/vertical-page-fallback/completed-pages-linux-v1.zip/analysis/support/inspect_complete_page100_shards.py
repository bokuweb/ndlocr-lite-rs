"""Verify the completed Page100 kind only; never marks the full matrix as passed."""
from pathlib import Path
import csv,json,subprocess,sys
sys.path.insert(0,'tools')
import vertical_page_matrix as matrix
from vertical_page_shards import partition_inputs,validate_coverage
from verify_low_stop_evidence import metric_values
root=Path(__file__).resolve().parent
bundle=matrix.Bundle(Path('docs/benchmarks/vertical-page-fallback'))
inputs=bundle.index['physical_inputs'];scoring=bundle.index['scoring_inputs']
paths=[next((root/f'remote-page100-shard{i}-v1').rglob('job.json')) for i in range(4)]
metas=[json.loads(p.read_text()) for p in paths]
assert set(validate_coverage(metas,inputs))=={'page100'}
data={};bindings=[]
for i,(path,meta) in enumerate(zip(paths,metas)):
 selected=partition_inputs(inputs,i,4);kind,folder=matrix.verify_job_artifact(bundle,path,selected);assert kind=='page100'
 plan=next((root/f'remote-page100-shard{i}-v1').rglob('shard-plan.json'));digest=matrix.sha(plan.read_bytes())
 assert meta['shard_plan_sha256']==digest
 assert json.loads(plan.read_bytes())=={'kind':kind,'shard':meta['shard'],'global_physical_inputs':len(inputs),'bundle_sha256':meta['bundle_sha256']}
 assert meta['PageRecognizer_loads']==2 and meta['model_session_loads']==4
 bindings.append({'shard':i,'physical_inputs':len(selected),'job_sha256':matrix.sha(path.read_bytes()),'plan_sha256':digest})
 for variant in ['baseline','candidate']:
  for route,values in matrix.read_job_texts(kind,folder,variant,selected).items():
   merged=data.setdefault((variant,route),{});assert set(merged).isdisjoint(values);merged.update(values)
assert set(data)=={(v,r) for v in ['baseline','candidate'] for r in ['100_eval','100_default']}
for values in data.values():assert set(values)=={r['id'] for r in inputs}
output=root/'remote-page100-partial-evaluation-v1';output.mkdir()
truth=output/'truth';truth.mkdir();systems={}
for row in scoring:(truth/(row['id']+'.txt')).write_bytes(bundle.read('data.zip',row['truth']))
for key,values in data.items():
 name='_'.join(key);directory=output/name;directory.mkdir();systems[name]=directory
 for ident,text in matrix.map_predictions(scoring,values).items():(directory/(ident+'.txt')).write_bytes(text.encode())
scorer=output/'eval_ocr_metrics.py';scorer.write_bytes(bundle.read('sources.zip','scoring/eval_ocr_metrics.py'))
assert matrix.sha(scorer.read_bytes())==bundle.index['eval_ocr_metrics.py_sha256']
assert matrix.sha(Path(sys.modules['fast_distance'].__file__).read_bytes())==bundle.index['fast_distance.py_sha256']
verified=0;regressions=[];gains=[];changes=[];commands=[];totals=[]
for mode in ['none','width','strict']:
 table=output/(mode+'.csv');argv=[sys.executable,str(scorer),'--truth-dir',str(truth)]
 for name,directory in systems.items():argv+=['--system',name+'='+str(directory)]
 argv+=['--normalize',mode,'--require-all','--output-csv',str(table)]
 process=subprocess.run(argv,capture_output=True);table.with_suffix('.stdout').write_bytes(process.stdout);table.with_suffix('.stderr').write_bytes(process.stderr);commands.append({'argv':argv,'exit_code':process.returncode});assert process.returncode==0
 rows=list(csv.DictReader(table.open()));assert len(rows)==len(scoring)*4;keyed={(r['system'],r['file']):r for r in rows};assert len(keyed)==len(rows)
 for r in rows:
  expected=metric_values((truth/r['file']).read_text(),(systems[r['system']]/r['file']).read_text(),mode)
  assert tuple(int(r[k]) for k in ['char_errors','char_total','word_errors','word_total'])==expected;verified+=1
 for name in systems:
  group=[r for r in rows if r['system']==name];totals.append({'mode':mode,'system':name,**{k:sum(int(r[k]) for r in group) for k in ['char_errors','char_total','word_errors','word_total']}})
 for r in scoring:
  for route in ['100_eval','100_default']:
   a,b=[keyed[v+'_'+route,r['id']+'.txt'] for v in ['baseline','candidate']]
   item={'id':r['id'],'physical_id':r['physical_id'],'cohort':r['cohort'],'route':route,'mode':mode,'before_chars':int(a['char_errors']),'after_chars':int(b['char_errors']),'before_words':int(a['word_errors']),'after_words':int(b['word_errors'])}
   if item['after_chars']>item['before_chars'] or item['after_words']>item['before_words']:regressions.append(item)
   if item['after_chars']<item['before_chars'] and item['after_words']<=item['before_words']:gains.append(item)
for r in scoring:
 for route in ['100_eval','100_default']:
  a,b=[data[v,route][r['physical_id']] for v in ['baseline','candidate']]
  if a!=b:changes.append({'id':r['id'],'cohort':r['cohort'],'route':route,'before':a,'after':b})
summary={'run':39532673209,'model':'100','physical_inputs':len(inputs),'scoring_inputs':len(scoring),'Page_API_results':len(inputs)*4,'PageRecognizer_loads':8,'Page_model_session_loads':16,'official_CSV_rows_independently_verified':verified,'changed_scoring_routes':len(changes),'regressions':regressions,'raw_gain_pairs':[r for r in gains if r['mode']=='none'],'all_gains':gains,'totals':totals,'source_build_argv_and_pre_NN_plans_verified':True,'shard_bindings':bindings,'full_gate_pass':False,'scope':'complete Page100 kind only;CLI incomplete,all-four-kind gate still required','new_NN_calls':0,'reader_sha256':matrix.sha(Path(matrix.__file__).read_bytes()),'independent_normalizer_sha256':matrix.sha(Path('tools/verify_low_stop_evidence.py').read_bytes())}
(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(output/'changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');(output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['totals','raw_gain_pairs','all_gains','regressions','shard_bindings']},indent=2));print('regressions',len(regressions),'rawgains',len(summary['raw_gain_pairs']))
