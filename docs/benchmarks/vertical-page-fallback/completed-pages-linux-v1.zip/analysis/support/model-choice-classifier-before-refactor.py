"""Classify saved Page observations; never selects an inference result."""
import math
from verify_low_stop_evidence import metric_values


def _portrait_line(record):
    lines = record.get('lines', [])
    if len(lines) != 1 or record.get('text') != lines[0].get('text'):
        return None
    line = lines[0]
    bounds = line.get('bbox', [])
    if len(bounds) != 4 or any(type(value) is not int for value in bounds):
        return None
    x0, y0, x1, y1 = bounds
    if not (0 <= x0 < x1 and 0 <= y0 < y1 and x1 - x0 >= 12
            and y1 - y0 >= 8 * (x1 - x0)):
        return None
    return line


def classify_model_choice(smaller, model100, truths, raw_limit):
    line = _portrait_line(smaller)
    if (line is None or not truths or any(not isinstance(text, str) or not text for text in truths)
            or type(raw_limit) is not int or raw_limit <= 0):
        return None
    text = line['text']
    confidence = line.get('confidence')
    if (not isinstance(text, str) or len(text) <= raw_limit
            or type(confidence) not in (int, float) or not math.isfinite(confidence)
            or not .9 <= confidence <= 1.0):
        return None
    other_text = model100['text']
    lower_metrics = [metric_values(truth, text, 'none') for truth in truths]
    other_metrics = [metric_values(truth, other_text, 'none') for truth in truths]
    if any(a[0] >= b[0] or a[2] > b[2] for a, b in zip(lower_metrics, other_metrics)):
        return None
    other = _portrait_line(model100)
    same_crop = other is not None and other['bbox'] == line['bbox']
    category = ('shorter_same_crop' if len(other_text) < len(text) else 'different_text_same_crop') if same_crop else 'different_or_absent_crop'
    return {'category':category, 'smaller_text':text, 'model100_text':other_text,
            'smaller_bounds':line['bbox'], 'model100_bounds':other['bbox'] if other else None,
            'smaller_confidence':confidence, 'raw_limit':raw_limit,
            'lower_metrics':lower_metrics, 'model100_metrics':other_metrics,
            'model100_is_complete_prefix':bool(same_crop and other_text and text.startswith(other_text)),
            'raw_limit_proxy_only':True, 'actual_CLI_observed':False}
