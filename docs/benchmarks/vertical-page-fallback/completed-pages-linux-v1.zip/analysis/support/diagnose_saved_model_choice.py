from pathlib import Path
from collections import Counter
import json,sys,datetime
sys.path.insert(0,'tools')
import vertical_page_matrix as matrix
from vertical_page_shards import partition_inputs,validate_coverage
from vertical_page_model_choice import classify_model_choice
from verify_low_stop_evidence import Packet
root=Path(__file__).resolve().parent;bundle=matrix.Bundle(Path('docs/benchmarks/vertical-page-fallback'));inputs=bundle.index['physical_inputs']
paths=[next((root/f'remote-page{label}-full-v1').rglob('job.json')) for label in ['30','50']]+[next((root/f'remote-page100-shard{i}-v1').rglob('job.json')) for i in range(4)]
metas=[json.loads(p.read_text()) for p in paths];assert set(validate_coverage(metas,inputs))=={'page30','page50','page100'}
observations={};bindings=[]
for path,meta in zip(paths,metas):
 shard=meta.get('shard');selected=partition_inputs(inputs,shard['index'],shard['total']) if shard else inputs
 kind,folder=matrix.verify_job_artifact(bundle,path,selected)
 if shard:
  plan=next(path.parents[2].rglob('shard-plan.json'));assert matrix.sha(plan.read_bytes())==meta['shard_plan_sha256']
  assert json.loads(plan.read_bytes())=={'kind':kind,'shard':shard,'global_physical_inputs':len(inputs),'bundle_sha256':meta['bundle_sha256']}
 bindings.append({'kind':kind,'shard':shard,'job_sha256':matrix.sha(path.read_bytes())})
 for variant in ['baseline','candidate']:
  for route,rows in matrix.read_page_results(folder/'page'/variant,kind[4:],selected).items():
   merged=observations.setdefault((variant,route),{});assert set(merged).isdisjoint(rows);merged.update(rows)
assert len(observations)==12 and all(set(v)=={r['id'] for r in inputs} for v in observations.values())
packet=Packet('docs/benchmarks/vertical-low-stop-development/index.json');metadata_path='tmp/vertical-output-capacity/metadata/results.json';metadata=packet.json(metadata_path)
limits={r['label']:r['outputs'][0]['max_raw_scalars_from_static_shape'] for r in metadata}
for r in metadata:
 assert r['outputs'][0]['dimensions'][1]==limits[r['label']]
 assert Path(r['path']).name==bundle.index['assets'][r['label']]['name']
assets={}
for key,asset in bundle.index['assets'].items():
 value=matrix.sha((Path('models')/asset['name']).read_bytes());assert value==asset['sha256'];assets[key]=value
truths={r['id']:[] for r in inputs};cohorts={r['physical_id']:r['cohort'] for r in bundle.index['scoring_inputs']}
for r in bundle.index['scoring_inputs']:truths[r['physical_id']].append((r['id'],bundle.read('data.zip',r['truth']).decode()))
output=root/'saved-model-choice-v1';output.mkdir()
plan={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'spec_sha256':matrix.sha(Path('docs/vertical_page_model_choice_diagnostic.md').read_bytes()),'bundle_sha256':matrix.sha((bundle.folder/'bundle.json').read_bytes()),'model_assets_SHA':assets,'metadata_packet_index_SHA':matrix.sha(Path('docs/benchmarks/vertical-low-stop-development/index.json').read_bytes()),'metadata_member_SHA':matrix.sha(packet.read(metadata_path)),'raw_limits':limits,'classifier_SHA':matrix.sha(Path('tools/vertical_page_model_choice.py').read_bytes()),'parent_job_bindings':bindings,'new_NN_calls':0,'model_loads':0}
(output/'before-classification.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
cases=[]
for variant in ['baseline','candidate']:
 for setting in ['eval','default']:
  for model in ['30','50']:
   for row in inputs:
    ident=row['id'];aliases=truths[ident]
    result=classify_model_choice(observations[variant,model+'_'+setting][ident],observations[variant,'100_'+setting][ident],[text for _,text in aliases],limits[model])
    if result:cases.append({'variant':variant,'model':model,'setting':setting,'id':ident,'cohort':cohorts[ident],'scoring_ids':[name for name,_ in aliases],**result})
summary={'candidate_comparisons':len(inputs)*2*2*2,'cases':len(cases),'by_variant_category':dict(Counter(r['variant']+'/'+r['category'] for r in cases)),'complete_prefix_cases':sum(r['model100_is_complete_prefix'] for r in cases),'unique_physical_inputs':len({r['id'] for r in cases}),'new_NN_calls':0,'model_loads':0,'actual_CLI_trace':False,'runtime_policy_changed':False,'adoption_gate_pass':False,'scope':'saved Linux Page only;bothOandisolatedFVB;GTusedfordiagnosisonly;raw-limitproxyisnotdirectH/Otrace'}
(output/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n');(output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
