LATEST: H2 implemented and geometry verified. Read tmp/vertical-capacity/otsu/checkpoint.md first. The following parent checkpoint is historical.

# Authoritative checkpoint after E adoption and real vertical baseline

Goal ACTIVE unlimited. PR21 merged, attached draft PR22 https://github.com/bokuweb/ndlocr-lite-rs/pull/22.
Do not mark complete: real vertical recovery, other structural and real-document measures remain. No subagents authorized.
Japanese commentary <=60s. AGENTS docs + failing tests before implementation, small TDD, meaningful PBT.
Cargo.lock ignored, NEVER force-add. SHA862a213854cce3467b7d478e63f8d08854b7631219c12815a04bcdb71cb0ad65 unchanged.
Bundled PIL Python /Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.
Keep frozen binaries outside Cargo target (MBX GC). Do not parallel Cargo jobs sharing target.

## Published COMPLETE
Current HEAD 8d9ae3ddb9b38da4dff2c869db00559a17c8fdf2, branch codex/accuracy-followup, pushed.
Runtime implementation b9b64efd9555a0e6b38085784691d9602c5d29a0 (E dotted Latin).
CI39391132274 b9 ALL5SUCCESS. CI39395244469 exact8d ALL5SUCCESS.
8d docs/real-data/CI receipt only; Rust byte equal b9. PR remote exact head/body verified.
Authoritative latest PR body tmp/real-vertical-scan/pr-body-current.md, remote pr-remote-final.json.
Do not start from old tmp/latin-pair-policy/pr-body-current.md or older E body!
E public docs/benchmarks/latin-dotted-body, 10ZIP ~415MiB each<50MiB.
E current source adopted, frozen owner unchanged, policy body unchanged except first doc comment.
223143 old +59322 new=282465 pairs.102changes23RGB,new19RGB; none exact45,width91,strict tie; all per-input char/word reg0.
none char573245->573189,width553121->553019. Old raw-correct postloss467->456.
Old12changes11exact+1punct-only; fresh64changes none22/width54 exact; H26changes none12/width26 exact.
All new noise9072x3 unchanged; known-font development corpus, no unknown font/doc holdout.
Fresh19440 conditions/13320 uniqueRGB allunseen old, GTconflicts0, AutoRot334.
All59322 new raw complete. Actualcapture19774,1854 independent redraws,4536 noisepng reconstruction.
API426pairs852forwards and CLI426procs: H26 API is represented by original Auto26 CLI counterparts because CLI has no H option.
Full product282465 replay, model-free separate restore306CSV/MD and711summaries plus all pixels/raw/API/CLI succeed.
Restored source default newbuild actualRust282465 and19440x3tensor bits succeed.
Normal740/native692/examples24/fmt/diff/Clippy45old45new0 pass forpublished E.
Initial local commit cc7cf85 unpublished amended ->b9 to gzip exact stdout logs (trailing blank lines diff check); originals preserved.
Package E full restoration tmp/latin-dotted-body/final-restored (~2.3GiB), frozen restored binary/source/proofs preserved.
Do not delete originals. Earlier C restoration COPY only was safely removed; all parent archives intact.

## Real vertical baseline COMPLETE, published8d
Spec docs/real_vertical_scan_audit.md. Packet docs/benchmarks/real-vertical-scan (~32MiB).
Data tmp/real-vertical-scan. NDL IIIF PID1884801 title坊つちやん/Iwanami1939-18printing, manifest Access Restrictions=PDM.
Original3 full JPEGs canvases3,4,5; first12 thumbnails viewed before NN. InitialPID1703887 manifest404/book500, saved.
Selection: first body page percanvas (3left,4/5right), first3columns. Whole spreads not scored.
Full3orig unchanged. Crop3 [1130,480,1405,2440],4 [2932,480,3190,2440],5 [2938,480,3190,2440].
Prior crop-proposals clipped thirdcol3 and included fourthcolruby5; fixed BEFORENN, all original proposals kept.
Manual truth9cols392scalars incl6LF, no terminalLF; ruby excluded explicitly from bodyGT but retainedpixels.
U+3031 repeatmark convention (model often U+3033+3035), old字 retained. Strong U+5F3A->U+5F37 corrected with actualglyph refs BEFORENN.
Do not tune GT on model outcomes; existing typo/variant ambiguity is acknowledged as residual. Model training overlap unknown.
Initial24pagepairs:6CLI(DEIM/bands)x3 +18API(30/50/100x eval/default x3).
Original snapshot manifest evaluation-manifest-before-nn.json, initial-spec.md, initial-freeze/command.json, initial-source.
Existing capture_page_matrix example freshly built and frozen page-capture-binary; E CLI frozen source runtime byteequal b9 excepttestformat.
All source/models/RGB/GT unchanged after. Actual internal NN forwards NOTinstrumented: do not invent from API call counts.
none/width CER char errors /392: CLI DEIM13,bands380,API30 269,50 14,100 13. eval/default equal.
strict DEIM/10010,30 266,50 14,bands380. No new product improvement.
All6API routes same9bboxes. Derived detected-columns/manifest.json all9 exactactualRGB/PNG/GT, noNN pixel transforms.
All9 x8routes x3models =216 actual line API pairs via existing native E punctuation_context_capture::capture_line_matrix.
line-capture-binary frozen, line-freeze/command allsuccessful; includes27 raw_session unprocessed Auto reads.
27 raw/Page mean bit allsame,25textbytes same,2 diffs onlytrailingASCIIspace1 on30 (canvas4 cols1/3).
Raw30 counts [6,19,29,5,24,3,29,9,28]; majorloss alreadyraw. All means unaffected by sanitizer.
Line50/100 ~42-44chars, no major missing. PagePool DEIM passeswholeAuto batch; existing explicitvertical splitter not connected.
Cause hypothesis compression/capacity; split recognition still UNMEASURED.
Initial-scores &line-scores 6CSV+6MD, source/scorer unchanged.
Independent model-free restored-final all12tables/pixels/24page/216line/27parity verified.
First packet missed.csv, caught in actualrestore; test_packet_tables Red->Green fixed allowed.csv; packet-initial, reproduce-first failures kept.
Packet current includes alloriginal/raw/GT/source/metrics/failed retrieval/crop/glyph/source/binary/modelSHA (no executable/model bytes).
No additional runtime source in8d, optional per-document rulepacks untouched.

## H1 vertical capacity investigation CURRENT UNCOMMITTED TEST ONLY
Dirty files exactly:
- src/infer/mod.rs: ONLY appended cfg(test) mod vertical_capacity;
- new src/infer/vertical_capacity.rs
- docs/vertical_model_capacity_recovery.md: appended H1 geometry observation aftercommittedspec
- new docs/vertical_capacity_otsu_support.md (H2 nextspec, no implementation yet)
No productionhook, no capacity gate/NN selector implemented.
H1 spec initial committed8d BEFOREcode/newmask. Existing dense horizontal numericalgates frozen asinitialproposal:
H>=12,basecount<=16,W*ih>2*H*iw,inkcols>=ceilW/3,extent>=ceilH/2,groups>=40and>=4*basecount;
existing vertical splitter(20groups/aspect20/2xmodel),2+chunks,nonemptyallconf>=.9,emitted>=max2base/ceilgroups2,distinctUnicodealnum>=4;
NEW declared before any candidateNN: whitespace scalar sequence exactlysame asbase, rejectadds/deletes, neverdelete toforceagreement.
ExtraNN candidate NOTRUN.
Only prepare() implemented (test-only): lossless CCW original, normalize_chromatic_panels for SUPPORT ONLY, retain distinct originalRGB Vec.
Meaningful stubRed1fail ->Green1. Then PBT64 palette/dimension imageRGB multiset preservation plus independent coordinateexample.
Latestfull default library371passed33ignored. Target2passed1ignored. Clippy final45baseline45current0new,fmt pass.
prepare-red-source/logs, prepare-before-format, prepare-checkpoint.json old stage; geometry-source snapshots latest.
geometry-binary frozendefault32M, geometry-build.jsonl,geometry-freeze/command exit0.
Ignored record_prepared_columns_and_existing_splits reads all9, writes rotated original/support +3shapeschunks originalRGB.
run_geometry.py actual source/inputs frozen beforeafter, noNN. verify_geometry.py independent PIL rotations and perchunk coordinatepixel checks.
columns-prepared all original/support and72RGBchunks; PNGs for futurediagnostic but DO NOT RUN currentproposalNN.
geometry-audit.json: all9 rotations byteequal,72chunks byteequal,27 modelrows, GEOMETRICREACHABLE0.
Original threshold group0 inall9. Chromatic-normalized support groupcounts [9,12,6,15,12,22,14,6,9], far below40.
H1 MASK+LEGACYGATES COMBINATION REJECTED beforeNN. Do not loosen40 or invent recovery. Geometry failure !=accuracy regression.
Do not finish NNselector/productionhook for this unreachableH1 policy. Preserve source/images/logs.
Latest private checkpoint.json adds0reach etc; source hashes inoldpreparecheckpoint earlierstage, authoritative new source ingeometry-freeze/source.
Full library after ignoreddiag verified371pass33ignored inlib-final.*. clippy-final.jsonl +audit_clippy_final.py audit0new.
Cargo.lock unchanged862a... after all builds.

## NEXT H2: OTSU SUPPORT ONLY — spec written, not implemented, no masks/NN yet
Read docs/vertical_capacity_otsu_support.md (newuncommitted) BEFORE implementation.
Primaryrefs OpenCV4.10 threshold tutorial,scikit-image thresholding guide checked viaweb. Don't need browse again for these.
Keep H1 evidence/source unchanged; implement separateH2 helper/testmodule, not silentlyretune prepare() H1.
Gray=floor(R+G+B)/3 from ORIGINALROTATEDRGB, nochromatic normalizationinput.
Otsu 256hist bins; n/S global, w/s prefix t0..254;score (S*w-s*n)^2/(w*(n-w)),0<w<n.
checkedu128 sums/products; overflow->None; empty/singlelevel->None; maxscore ties smaller threshold;pixelg<=t black elsewhite.
Exact rational comparison via continued fractions / integer quotient-remainder (avoidcrossproduct overflow orfloat tie drift).
Small tests BEFOREimplementation:2tone(0/255->0,64/200->64),single/emptyNone,uniformhist256->127,asym/ties/overflow.
PBT64 fractioncomparison vs small safe crossproducts;hist positiveweight scale invariant;graytranslation notsaturating shifts threshold.
Need preserve originalRGB/mask separation tests (neverrecognizebinarymask).
AfterpureGreen freeze H2 before newmaskgeneration; all9columnsre-audit Rustthreshold+mask vs independentPython Fraction threshold search.
Keep allH1 resultfiles. Do not tune existingeligibility/selector gates based on newNN outcomes.
Only ifgeometryreachable then freeze additional real/nontext controls BEFORE ANY splitNN; old9 areknown dev,
newbookcanvas6/7/8 or differentpublicsource mustGT/pixels before recognition; modeltrainingoverlap unknown.
Beforeadopt need native Red, allpage/vertical/horizontal perinputchar/word none/width/strictnonreg +newunobservedapply.
Currentexisting287page8routes evidence in tmp/page-primary50-audit/page-word-reaudit etc canreuse only withfullsource/inputSHA proof;
prefer fresh baselineb9/8d capture_page_matrix3models2options+CLI2 ifneeded. Currentrawroute no productchange.
Supportsanyfutureexactfixedinput refs allmodels3dynamicbatchfalse sizes256x24,384x24,768x24.

## State / operating notes
No live processes now except final PR edit already completed; every tool sessionclosed afteroutputs.
Public CI8d39395244469 ALL5SUCCESS, b9 prior39391132274 ALL5SUCCESS. Exact latest PR verified.
~5GiB free; E full restoration copy2.3GiB still exists, frozenbinariesoutsidetarget. Cleanup only verifiedgeneratedcopies withreceipts, NOT originals.
F restored copies small, initialfailedpacket32M kept. Avoid broad cleanup.
Push helper git -c credential.helper='!gh auth git-credential' push. NeverforceCargo.lock.
Goal continues; don't mark complete or blocked. No permissionneeded, no subagents authorized.
