from pathlib import Path
import sys,json,hashlib,platform
from PIL import Image
from generate import designed_rgb,to_vertical
r=Path('tmp/vertical-capacity/controls'); (r/'inputs').mkdir(exist_ok=True); (r/'gt').mkdir(exist_ok=True); (r/'points').mkdir(exist_ok=True)
truth={
6:['しばらくすると井戶端でざあ〱音がするから、出て見たら竹の先へ蝦蟇口の紐を引き懸けたの','を水で洗つて居た。夫から口をあけて壹圓札を改めたら茶色になつた模樣が消えかゝつて居た。','清は火鉢で乾かして、是でいいでせうと出した。一寸かいで見て臭いやと云つたら、それぢや御'],
7:['暗に云ふものだから、それぢや可哀想で不仕合せなんだらうと思つた。其外に苦になる事は少し','もなかつた。只おやぢが小遣を吳れないには閉口した。','母が死んでから六年目の正月におやぢも卒中で亡くなつた。其年の四月におれはある私立の中'],
8:['おれは六百圓の使用法に就て寢ながら考へた。商賣をしたつて面倒くさくつて旨く出來るもの','ぢやなし、ことに六百圓の金で商賣らしい商賣がやれる譯でもなからう。よしやれるとしても、','今の樣ぢや人の前へ出て敎育を受けたと威張れないから詰り損になる許りだ。資本抔はどうでも']}
boxes={6:(2970,480,3230,2445),7:(2908,460,3165,2445),8:(2945,450,3215,2445)}
items=[]
def save(name,im,gt,kind,**extra):
 path=r/'inputs'/f'{name}.png'; im.save(path); gp=r/'gt'/f'{name}.txt';gp.write_text(gt,encoding='utf-8'); raw=im.tobytes()
 item={'id':name,'kind':kind,'path':str(path),'gt_path':str(gp),'dimensions':list(im.size),'png_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rgb_sha256':hashlib.sha256(raw).hexdigest(),'gt_sha256':hashlib.sha256(gt.encode()).hexdigest(),'scalars':len(gt),**extra};items.append(item)
for n,box in boxes.items():
 im=Image.open(r/'original'/f'1884801_{n:02}.jpg').convert('RGB');save(f'body-{n:02}',im.crop(box),'\n'.join(truth[n]),'real_body',canvas=n,box=box,columns=truth[n])
 for k,b in enumerate(((220,480,280,2440),(3300,480,3360,2440)),1):save(f'margin-{n:02}-{k}',im.crop(b),'','real_margin',canvas=n,box=b)
for paper in ('white','warm','gray'):
 for pattern in ('bars','zigzag','brush'):
  for n in (45,60):
   name=f'{paper}-{pattern}-{n}';rgb,w,h,points=designed_rgb(paper,pattern,n);vert,vw,vh=to_vertical(rgb,w,h);im=Image.frombytes('RGB',(vw,vh),vert)
   assert im.transpose(Image.Transpose.ROTATE_90).tobytes()==rgb
   pointpath=r/'points'/f'{name}.json';pointpath.write_text(json.dumps(points,separators=(',',':'))+'\n')
   save(name,im,'','artificial_stability',paper=paper,pattern=pattern,count=n,points_path=str(pointpath),points_sha256=hashlib.sha256(pointpath.read_bytes()).hexdigest(),designed_rgb_sha256=hashlib.sha256(rgb).hexdigest())
manifest={'stage':'before any baseline or candidate NN on these controls','python':sys.version,'platform':platform.platform(),'items':items,'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'generate.py',r/'test_generate.py',Path('docs/vertical_capacity_controls.md'))}}
(r/'manifest-before-nn.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(len(items),len([x for x in items if x['kind']=='artificial_stability']))
# All margins at original width, compressed only for visual contact (preserve originals above).
contact=Image.new('RGB',(6*80,1960),'#aaa')
for i,item in enumerate(x for x in items if x['kind']=='real_margin'):contact.paste(Image.open(item['path']),(i*80+10,0))
contact.save(r/'margins-contact.png')
contact=Image.new('RGB',(18*75,1400),'#aaa')
for i,item in enumerate(x for x in items if x['kind']=='artificial_stability'):
 im=Image.open(item['path']);im.thumbnail((60,1380));contact.paste(im,(i*75+7,10))
contact.save(r/'artificial-contact.png')
