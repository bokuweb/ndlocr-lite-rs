from pathlib import Path
import json,hashlib,shutil,gzip,time
r=Path('tmp/vertical-capacity');e=Path('tmp/latin-dotted-body');copy=(e/'final-restored').resolve();assert copy.name=='final-restored'and copy.is_dir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();proof=r/'e-restoration-cleanup-proof';proof.mkdir();v=json.loads((copy/'verification.json').read_text());assert v['product_pairs']==282465 and v['table_files_byte_equal']==306 and v['metadata_summaries_recomputed_equal']==711;actual=json.loads((e/'restored-rust-command.json').read_text());assert actual['exit_code']==0 and actual['restored_actual_product_pairs']==282465;build=json.loads((e/'restored-build-command.json').read_text());assert sha(e/'restored-rust-binary')==build['binary_sha256'];archives={}
for packet in ['latin-dotted-body','latin-pair-bridge']:
 out=Path('docs/benchmarks')/packet;index=json.loads((out/'archives.json').read_text())['archives'];archives[packet]={}
 for name,h in index.items():
  p=out/(name+'.zip');assert sha(p)==h;archives[packet][str(p)]=h
 if packet=='latin-dotted-body':assert index==v['archive_sha256']
inputs=json.loads((e/'product-rgb-inventory.json').read_text());assert len(inputs)==92669
for p,x in inputs.items():
 resolved=Path(p).resolve();assert copy not in resolved.parents and resolved!=copy;assert sha(p)==x['rgb_sha256']
for x in json.loads(Path('tmp/real-vertical-scan/detected-columns/manifest.json').read_text())['inputs']:
 for field in ['image','rgb','truth']:
  p=Path(x[field]);assert copy not in p.resolve().parents and sha(p)==x[field+'_sha256']
source=proof/'restored-source'
for p,h in build['sources_sha256'].items():
 src=copy/p;assert sha(src)==h;dst=source/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2(copy/'verification.json',proof/'verification.json');product=copy/'product-manifest.json';product_hash=sha(product)
with product.open('rb')as src,(proof/'product-manifest.json.gz').open('wb')as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as zipped:shutil.copyfileobj(src,zipped)
with gzip.open(proof/'product-manifest.json.gz','rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==product_hash
before={'root':str(copy),'verified_generated_copy_only':True,'verification_sha256':sha(copy/'verification.json'),'restored_rust_receipt_sha256':sha(e/'restored-rust-command.json'),'restored_binary_sha256':sha(e/'restored-rust-binary'),'preserved_source_files':len(build['sources_sha256']),'preserved_absolute_product_manifest_sha256':product_hash,'archive_sha256':archives,'original_rgb_paths_checked':len(inputs),'free_before':shutil.disk_usage('.').free,'driver_sha256':sha(__file__)};(r/'e-restoration-cleanup-start.json').write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic();shutil.rmtree(copy)
for packet,paths in archives.items():
 for p,h in paths.items():assert sha(p)==h
for p,x in inputs.items():assert sha(p)==x['rgb_sha256']
assert sha(e/'restored-rust-binary')==before['restored_binary_sha256'];before.update(copy_removed=not copy.exists(),free_after=shutil.disk_usage('.').free,seconds=time.monotonic()-start,all_original_rgb_archives_binary_unchanged_after=True);(r/'e-restoration-cleanup.json').write_text(json.dumps(before,indent=2)+'\n');print('verified E generated restoration removed; originals/archives/frozen binary rehashed; freeGiB',round(before['free_after']/2**30,2))
