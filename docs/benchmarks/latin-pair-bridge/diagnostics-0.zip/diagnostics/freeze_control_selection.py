from pathlib import Path
import json,hashlib,collections
r=Path('tmp/latin-pair-policy');m=json.loads((r/'fresh/evaluation-manifest.json').read_text());models=['30','50','100'];rows=[]
for x in m['inputs']:
 if x['kind']=='noise':
  rows.append({'corpus':'latin-fresh','id':x['id'],'model':models[hashlib.sha256(x['id'].encode()).digest()[0]%3],'orientation':'auto','rgb_sha256':x['rgb_sha256']})
assert len(rows)==9072 and len({x['id']for x in rows})==9072
record={'algorithm':'sha256(id UTF-8).digest()[0] % 3, models [30,50,100]','spec_sha256':hashlib.sha256((r/'api-cli-selection-spec.md').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((r/'fresh/evaluation-manifest.json').read_bytes()).hexdigest(),'sampling_uses_model_predictions':False,'selection_created_while_raw_forward_running':True,'model_counts':dict(collections.Counter(x['model']for x in rows)),'cases':rows}
(r/'fixed-noise-control-selection.json').write_text(json.dumps(record,indent=2)+'\n')
print('9072 fixed model assignments; no prediction inspected',record['model_counts'])
