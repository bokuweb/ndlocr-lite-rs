from pathlib import Path
import json,hashlib,os
r=Path('tmp/latin-pair-policy');out=r/'fresh-policy';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();models=['30','50','100'];cases=[];existing=[];records=[];oldrecords=[];means=[];summaries=[];changes=[];charreg=[];wordreg=[];sources={}
for model in models:
 p=r/('fresh-policy-model'+model);m=json.loads((p/'manifest.json').read_text());a=json.loads((p/'audit.json').read_text());assert len(m['cases'])==19440 and{c['model']for c in m['cases']}=={model}
 cases+=m['cases'];existing+=json.loads((p/'existing-manifest.json').read_text())['cases'];records+=json.loads((p/'replay/records.json').read_text());oldrecords+=json.loads((p/'existing-replay/records.json').read_text());means+=json.loads((p/'raw-means.json').read_text());summaries+=a['summary'];changes+=a['changes'];charreg+=a['char_regressions'];wordreg+=a['word_regressions'];sources[model]={}
 for name in ['baseline-command.json','candidate-command.json','manifest.json','existing-manifest.json','replay/records.json','existing-replay/records.json','raw-means.json','audit.json','freeze.json']:
  sources[model][name]=sha(p/name)
 for sub in ['truth','subsets','scores','replay','existing-replay']:
  for src in(p/sub).rglob('*'):
   if not src.is_file()or src.name=='records.json':continue
   dest=out/src.relative_to(p);dest.parent.mkdir(parents=True,exist_ok=True)
   if dest.exists():assert sha(dest)==sha(src)
   else:os.link(src,dest)
assert len(cases)==len(records)==len(existing)==len(oldrecords)==len(means)==58320
for name,data in [('manifest.json',{'cases':cases,'expected_cases':58320}),('existing-manifest.json',{'cases':existing,'expected_cases':58320}),('replay/records.json',records),('existing-replay/records.json',oldrecords),('raw-means.json',means)]:
 (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
order=list(dict.fromkeys(x['group']for x in summaries if x['model']=='30'));norms=['none','width','strict']
summaries.sort(key=lambda x:(order.index(x['group']),models.index(x['model']),norms.index(x['normalization'])))
for values in [changes,charreg,wordreg]:values.sort(key=lambda x:(order.index(x[0]),models.index(x[1]),norms.index(x[2]),x[3]))
a={'summary':summaries,'changes':changes,'char_regressions':charreg,'word_regressions':wordreg,'scorer_sha256':sha('tools/eval_ocr_metrics.py'),'driver_sha256':sha(__file__),'model_orchestration_source_proof_sha256':sha(r/'model-orchestration-source-proof.json'),'source_model_evaluations':sources}
(out/'audit.json').write_text(json.dumps(a,indent=2)+'\n')
assert len(summaries)==261 and not charreg and not wordreg,'Reject fixed proposal; preserve all models/inputs/results'
xs={x['id']:x for x in json.loads((r/'fresh/evaluation-manifest.json').read_text())['inputs']};selected=[x for x in records if x['selected']];novel=[x for x in selected if not xs[x['id']]['seen_before_162915']]
result={'fresh_model_pairs':58320,'changes':len(selected),'unique_changed_original_rgb':len({(xs[x['id']]['width'],xs[x['id']]['height'],xs[x['id']]['rgb_sha256'])for x in selected}),'novel_changed_model_pairs':len(novel),'char_regressions':len(charreg),'word_regressions':len(wordreg),'scope':'Known fonts/bodies development controls, not held-out documents'}
(r/'fresh-evaluation-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
assert novel,'No actual novel RGB application: do not connect'
