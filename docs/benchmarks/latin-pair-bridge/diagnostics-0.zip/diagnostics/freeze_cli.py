from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();events=[json.loads(s)for s in(r/'cli-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x.get('success')for x in events)
bins=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr-lite-rs'];assert len(bins)==1;shutil.copy2(bins[0],r/'cli-after-binary')
native=json.loads((r/'verification-command.json').read_text())
for name,h in native['source_sha256'].items():
 assert sha(name)==h,name;p=r/'cli-source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(name,p)
for name,h in native['models'].items():assert sha(name)==h,name
meta={'binary_sha256':sha(r/'cli-after-binary'),'source_sha256':native['source_sha256'],'models':native['models'],'build_sha256':sha(r/'cli-build.jsonl'),'build_finished_success':True,'driver_sha256':sha(__file__),'manifest_sha256':sha(r/'cli-manifest.json')}
(r/'cli-binary.json').write_text(json.dumps(meta,indent=2)+'\n');print('actual CLI source/executable/models/input manifest frozen',flush=True)
