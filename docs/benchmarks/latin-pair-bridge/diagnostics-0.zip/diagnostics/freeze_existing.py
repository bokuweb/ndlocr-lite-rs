from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();build=[json.loads(x)for x in(r/'probe-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x.get('success')for x in build);bins=[x['executable']for x in build if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(bins)==1;shutil.copy2(bins[0],r/'probe-binary')
kernel=Path('src/infer/visible_repetitions/latin_pair_bridge.rs').read_bytes().split(b'#[cfg(test)]',1)[0];assert kernel.replace(b'pub(super) fn split_pair',b'fn split_pair')==Path('tmp/latin-pair-kernel/frozen-kernel-source.rs').read_bytes();policy=Path('src/infer/visible_repetitions/latin_pair_policy.rs').read_bytes().split(b'#[cfg(test)]',1)[0];(r/'frozen-policy-source.rs').write_bytes(policy);lock={'policy_prefix_sha256':hashlib.sha256(policy).hexdigest(),'policy_spec_sha256':sha('docs/latin_pair_bridge_policy.md'),'kernel_lock_sha256':sha('tmp/latin-pair-kernel/kernel-lock.json'),'kernel_source_visibility_only_change':True,'production_connected':False,'new_model_calls':0};(r/'policy-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
parent=Path('tmp/narrow-round-profile/product-manifest.json');m=json.loads(parent.read_text());assert len(m['cases'])==162915;(r/'manifest.json').write_bytes(parent.read_bytes());hashes={}
for x in m['cases']:
 p=x['rgb']
 if p not in hashes:hashes[p]=sha(p)
 assert hashes[p]==x['rgb_sha256'],p
sources={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),*Path('docs').glob('latin*md')]:
 q=r/'probe-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sources[str(p)]=sha(p)
for p in Path('tests/fixtures/latin_pair_bridge').iterdir():
 q=r/'probe-fixtures'/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
models=json.loads(Path('tmp/narrow-round-profile/verification-command.json').read_text())['models']
for p,h in models.items():assert sha(p)==h
record={'baseline_commit':'d711eec30a4e4bd13decad496221f8c0613b482b','baseline_ci_run':39354887325,'source_sha256':sources,'binary_sha256':sha(r/'probe-binary'),'models':models,'input_manifest_sha256':sha(r/'manifest.json'),'parent_manifest_sha256':sha(parent),'unique_original_rgb_paths_verified':len(hashes),'policy_lock_sha256':sha(r/'policy-lock.json'),'argv':[str((r/'probe-binary').resolve()),'infer::visible_repetitions::latin_pair_policy::tests::record_latin_pair_policy','--exact','--ignored','--nocapture'],'env':{'NDLOCR_LATIN_PAIR_POLICY_ROOT':str(r)},'no_new_nn_forwards':True};(r/'probe-command.json').write_text(json.dumps(record,indent=2)+'\n');print('162915 B baselines, source/executable/spec/fixtures/model/RGB hashes frozen; original paths',len(hashes),flush=True)
