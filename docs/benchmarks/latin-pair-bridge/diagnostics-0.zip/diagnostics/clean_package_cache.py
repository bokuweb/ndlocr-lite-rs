from pathlib import Path
import json,hashlib,subprocess
r=Path('tmp/latin-pair-policy');target=Path('target').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();protected={}
for phase in ['probe','tensor','seed','verification']:
 p=r/(phase+'-binary');meta=json.loads((r/(phase+'-command.json')).read_text());assert sha(p)==meta['binary_sha256']and not p.resolve().is_relative_to(target);protected[str(p)]=sha(p)
for binname,metaname in [('cli-after-binary','cli-binary.json'),('product-seed-red-binary','product-seed-red-command.json')]:
 p=r/binname;assert sha(p)==json.loads((r/metaname).read_text())['binary_sha256']and not p.resolve().is_relative_to(target);protected[str(p)]=sha(p)
m={'argv':['cargo','clean','-p','ndlocr-lite-rs'],'scope':'rebuildable compiled package outputs only','target':str(target),'protected_executable_sha256':protected,'before_df':subprocess.run(['df','-k','.'],capture_output=True,text=True,check=True).stdout}
(r/'cache-clean-command.json').write_text(json.dumps(m,indent=2)+'\n')
p=subprocess.run(m['argv'],capture_output=True);(r/'cache-clean.stdout').write_bytes(p.stdout);(r/'cache-clean.stderr').write_bytes(p.stderr);assert p.returncode==0
for name,h in protected.items():assert sha(Path(name))==h
m['exit_code']=0;m['all_frozen_executables_unchanged']=True;m['after_df']=subprocess.run(['df','-k','.'],capture_output=True,text=True,check=True).stdout;(r/'cache-clean-command.json').write_text(json.dumps(m,indent=2)+'\n');print(m['after_df'],flush=True)
