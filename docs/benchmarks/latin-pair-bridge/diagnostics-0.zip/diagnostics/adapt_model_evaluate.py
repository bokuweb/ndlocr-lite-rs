from pathlib import Path
import hashlib,json
r=Path('tmp/latin-pair-policy');source=r/'pre-nn-freeze/evaluate.py';before=source.read_text();lock=json.loads((r/'pre-nn-freeze.json').read_text());assert hashlib.sha256(source.read_bytes()).hexdigest()==lock['files_sha256']['evaluate.py']
s=before.replace("folder=sys.argv[1];assert folder in ['fresh','horizontal'];f=r/folder;out=r/(folder+'-policy');out.mkdir()","folder=sys.argv[1];assert folder=='fresh';label=sys.argv[2];assert label in ['30','50','100'];models=[label];f=r/folder;out=r/(folder+'-policy-model'+label);out.mkdir()")
s=s.replace("for model in ['30','50','100']:","for model in models:").replace('3*n','len(models)*n')
s=s.replace('shutil.copy2(binary,dest)','os.link(binary,dest)')
s=s.replace("argv","argv")
(r/'evaluate_model.py').write_text(s)
(r/'model-orchestration-source-proof.json').write_text(json.dumps({'frozen_driver_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'model_driver_sha256':hashlib.sha256(s.encode()).hexdigest(),'adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'changes':['fresh-only output per model; explicitly selected completed model','all 3-model loops narrowed to passed single model, counts generalized','immutable binary copies use hardlinks'],'no_candidate_condition_or_scorer_or_group_changes':True,'spec_sha256':hashlib.sha256(Path('docs/latin_pair_bridge_evaluation_pipeline.md').read_bytes()).hexdigest()},indent=2)+'\n')
