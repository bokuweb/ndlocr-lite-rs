from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert Path('src/infer/visible_repetitions/latin_pair_policy.rs').read_bytes().split(b'#[cfg(test)]')[0]==(r/'frozen-policy-source.rs').read_bytes()
kernel=Path('src/infer/visible_repetitions/latin_pair_bridge.rs').read_bytes().split(b'#[cfg(test)]')[0]
assert kernel.replace(b'pub(super) fn split_pair',b'fn split_pair')==Path('tmp/latin-pair-kernel/frozen-kernel-source.rs').read_bytes()
events=[json.loads(s)for s in(r/'tensor-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x['success']for x in events)
bins=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(bins)==1;shutil.copy2(bins[0],r/'tensor-binary');hs={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),*Path('docs').glob('latin*md')]:
 q=r/'tensor-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
meta={'source_sha256':hs,'binary_sha256':sha(r/'tensor-binary'),'policy_lock_sha256':sha(r/'policy-lock.json'),'input_manifest_sha256':sha(r/'fresh/evaluation-manifest.json'),'argv':[str((r/'tensor-binary').resolve()),'infer::visible_repetitions::latin_pair_policy::tests::verify_fresh_latin_pair_auto_tensors','--exact','--ignored','--nocapture'],'env':{'NDLOCR_LATIN_PAIR_POLICY_ROOT':str(r)},'no_nn_forwards':True}
(r/'tensor-command.json').write_text(json.dumps(meta,indent=2)+'\n')
