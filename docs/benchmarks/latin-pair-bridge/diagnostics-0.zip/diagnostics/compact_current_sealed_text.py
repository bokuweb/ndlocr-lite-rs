from pathlib import Path
import json,hashlib,os,subprocess,time
from native_text_clone import dedup
r=Path('tmp/latin-pair-policy');roots=[r/'replay',r/'truth',r/'fresh-policy/truth']
for model in ['30','50','100']:roots.append(r/('fresh-policy-model'+model)/'truth')
roots=[p for p in roots if p.exists()]
assert all(p.resolve().is_relative_to(Path('tmp').resolve())for p in roots)
files=sorted({p for root in roots for p in root.rglob('*.txt')})
m={'roots':[str(p)for p in roots],'files':len(files),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),r/'native_text_clone.py',r/'test_native_text_clone.py']},'sdk_header_sha256':hashlib.sha256(Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/clonefile.h').read_bytes()).hexdigest(),'byte_identical_cow_only':True,'backend':'libSystem clonefile, flags0; no hardlink fallback','before_df':subprocess.run(['df','-k','.'],capture_output=True,text=True,check=True).stdout}
(r/'current-sealed-text-compact-command.json').write_text(json.dumps(m,indent=2)+'\n');print('eligible completed generated text paths',len(files),flush=True);t=time.monotonic()
rows=dedup(files,r/'current-sealed-generated-text',lambda done,total:print('COW',done,'/',total,flush=True))
(r/'current-sealed-text-compact-records.json').write_text(json.dumps(rows,indent=2)+'\n')
m.update({'exit_code':0,'all_file_bytes_unchanged':True,'records_sha256':hashlib.sha256((r/'current-sealed-text-compact-records.json').read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-t,'after_df':subprocess.run(['df','-k','.'],capture_output=True,text=True,check=True).stdout});(r/'current-sealed-text-compact-command.json').write_text(json.dumps(m,indent=2)+'\n');print('all generated text paths preserved byte-for-byte using COW',len(rows),flush=True)
