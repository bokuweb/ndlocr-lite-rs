from pathlib import Path
import shutil
r=Path('tmp/latin-pair-policy')
s=Path('tmp/narrow-round-profile/prepare_fresh.py').read_text()
s=s.replace('crop_white, shape_pixels','crop_white, compose_noise')
s=s.replace("tmp/narrow-round-profile","tmp/latin-pair-policy").replace('docs/narrow_round_marker_controls.md','docs/latin_pair_bridge_controls.md')
s=s.replace("bodies = [chr(0x60c5) + chr(0x5831), chr(0x5831) + chr(0x60c5)]","bodies = ['KLM', 'XYZ', 'MLK', 'WM', 'VVM', 'qjp']")
s=s.replace("'left_curve', 'fork'","'left_curve', 'fork_inner', 'fork_outer'")
s=s.replace('seen_before_137991','seen_before_162915').replace('for size in [20, 28]:','for size in [24, 40]:')
s=s.replace("body = unspaced[0] + ' ' * body_spaces + unspaced[1]","body = (' ' * body_spaces).join(unspaced)")
s=s.replace("'body_id': body_id, 'body_spaces': body_spaces","'body_id': body_id, 'body': unspaced, 'body_spaces': body_spaces")
start=s.index("                    native_id = prefix + '_bare'")
end=s.index('\nassert len(rows)',start)
s=s[:start]+"""                    if body_spaces and unspaced != 'WM':
                        continue
                    native_id = prefix + '_bare'
                    native = draw_native(engine, palt, font, size, body, native_id)
                    for shape in shapes:
                        for leading in [False, True]:
                            for gap in [0, 1]:
                                image, geometry = compose_noise(native, shape, leading, gap)
                                save(image, body, prefix + f'_noise{shape}_lead{int(leading)}_gap{gap}', common |
                                     {'kind': 'noise', 'native_id': native_id, 'shape': shape,
                                      'leading': leading, 'gap': gap} | geometry)
""" + s[end:]
s=s.replace('len(rows) == 8064 and len(records) == 648','len(rows) == 19440 and len(records) == 1854')
s=s.replace('8064 mixed-mode controls;648 real native draws','19440 mixed-mode controls;1854 real native draws')
# Freeze driver and inputs before the first native draw.
at=s.index('\nrows, records = [], []')
s=s[:at]+"""
assert json.loads((r / 'summary.json').read_text())['char_regressions'] == 0
assert json.loads((r / 'summary.json').read_text())['word_regressions'] == 0
sources = [Path(__file__), r / 'adapt_generator.py', r / 'renderer_ft.py', r / 'graphics.py',
           r / 'render.swift', r / 'render', r / 'capture-controls-spec.md', r / 'policy-lock.json',
           r / 'probe-command.json', r / 'manifest.json', r / 'summary.json']
snapshot = r / 'fresh-generation-source'
snapshot.mkdir()
for path in sources:
    shutil.copy2(path, snapshot / path.name)
(r / 'fresh-generation-lock.json').write_text(json.dumps({
    'source_sha256': {str(p): sha(p.read_bytes()) for p in sources},
    'fonts': fonts, 'expected_conditions': 19440, 'expected_native_draws': 1854,
    'new_nn_before_generation': 0
}, ensure_ascii=False, indent=2) + '\\n')
""" + s[at:]
(r/'prepare_fresh.py').write_text(s)
shutil.copy2('tmp/narrow-round-profile/renderer_ft.py',r/'renderer_ft.py')
