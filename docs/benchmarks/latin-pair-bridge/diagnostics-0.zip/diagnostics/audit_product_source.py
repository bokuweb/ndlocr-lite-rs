from pathlib import Path
import json,hashlib,subprocess
r=Path('tmp/latin-pair-policy');sha=lambda b:hashlib.sha256(b).hexdigest()
def head(path):return subprocess.run(['git','show','d711eec30a4e4bd13decad496221f8c0613b482b:'+str(path)],capture_output=True,check=True).stdout
p=Path('src/infer/visible_repetitions.rs');before=head(p);expected=before.replace(b'mod narrow_round_marker;',b'mod latin_pair_bridge;\nmod latin_pair_policy;\nmod narrow_round_marker;',1)
anchor=b'        if owned_parts_body_bridge::supports_narrow_round(&fragment, rgb, width, height) {\n            return fragment;\n        }'
assert before.count(anchor)==1
expected=expected.replace(anchor,anchor+b'\n        if latin_pair_policy::supports(&fragment, rgb, width, height) {\n            return fragment;\n        }',1);assert p.read_bytes()==expected
marker=b'pub(crate) fn sanitize_visible_repetitions';assert expected[expected.index(marker):]==before[before.index(marker):]
p=Path('src/infer/visible_repetitions/narrow_round_marker.rs');before=head(p);prefix,suffix=before.split(b'#[cfg(test)]',1);assert prefix.count(b'body_height')==5;assert p.read_bytes()==prefix.replace(b'body_height',b'reference_height')+b'#[cfg(test)]'+suffix
p=Path('src/infer/cached.rs');assert p.read_bytes()==head(p)+b'\n#[cfg(test)]\n#[path = "../../tests/support/latin_pair_model.rs"]\nmod latin_pair_model_tests;\n'
policy=Path('src/infer/visible_repetitions/latin_pair_policy.rs').read_bytes().split(b'#[cfg(test)]')[0]
assert policy.replace(b'//! Support for an owned pair',b'//! Test-only support for an owned pair',1).replace(b'pub(super) fn supports(',b'fn supports(',1)==(r/'frozen-policy-source.rs').read_bytes()
kernel=Path('src/infer/visible_repetitions/latin_pair_bridge.rs').read_bytes().split(b'#[cfg(test)]')[0]
assert kernel.replace(b'//! Structural view of one raster neck',b'//! Test-only exploration of one raster neck',1).replace(b'pub(super) fn split_pair',b'fn split_pair')==Path('tmp/latin-pair-kernel/frozen-kernel-source.rs').read_bytes()
skip={'src/infer/visible_repetitions.rs','src/infer/visible_repetitions/narrow_round_marker.rs','src/infer/cached.rs'}
files=[p for p in subprocess.run(['git','ls-tree','-r','--name-only','d711eec30a4e4bd13decad496221f8c0613b482b'],capture_output=True,check=True,text=True).stdout.splitlines()if p.endswith('.rs')];same=[]
for name in files:
 if name in skip:continue
 assert Path(name).read_bytes()==head(name),name;same.append(name)
m=json.loads((r/'fresh/raw-command.json').read_text())['raw_source_capture']['models']
for name,h in m.items():assert sha(Path(name).read_bytes())==h,name
record={'baseline_commit':'d711eec30a4e4bd13decad496221f8c0613b482b','main_matches_exact_minimal_hook':True,'marker_parameter_name_only':True,'cached_only_new_test_module':True,'page_fragment_tail_byte_equal':True,'fixed_policy_and_kernel_numeric_source_unchanged':True,'all_other_tracked_rust_byte_equal':len(same),'models_and_charset_unchanged':True,'fixed_source_locks':{'policy':sha((r/'frozen-policy-source.rs').read_bytes()),'kernel':sha(Path('tmp/latin-pair-kernel/frozen-kernel-source.rs').read_bytes())},'driver_sha256':sha(Path(__file__).read_bytes()),'new_page_accuracy_evaluation_runs':0}
(r/'source-proof.json').write_text(json.dumps(record,indent=2)+'\n');print('exact minimal runtime hook, fixed numeric sources, existing fragment/NN code and assets verified')
