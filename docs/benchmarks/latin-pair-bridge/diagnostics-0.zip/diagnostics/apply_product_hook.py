from pathlib import Path
import hashlib,json
r=Path('tmp/latin-pair-policy');sha=lambda b:hashlib.sha256(b).hexdigest()
for p in [r/'audit.json',r/'fresh-policy/audit.json',r/'horizontal-policy/audit.json']:
 a=json.loads(p.read_text());assert not a['char_regressions']and not a['word_regressions']
assert json.loads((r/'fresh-evaluation-summary.json').read_text())['novel_changed_model_pairs']>0
assert len(json.loads((r/'product-manifest.json').read_text())['cases'])==223143
red=(r/'product-seed-red.stderr').read_text();assert 'assertion' in red and 'KLM' in red
for model in ['30','50','100']:assert json.loads((r/('api-seed-red-'+model+'-command.json')).read_text())['exit_code']==101
p=Path('src/infer/visible_repetitions/latin_pair_policy.rs');before=p.read_bytes();prefix=before.split(b'#[cfg(test)]')[0];assert prefix==(r/'frozen-policy-source.rs').read_bytes()
after=before.replace(b'//! Test-only support for an owned pair',b'//! Support for an owned pair',1).replace(b'fn supports(',b'pub(super) fn supports(',1)
assert after.split(b'#[cfg(test)]')[0].replace(b'//! Support for an owned pair',b'//! Test-only support for an owned pair',1).replace(b'pub(super) fn supports(',b'fn supports(',1)==prefix
p.write_bytes(after)
p=Path('src/infer/visible_repetitions/latin_pair_bridge.rs');before=p.read_bytes()
assert before.split(b'#[cfg(test)]')[0].replace(b'pub(super) fn split_pair',b'fn split_pair')==Path('tmp/latin-pair-kernel/frozen-kernel-source.rs').read_bytes()
after=before.replace(b'//! Test-only exploration of one raster neck',b'//! Structural view of one raster neck',1);p.write_bytes(after)
p=Path('src/infer/visible_repetitions.rs');before=p.read_text()
after=before.replace('#[cfg(test)]\nmod latin_pair_bridge;\n#[cfg(test)]\nmod latin_pair_policy;','mod latin_pair_bridge;\nmod latin_pair_policy;',1)
anchor='''        if owned_parts_body_bridge::supports_narrow_round(&fragment, rgb, width, height) {
            return fragment;
        }'''
assert before.count(anchor)==1
after=after.replace(anchor,anchor+'''
        if latin_pair_policy::supports(&fragment, rgb, width, height) {
            return fragment;
        }''',1)
assert after[after.index('pub(crate) fn sanitize_visible_repetitions'):]==before[before.index('pub(crate) fn sanitize_visible_repetitions'):]
p.write_text(after)
(r/'hook-condition-proof.json').write_text(json.dumps({'frozen_policy_prefix_sha256':sha(prefix),'policy_changes_only_visibility_and_module_doc':True,'kernel_change_only_module_doc_beyond_prior_visibility_access':'one fixed replacement','page_fragment_tail_byte_equal':True,'numeric_conditions_changed_after_new_nn':False,'driver_sha256':sha(Path(__file__).read_bytes())},indent=2)+'\n')
print('fixed C support connected only to last single-line fallback; numerical source unchanged')
