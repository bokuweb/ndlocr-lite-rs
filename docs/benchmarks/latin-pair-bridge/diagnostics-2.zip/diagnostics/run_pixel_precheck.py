from pathlib import Path
import json,zipfile,shutil,sys
r=Path('tmp/latin-pair-policy');sys.path.insert(0,str(r.resolve()));import reproduce
root=(r/'pixel-precheck').resolve();root.mkdir();media=r/'packet-media';names=[]
for name in ['static-media.json','nn-inputs.json']:names+=json.loads((media/name).read_text())['archives']
hashes=reproduce.restore(media,root,names);diag=root/'diagnostics';diag.mkdir(exist_ok=True)
for name in ['verify_fresh.py','verify_noise.py','fresh-pixel-audit.json','noise-pixel-audit.json','native-audit.json','test_fresh.py']:shutil.copy2(r/name,diag/name)
with zipfile.ZipFile('docs/benchmarks/narrow-round-marker/diagnostics.zip')as z:prior=json.loads(z.read('diagnostics/portable-cases.json'))['cases']
stats=reproduce.verify_pixels(root,prior);(root/'verification.json').write_text(json.dumps(stats|{'archive_sha256':hashes},indent=2)+'\n');print(json.dumps(stats,indent=2),flush=True)
