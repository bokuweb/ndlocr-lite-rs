from pathlib import Path
import json,unittest
class Reproduction(unittest.TestCase):
 def test_full_independent_evidence_reproduction(self):
  v=json.loads(Path('tmp/latin-pair-policy/final-restored/verification.json').read_text())
  self.assertEqual(v['product_pairs'],223143);self.assertEqual(v['changes'],112);self.assertEqual(v['unique_changed_original_rgb'],48);self.assertEqual(v['table_files_byte_equal'],1188);self.assertEqual(v['new_evaluation_raw_forwards'],60228);self.assertEqual(v['native_api_pairs'],9184);self.assertEqual(v['cli_processes'],9184);self.assertEqual(v['actual_captures'],20076);self.assertTrue(v['parent_fully_reproduced']);self.assertTrue(v['fixed_numeric_source_verified'])
if __name__=='__main__':unittest.main()
