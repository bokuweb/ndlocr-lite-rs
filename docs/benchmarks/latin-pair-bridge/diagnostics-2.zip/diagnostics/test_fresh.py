from pathlib import Path
import itertools,json,unittest,collections
class Fresh(unittest.TestCase):
 def test_all_fixed_text_and_graphic_conditions_and_native_calls_are_retained(self):
  m=json.loads(Path('tmp/latin-pair-policy/fresh/evaluation-manifest.json').read_text());rows=m['inputs'];self.assertEqual(len(rows),19440);self.assertEqual(len({x['id']for x in rows}),19440);self.assertEqual(len(m['native_records']),1854);self.assertEqual(collections.Counter(x['engine']for x in m['native_records']),{'freetype':618,'coretext':1236})
  modes=[('freetype',None),('coretext',0),('coretext',1)];fonts=['maru','gothic','mincho'];bodies=['KLM','XYZ','MLK','WM','VVM','qjp'];formats=['png','jpeg75'];shapes=['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer'];expected=set()
  for mode,font,size,body,bs,closer,leading,spaces,paper,fmt in itertools.product(modes,fonts,[24,40],bodies,[0,1],[')','\uff09'],[False,True],[0,1],[0,2,10],formats):
   expected.add(('text',mode[0],mode[1],font,size,body,bs,closer,leading,spaces,paper,fmt))
  for mode,font,size,body,shape,leading,gap,fmt in itertools.product(modes,fonts,[24,40],bodies,shapes,[False,True],[0,1],formats):
   for bs in ([0,1]if body=='WM'else[0]):expected.add(('noise',mode[0],mode[1],font,size,body,bs,shape,leading,gap,fmt))
  actual=set()
  for x in rows:
   common=(x['kind'],x['engine'],x['palt'],x['font'],x['size'],x['body'],x['body_spaces'])
   actual.add(common+((x['closer'],x['leading'],x['spaces'],x['paper'],x['format'])if x['kind']=='text'else(x['shape'],x['leading'],x['gap'],x['format'])))
  self.assertEqual(actual,expected);self.assertEqual(len(expected),19440)
if __name__=='__main__':unittest.main()
