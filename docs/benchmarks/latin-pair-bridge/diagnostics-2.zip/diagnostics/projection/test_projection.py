import random,unittest
from projection import analyze_components

def image(points,w,h,tone=(0,0,0)):
 rgb=bytearray([255]*(w*h*3))
 for x,y in points:rgb[(y*w+x)*3:(y*w+x+1)*3]=bytes(tone)
 return rgb
class ProjectionTests(unittest.TestCase):
 def test_three_blocks_keep_all_pixels_and_expose_the_two_single_pixel_columns(self):
  points={(x,y)for x in [1,2,3,4,6,7,8,9,11,12,13,14]for y in range(1,7)}|{(5,3),(10,3)};rgb=image(points,17,9);before=bytes(rgb);rows=analyze_components(rgb,17,9)
  self.assertEqual(rows,[{'bbox':[1,1,15,7],'area':74,'rows':[12,12,14,12,12,12],'columns':[6,6,6,6,1,6,6,6,6,1,6,6,6,6],'one_pixel_columns':[[5,3],[10,3]]}]);self.assertEqual(bytes(rgb),before)
 def test_diagonal_pixels_share_one_eight_connected_component(self):
  rows=analyze_components(image({(0,0),(1,1)},2,2),2,2);self.assertEqual(len(rows),1);self.assertEqual(rows[0]['area'],2);self.assertEqual(rows[0]['bbox'],[0,0,2,2])
 def test_foreground_sum659_is_kept_and660_is_excluded(self):
  for tone in [(219,220,220),(220,219,220),(220,220,219)]:
   rows=analyze_components(bytearray(tone+(220,220,220)),2,1);self.assertEqual(rows,[{'bbox':[0,0,1,1],'area':1,'rows':[1],'columns':[1],'one_pixel_columns':[[0,0]]}])
 def test_invalid_shape_is_rejected_without_mutation(self):
  for w,h,n in [(0,1,0),(1,0,0),(-1,1,0),(1,1,2),(2,1,7)]:
   rgb=bytearray([255]*n);before=bytes(rgb)
   with self.subTest(w=w,h=h,n=n),self.assertRaises(ValueError):analyze_components(rgb,w,h)
   self.assertEqual(bytes(rgb),before)
 def test_horizontal_reflection_preserves_area_rows_and_reverses_column_counts(self):
  rng=random.Random(17);w,h=7,5
  for case in range(40):
   points={(x,y)for x in range(w)for y in range(h)if rng.random()<0.28};original=analyze_components(image(points,w,h),w,h);mirrored=analyze_components(image({(w-1-x,y)for x,y in points},w,h),w,h);expected=[]
   for row in original:
    x0,y0,x1,y1=row['bbox'];expected.append(row|{'bbox':[w-x1,y0,w-x0,y1],'columns':row['columns'][::-1],'one_pixel_columns':sorted([[w-1-x,y]for x,y in row['one_pixel_columns']])})
   self.assertEqual(mirrored,sorted(expected,key=lambda r:(r['bbox'][0],r['bbox'][1],r['bbox'][2],r['bbox'][3])))
if __name__=='__main__':unittest.main()
