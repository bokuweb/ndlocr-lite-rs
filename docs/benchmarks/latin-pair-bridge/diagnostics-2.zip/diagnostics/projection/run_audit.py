from pathlib import Path
import json,hashlib,collections
from projection import analyze_components
r=Path('tmp/latin-triplet-audit');source=Path('tmp/narrow-round-profile/product-manifest.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();spec=Path('docs/latin_triplet_projection_audit.md');m=json.loads(source.read_text());assert len(m['cases'])==162915;closers=set(')\uff09\u300d\u300f\u3011');selected=[];groups={}
for x in m['cases']:
 text=x['raw']
 if text!=x['truth']or x['expected_after']==x['truth']or len(text)!=4:continue
 if sum(c in closers for c in text)!=1 or (text[0]not in closers and text[-1]not in closers):continue
 body=text[1:]if text[0]in closers else text[:-1]
 if not(body.isascii()and body.isalpha()):continue
 selected.append(x);groups.setdefault((x['width'],x['height'],x['rgb_sha256']),[]).append(x)
meta={'baseline_commit':'d711eec30a4e4bd13decad496221f8c0613b482b','source_manifest_sha256':sha(source),'spec_sha256':sha(spec),'driver_sha256':sha(__file__),'projection_sha256':sha(r/'projection.py'),'raw_model_calls':0,'scope':'read-only original RGB projections, not actual Rust collector acceptance or accuracy measurement'};(r/'freeze.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
for (w,h,digest),refs in groups.items():
 p=Path(refs[0]['rgb']);assert sha(p)==digest;rgb=p.read_bytes();components=analyze_components(rgb,w,h);assert sha(p)==digest;rows.append({'width':w,'height':h,'rgb_sha256':digest,'rgb':str(p),'references':[{k:x[k]for k in ['corpus','model','id','orientation','raw','truth','expected_after']}for x in refs],'components':components})
(r/'result.json').write_text(json.dumps({'metadata':meta,'conditions_model_direction_pairs':len(selected),'unique_original_rgb':len(rows),'rows':rows},ensure_ascii=False,indent=2)+'\n');summary={'selected_pairs':len(selected),'unique_original_rgb':len(rows),'unfiltered_component_count_histogram':dict(collections.Counter(len(x['components'])for x in rows)),'components_with_single_pixel_columns':sum(any(c['one_pixel_columns']for c in x['components'])for x in rows),'example_ids':[x['references'][0]['id']for x in rows[:8]]};(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
