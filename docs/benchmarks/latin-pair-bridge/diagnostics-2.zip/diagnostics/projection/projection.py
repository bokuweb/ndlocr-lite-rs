def analyze_components(rgb,width,height):
 if width<=0 or height<=0 or len(rgb)!=width*height*3:raise ValueError('invalid RGB dimensions')
 remaining={i for i in range(width*height)if sum(rgb[i*3:i*3+3])<660};out=[]
 while remaining:
  first=min(remaining);remaining.remove(first);stack=[first];points=[]
  while stack:
   i=stack.pop();x,y=i%width,i//width;points.append((x,y))
   for dy in [-1,0,1]:
    for dx in [-1,0,1]:
     nx,ny=x+dx,y+dy
     if (dx or dy)and 0<=nx<width and 0<=ny<height and ny*width+nx in remaining:
      remaining.remove(ny*width+nx);stack.append(ny*width+nx)
  x0=min(x for x,y in points);y0=min(y for x,y in points);x1=max(x for x,y in points)+1;y1=max(y for x,y in points)+1;rows=[0]*(y1-y0);columns=[0]*(x1-x0);by_column={}
  for x,y in points:rows[y-y0]+=1;columns[x-x0]+=1;by_column.setdefault(x,[]).append(y)
  out.append({'bbox':[x0,y0,x1,y1],'area':len(points),'rows':rows,'columns':columns,'one_pixel_columns':[[x,ys[0]]for x,ys in sorted(by_column.items())if len(ys)==1]})
 return sorted(out,key=lambda r:tuple(r['bbox']))
