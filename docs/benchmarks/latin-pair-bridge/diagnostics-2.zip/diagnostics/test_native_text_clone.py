from pathlib import Path
import unittest,tempfile,os
from native_text_clone import dedup
class Clone(unittest.TestCase):
 def test_cow_keeps_bytes_permissions_and_future_writes_separate(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent)as td:
   d=Path(td);a=d/'a.txt';b=d/'b.txt';a.write_text('KLM)');b.write_text('KLM)');b.chmod(0o600);rows=dedup([a,b],d/'store');self.assertEqual(a.read_text(),b.read_text());self.assertNotEqual(a.stat().st_ino,b.stat().st_ino);self.assertEqual(b.stat().st_mode&0o777,0o600);a.write_text('changed');self.assertEqual(b.read_text(),'KLM)');self.assertEqual(Path(rows[0]['canonical']).read_text(),'KLM)')
 def test_nontext_and_symlinks_are_rejected_before_any_replacement(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent)as td:
   d=Path(td);a=d/'a.txt';a.write_text('KLM)');bad=d/'bad.rgb';bad.write_bytes(b'RGB');ino=a.stat().st_ino
   with self.assertRaises(ValueError):dedup([a,bad],d/'store')
   self.assertEqual(a.stat().st_ino,ino);self.assertEqual(a.read_text(),'KLM)');link=d/'link.txt';link.symlink_to(a)
   with self.assertRaises(ValueError):dedup([a,link],d/'store')
if __name__=='__main__':unittest.main()
