from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,os
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();binary=r/'verification-binary';meta=json.loads((r/'verification-command.json').read_text());assert sha(binary)==meta['binary_sha256']
for p,h in meta['source_sha256'].items():assert sha(p)==h,p
for p,h in meta['models'].items():assert sha(p)==h,p
meta.update({'driver_sha256':sha(__file__),'product_manifest_sha256':sha(r/'product-manifest.json'),'native_manifest_sha256':sha(r/'native-manifest.json'),'source_proof_sha256':sha(r/'source-proof.json')});(r/'verification-command.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,test,extra):
 argv=[str(binary.resolve()),test,'--exact','--ignored','--nocapture'];env={'NDLOCR_INTRA_THREADS':'1'}|extra;record={'binary_sha256':sha(binary),'compiled_source_record_sha256':sha(r/'verification-command.json'),'argv':argv,'env':env};p=r/(name+'-command.json');p.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as a,(r/(name+'.stderr')).open('wb')as b:done=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=b)
 record['exit_code']=done.returncode;p.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name;return name
run('seed-green','infer::cached::latin_pair_model_tests::latin_pair_keeps_the_owned_round_closer_in_session_and_horizontal_pool',{})
def product():return run('product-verification','infer::visible_repetitions::latin_pair_policy::tests::verify_product_matches_frozen_latin_pair_policy',{'NDLOCR_LATIN_PAIR_PRODUCT_MANIFEST':str(r/'product-manifest.json')})
def native(model):return run('native'+model,'infer::cached::narrow_round_model_tests::verify_changed_and_boundary_cases_through_public_apis',{'NDLOCR_NARROW_ROUND_NATIVE_MANIFEST':str(r/'native-manifest.json'),'NDLOCR_NARROW_ROUND_MODEL':model,'NDLOCR_NARROW_ROUND_NATIVE_OUTPUT':str(r/('native'+model+'-results.json'))})
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 futures=[pool.submit(product)]+[pool.submit(native,m)for m in ['30','50','100']]
 for f in concurrent.futures.as_completed(futures):print('completed',f.result(),flush=True)
