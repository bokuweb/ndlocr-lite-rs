from pathlib import Path
import json,unittest
class Capture(unittest.TestCase):
 def test_every_model30_actual_crop_matches_the_pre_registered_forward_rgb(self):
  r=Path('tmp/latin-pair-policy');a=json.loads((r/'nn-capture-audit.json').read_text());self.assertEqual(a['actual_model30_rgb_captures'],20076);self.assertEqual(a['by_orientation'],{'auto':19440,'horizontal':636});self.assertTrue(a['all_original_effective_rgb_byte_equal']);self.assertEqual(len(a['rows']),20076)
if __name__=='__main__':unittest.main()
