from PIL import Image
import unittest
from graphics import crop_white,foreground_bbox,shape_pixels,compose_noise
class Graphics(unittest.TestCase):
 def test_edge_ink_and_soft_pixels_get_real_white_padding(self):
  source=Image.new('RGB',(5,6),'white');source.putpixel((0,0),(0,0,0));source.putpixel((2,3),(254,254,254));before=source.tobytes();out=crop_white(source);self.assertEqual(out.size,(7,8));self.assertEqual(out.getpixel((2,2)),(0,0,0));self.assertEqual(out.getpixel((4,5)),(254,254,254));self.assertEqual(source.tobytes(),before)
  for y in range(out.height):
   for x in range(out.width):
    if x<2 or y<2 or x>=out.width-2 or y>=out.height-2:self.assertEqual(out.getpixel((x,y)),(255,255,255))
 def test_foreground_reference_uses_sum659_but_not660(self):
  source=Image.new('RGB',(2,1));source.putpixel((0,0),(219,220,220));source.putpixel((1,0),(220,220,220));self.assertEqual(foreground_bbox(source),(0,0,1,1))
  with self.assertRaises(ValueError):foreground_bbox(Image.new('RGB',(2,2),'white'))
 def test_nine_shapes_have_marker_sized_geometry_and_connected_owned_points(self):
  shapes=['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer']
  for h in [6,12,17,20,28,29,32,40]:
   for name in shapes:
    w,mh,ps=shape_pixels(name,h)
    if name=='none':self.assertEqual((w,mh,ps),(0,0,set()));continue
    self.assertEqual((w,mh),((4,4)if name=='dot'else(1 if name=='thin'else max(3,(h+3)//4),(4*h+2)//3)))
    self.assertTrue(all(0<=x<w and 0<=y<mh for x,y in ps));seen=set();pending=[next(iter(ps))]
    while pending:
     x,y=pending.pop()
     if (x,y)in seen:continue
     seen.add((x,y));pending.extend((xx,yy)for yy in range(y-1,y+2)for xx in range(x-1,x+2)if(xx,yy)in ps and(xx,yy)not in seen)
    self.assertEqual(seen,ps,(name,h))
    branch=max(0,w-4)if name=='fork_inner'else(w-1)//4
    expected=16 if name=='dot'else w*mh if name=='bar'else mh+w-1-branch if name.startswith('fork_')else mh
    self.assertEqual(len(ps),expected,(name,h))
   for name in shapes:
    with self.assertRaises(ValueError):shape_pixels(name,5)
  self.assertIn((4,19),shape_pixels('fork_inner',29)[2]);self.assertIn((1,19),shape_pixels('fork_outer',29)[2])
 def test_tall_graphics_use_foreground_height_preserve_all_ink_and_do_not_clip(self):
  source=Image.new('RGB',(6,8),'white')
  for y in range(1,7):
   for x in range(1,4):source.putpixel((x,y),(0,0,0))
  source.putpixel((0,0),(254,254,254));body=crop_white(source);before=body.tobytes()
  for shape in ['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer']:
   for leading in [False,True]:
    for gap in [0,1]:
     out,m=compose_noise(body,shape,leading,gap);dx,dy=m['body_offset'];sx,sy,ex,ey=m['shape_bounds'];self.assertEqual(m['reference_fg_height'],6);self.assertEqual(body.tobytes(),before)
     for y in range(body.height):
      for x in range(body.width):
       v=body.getpixel((x,y))
       if v!=(255,255,255):self.assertEqual(out.getpixel((x+dx,y+dy)),v)
     self.assertTrue(0<=sx<=ex<=out.width and 0<=sy<=ey<=out.height)
     if shape not in ['none','dot']:self.assertEqual(ey-sy,8);self.assertEqual(sy,2)
     for xx,yy in m['shape_relative_points']:self.assertEqual(out.getpixel((sx+xx,sy+yy)),(0,0,0))
if __name__=='__main__':unittest.main()
