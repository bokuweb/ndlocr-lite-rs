from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib
r=Path('tmp/latin-pair-policy');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());xs=m['inputs'];picked=[];modes=[('freetype',None),('coretext',0),('coretext',1)];fonts=['maru','gothic','mincho'];bodies=['KLM','XYZ','MLK','WM','VVM','qjp'];shapes=['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer']
def choose(engine,palt,**fields):
 return next(x for x in xs if x['engine']==engine and x['palt']==palt and all(x.get(k)==v for k,v in fields.items()))
for engine,palt in modes:
 local=[]
 for i in range(18):
  body=bodies[i%6];leading=bool(i%2);ci=(i//2)%2
  local.append(choose(engine,palt,kind='text',font=fonts[(i//6)%3],size=24 if i%2==0 else 40,body=body,body_spaces=(i//3)%2,closer=[')',chr(0xff09)][ci],leading=leading,spaces=(i//4)%2,paper=[0,2,10][i%3],format='jpeg75'if(i//5)%2 else'png'))
 for si,shape in enumerate(shapes):
  for leading in [False,True]:
   body=bodies[(si+int(leading))%6]
   local.append(choose(engine,palt,kind='noise',font=fonts[si%3],size=24 if si%2==0 else 40,body=body,body_spaces=1 if body=='WM'and leading else 0,shape=shape,leading=leading,gap=si%2,format='jpeg75'if leading else'png'))
 assert len(local)==36
 picked.extend(local)
 sheet=Image.new('RGB',(1500,1200),'#eeeeee');draw=ImageDraw.Draw(sheet)
 for i,x in enumerate(local):
  im=Image.open(x['image']).convert('RGB');im=im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST);im.thumbnail((244,148));px=i%6*250;py=i//6*200;sheet.paste(im,(px+3,py+3));kind=x.get('shape','text')
  draw.text((px+3,py+153),f'{i} {engine} p{palt} {x["font"]} {x["size"]}\n{kind} {x["body"]} bs{x["body_spaces"]}\nlead{int(x["leading"])} {x["format"]}',fill='black')
 sheet.save(f/f'contact-{engine}-{palt}.png')
assert len(picked)==108 and len({x['id']for x in picked})==108
(f/'contact.json').write_text(json.dumps({'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_ids':[x['id']for x in picked],'sheets':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in f.glob('contact-*.png')}},indent=2)+'\n')
