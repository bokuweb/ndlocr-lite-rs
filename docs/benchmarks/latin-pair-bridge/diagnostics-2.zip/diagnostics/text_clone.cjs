const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
function dedup(files, store, progress = () => {}) {
 for (const p of files) {
  if (!p.endsWith('.txt') || !fs.lstatSync(p).isFile()) throw new Error('only regular generated txt permitted: ' + p);
 }
 fs.mkdirSync(store, { recursive: true }); const rows = [];
 for (const p of files) {
  const before = fs.readFileSync(p), h = digest(before), st = fs.statSync(p), canonical = path.join(store, h + '.txt');
  if (!fs.existsSync(canonical)) fs.copyFileSync(p, canonical, fs.constants.COPYFILE_EXCL);
  if (digest(fs.readFileSync(canonical)) !== h) throw new Error('canonical mismatch: ' + p);
  const temp = p + '.cow-' + process.pid;
  if (fs.existsSync(temp)) throw new Error('unexpected prior temp: ' + temp);
  try {
   fs.copyFileSync(canonical, temp, fs.constants.COPYFILE_FICLONE_FORCE | fs.constants.COPYFILE_EXCL);
   if (fs.statSync(temp).ino === fs.statSync(canonical).ino) throw new Error('hardlink forbidden');
   if (!fs.readFileSync(temp).equals(before) || !fs.readFileSync(p).equals(before)) throw new Error('concurrent or clone content change: ' + p);
   fs.chmodSync(temp, st.mode & 0o7777); fs.utimesSync(temp, st.atime, st.mtime); fs.renameSync(temp, p);
   if (!fs.readFileSync(p).equals(before)) throw new Error('post-replacement mismatch: ' + p);
   rows.push({ path: p, canonical, sha256: h, size: before.length, permission: st.mode & 0o7777, source_bytes_unchanged: true });
  } finally { if (fs.existsSync(temp)) fs.unlinkSync(temp); }
  if (rows.length % 10000 === 0) progress(rows.length, files.length);
 }
 return rows;
}
module.exports = { dedup };
