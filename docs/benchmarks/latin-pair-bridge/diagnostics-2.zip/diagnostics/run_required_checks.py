from pathlib import Path
import subprocess,shlex,json,os,re,hashlib
r=Path('tmp/latin-pair-policy');workflow=Path('.github/workflows/ci.yml');line=next(x for x in workflow.read_text().splitlines()if x.strip().startswith('run: cargo test --features onnx --lib --test'))
native=shlex.split(line.strip()[5:]);env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_TEST_PARSEQ_MODEL':'models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','NDLOCR_TEST_CHARSET':'models/NDLmoji.yaml','NDLOCR_TEST_DEIM_MODEL':'models/deim-s-1024x1024.onnx','NDLOCR_TEST_REPEAT_IMAGE':'tests/fixtures/parseq_unprocessed/repeated_digits.png','NDLOCR_DIAGNOSTIC_PYTHON':'/Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'}
jobs=[('native-tests',native),('example-tests',['cargo','test','--locked','--features','onnx','--examples','--test','margin_sensitivity_tests']),('clippy-final',['cargo','clippy','--features','onnx','--all-targets','--message-format=json'])]
summary={}
for name,argv in jobs:
 record={'argv':argv,'env':env,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'workflow_sha256':hashlib.sha256(workflow.read_bytes()).hexdigest()};cmd=r/(name+'-command.json');cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as a,(r/(name+'.stderr')).open('wb')as b:p=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=b)
 record['exit_code']=p.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert p.returncode==0,name
 if name!='clippy-final':
  rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(r/(name+'.stdout')).read_text());assert rows and all(int(b)==0 for a,b,c in rows)
  summary[name]={'passed':sum(int(a)for a,b,c in rows),'ignored':sum(int(c)for a,b,c in rows),'reports':len(rows)}
 print('completed',name,summary.get(name,{}),flush=True)
(r/'required-check-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
