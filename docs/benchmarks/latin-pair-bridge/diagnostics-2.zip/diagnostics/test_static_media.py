from pathlib import Path
import json,hashlib,zipfile,unittest
class Static(unittest.TestCase):
 def test_every_static_media_path_is_restorable_with_the_recorded_hash(self):
  r=Path('tmp/latin-pair-policy');base=r/'packet-media';index=json.loads((base/'static-media.json').read_text());expected={}
  for folder in ['fresh','horizontal']:
   f=r/folder
   for name in ['native','original','png','rgb','effective','truth']:
    for p in(f/name).rglob('*'):
     if p.is_file():expected['data/'+folder+'/'+str(p.relative_to(f))]=hashlib.sha256(p.read_bytes()).hexdigest()
   for p in f.iterdir():
    if p.is_file()and(p.name in ['atlas.png','lines.json','evaluation-manifest.json','tensor-proof.json','contact.json']or p.name.startswith('contact-')and p.suffix=='.png'):
     expected['data/'+folder+'/'+p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
  actual={}
  for name in index['archives']:
   archive=base/(name+'.zip');self.assertLess(archive.stat().st_size,50*1024*1024);meta=json.loads((base/(name+'.json')).read_text());self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(),meta['sha256'])
   with zipfile.ZipFile(archive)as z:
    for key,h in meta['members'].items():self.assertEqual(hashlib.sha256(z.read(key)).hexdigest(),h)
    aliases=json.loads(z.read(name+'-aliases.json'))
    for key,h in meta['members'].items():
     if key.endswith('-aliases.json'):continue
     self.assertNotIn(key,actual);actual[key]=h
    for key,a in aliases.items():self.assertNotIn(key,actual);self.assertEqual(a['sha256'],meta['members'][a['source']]);actual[key]=a['sha256']
  self.assertEqual(actual,expected)
if __name__=='__main__':unittest.main()
