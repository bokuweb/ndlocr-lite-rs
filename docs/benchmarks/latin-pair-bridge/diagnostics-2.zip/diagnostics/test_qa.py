from pathlib import Path
import json,unittest
class QA(unittest.TestCase):
 def test_all_native_draws_are_independently_reproduced(self):
  a=json.loads(Path('tmp/latin-pair-policy/native-audit.json').read_text());self.assertEqual(a['native_generation_records'],1854);self.assertEqual(a['independent_native_qa_redraws'],1854);self.assertEqual(len(a['records']),1854)
 def test_all_graphic_pngs_have_independently_reconstructed_pixels(self):
  a=json.loads(Path('tmp/latin-pair-policy/noise-pixel-audit.json').read_text());self.assertEqual(a['pre_jpeg_pairs'],4536);self.assertTrue(a['all_source_body_nonwhite_pixels_preserved']);self.assertTrue(a['all_shape_glyph_overlap_counts_zero']);self.assertTrue(a['all_png_reconstructions_byte_equal']);self.assertEqual(len(a['rows']),4536)
 def test_all_inputs_original_effective_truth_atlas_and_prior_matches_are_checked(self):
  a=json.loads(Path('tmp/latin-pair-policy/fresh-pixel-audit.json').read_text());self.assertEqual(a['inputs'],19440);self.assertEqual(a['internal_truth_conflicts'],[]);self.assertEqual(a['seen_rgb_inputs']+a['unseen_rgb_inputs'],19440)
if __name__=='__main__':unittest.main()
