from pathlib import Path
import json,hashlib,zipfile,unittest
class Packet(unittest.TestCase):
 def test_all_packet_archives_members_aliases_and_required_sources_are_present(self):
  p=Path('docs/benchmarks/latin-pair-bridge');m=json.loads((p/'archives.json').read_text());keys=set()
  for name,h in m['archives'].items():
   archive=p/(name+'.zip');self.assertLess(archive.stat().st_size,50*1024*1024);self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(),h);index=json.loads((p/(name+'.json')).read_text());self.assertEqual(index['sha256'],h)
   with zipfile.ZipFile(archive)as z:
    self.assertEqual(set(z.namelist()),set(index['members']))
    for key,h in index['members'].items():self.assertEqual(hashlib.sha256(z.read(key)).hexdigest(),h)
    aliases=json.loads(z.read(name+'-aliases.json'))
    for key,x in aliases.items():self.assertEqual(x['sha256'],index['members'][x['source']])
    keys.update(index['members']);keys.update(aliases)
  for key in ['diagnostics/portable-cases.json','diagnostics/kernel/frozen-kernel-source.rs','diagnostics/projection/result.json','diagnostics/verification-source/src/infer/visible_repetitions/latin_pair_policy.rs','diagnostics/native100-results.json','diagnostics/line-cli-results.json','diagnostics/source/eval_ocr_metrics.py','data/fresh/tensor-proof.json']:
   self.assertIn(key,keys)
if __name__=='__main__':unittest.main()
