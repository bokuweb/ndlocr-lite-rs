from pathlib import Path
import json,unittest,sys
label=sys.argv.pop(1)
class ModelEvaluation(unittest.TestCase):
 def test_all_fixed_conditions_and_normalizations_are_scored_without_regression(self):
  r=Path('tmp/latin-pair-policy')/('fresh-policy-model'+label);m=json.loads((r/'manifest.json').read_text());a=json.loads((r/'audit.json').read_text())
  self.assertEqual(len(m['cases']),19440);self.assertEqual({x['model']for x in m['cases']},{label});self.assertEqual({x['normalization']for x in a['summary']},{'none','width','strict'});self.assertEqual({x['group']for x in a['summary']},set(['all','unseen','text','noise','freetype-pNone','coretext-p0','coretext-p1']+['body-'+b for b in ['KLM','XYZ','MLK','WM','VVM','qjp']]+['body_spaces-0','body_spaces-1','size-24','size-40','font-maru','font-gothic','font-mincho']+['noise-'+s for s in ['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer']]))
  self.assertEqual(a['char_regressions'],[]);self.assertEqual(a['word_regressions'],[])
if __name__=='__main__':unittest.main()
