from pathlib import Path
import json,unittest
class Combined(unittest.TestCase):
 def test_three_models_have_every_fixed_case_and_audit_with_no_regressions(self):
  r=Path('tmp/latin-pair-policy/fresh-policy');m=json.loads((r/'manifest.json').read_text());a=json.loads((r/'audit.json').read_text());records=json.loads((r/'replay/records.json').read_text())
  self.assertEqual(len(m['cases']),58320);self.assertEqual(len(records),58320);self.assertEqual(len({(x['model'],x['id'])for x in records}),58320)
  for label in ['30','50','100']:self.assertEqual(sum(x['model']==label for x in records),19440)
  self.assertEqual(a['char_regressions'],[]);self.assertEqual(a['word_regressions'],[])
  self.assertEqual(len(a['summary']),261)
if __name__=='__main__':unittest.main()
