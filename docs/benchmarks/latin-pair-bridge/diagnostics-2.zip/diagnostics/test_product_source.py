from pathlib import Path
import json,unittest
class Source(unittest.TestCase):
 def test_only_preregistered_runtime_hook_and_fixed_conditions_are_added(self):
  a=json.loads(Path('tmp/latin-pair-policy/source-proof.json').read_text());self.assertTrue(a['main_matches_exact_minimal_hook']);self.assertTrue(a['marker_parameter_name_only']);self.assertTrue(a['cached_only_new_test_module']);self.assertTrue(a['page_fragment_tail_byte_equal']);self.assertTrue(a['fixed_policy_and_kernel_numeric_source_unchanged']);self.assertGreater(a['all_other_tracked_rust_byte_equal'],100);self.assertTrue(a['models_and_charset_unchanged'])
if __name__=='__main__':unittest.main()
