from pathlib import Path
import json,hashlib,zipfile,struct,subprocess,os,concurrent.futures
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();b=Path('tmp/narrow-round-profile/verification-binary');parent=Path('tmp/narrow-round-profile/verification-command.json');rec=json.loads(parent.read_text());assert sha(b)==rec['binary_sha256']
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:old=json.loads(z.read('probe.json'))
means={(m['label'].removeprefix('single'),x['id']):struct.unpack('<I',struct.pack('<f',x['mean_confidence']))[0]for m in old['models']for x in m['rows']}
cases=[];manifest=json.loads((r/'manifest.json').read_text())
for model in ['30','50','100']:
 x=next(x for x in manifest['cases']if x['corpus']=='old'and x['model']==model and x['id']=='leading_round_suffix_joined_mincho24_png')
 assert x['raw']=='KLM)'and sha(x['rgb'])==x['rgb_sha256']
 cases.append(x|{'expected_after':'KLM)','selected':True,'mean_bits':means[model,x['id']]})
(r/'api-seed-manifest.json').write_text(json.dumps({'cases':cases,'counts':{'30':1,'50':1,'100':1}},indent=2)+'\n')
meta={'binary_sha256':sha(b),'baseline_source_record_sha256':sha(parent),'models':rec['models'],'manifest_sha256':sha(r/'api-seed-manifest.json'),'spec_sha256':sha('docs/latin_pair_bridge_public_api.md'),'driver_sha256':sha(__file__),'new_raw_evaluation_calls':0,'api_validation_forwards':6};(r/'api-seed-red-freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(model):
 argv=[str(b.resolve()),'infer::cached::narrow_round_model_tests::verify_changed_and_boundary_cases_through_public_apis','--exact','--ignored','--nocapture']
 env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_NARROW_ROUND_NATIVE_MANIFEST':str(r/'api-seed-manifest.json'),'NDLOCR_NARROW_ROUND_MODEL':model,'NDLOCR_NARROW_ROUND_NATIVE_OUTPUT':str(r/('api-seed-red-'+model+'-results.json'))}
 record={'argv':argv,'env':env};p=r/('api-seed-red-'+model+'-command.json');p.write_text(json.dumps(record,indent=2)+'\n');done=subprocess.run(argv,env=os.environ|env,capture_output=True);(r/('api-seed-red-'+model+'.stdout')).write_bytes(done.stdout);(r/('api-seed-red-'+model+'.stderr')).write_bytes(done.stderr);record['exit_code']=done.returncode;p.write_text(json.dumps(record,indent=2)+'\n')
 assert done.returncode==101 and ('actual '+model).encode()in done.stderr and b'KLM' in done.stderr,done.stderr
 return model
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:print('public API meaningful Red confirmed',list(pool.map(run,['30','50','100'])))
