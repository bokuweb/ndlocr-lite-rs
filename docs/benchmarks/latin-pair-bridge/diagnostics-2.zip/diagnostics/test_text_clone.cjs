const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { dedup } = require('./text_clone.cjs');
const root = fs.mkdtempSync(path.join(__dirname, 'clone-test-'));
try {
 const a = path.join(root, 'a.txt'), b = path.join(root, 'b.txt');
 fs.writeFileSync(a, 'KLM)'); fs.writeFileSync(b, 'KLM)'); fs.chmodSync(b, 0o600);
 const rows = dedup([a, b], path.join(root, 'canonical'));
 assert.equal(rows.length, 2); assert.equal(fs.readFileSync(a, 'utf8'), 'KLM)'); assert.equal(fs.readFileSync(b, 'utf8'), 'KLM)');
 assert.notEqual(fs.statSync(a).ino, fs.statSync(b).ino); assert.equal(fs.statSync(b).mode & 0o777, 0o600);
 fs.writeFileSync(a, 'changed'); assert.equal(fs.readFileSync(b, 'utf8'), 'KLM)'); assert.equal(fs.readFileSync(rows[0].canonical, 'utf8'), 'KLM)');
 const bad = path.join(root, 'source.rgb'); fs.writeFileSync(bad, 'RGB');
 assert.throws(() => dedup([b, bad], path.join(root, 'other')), /txt/);
 assert.equal(fs.readFileSync(b, 'utf8'), 'KLM)'); assert.equal(fs.readFileSync(bad, 'utf8'), 'RGB');
 console.log('COW bytes, distinct inodes, later write isolation, permissions and non-txt rejection verified');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
