from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sources={}
assert Path('src/infer/visible_repetitions/latin_pair_policy.rs').read_bytes().split(b'#[cfg(test)]')[0]==(r/'frozen-policy-source.rs').read_bytes()
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock')]:
 q=r/'product-seed-red-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sources[str(p)]=sha(p)
argv=['cargo','test','--lib','--message-format=json','infer::visible_repetitions::latin_pair_policy::tests::an_owned_pair_and_singleton_support_the_existing_round_fragment','--','--exact','--nocapture']
m={'argv':argv,'source_sha256':sources,'no_nn_forwards':True};out=r/'product-seed-red-command.json';out.write_text(json.dumps(m,indent=2)+'\n')
with(r/'product-seed-red.stdout').open('wb')as a,(r/'product-seed-red.stderr').open('wb')as b:done=subprocess.run(argv,stdout=a,stderr=b)
m['exit_code']=done.returncode;events=[]
for line in(r/'product-seed-red.stdout').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
assert any(x.get('reason')=='build-finished'and x.get('success')for x in events)
bins=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(bins)==1
shutil.copy2(bins[0],r/'product-seed-red-binary');m['binary_sha256']=sha(r/'product-seed-red-binary');out.write_text(json.dumps(m,indent=2)+'\n')
assert done.returncode==101
s=(r/'product-seed-red.stderr').read_text();assert 'assertion'in s and 'left: "KLM"'in s and 'right: "KLM)"'in s,s
print('meaningful pure product Red after successful build; frozen numerical conditions unchanged; no NN')
