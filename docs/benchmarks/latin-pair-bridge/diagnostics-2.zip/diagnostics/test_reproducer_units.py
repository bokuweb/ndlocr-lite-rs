from pathlib import Path
import json,zipfile,tempfile,unittest,sys,hashlib
sys.path.insert(0,str(Path(__file__).parent.resolve()))
import reproduce
class Restore(unittest.TestCase):
 def packet(self,p,key='data/a.txt'):
  data=b'KLM)';h=hashlib.sha256(data).hexdigest();alias={'data/b.txt':{'source':key,'sha256':h}};meta={}
  with zipfile.ZipFile(p/'part.zip','w')as z:
   z.writestr(key,data);b=(json.dumps(alias)+'\n').encode();z.writestr('part-aliases.json',b);meta={key:h,'part-aliases.json':hashlib.sha256(b).hexdigest()}
  index={'sha256':hashlib.sha256((p/'part.zip').read_bytes()).hexdigest(),'members':meta};(p/'part.json').write_text(json.dumps(index))
 def test_verified_members_and_aliases_restore_exact_bytes(self):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);self.packet(p);out=p/'out';out.mkdir();reproduce.restore(p,out,['part']);self.assertEqual((out/'data/a.txt').read_bytes(),b'KLM)');self.assertEqual((out/'data/b.txt').read_bytes(),b'KLM)')
 def test_tampered_archive_and_parent_escape_reject(self):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);self.packet(p);(p/'part.zip').write_bytes(b'bad');out=p/'out';out.mkdir()
   with self.assertRaises(AssertionError):reproduce.restore(p,out,['part'])
   self.packet(p,'../escape.txt')
   with self.assertRaises(AssertionError):reproduce.restore(p,out,['part'])
   self.assertFalse((p/'escape.txt').exists())
 def test_alias_must_reference_a_member_of_the_verified_archive(self):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);self.packet(p);(p/'outside.txt').write_bytes(b'KLM)')
   with zipfile.ZipFile(p/'part.zip')as z:members={n:z.read(n)for n in z.namelist()}
   a=json.loads(members['part-aliases.json']);a['data/b.txt']['source']='../outside.txt';members['part-aliases.json']=json.dumps(a).encode()
   with zipfile.ZipFile(p/'part.zip','w')as z:
    for n,b in members.items():z.writestr(n,b)
   index={'sha256':hashlib.sha256((p/'part.zip').read_bytes()).hexdigest(),'members':{n:hashlib.sha256(b).hexdigest()for n,b in members.items()}};(p/'part.json').write_text(json.dumps(index));out=p/'out';out.mkdir()
   with self.assertRaises(AssertionError):reproduce.restore(p,out,['part'])
if __name__=='__main__':unittest.main()
