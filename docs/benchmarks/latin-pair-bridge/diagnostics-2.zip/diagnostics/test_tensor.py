from pathlib import Path
import json,unittest
class Tensor(unittest.TestCase):
 def test_every_original_auto_matches_effective_horizontal_at_all_model_shapes(self):
  a=json.loads(Path('tmp/latin-pair-policy/fresh/tensor-proof.json').read_text());self.assertEqual(a['images'],19440);self.assertEqual(a['model_shapes'],3);self.assertTrue(a['all_original_auto_and_effective_horizontal_tensors_bit_equal'])
if __name__=='__main__':unittest.main()
