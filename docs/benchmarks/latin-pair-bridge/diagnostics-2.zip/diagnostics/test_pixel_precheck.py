from pathlib import Path
import json,unittest
class PixelPrecheck(unittest.TestCase):
 def test_independent_restored_media_and_pixel_audits(self):
  a=json.loads(Path('tmp/latin-pair-policy/pixel-precheck/verification.json').read_text());self.assertEqual(a['images'],20076);self.assertEqual(a['actual_captures'],20076);self.assertEqual(a['pre_jpeg_noise_pairs'],4536);self.assertEqual(a['native_records'],1854);self.assertEqual(a['unique_fresh_rgb'],13368);self.assertEqual(a['unique_unseen_rgb'],13368)
if __name__=='__main__':unittest.main()
