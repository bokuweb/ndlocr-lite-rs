from pathlib import Path
import json,hashlib,zipfile,shutil,zlib
r=Path('tmp/latin-pair-policy');out=Path('docs/benchmarks/latin-pair-bridge');sha=lambda b:hashlib.sha256(b).hexdigest()
def shards(prefix,paths):
 result={};part=0;z=None;members={};aliases={};seen={}
 def finish():
  nonlocal z
  if z is None:return
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b);z.close()
  p=out/(name+'.zip');assert p.stat().st_size<50*1024*1024
  h=sha(p.read_bytes());(out/(name+'.json')).write_text(json.dumps({'sha256':h,'members':members},indent=2)+'\n');result[name]=h;print(name,len(members),len(aliases),p.stat().st_size,flush=True)
 for key,p in sorted(paths):
  b=p.read_bytes();h=sha(b)
  if z is None:
   name=prefix+'-'+str(part);z=zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)
  if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
  estimate=len(zlib.compress(b,6))+len(key.encode())*2+200
  if z.fp.tell()+estimate>44*1024*1024 and members:
   finish();part+=1;name=prefix+'-'+str(part);z=zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6);members={};aliases={};seen={}
  seen[h]=key;z.writestr(key,b);members[key]=h
 finish();return result
def main():
 assert json.loads((r/'line-cli-command.json').read_text())['manifest_sha256']==sha((r/'cli-manifest.json').read_bytes())
 cli=json.loads((r/'line-cli-results.json').read_text());assert len(cli)==9184
 out.mkdir(exist_ok=True);archives={}
 for index in ['static-media.json','nn-inputs.json']:
  for name in json.loads((r/'packet-media'/index).read_text())['archives']:
   for suffix in ['.zip','.json']:shutil.copy2(r/'packet-media'/(name+suffix),out/(name+suffix))
   archives[name]=json.loads((out/(name+'.json')).read_text())['sha256']
 exclude={'packet-media','final-restored','pixel-precheck','portable-pixel-work','sealed-generated-text','current-sealed-generated-text','__pycache__','subsets','truth','scores','line-cli','native','native-rerender','original','png','rgb','effective','whole-rgb-capture','static-media-oversize-initial','restored-rust-source','restored-rust-target'}
 suffixes={'.json','.jsonl','.py','.md','.rs','.log','.stdout','.stderr','.swift','.toml','.lock','.yaml','.cjs'}
 diag=[]
 for base,prefix in [(r,'diagnostics'),(Path('tmp/latin-pair-kernel'),'diagnostics/kernel'),(Path('tmp/latin-triplet-audit'),'diagnostics/projection')]:
  for directory,dirs,names in __import__('os').walk(base):
   dirs[:]=[d for d in dirs if d not in exclude and not d.startswith('clone-test-')]
   for name in names:
    p=Path(directory)/name
    if p.suffix in suffixes and name not in {'checkpoint.md','reproduce.py','build_reproducer.py','reproduce-command.json','reproduce.stdout','reproduce.stderr'} and not name.startswith('reproducer-') and not name.startswith('restored-') and not name.startswith('run_restored') and not name.startswith('reproduction-'):diag.append((prefix+'/'+str(p.relative_to(base)),p))
 for p in Path('tests/fixtures/latin_pair_bridge').iterdir():diag.append(('diagnostics/fixtures/'+p.name,p))
 for p in Path('docs').glob('latin*md'):diag.append(('diagnostics/specs/'+p.name,p))
 diag += [('diagnostics/source/eval_ocr_metrics.py',Path('tools/eval_ocr_metrics.py')),('diagnostics/source/means.py',Path('tmp/punct-matched/means.py'))]
 for base in [Path('tests/fixtures'),Path('benches')]:
  for p in base.rglob('*'):
   if p.is_file():diag.append(('diagnostics/build-support/'+str(p),p))
 archives.update(shards('diagnostics',diag));text=[]
 for sub in ['scores','fresh-policy/scores','horizontal-policy/scores','line-cli']:
  for p in(r/sub).rglob('*'):
   if p.is_file()and p.suffix in {'.csv','.md','.txt','.json','.stdout','.stderr','.png'}:text.append(('text/'+str(p.relative_to(r)),p))
 archives.update(shards('text',text));parent=Path('docs/benchmarks/narrow-round-marker')
 refs={'packet':parent.name,'reproducer_sha256':sha((parent/'reproduce.py').read_bytes()),'archives':{n:json.loads((parent/(n+'.json')).read_text())['sha256']for n in ['images','pixels','inputs','diagnostics','text']},'nested_parents_json_sha256':sha((parent/'parents.json').read_bytes())}
 (out/'parents.json').write_text(json.dumps(refs,indent=2)+'\n');(out/'archives.json').write_text(json.dumps({'archives':archives,'expected_cases':223143,'source_sha256':sha(Path(__file__).read_bytes())},indent=2)+'\n')
 for name in ['reproduce.py','portable_native.py']:shutil.copy2(r/name,out/name)
if __name__=='__main__':main()
