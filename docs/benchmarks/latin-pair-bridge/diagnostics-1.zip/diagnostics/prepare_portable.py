from pathlib import Path
import json,zipfile,hashlib
r=Path('tmp/latin-pair-policy');p=Path('docs/benchmarks/narrow-round-marker')
with zipfile.ZipFile(p/'diagnostics.zip')as z:old={(x['corpus'],x['model'],x['id']):x for x in json.loads(z.read('diagnostics/portable-cases.json'))['cases']}
cases=[]
for x in json.loads((r/'product-manifest.json').read_text())['cases']:
 k=x['corpus'],x['model'],x['id']
 if k in old:
  y=old[k];assert x['raw']==y['raw']and x['truth']==y['truth']and x['expected_before']==y['expected_after']and x['rgb_sha256']==y['rgb_sha256'];rgb='parent/'+y['rgb']
 else:assert x['corpus']in ['latin-fresh','latin-horizontal'];rgb='data/fresh/rgb/'+x['id']+'.rgb'
 cases.append(x|{'rgb':rgb})
assert len(cases)==223143
(r/'portable-cases.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n')
s=[x for x in cases if x['selected']];assert len(s)==112
print('portable223143;selected112;unique',len({(x['width'],x['height'],x['rgb_sha256'])for x in s}),flush=True)
