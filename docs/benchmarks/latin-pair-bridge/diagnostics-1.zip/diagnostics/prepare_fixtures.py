from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/latin-pair-policy');out=Path('tests/fixtures/latin_pair_bridge');source=Path('tmp/latin-pair-kernel/component-input.json');data=json.loads(source.read_text());rows={ref['id']:x for x in data['rows']for ref in x['references']};names={
 'klm_round_suffix_mincho24':'leading_round_suffix_joined_mincho24_png',
 'klm_round_prefix_mincho24':'leading_round_prefix_joined_mincho24_png',
 'xyz_round_suffix_mincho':'widecell_latin_round_suffix_joined_mincho_png',
 'xyz_round_thick_jpeg':'widecell_latin_round_suffix_joined_mincho_jpeg75',
 'xyz_round_overlapping_gothic_jpeg':'widecell_latin_round_suffix_joined_gothic_jpeg75',
};sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
for name,id in names.items():
 x=rows[id];rgb=Path(x['rgb']).read_bytes();assert sha(rgb)==x['rgb_sha256'];p=out/(name+'.png');Image.frombytes('RGB',(x['width'],x['height']),rgb).save(p);assert Image.open(p).convert('RGB').tobytes()==rgb;records.append({'fixture':str(p),'fixture_sha256':sha(p.read_bytes()),'source_rgb_sha256':x['rgb_sha256'],'source_rgb':x['rgb'],'source_id':id,'width':x['width'],'height':x['height'],'references':x['references']})
(out/'provenance.json').write_text(json.dumps({'baseline_commit':'d711eec30a4e4bd13decad496221f8c0613b482b','source_manifest_sha256':sha(source.read_bytes()),'driver_sha256':sha(Path(__file__).read_bytes()),'records':records},ensure_ascii=False,indent=2)+'\n');print('Five fixture PNGs preserve original RGB exactly; no new glyph rendering or NN')
