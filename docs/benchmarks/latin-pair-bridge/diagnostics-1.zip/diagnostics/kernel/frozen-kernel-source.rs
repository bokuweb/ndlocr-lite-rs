//! Test-only exploration of one raster neck between unequal narrow glyph cells.

fn split_pair(
    mask: &[bool],
    width: usize,
    height: usize,
    body_height: usize,
) -> Option<[super::Component; 2]> {
    use super::single_pixel_bridge::take_region;
    if width < 3
        || height == 0
        || body_height < 6
        || height > body_height
        || height as u128 * 4 < body_height as u128 * 3
        || width.checked_mul(height) != Some(mask.len())
        || mask.len() > 65_536
        || width as u128 > body_height as u128 * 3 + 1
    {
        return None;
    }
    let area = mask.iter().filter(|&&v| v).count();
    for cut in 1..width - 1 {
        let mut rows = (0..height).filter(|&y| mask[y * width + cut]);
        let Some(row) = rows.next() else { continue };
        if rows.next().is_some() {
            continue;
        }
        let touches =
            |x| (row.saturating_sub(1)..=(row + 1).min(height - 1)).any(|y| mask[y * width + x]);
        if !touches(cut - 1) || !touches(cut + 1) {
            continue;
        }
        let mut remaining = mask.to_vec();
        remaining[row * width + cut] = false;
        let Some(left) = take_region(&mut remaining, width, height, 0, cut) else {
            continue;
        };
        let Some(right) = take_region(&mut remaining, width, height, cut + 1, width) else {
            continue;
        };
        if remaining.iter().any(|&v| v)
            || left.area + right.area + 1 != area
            || left.x0 != 0
            || left.x1 != cut
            || right.x0 != cut + 1
            || right.x1 != width
            || left.y0.min(right.y0) != 0
            || left.y1.max(right.y1) != height
        {
            continue;
        }
        let widths = [left.x1 - left.x0, right.x1 - right.x0];
        if widths.iter().any(|&w| {
            w as u128 * 2 < body_height as u128 || w as u128 * 2 > body_height as u128 * 3
        }) || widths[0].max(widths[1]) as u128 > widths[0].min(widths[1]) as u128 * 2
        {
            continue;
        }
        let shared_height = left.y1.min(right.y1).saturating_sub(left.y0.max(right.y0));
        if shared_height as u128 * 4 < body_height as u128 * 3 {
            continue;
        }
        return Some([left, right]);
    }
    None
}

