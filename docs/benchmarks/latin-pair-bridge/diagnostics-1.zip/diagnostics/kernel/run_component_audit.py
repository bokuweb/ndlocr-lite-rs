from pathlib import Path
import json,hashlib,shutil,subprocess,os
r=Path('tmp/latin-pair-kernel');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=Path('src/infer/visible_repetitions/latin_pair_bridge.rs');prefix=source.read_bytes().split(b'#[cfg(test)]',1)[0];lock=json.loads((r/'kernel-lock.json').read_text());assert hashlib.sha256(prefix).hexdigest()==lock['kernel_prefix_sha256'];assert sha('docs/latin_pair_bridge_kernel.md')==lock['spec_sha256']
xs=[json.loads(x)for x in(r/'component-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x.get('success')for x in xs);binaries=[x['executable']for x in xs if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(binaries)==1;binary=r/'component-binary';shutil.copy2(binaries[0],binary);sources={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').glob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),*Path('docs').glob('latin*md')]:
 q=r/'component-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sources[str(p)]=sha(p)
original=Path('tmp/latin-triplet-audit/result.json');shutil.copy2(original,r/'component-input.json');data=json.loads(original.read_text());rgb={x['rgb']:x['rgb_sha256']for x in data['rows']}
for p,h in rgb.items():assert sha(p)==h
argv=[str(binary.resolve()),'infer::visible_repetitions::latin_pair_bridge::tests::record_known_component_kernel_views','--exact','--ignored','--nocapture'];env={'NDLOCR_LATIN_PAIR_KERNEL_AUDIT_ROOT':str(r)};record={'argv':argv,'env':env,'binary_sha256':sha(binary),'source_sha256':sources,'input_sha256':sha(r/'component-input.json'),'kernel_lock_sha256':sha(r/'kernel-lock.json'),'original_rgb_sha256':rgb,'driver_sha256':sha(__file__),'new_model_calls':0};path=r/'component-command.json';path.write_text(json.dumps(record,indent=2)+'\n')
with(r/'component.stdout').open('wb')as a,(r/'component.stderr').open('wb')as b:done=subprocess.run(argv,stdout=a,stderr=b,env=os.environ|env)
record['exit_code']=done.returncode;path.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0
for p,h in rgb.items():assert sha(p)==h
print('Actual Rust component/kernel audit completed; all27 original RGB files unchanged; model calls0')
