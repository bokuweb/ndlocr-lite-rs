from pathlib import Path
import json,unittest
class ActualAuditTests(unittest.TestCase):
 def test_every_known_component_is_retained_and_seed_views_use_original_coordinates(self):
  r=Path('tmp/latin-pair-kernel');data=json.loads((r/'actual-kernel.json').read_text());source=json.loads(Path('tmp/latin-triplet-audit/result.json').read_text());self.assertEqual(data['images'],27);self.assertEqual(len(data['records']),84);self.assertEqual(data['new_model_calls'],0)
  refs={(x['image_id'],x['component_index']):x for x in data['records']};self.assertEqual(len(refs),84);expected=set()
  for row in source['rows']:
   image_id=row['references'][0]['id']
   for i,c in enumerate(row['components']):
    expected.add((image_id,i));actual=refs[image_id,i];self.assertEqual(actual['bbox'],c['bbox']);self.assertEqual(actual['area'],c['area']);self.assertEqual(actual['reference_height'],c['bbox'][3]-c['bbox'][1])
    if actual['supported']:
     self.assertTrue(actual['owns_bbox_foreground']);self.assertEqual(sum(c[4]for c in actual['global_views'])+1,c['area'])
  self.assertEqual(set(refs),expected)
  for image_id,index,boxes in [
   ('leading_round_suffix_joined_mincho24_png',1,[[26,9,39,26],[40,9,61,26]]),
   ('widecell_latin_round_suffix_joined_mincho_png',0,[[8,9,25,26],[26,9,42,26]]),
  ]:
   actual=refs[image_id,index];self.assertTrue(actual['supported']);self.assertEqual([c[:4]for c in actual['global_views']],boxes)
  self.assertTrue(any(not x['owns_bbox_foreground']for x in data['records']))
if __name__=='__main__':unittest.main()
