//! Test-only support for an owned pair and a separate narrow glyph cell.

fn supports(text: &str, rgb: &[u8], width: usize, height: usize) -> bool {
    let chars: Vec<_> = text.chars().take(5).collect();
    let round = |c| matches!(c, ')' | '）');
    if chars.len() != 4
        || chars.iter().filter(|&&c| round(c)).count() != 1
        || chars
            .iter()
            .filter(|&&c| !round(c))
            .any(|c| !c.is_ascii_alphabetic())
    {
        return false;
    }
    let leading = round(chars[0]);
    if !leading && !round(chars[3]) {
        return false;
    }
    let Some((mut body, _)) = super::collect_components(rgb, width, height) else {
        return false;
    };
    if body.len() != 3 {
        return false;
    }
    let mark = if leading {
        body.remove(0)
    } else {
        body.pop().unwrap()
    };
    if body[0].x1 > body[1].x0 {
        return false;
    }
    let body_height = body.iter().map(|c| c.y1 - c.y0).max().unwrap();
    let body_start = body.iter().map(|c| c.x0).min().unwrap();
    let body_end = body.iter().map(|c| c.x1).max().unwrap();
    let gap = if leading {
        body_start.checked_sub(mark.x1)
    } else {
        mark.x0.checked_sub(body_end)
    };
    let Some(gap) = gap else { return false };
    if gap > body_height.div_ceil(4) {
        return false;
    }
    let mark_width = mark.x1 - mark.x0;
    if mark_width as u128 * 4 < body_height as u128 || mark_width as u128 * 2 > body_height as u128
    {
        return false;
    }
    let mark_height = mark.y1 - mark.y0;
    if mark_height as u128 * 4 < body_height as u128 * 3
        || mark_height as u128 * 2 > body_height as u128 * 3
    {
        return false;
    }
    // Check the marker's own narrow aspect and outline here. Its relation to
    // the body height is a separate constraint for this Latin view.
    if !super::narrow_round_marker::supports_mark(&mark, rgb, width, height, mark_height) {
        return false;
    }
    let mut pair = None;
    for (index, c) in body.iter().enumerate() {
        let (w, h) = (c.x1 - c.x0, c.y1 - c.y0);
        let mut mask = Vec::with_capacity(w * h);
        for y in c.y0..c.y1 {
            for x in c.x0..c.x1 {
                let p = (y * width + x) * 3;
                mask.push(rgb[p..p + 3].iter().map(|&v| u16::from(v)).sum::<u16>() < 660);
            }
        }
        if mask.iter().filter(|&&v| v).count() != c.area {
            return false;
        }
        if let Some(cells) = super::latin_pair_bridge::split_pair(&mask, w, h, body_height) {
            if pair.is_some() {
                return false;
            }
            pair = Some((index, cells));
        }
    }
    let Some((index, [mut left, mut right])) = pair else {
        return false;
    };
    for c in [&mut left, &mut right] {
        c.x0 += body[index].x0;
        c.x1 += body[index].x0;
        c.y0 += body[index].y0;
        c.y1 += body[index].y0;
    }
    let singleton = body.remove(1 - index);
    let singleton_width = singleton.x1 - singleton.x0;
    if singleton_width as u128 * 2 < body_height as u128
        || singleton_width as u128 * 2 > body_height as u128 * 3
    {
        return false;
    }
    let mut views = if index == 0 {
        vec![left, right, singleton]
    } else {
        vec![singleton, left, right]
    };
    if views
        .windows(2)
        .any(|p| p[0].x1 > p[1].x0 || p[1].x0 - p[0].x1 > body_height.div_ceil(4))
    {
        return false;
    }
    if leading {
        views.insert(0, mark);
    } else {
        views.push(mark);
    }
    super::supports_collected(&views, body_height, 4, Some(text))
}

