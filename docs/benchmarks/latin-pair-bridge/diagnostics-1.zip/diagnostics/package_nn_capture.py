from pathlib import Path
from PIL import Image
import json,hashlib,zipfile
r=Path('tmp/latin-pair-policy');out=r/'packet-media';sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 size=(out/(name+'.zip')).stat().st_size;assert size<50*1024*1024
 (out/(name+'.json')).write_text(json.dumps({'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members},indent=2)+'\n')
 print(name,len(members),len(aliases),size,flush=True)
paths={k:[]for k in ['inputs-maru','inputs-gothic','inputs-mincho','inputs-metadata']};audit=[]
for folder,count in [('fresh',19440),('horizontal',636)]:
 f=r/folder
 assert json.loads((f/'30-command.json').read_text())['exit_code']==0
 xs={x['id']:x for x in json.loads((f/'evaluation-manifest.json').read_text())['inputs']}
 cap=json.loads((f/'whole-rgb-capture/inputs.json').read_text())
 assert len(xs)==len(cap['chunks'])==count and cap['model_input_dimensions']==[256,24]
 assert {c['line_id']for c in cap['chunks']}==set(xs)
 paths['inputs-metadata'].append(('data/'+folder+'/whole-rgb-capture/inputs.json',f/'whole-rgb-capture/inputs.json'))
 for c in cap['chunks']:
  x=xs[c['line_id']];p=f/'whole-rgb-capture'/c['image'];im=Image.open(p).convert('RGB')
  assert list(im.size)==c['dimensions']==[x['forward_width'],x['forward_height']]
  assert c['chunk_index']==0 and c['x_range']==[0,x['forward_width']]
  assert im.tobytes()==Path(x['effective_rgb']).read_bytes()
  assert sha(im.tobytes())==x['effective_rgb_sha256']
  paths['inputs-'+x['font']].append(('data/'+folder+'/whole-rgb-capture/'+c['image'],p))
  audit.append({'folder':folder,'id':x['id'],'actual_rgb_sha256':sha(im.tobytes()),'capture_png_sha256':sha(p.read_bytes())})
assert len(audit)==20076
a={'driver_sha256':sha(Path(__file__).read_bytes()),'actual_model30_rgb_captures':20076,'by_orientation':{'auto':19440,'horizontal':636},'all_original_effective_rgb_byte_equal':True,'rows':audit}
(r/'nn-capture-audit.json').write_text(json.dumps(a,indent=2)+'\n')
paths['inputs-metadata'].append(('diagnostics/nn-capture-audit.json',r/'nn-capture-audit.json'))
for name,ps in paths.items():packet(name,ps)
(out/'nn-inputs.json').write_text(json.dumps({'archives':list(paths),'actual_model30_rgb_captures':len(audit),'driver_sha256':sha(Path(__file__).read_bytes())},indent=2)+'\n')
