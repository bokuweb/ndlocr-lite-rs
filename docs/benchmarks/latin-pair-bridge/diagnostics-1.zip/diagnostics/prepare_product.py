from pathlib import Path
import json,hashlib,struct,zipfile,sys,collections
sys.path.insert(0,'tmp/punct-matched');from means import emitted_means
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# All old/new gates must exist before any product manifest can be prepared.
for p in [r/'audit.json',r/'fresh-policy/audit.json',r/'horizontal-policy/audit.json']:
 a=json.loads(p.read_text());assert not a['char_regressions']and not a['word_regressions'],str(p)
assert json.loads((r/'fresh-evaluation-summary.json').read_text())['novel_changed_model_pairs']>0
batches=[(r/'manifest.json',r/'replay/records.json'),(r/'fresh-policy/manifest.json',r/'fresh-policy/replay/records.json'),(r/'horizontal-policy/manifest.json',r/'horizontal-policy/replay/records.json')]
cases=[];seen=set();rgb_hashes={}
for manifest,records in batches:
 refs={(x['corpus'],x['model'],x['id']):x for x in json.loads(records.read_text())}
 for x in json.loads(manifest.read_text())['cases']:
  key=x['corpus'],x['model'],x['id'];assert key not in seen;seen.add(key);y=refs[key];assert x['raw']==y['raw'];p=x['rgb']
  if p not in rgb_hashes:rgb_hashes[p]=sha(p)
  assert rgb_hashes[p]==x['rgb_sha256'];assert y['selected']==(y['baseline']!=y['candidate'])
  cases.append(x|{'orientation':x.get('orientation','auto'),'expected_before':y['baseline'],'expected_after':y['candidate'],'selected':y['selected']})
assert len(cases)==223143
(r/'product-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');by_key={(x['corpus'],x['model'],x['id']):x for x in cases};means={}
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:old=json.loads(z.read('probe.json'))
for m in old['models']:
 for x in m['rows']:means['old',m['label'].removeprefix('single'),x['id']]=x['mean_confidence']
for corpus,folder in [('latin-fresh',r/'fresh'),('latin-horizontal',r/'horizontal')]:
 for model in ['30','50','100']:
  for x in json.loads((folder/(model+'-export.json')).read_text()):means[corpus,model,x['id']]=emitted_means(x)[0]
selected={k for k,x in by_key.items()if x['selected']};matrix=set(selected);cli={k for k in selected if by_key[k]['orientation']=='auto'}
controls=json.loads((r/'fixed-noise-control-selection.json').read_text())
assert len(controls['cases'])==9072
for x in controls['cases']:
 k=x['corpus'],x['model'],x['id'];assert by_key[k]['orientation']==x['orientation']=='auto'and by_key[k]['rgb_sha256']==x['rgb_sha256']
 matrix.add(k);cli.add(k)
native=[]
for k in sorted(matrix):
 x=by_key[k];bits=struct.unpack('<I',struct.pack('<f',means[k]))[0];native.append(x|{'mean_bits':bits})
counts=dict(collections.Counter(x['model']for x in native));meta={'cases':native,'counts':counts,'fixed_control_selection_sha256':sha(r/'fixed-noise-control-selection.json'),'all_changed_model_pairs':len(selected),'control_pairs':9072}
(r/'native-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
cli_cases=[by_key[k]for k in sorted(cli)];assert all(x['orientation']=='auto'for x in cli_cases)
(r/'cli-manifest.json').write_text(json.dumps({'cases':cli_cases,'all_changed_model_pairs':len(selected),'control_pairs':9072},ensure_ascii=False,indent=2)+'\n')
print('223143 frozen candidate pairs;API',len(native),counts,'CLI',len(cli_cases),'changed',len(selected),flush=True)
