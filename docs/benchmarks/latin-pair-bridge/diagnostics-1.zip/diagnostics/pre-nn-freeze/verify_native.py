from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import json,hashlib,subprocess
r=Path('tmp/latin-pair-policy');f=r/'fresh';out=r/'native-rerender';out.mkdir();m=json.loads((f/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();records=[];fonts={x['id']:x for x in m['fonts']};cache={}
for rec in m['native_records']:
 original=Image.open(f/'native'/(rec['id']+'.png')).convert('RGB');trace=json.loads((f/'native'/(rec['id']+'.json')).read_text());font=fonts[rec['font']];assert sha(Path(font['path']).read_bytes())==font['sha256']
 if rec['engine']=='freetype':
  key=font['path'],rec['size']
  if key not in cache:cache[key]=ImageFont.truetype(font['path'],rec['size'],index=0,layout_engine=ImageFont.Layout.BASIC)
  face=cache[key];text=rec['call']['text'];box=face.getbbox(text);assert list(box)==trace['bbox']and list(face.getname())==trace['font_face'];assert face.getlength(text)==trace['length']and trace['prefix_lengths']==[face.getlength(text[:i])for i in range(len(text)+1)]
  for g in trace['glyph_masks']:
   mask=face.getmask(g['character'],mode='L');assert list(mask.size)==g['size']and sha(bytes(mask))==g['mask_sha256']
  a,b,c,d=box;actual=Image.new('RGB',(c-a+16,d-b+16),'white');ImageDraw.Draw(actual).text((8-a,8-b),text,font=face,fill='black');actual.save(out/(rec['id']+'.png'))
 else:
  argv=rec['argv'][:-1]+[str(out/(rec['id']+'.png'))];p=subprocess.run(argv,check=True,capture_output=True);actual=Image.open(argv[-1]).convert('RGB');now=json.loads(p.stdout);assert now==trace;(out/(rec['id']+'.json')).write_bytes(p.stdout+b'\n')
 assert actual.size==original.size and actual.tobytes()==original.tobytes(),rec['id'];records.append({'id':rec['id'],'engine':rec['engine'],'native_rgb_sha256':sha(actual.tobytes()),'font_advance_glyph_and_rgb_verified':True})
assert len(records)==1854;(r/'native-audit.json').write_text(json.dumps({'driver_sha256':sha(Path(__file__).read_bytes()),'native_generation_records':1854,'independent_native_qa_redraws':1854,'records':records},indent=2)+'\n');print('1854 real independent native redraws match original glyph/advance/RGB records',flush=True)
