

製品へ接続する場合は、旧新の候補変更組を全件、Auto/元Horizontalの該当方向で
raw API・既定APIに通し、raw文字列と候補文字列・平均信頼度を凍結値に照合する。
加えて新図形条件はmode/font/size/body/body-space/shape/lead/gap/formatの
各組につきmodelをidのSHA256先頭byte mod3で一意に割り当てた1モデルを全件検査する。
CLIは全変更Auto組と、この図形対照の同じ1モデルを全件検査する。
結果を見てサンプルを選び直さない。API呼出しはraw収集forwardとは別の検証呼出しとして数える。
