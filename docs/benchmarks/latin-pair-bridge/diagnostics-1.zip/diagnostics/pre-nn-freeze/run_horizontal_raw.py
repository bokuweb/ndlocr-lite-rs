from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,os,shutil
r=Path('tmp/latin-pair-policy');f=r/'horizontal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior=json.loads(Path('tmp/punct-proportional/parent-raw-capture.json').read_text());binary=f/'export-binary';shutil.copy2('tmp/punct-width/new/export-binary',binary);assert sha(binary)==prior['binary_sha256'];source=Path('tmp/punct-proportional/whole-roi-source')
for p,s in prior['source_sha256'].items():assert sha(source/p)==s,p
for p,s in prior['models'].items():assert sha(p)==s,p
shutil.copytree(source,f/'export-source');m=json.loads((f/'evaluation-manifest.json').read_text());assert sha(f/'atlas.png')==m['atlas_sha256'];assert sha(f/'lines.json')==m['lines_sha256'];proof='original RGB Horizontal;atlas crop exact verified'
models={'30':'parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','50':'parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx','100':'parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx'};meta={'raw_binary_sha256':sha(binary),'raw_source_capture':prior,'manifest_sha256':sha(f/'evaluation-manifest.json'),'driver_sha256':sha(__file__),'tensor_proof_sha256':sha(f/'evaluation-manifest.json'),'tensor_command_sha256':sha(r/'tensor-command.json')};(f/'raw-command.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(model):
 out=f/(model+'-export.json');argv=[str(binary.resolve()),'--image',str(f/'atlas.png'),'--model','models/'+models[model],'--charset','models/NDLmoji.yaml','--manifest',str(f/'lines.json'),'--output',str(out),'--top-k','2','--whole-roi']
 if model=='30':argv+=['--chunk-input-dir',str(f/'whole-rgb-capture')]
 record={'argv':argv,'env':{'NDLOCR_INTRA_THREADS':'1'}};cmd=f/(model+'-command.json');cmd.write_text(json.dumps(record,indent=2)+'\n');p=subprocess.run(argv,capture_output=True,env=os.environ|record['env']);(f/(model+'.stdout')).write_bytes(p.stdout);(f/(model+'.stderr')).write_bytes(p.stderr);record['exit_code']=p.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert p.returncode==0,p.stderr
 rows=json.loads(out.read_text());assert len(rows)==636;assert {x['id']for x in rows}=={x['id']for x in m['inputs']};assert all(len(x['chunks'])==1 for x in rows);return model
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:print('completed',list(pool.map(run,models)),flush=True)
