from pathlib import Path
from PIL import Image
import json,hashlib,shutil,subprocess,sys,os,csv
sys.path.insert(0,'tmp/punct-matched');from means import emitted_means
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();folder=sys.argv[1];assert folder in ['fresh','horizontal'];f=r/folder;out=r/(folder+'-policy');out.mkdir();m=json.loads((f/'evaluation-manifest.json').read_text());xs={x['id']:x for x in m['inputs']};n=len(xs);assert n==(19440 if folder=='fresh'else 636);cap=json.loads((f/'whole-rgb-capture/inputs.json').read_text());assert cap['model_input_dimensions']==[256,24]and len(cap['chunks'])==n
for c in cap['chunks']:
 x=xs[c['line_id']];im=Image.open(f/'whole-rgb-capture'/c['image']).convert('RGB');assert list(im.size)==c['dimensions']==[x['forward_width'],x['forward_height']];assert c['chunk_index']==0 and c['x_range']==[0,x['forward_width']];assert hashlib.sha256(im.tobytes()).hexdigest()==x['effective_rgb_sha256']
cases=[];means=[]
for model in ['30','50','100']:
 assert json.loads((f/(model+'-command.json')).read_text())['exit_code']==0;rows=json.loads((f/(model+'-export.json')).read_text());assert len(rows)==n and {x['id']for x in rows}==set(xs)
 for row in rows:
  x=xs[row['id']];assert len(row['chunks'])==1 and row['bounds']==x['bounds'];c=row['chunks'][0];assert c['x_range']==[0,x['forward_width']]and c['text']==row['text']and not c['inserted_space_before'];assert sha(x['rgb'])==x['rgb_sha256']and sha(x['truth'])==x['truth_sha256'];cases.append({'corpus':'latin-'+folder,'model':model,'id':x['id'],'raw':row['text'],'rgb':x['rgb'],'rgb_sha256':x['rgb_sha256'],'width':x['width'],'height':x['height'],'truth':Path(x['truth']).read_text(),'expected_baseline':None}|({'orientation':'horizontal'}if folder=='horizontal'else{}));means.append({'model':model,'id':x['id'],'mean_confidence':emitted_means(row)[0]})
(out/'existing-manifest.json').write_text(json.dumps({'cases':cases,'expected_cases':3*n},ensure_ascii=False,indent=2)+'\n');(out/'raw-means.json').write_text(json.dumps(means,indent=2)+'\n')
meta={'driver_sha256':sha(__file__),'manifest_sha256':sha(out/'existing-manifest.json'),'raw_means_sha256':sha(out/'raw-means.json'),'actual_rgb_captures_verified':n,'binaries':{}};(out/'freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,binary,record,test,env):
 rec=json.loads(Path(record).read_text());assert sha(binary)==rec['binary_sha256'];dest=out/(name+'-binary');shutil.copy2(binary,dest);cmd={'binary_sha256':sha(dest),'source_record_sha256':sha(record),'argv':[str(dest.resolve()),test,'--exact','--ignored','--nocapture'],'env':env};p=out/(name+'-command.json');p.write_text(json.dumps(cmd,indent=2)+'\n')
 with(out/(name+'.stdout')).open('wb')as a,(out/(name+'.stderr')).open('wb')as b:d=subprocess.run(cmd['argv'],env=os.environ|env,stdout=a,stderr=b)
 cmd['exit_code']=d.returncode;p.write_text(json.dumps(cmd,indent=2)+'\n');assert d.returncode==0,name
run('baseline','tmp/narrow-round-profile/verification-binary','tmp/narrow-round-profile/verification-command.json','infer::visible_repetitions::single_pixel_bridge::tests::record_existing_bridge_policy',{'NDLOCR_BRIDGE_ROOT':str(out)})
rs={(x['model'],x['id']):x for x in json.loads((out/'existing-replay/records.json').read_text())};assert len(rs)==3*n
for x in cases:
 y=rs[x['model'],x['id']];assert y['raw']==x['raw']and y['baseline']==y['candidate'];x['expected_after']=y['baseline']
(out/'manifest.json').write_text(json.dumps({'cases':cases,'expected_cases':3*n},ensure_ascii=False,indent=2)+'\n')
run('candidate','tmp/latin-pair-policy/tensor-binary','tmp/latin-pair-policy/tensor-command.json','infer::visible_repetitions::latin_pair_policy::tests::record_latin_pair_policy',{'NDLOCR_LATIN_PAIR_POLICY_ROOT':str(out)})
records=json.loads((out/'replay/records.json').read_text());assert len(records)==3*n;scorer=Path('tools/eval_ocr_metrics.py');audit={'summary':[],'changes':[],'char_regressions':[],'word_regressions':[],'scorer_sha256':sha(scorer),'driver_sha256':sha(__file__)}
groups={'all':list(xs),'seen':[k for k,x in xs.items()if x['seen_before_162915']],'unseen':[k for k,x in xs.items()if not x['seen_before_162915']],'text':[k for k,x in xs.items()if x['kind']=='text'],'noise':[k for k,x in xs.items()if x['kind']=='noise']}
for mode in sorted({x['engine']+('-p'+str(x['palt'])) for x in xs.values()}):
 groups[mode]=[k for k,x in xs.items() if x['engine']+('-p'+str(x['palt']))==mode]
for field in ['body','body_spaces','size','font']:
 for value in sorted({x[field]for x in xs.values()}):
  groups[field+'-'+str(value)]=[k for k,x in xs.items()if x[field]==value]
for shape in sorted({x['shape']for x in xs.values()if x['kind']=='noise'}):
 groups['noise-'+shape]=[k for k,x in xs.items()if x.get('shape')==shape]

for group,ids in groups.items():
 if not ids:continue
 truth=out/'truth'/group;truth.mkdir(parents=True)
 for id in ids:(truth/(id+'.txt')).write_bytes(Path(xs[id]['truth']).read_bytes())
 for model in ['30','50','100']:
  paths={}
  for phase in ['baseline','candidate']:
   p=out/'subsets'/group/model/phase;p.mkdir(parents=True)
   for id in ids:os.link(out/'replay'/('latin-'+folder)/model/phase/(id+'.txt'),p/(id+'.txt'))
   paths[phase]=p
  for norm in ['none','width','strict']:
   p=out/'scores'/group;p.mkdir(parents=True,exist_ok=True);table=p/(model+'-'+norm+'.csv');report=table.with_suffix('.md');subprocess.run([sys.executable,str(scorer),'--truth-dir',str(truth),'--system','baseline='+str(paths['baseline']),'--system','candidate='+str(paths['candidate']),'--normalize',norm,'--require-all','--output-csv',str(table),'--output-md',str(report)],check=True,capture_output=True);table.write_bytes(table.read_bytes().replace(b'\r\n',b'\n'));report.write_bytes((report.read_text().rstrip()+'\n').encode());rows=list(csv.DictReader(table.open()));b={x['file']:x for x in rows if x['system']=='baseline'};a={x['file']:x for x in rows if x['system']=='candidate'};assert len(a)==len(b)==len(ids);stat={'group':group,'model':model,'normalization':norm,'images':len(ids),'changes':0,'char_improvements':0,'word_improvements':0,'exact_improvements':0}
   for id in b:
    bc,ac=int(b[id]['char_errors']),int(a[id]['char_errors']);bw,aw=int(b[id]['word_errors']),int(a[id]['word_errors']);changed=(paths['baseline']/id).read_bytes()!=(paths['candidate']/id).read_bytes();stat['changes']+=changed;stat['char_improvements']+=ac<bc;stat['word_improvements']+=aw<bw;stat['exact_improvements']+=bc>0 and ac==0
    if changed:audit['changes'].append([group,model,norm,id,bc,ac,bw,aw])
    if ac>bc:audit['char_regressions'].append([group,model,norm,id,bc,ac])
    if aw>bw:audit['word_regressions'].append([group,model,norm,id,bw,aw])
   audit['summary'].append(stat)
(out/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(folder,'actual model-pairs',3*n,'changes',sum(x['selected']for x in records),'char/word regressions',len(audit['char_regressions']),len(audit['word_regressions']),flush=True)

assert not audit['char_regressions'] and not audit['word_regressions'], 'Rejected fixed proposal: retain all evidence and do not tune on outcomes'
