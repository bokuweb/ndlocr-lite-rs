from pathlib import Path
r=Path('tmp/latin-pair-policy')
s=Path('tmp/narrow-round-profile/evaluate.py').read_text()
s=s.replace("r=Path('tmp/narrow-round-profile')","r=Path('tmp/latin-pair-policy')")
s=s.replace('8064','19440').replace('else 244','else 636').replace('narrow-','latin-').replace('seen_before_137991','seen_before_162915')
s=s.replace('tmp/owned-parts-bridge/freetype/verification-binary','tmp/narrow-round-profile/verification-binary').replace('tmp/owned-parts-bridge/freetype/verification-command.json','tmp/narrow-round-profile/verification-command.json')
s=s.replace('tmp/narrow-round-profile/tensor-binary','tmp/latin-pair-policy/tensor-binary').replace('tmp/narrow-round-profile/tensor-command.json','tmp/latin-pair-policy/tensor-command.json')
s=s.replace('infer::visible_repetitions::narrow_round_marker::tests::record_narrow_round_policy','infer::visible_repetitions::latin_pair_policy::tests::record_latin_pair_policy').replace('NDLOCR_NARROW_ROUND_ROOT','NDLOCR_LATIN_PAIR_POLICY_ROOT')
at=s.index('\nfor group,ids in groups.items():')
s=s[:at]+"""
for field in ['body','body_spaces','size','font']:
 for value in sorted({x[field]for x in xs.values()}):
  groups[field+'-'+str(value)]=[k for k,x in xs.items()if x[field]==value]
for shape in sorted({x['shape']for x in xs.values()if x['kind']=='noise'}):
 groups['noise-'+shape]=[k for k,x in xs.items()if x.get('shape')==shape]
""" +s[at:]
# Keep the immutable scorer and all per-input output strings. No aggregate-only gate.
s += """
assert not audit['char_regressions'] and not audit['word_regressions'], 'Rejected fixed proposal: retain all evidence and do not tune on outcomes'
"""
s=s.replace('tmp/latin-round-profile/tensor-', 'tmp/latin-pair-policy/tensor-')
(r/'evaluate.py').write_text(s)
