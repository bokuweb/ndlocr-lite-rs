from pathlib import Path
import json,hashlib,shutil
from PIL import Image
r=Path('tmp/latin-pair-policy');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
t=json.loads((r/'tensor-command.json').read_text());assert t['exit_code']==0
for p,s in t['source_sha256'].items():assert sha(r/'tensor-source'/p)==s,p
assert sha(r/'tensor-binary')==t['binary_sha256']
a=json.loads((r/'audit.json').read_text());assert not a['char_regressions'] and not a['word_regressions']
assert json.loads((r/'geometry/result.json').read_text())['novel_rgb_geometry_changes']>0
assert json.loads((r/'fresh/tensor-proof.json').read_text())['all_original_auto_and_effective_horizontal_tensors_bit_equal']
q=json.loads((r/'fresh-pixel-audit.json').read_text());assert q['inputs']==19440 and not q['internal_truth_conflicts']
n=json.loads((r/'native-audit.json').read_text());assert len(n['records'])==1854 and n['independent_native_qa_redraws']==1854
assert all(x['font_advance_glyph_and_rgb_verified'] for x in n['records'])
for folder,count in [('fresh',19440),('horizontal',636)]:
 f=r/folder;m=json.loads((f/'evaluation-manifest.json').read_text());assert len(m['inputs'])==count
 assert sha(f/'atlas.png')==m['atlas_sha256'] and sha(f/'lines.json')==m['lines_sha256'];atlas=Image.open(f/'atlas.png').convert('RGB')
 for x in m['inputs']:
  assert sha(x['rgb'])==x['rgb_sha256'] and sha(x['effective_rgb'])==x['effective_rgb_sha256']
  assert atlas.crop(tuple(x['bounds'])).tobytes()==Path(x['effective_rgb']).read_bytes()
noise=json.loads((r/'noise-pixel-audit.json').read_text())
assert noise['pre_jpeg_pairs']==4536 and noise['all_source_body_nonwhite_pixels_preserved'] and noise['all_shape_glyph_overlap_counts_zero'] and noise['all_png_reconstructions_byte_equal']
visual=json.loads((r/'visual-audit.json').read_text());assert visual['sample_count']==108 and visual['viewed_all_three_sheets']
assert json.loads((r/'geometry/freeze.json').read_text())['binaries']['baseline']['binary_sha256']==json.loads(Path('tmp/narrow-round-profile/verification-command.json').read_text())['binary_sha256']
assert Path('src/infer/visible_repetitions/latin_pair_policy.rs').read_bytes().split(b'#[cfg(test)]')[0]==(r/'frozen-policy-source.rs').read_bytes()
files=['run_fresh_raw.py','run_horizontal_raw.py','freeze_raw.py','policy-lock.json','tensor-command.json','audit.json','geometry/freeze.json','geometry/result.json','fresh/tensor-proof.json','fresh-pixel-audit.json','noise-pixel-audit.json','native-audit.json','visual-audit.json','capture-controls-spec.md','fresh/evaluation-manifest.json','horizontal/evaluation-manifest.json','prepare_horizontal.py','test_horizontal.py','visual-audit.json','native-audit.json','fresh/contact.json','graphics.py','verify_noise.py','verify_native.py','verify_fresh.py','prepare_fresh.py','fresh-generation-lock.json','api-cli-selection-spec.md','evaluate.py','adapt_evaluate.py','score.py','frozen-policy-source.rs']
out=r/'pre-nn-freeze';out.mkdir()
files=list(dict.fromkeys(files))
for p in files:
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,dest)
record={'files_sha256':{p:sha(r/p) for p in files},'new_raw_forwards':60228,'fresh_condition_inputs':19440,'horizontal_condition_inputs':636,'models':3,'production_candidate_connected':False,'all_pre_nn_gates_passed':True,'current_controls_spec_sha256':sha('docs/latin_pair_bridge_controls.md'),'api_cli_selection_spec_sha256':sha(r/'api-cli-selection-spec.md')};(r/'pre-nn-freeze.json').write_text(json.dumps(record,indent=2)+'\n');print('All pre-NN gates passed; immutable scripts/QA copied')
