from pathlib import Path
from PIL import Image, ImageChops
import hashlib, json, shutil, subprocess
from renderer_ft import draw_basic
from graphics import crop_white, compose_noise

r = Path('tmp/latin-pair-policy')
out = r / 'fresh'
out.mkdir()
for name in ['native', 'original', 'png', 'rgb', 'effective', 'truth']:
    (out / name).mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
old_ct = json.loads(Path('tmp/owned-parts-bridge/fresh/evaluation-manifest.json').read_text())
assert sha(Path('tmp/owned-parts-bridge/render').read_bytes()) == old_ct['renderer_binary_sha256']
assert sha(Path('tmp/owned-parts-bridge/render.swift').read_bytes()) == old_ct['renderer_source_sha256']
shutil.copy2('tmp/owned-parts-bridge/render', r / 'render')
shutil.copy2('tmp/owned-parts-bridge/render.swift', r / 'render.swift')
shutil.copy2('docs/latin_pair_bridge_controls.md', r / 'capture-controls-spec.md')
fonts = json.loads(Path('tmp/owned-parts-bridge/freetype/fresh/evaluation-manifest.json').read_text())['fonts']
prior = {}
for row in json.loads((r / 'manifest.json').read_text())['cases']:
    key = row['width'], row['height'], row['rgb_sha256']
    prior.setdefault(key, []).append({k: row.get(k) for k in ['corpus', 'model', 'id', 'orientation', 'truth']})
assert json.loads((r / 'summary.json').read_text())['char_regressions'] == 0
assert json.loads((r / 'summary.json').read_text())['word_regressions'] == 0
sources = [Path(__file__), r / 'adapt_generator.py', r / 'renderer_ft.py', r / 'graphics.py',
           r / 'render.swift', r / 'render', r / 'capture-controls-spec.md', r / 'policy-lock.json',
           r / 'probe-command.json', r / 'manifest.json', r / 'summary.json']
snapshot = r / 'fresh-generation-source'
snapshot.mkdir()
for path in sources:
    shutil.copy2(path, snapshot / path.name)
(r / 'fresh-generation-lock.json').write_text(json.dumps({
    'source_sha256': {str(p): sha(p.read_bytes()) for p in sources},
    'fonts': fonts, 'expected_conditions': 19440, 'expected_native_draws': 1854,
    'new_nn_before_generation': 0
}, ensure_ascii=False, indent=2) + '\n')

rows, records = [], []
bodies = ['KLM', 'XYZ', 'MLK', 'WM', 'VVM', 'qjp']
closers = [')', chr(0xff09)]
shapes = ['none', 'thin', 'bar', 'dot', 'diagonal', 'chevron', 'left_curve', 'fork_inner', 'fork_outer']


def draw_native(engine, palt, font, size, text, key):
    png = out / 'native' / (key + '.png')
    trace_path = png.with_suffix('.json')
    if engine == 'freetype':
        image, trace = draw_basic(font, size, text)
        image.save(png)
        trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=2) + '\n')
        call = {'call': {'font': font, 'size': size, 'text': text}, 'completed': True}
    else:
        argv = [str(r / 'render'), font['path'], str(size), str(palt), text, str(png)]
        process = subprocess.run(argv, capture_output=True, check=True)
        trace = json.loads(process.stdout)
        assert Path(trace['font_file']).samefile(font['path'])
        for run in trace['runs']:
            assert Path(run['font_file']).samefile(font['path'])
            assert run['font'] == trace['font'] and 0 not in run['glyphs']
        assert sorted(i for run in trace['runs'] for i in run['string_indices']) == list(range(len(text)))
        trace_path.write_bytes(process.stdout + b'\n')
        call = {'argv': argv, 'exit_code': process.returncode}
        image = Image.open(png).convert('RGB')
    cropped = crop_white(image)
    box = ImageChops.difference(image, Image.new('RGB', image.size, 'white')).getbbox()
    assert image.crop(box).tobytes() == cropped.crop((2, 2, cropped.width - 2, cropped.height - 2)).tobytes()
    records.append({'id': key, 'engine': engine, 'palt': palt, 'font': font['id'], 'size': size,
                    'png_sha256': sha(png.read_bytes()), 'trace_sha256': sha(trace_path.read_bytes()),
                    'native_dimensions': list(image.size), 'native_ink_bbox': list(box),
                    'cropped_dimensions': list(cropped.size), 'cropped_rgb_sha256': sha(cropped.tobytes())} | call)
    return cropped


def save(image, truth, key, metadata):
    pre_codec = sha(image.tobytes())
    for fmt in ['png', 'jpeg75']:
        id = key + '_' + fmt
        original = out / 'original' / (id + ('.png' if fmt == 'png' else '.jpg'))
        image.save(original, **({} if fmt == 'png' else {'quality': 75, 'subsampling': 2}))
        decoded = Image.open(original).convert('RGB')
        canonical = out / 'png' / (id + '.png')
        decoded.save(canonical)
        rgb = out / 'rgb' / (id + '.rgb')
        rgb.write_bytes(decoded.tobytes())
        gt = out / 'truth' / (id + '.txt')
        gt.write_text(truth)
        rotated = 5 * decoded.height > 4 * decoded.width
        effective = decoded.transpose(Image.Transpose.ROTATE_90) if rotated else decoded
        fp = out / 'effective' / (id + '.rgb')
        fp.write_bytes(effective.tobytes())
        matches = prior.get((decoded.width, decoded.height, sha(decoded.tobytes())), [])
        conflicts = [x for x in matches if x['truth'] != truth]
        if conflicts:
            (out / 'truth-conflicts.json').write_text(json.dumps({'id': id, 'truth': truth, 'prior_matches': conflicts}, ensure_ascii=False, indent=2) + '\n')
            raise ValueError('identical prior RGB has different truth: ' + id)
        row = metadata | {'id': id, 'format': fmt, 'width': decoded.width, 'height': decoded.height,
                          'rotated_for_auto': rotated, 'forward_width': effective.width, 'forward_height': effective.height,
                          'pre_codec_rgb_sha256': pre_codec, 'seen_before_162915': bool(matches), 'prior_rgb_matches': matches}
        for name, path in [('original', original), ('image', canonical), ('rgb', rgb), ('effective_rgb', fp), ('truth', gt)]:
            row[name] = str(path)
            row[name + '_sha256'] = sha(path.read_bytes())
        if fmt == 'png':
            assert sha(decoded.tobytes()) == pre_codec
        rows.append(row)


for engine, palt in [('freetype', None), ('coretext', 0), ('coretext', 1)]:
    for font in fonts:
        assert sha(Path(font['path']).read_bytes()) == font['sha256']
        for size in [24, 40]:
            for body_id, unspaced in enumerate(bodies):
                for body_spaces in [0, 1]:
                    body = (' ' * body_spaces).join(unspaced)
                    prefix = f'r_{engine}_p{palt}_b{body_id}_{font["id"]}_{size}_bs{body_spaces}'
                    common = {'engine': engine, 'palt': palt, 'font': font['id'], 'size': size,
                              'body_id': body_id, 'body': unspaced, 'body_spaces': body_spaces}
                    for ci, closer in enumerate(closers):
                        for leading in [False, True]:
                            for spaces in [0, 1]:
                                text = closer + ' ' * spaces + body if leading else body + ' ' * spaces + closer
                                native_id = prefix + f'_c{ci}_lead{int(leading)}_sp{spaces}'
                                roi = draw_native(engine, palt, font, size, text, native_id)
                                for paper in [0, 2, 10]:
                                    padded = Image.new('RGB', (roi.width, roi.height + 2 * paper), 'white')
                                    padded.paste(roi, (0, paper))
                                    save(padded, text, native_id + f'_paper{paper}', common | {'kind': 'text', 'native_id': native_id,
                                         'closer': closer, 'leading': leading, 'spaces': spaces, 'paper': paper})
                    if body_spaces and unspaced != 'WM':
                        continue
                    native_id = prefix + '_bare'
                    native = draw_native(engine, palt, font, size, body, native_id)
                    for shape in shapes:
                        for leading in [False, True]:
                            for gap in [0, 1]:
                                image, geometry = compose_noise(native, shape, leading, gap)
                                save(image, body, prefix + f'_noise{shape}_lead{int(leading)}_gap{gap}', common |
                                     {'kind': 'noise', 'native_id': native_id, 'shape': shape,
                                      'leading': leading, 'gap': gap} | geometry)

assert len(rows) == 19440 and len(records) == 1854
x = y = row_height = maximum_width = 0
tiles = []
for row in rows:
    tile = Image.frombytes('RGB', (row['forward_width'], row['forward_height']), Path(row['effective_rgb']).read_bytes())
    if x and x + tile.width > 4096:
        y += row_height + 4
        x = row_height = 0
    row['bounds'] = [x, y, x + tile.width, y + tile.height]
    tiles.append(tile)
    x += tile.width + 4
    row_height = max(row_height, tile.height)
    maximum_width = max(maximum_width, x)
atlas = Image.new('RGB', (maximum_width, y + row_height), 'white')
for row, tile in zip(rows, tiles):
    atlas.paste(tile, (row['bounds'][0], row['bounds'][1]))
atlas.save(out / 'atlas.png')
(out / 'lines.json').write_text(json.dumps([{'id': row['id'], 'bounds': row['bounds']} for row in rows], indent=2) + '\n')
manifest = {'inputs': rows, 'fonts': fonts, 'native_records': records,
            'source_sha256': {str(p): sha(p.read_bytes()) for p in [Path(__file__), r / 'renderer_ft.py', r / 'graphics.py', r / 'render.swift']},
            'renderer_binary_sha256': sha((r / 'render').read_bytes()), 'spec_sha256': sha((r / 'capture-controls-spec.md').read_bytes()),
            'atlas_sha256': sha((out / 'atlas.png').read_bytes()), 'lines_sha256': sha((out / 'lines.json').read_bytes())}
(out / 'evaluation-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print('19440 mixed-mode controls;1854 real native draws;rotated', sum(row['rotated_for_auto'] for row in rows),
      'seen', sum(row['seen_before_162915'] for row in rows), 'atlas', atlas.size, flush=True)
