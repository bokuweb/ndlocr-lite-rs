from pathlib import Path
import json,hashlib,zipfile
r=Path('tmp/latin-pair-policy');out=r/'packet-media';out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 size=(out/(name+'.zip')).stat().st_size
 (out/(name+'.json')).write_text(json.dumps({'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members},indent=2)+'\n')
 print(name,len(members),len(aliases),size,flush=True);assert size<50*1024*1024
paths={k:[]for k in ['native','originals','decoded','pixels-maru','pixels-gothic','pixels-mincho','pixels-atlases']}
for folder in ['fresh','horizontal']:
 f=r/folder
 font_by_id={x['id']:x['font']for x in json.loads((f/'evaluation-manifest.json').read_text())['inputs']}
 for name in ['native','original','png','rgb','effective','truth']:
  group={'native':'native','original':'originals','png':'decoded','rgb':'pixels','effective':'pixels','truth':'native'}[name]
  for p in(f/name).rglob('*'):
   if p.is_file():paths['pixels-'+font_by_id[p.stem]if group=='pixels'else group].append(('data/'+folder+'/'+str(p.relative_to(f)),p))
 for p in f.iterdir():
  if p.is_file()and(p.name in ['atlas.png','lines.json','evaluation-manifest.json','tensor-proof.json','contact.json']or p.name.startswith('contact-')and p.suffix=='.png'):
   paths['pixels-atlases'if p.name=='atlas.png'else'native'].append(('data/'+folder+'/'+p.name,p))
for name,ps in paths.items():packet(name,ps)
(out/'static-media.json').write_text(json.dumps({'archives':list(paths),'driver_sha256':sha(Path(__file__).read_bytes()),'includes_nn_capture':False},indent=2)+'\n')
