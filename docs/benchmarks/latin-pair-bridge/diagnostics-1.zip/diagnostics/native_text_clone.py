from pathlib import Path
import ctypes,hashlib,os,shutil
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib',use_errno=True)
lib.clonefile.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint32]
lib.clonefile.restype=ctypes.c_int
def digest(b):return hashlib.sha256(b).hexdigest()
def dedup(files,store,progress=lambda done,total:None):
 files=[Path(p)for p in files];store=Path(store)
 for p in files:
  if p.suffix!='.txt'or p.is_symlink()or not p.is_file():raise ValueError('only regular generated txt allowed: '+str(p))
 store.mkdir(parents=True,exist_ok=True);rows=[];checked=set()
 for p in files:
  before=p.read_bytes();h=digest(before);st=p.stat();canonical=store/(h+'.txt')
  if not canonical.exists():shutil.copy2(p,canonical)
  if h not in checked:assert not canonical.is_symlink()and digest(canonical.read_bytes())==h;checked.add(h)
  temp=p.with_name(p.name+'.cow-'+str(os.getpid()))
  assert not temp.exists()
  try:
   if lib.clonefile(os.fsencode(canonical),os.fsencode(temp),0)!=0:
    errno=ctypes.get_errno();raise OSError(errno,os.strerror(errno),str(temp))
   assert temp.stat().st_ino!=canonical.stat().st_ino
   assert temp.read_bytes()==before and p.read_bytes()==before
   temp.chmod(st.st_mode&0o7777);os.utime(temp,ns=(st.st_atime_ns,st.st_mtime_ns));os.replace(temp,p)
   assert p.read_bytes()==before
   rows.append({'path':str(p),'canonical':str(canonical),'sha256':h,'size':len(before),'permission':st.st_mode&0o7777,'source_bytes_unchanged':True})
  finally:
   if temp.exists():temp.unlink()
  if len(rows)%10000==0:progress(len(rows),len(files))
 return rows
