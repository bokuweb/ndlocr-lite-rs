# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `144`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 144 | 0 | 0.6620 | 1.0000 |
| candidate | 144 | 0 | 0.6620 | 1.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
