# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `628`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 628 | 0 | 0.7285 | 0.9593 |
| candidate | 628 | 0 | 0.7285 | 0.9593 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
