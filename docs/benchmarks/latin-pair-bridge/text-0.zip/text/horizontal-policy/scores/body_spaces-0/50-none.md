# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `628`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 628 | 0 | 0.6587 | 0.9826 |
| candidate | 628 | 0 | 0.6587 | 0.9826 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
