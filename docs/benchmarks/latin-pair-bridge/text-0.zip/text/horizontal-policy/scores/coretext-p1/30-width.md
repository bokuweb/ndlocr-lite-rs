# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `214`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 214 | 0 | 0.6331 | 0.9421 |
| candidate | 214 | 0 | 0.6331 | 0.9421 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
