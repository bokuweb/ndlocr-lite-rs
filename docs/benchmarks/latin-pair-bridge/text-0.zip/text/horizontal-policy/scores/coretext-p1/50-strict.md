# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `214`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 214 | 0 | 0.6033 | 0.9019 |
| candidate | 214 | 0 | 0.6033 | 0.9019 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
