# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `226`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 226 | 0 | 0.6104 | 0.9444 |
| candidate | 226 | 0 | 0.6104 | 0.9444 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
