# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `4`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 4 | 0 | 0.1875 | 0.5000 |
| candidate | 4 | 0 | 0.1875 | 0.5000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
