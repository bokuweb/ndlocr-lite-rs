# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `580`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 580 | 0 | 0.6546 | 0.9726 |
| candidate | 580 | 0 | 0.6546 | 0.9726 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
