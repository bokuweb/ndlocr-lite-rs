# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `196`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 196 | 0 | 0.7328 | 0.9817 |
| candidate | 196 | 0 | 0.7328 | 0.9817 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
