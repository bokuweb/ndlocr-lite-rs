# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `196`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 196 | 0 | 0.6567 | 0.9388 |
| candidate | 196 | 0 | 0.6567 | 0.9388 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
