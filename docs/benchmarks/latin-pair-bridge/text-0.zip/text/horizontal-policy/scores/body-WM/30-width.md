# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `52`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 52 | 0 | 0.2949 | 0.5769 |
| candidate | 52 | 0 | 0.2949 | 0.5769 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
