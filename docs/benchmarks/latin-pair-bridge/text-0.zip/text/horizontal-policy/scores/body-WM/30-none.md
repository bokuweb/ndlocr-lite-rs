# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `52`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 52 | 0 | 0.3718 | 0.8077 |
| candidate | 52 | 0 | 0.3718 | 0.8077 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
