# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `636`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 636 | 0 | 0.6571 | 0.9831 |
| candidate | 636 | 0 | 0.6571 | 0.9831 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
