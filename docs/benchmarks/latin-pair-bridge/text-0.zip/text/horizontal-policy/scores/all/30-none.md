# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `636`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 636 | 0 | 0.6387 | 0.9691 |
| candidate | 636 | 0 | 0.6387 | 0.9691 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
