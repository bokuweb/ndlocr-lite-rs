# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `252`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 252 | 0 | 0.5025 | 0.8056 |
| candidate | 252 | 0 | 0.5025 | 0.8056 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
