# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `252`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 252 | 0 | 0.5552 | 0.9451 |
| candidate | 252 | 0 | 0.5552 | 0.9451 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
