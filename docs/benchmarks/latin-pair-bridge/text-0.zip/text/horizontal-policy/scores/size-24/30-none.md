# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `408`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 408 | 0 | 0.6354 | 0.9545 |
| candidate | 408 | 0 | 0.6354 | 0.9545 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
