# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `122`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 122 | 0 | 0.5628 | 0.9437 |
| candidate | 122 | 0 | 0.5628 | 0.9437 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
