# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `122`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 122 | 0 | 0.6640 | 0.8934 |
| candidate | 122 | 0 | 0.6640 | 0.8934 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
