# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `40`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 40 | 0 | 0.6917 | 0.9000 |
| candidate | 40 | 0 | 0.6917 | 0.9000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
