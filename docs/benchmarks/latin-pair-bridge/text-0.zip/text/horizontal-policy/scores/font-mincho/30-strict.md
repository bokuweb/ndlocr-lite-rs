# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `236`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 236 | 0 | 0.5765 | 0.9576 |
| candidate | 236 | 0 | 0.5765 | 0.9576 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
