# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `6480`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 6480 | 0 | 0.3149 | 0.6552 |
| candidate | 6480 | 0 | 0.3149 | 0.6552 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
