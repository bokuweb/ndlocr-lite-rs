# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `3024`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3024 | 0 | 0.4804 | 0.7705 |
| baseline | 3024 | 0 | 0.4808 | 0.7714 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
