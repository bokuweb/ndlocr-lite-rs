# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `3024`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 3024 | 0 | 0.3434 | 0.6564 |
| candidate | 3024 | 0 | 0.3434 | 0.6564 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
