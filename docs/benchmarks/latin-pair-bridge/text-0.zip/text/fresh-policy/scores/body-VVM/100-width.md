# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `3024`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3024 | 0 | 0.3141 | 0.7646 |
| baseline | 3024 | 0 | 0.3159 | 0.7689 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
