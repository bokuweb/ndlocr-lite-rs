# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `9720`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 9720 | 0 | 0.3660 | 0.7333 |
| baseline | 9720 | 0 | 0.3669 | 0.7355 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
