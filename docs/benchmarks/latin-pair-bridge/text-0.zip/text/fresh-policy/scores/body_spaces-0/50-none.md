# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `12960`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 12960 | 0 | 0.3119 | 0.5847 |
| baseline | 12960 | 0 | 0.3125 | 0.5865 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
