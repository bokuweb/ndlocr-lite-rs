# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `9072`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 9072 | 0 | 0.1960 | 0.2914 |
| candidate | 9072 | 0 | 0.1960 | 0.2914 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
