# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1008`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 1008 | 0 | 0.1278 | 0.1875 |
| candidate | 1008 | 0 | 0.1278 | 0.1875 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
