# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `4320`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 4320 | 0 | 0.2218 | 0.4639 |
| candidate | 4320 | 0 | 0.2218 | 0.4639 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
