# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `9720`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 9720 | 0 | 0.2179 | 0.4532 |
| candidate | 9720 | 0 | 0.2179 | 0.4532 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
