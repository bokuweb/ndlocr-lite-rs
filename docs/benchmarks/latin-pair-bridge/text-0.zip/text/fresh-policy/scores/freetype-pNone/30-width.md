# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `6480`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 6480 | 0 | 0.3352 | 0.6851 |
| baseline | 6480 | 0 | 0.3360 | 0.6869 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
