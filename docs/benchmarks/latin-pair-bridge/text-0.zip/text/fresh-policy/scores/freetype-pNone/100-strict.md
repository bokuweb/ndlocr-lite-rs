# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `6480`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 6480 | 0 | 0.2095 | 0.4256 |
| candidate | 6480 | 0 | 0.2095 | 0.4256 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
