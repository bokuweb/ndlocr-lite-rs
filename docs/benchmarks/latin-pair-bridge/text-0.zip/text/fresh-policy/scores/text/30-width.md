# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `10368`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 10368 | 0 | 0.3808 | 0.7843 |
| baseline | 10368 | 0 | 0.3812 | 0.7852 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
