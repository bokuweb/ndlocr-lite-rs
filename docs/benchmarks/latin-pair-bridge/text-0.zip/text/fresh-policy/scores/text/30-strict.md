# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `10368`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 10368 | 0 | 0.2508 | 0.6029 |
| candidate | 10368 | 0 | 0.2508 | 0.6029 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
