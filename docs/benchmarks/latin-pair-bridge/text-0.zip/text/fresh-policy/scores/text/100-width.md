# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `10368`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 10368 | 0 | 0.3676 | 0.8090 |
| baseline | 10368 | 0 | 0.3685 | 0.8108 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
