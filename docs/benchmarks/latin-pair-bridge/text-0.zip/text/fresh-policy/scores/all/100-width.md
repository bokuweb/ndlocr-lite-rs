# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `19440`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 19440 | 0 | 0.3296 | 0.6917 |
| baseline | 19440 | 0 | 0.3302 | 0.6930 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
