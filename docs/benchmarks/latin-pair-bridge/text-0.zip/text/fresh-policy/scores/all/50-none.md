# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `19440`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 19440 | 0 | 0.3304 | 0.6129 |
| baseline | 19440 | 0 | 0.3307 | 0.6137 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
