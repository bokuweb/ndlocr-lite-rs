# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `19440`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 19440 | 0 | 0.2280 | 0.4576 |
| candidate | 19440 | 0 | 0.2280 | 0.4576 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
