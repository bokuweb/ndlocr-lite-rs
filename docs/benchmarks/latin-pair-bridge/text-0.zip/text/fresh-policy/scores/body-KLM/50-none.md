# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `3024`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3024 | 0 | 0.2263 | 0.5653 |
| baseline | 3024 | 0 | 0.2272 | 0.5675 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
