# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1008`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 1008 | 0 | 0.1202 | 0.2321 |
| candidate | 1008 | 0 | 0.1202 | 0.2321 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
