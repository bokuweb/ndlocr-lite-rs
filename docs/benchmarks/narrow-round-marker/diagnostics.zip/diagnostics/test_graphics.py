from PIL import Image
import unittest
from graphics import crop_white,shape_pixels
class Graphics(unittest.TestCase):
 def test_crop_keeps_all_nonwhite_pixels_and_white_padding_even_at_canvas_edges(self):
  im=Image.new('RGB',(5,6),'white');im.putpixel((0,0),(0,0,0));im.putpixel((2,3),(254,254,254));before=im.tobytes();out=crop_white(im);self.assertEqual(out.size,(7,8));self.assertEqual(out.getpixel((2,2)),(0,0,0));self.assertEqual(out.getpixel((4,5)),(254,254,254));self.assertEqual(im.tobytes(),before)
  self.assertEqual(sum(p!=(255,255,255)for p in out.getdata()),2)
  for y in range(out.height):
   for x in range(out.width):
    if x<2 or y<2 or x>=out.width-2 or y>=out.height-2:self.assertEqual(out.getpixel((x,y)),(255,255,255))
  with self.assertRaises(ValueError):crop_white(Image.new('RGB',(2,2),'white'))
 def test_all_eight_graphics_have_bounded_owned_pixels_and_one_connected_part(self):
  for h in [6,12,19,20,28,32,40]:
   for shape in ['none','thin','bar','dot','diagonal','chevron','left_curve','fork']:
    w,sh,ps=shape_pixels(shape,h);self.assertTrue(all(0<=x<w and 0<=y<sh for x,y in ps));self.assertEqual(len(ps),len(set(ps)))
    if shape=='none':self.assertEqual((w,len(ps)),(0,0));continue
    seen=set();pending=[next(iter(ps))]
    while pending:
     p=pending.pop()
     if p in seen:continue
     seen.add(p);x,y=p;pending.extend((xx,yy)for yy in range(y-1,y+2)for xx in range(x-1,x+2)if(xx,yy)in ps and(xx,yy)not in seen)
    self.assertEqual(seen,ps,(shape,h))
    if shape in ['thin','diagonal','chevron','left_curve']:
     expected=h
    elif shape=='dot':
     expected=16
    elif shape=='bar':
     expected=w*h
    else:
     expected=h+min(3,w-1)
    self.assertEqual(len(ps),expected,(shape,h))
   for shape in ['thin','bar','diagonal','chevron','left_curve','fork']:
    with self.assertRaises(ValueError):shape_pixels(shape,5)
if __name__=='__main__':unittest.main()
