from pathlib import Path
from PIL import Image, ImageChops
import json,hashlib,collections
r=Path('tmp/narrow-round-profile');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();prior={}
for x in json.loads((r/'manifest.json').read_text())['cases']:
 prior.setdefault((x['width'],x['height'],x['rgb_sha256']),[]).append({k:x.get(k)for k in ['corpus','model','id','orientation','truth']})
atlas=Image.open(f/'atlas.png').convert('RGB');assert sha((f/'atlas.png').read_bytes())==m['atlas_sha256'];assert sha((f/'lines.json').read_bytes())==m['lines_sha256'];fresh_truths={};native_truths={};seen=rotated=0
for x in m['inputs']:
 for k in ['original','image','rgb','effective_rgb','truth']:assert sha(Path(x[k]).read_bytes())==x[k+'_sha256'],(x['id'],k)
 body=[chr(0x60c5)+chr(0x5831),chr(0x5831)+chr(0x60c5)][x['body_id']];body=body[0]+' '*x['body_spaces']+body[1];truth=body
 if x['kind']=='text':truth=x['closer']+' '*x['spaces']+body if x['leading']else body+' '*x['spaces']+x['closer']
 assert Path(x['truth']).read_text()==truth;native_truths.setdefault(x['native_id'],set()).add(truth)
 im=Image.open(x['image']).convert('RGB');assert list(im.size)==[x['width'],x['height']];assert im.tobytes()==Path(x['rgb']).read_bytes();assert Image.open(x['original']).convert('RGB').tobytes()==im.tobytes();effective=im.transpose(Image.Transpose.ROTATE_90)if x['rotated_for_auto']else im;assert x['rotated_for_auto']==(5*im.height>4*im.width);assert list(effective.size)==[x['forward_width'],x['forward_height']];assert effective.tobytes()==Path(x['effective_rgb']).read_bytes()==atlas.crop(x['bounds']).tobytes()
 key=x['width'],x['height'],x['rgb_sha256'];matches=prior.get(key,[]);assert x['seen_before_137991']==bool(matches)and x['prior_rgb_matches']==matches;assert all(y['truth']==truth for y in matches);fresh_truths.setdefault(key,set()).add(truth);seen+=bool(matches);rotated+=x['rotated_for_auto']
conflicts=[{'key':key,'truths':sorted(values)}for key,values in fresh_truths.items()if len(values)>1];result={'inputs':len(m['inputs']),'seen_rgb_inputs':seen,'unseen_rgb_inputs':len(m['inputs'])-seen,'unique_fresh_rgb':len(fresh_truths),'auto_rotated':rotated,'internal_truth_conflicts':conflicts,'driver_sha256':sha(Path(__file__).read_bytes())};(r/'fresh-pixel-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='internal_truth_conflicts'},indent=2));assert not conflicts,conflicts[:2]
assert len(m['native_records'])==648
for rec in m['native_records']:
 png=f/'native'/(rec['id']+'.png');tp=png.with_suffix('.json');assert sha(png.read_bytes())==rec['png_sha256']and sha(tp.read_bytes())==rec['trace_sha256'];full=Image.open(png).convert('RGB');box=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();assert list(full.size)==rec['native_dimensions']and list(box)==rec['native_ink_bbox'];roi=Image.new('RGB',(box[2]-box[0]+4,box[3]-box[1]+4),'white');roi.paste(full.crop(box),(2,2));assert list(roi.size)==rec['cropped_dimensions']and sha(roi.tobytes())==rec['cropped_rgb_sha256'];trace=json.loads(tp.read_text());truth=native_truths[rec['id']];assert len(truth)==1;text=next(iter(truth))
 if rec['engine']=='freetype':
  assert rec['palt']is None and trace['palt']is None and trace['layout_engine']=='BASIC'and trace['face_index']==0;assert trace['text']==rec['call']['text']==text;assert all(g['different_from_missing_glyph']for g in trace['glyph_masks'])
 else:
  assert rec['exit_code']==0 and rec['argv'][4]==text
  for run in trace['runs']:assert Path(run['font_file']).samefile(rec['argv'][1])and run['font']==trace['font']and 0 not in run['glyphs']
  assert sorted(i for run in trace['runs']for i in run['string_indices'])==list(range(len(text)))
print('648 native traces and white ROI crops verified',flush=True)
