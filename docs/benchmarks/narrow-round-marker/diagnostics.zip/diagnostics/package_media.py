from pathlib import Path
import json,hashlib,zipfile,sys
r=Path('tmp/narrow-round-profile');out=r/'packet-media';out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 index={'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members};(out/(name+'.json')).write_text(json.dumps(index,indent=2)+'\n');assert (out/(name+'.zip')).stat().st_size<50*1024*1024;print(name,len(members),len(aliases),(out/(name+'.zip')).stat().st_size,flush=True)
images=[];inputs=[]
for sub in ['fresh','horizontal']:
 f=r/sub
 for name in ['native','original','png','rgb','effective','truth']:
  for p in(f/name).rglob('*'):
   if p.is_file():images.append(('data/'+sub+'/'+str(p.relative_to(f)),p))
 for name in ['atlas.png','lines.json','evaluation-manifest.json','contact-shapes.png','contact-shapes.json','tensor-proof.json']:
  p=f/name
  if p.exists():images.append(('data/'+sub+'/'+name,p))
 for p in(f/'whole-rgb-capture').rglob('*'):
  if p.is_file():inputs.append(('data/'+sub+'/'+str(p.relative_to(f)),p))
def pixel(key):return any(x in Path(key).parts for x in ['rgb','effective'])or Path(key).name=='atlas.png'
for name,paths in [('images',[(k,p)for k,p in images if not pixel(k)]),('pixels',[(k,p)for k,p in images if pixel(k)]),('inputs',inputs)]:packet(name,paths)
