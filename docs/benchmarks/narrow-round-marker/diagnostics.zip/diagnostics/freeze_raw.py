from pathlib import Path
import json,hashlib,shutil
from PIL import Image
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
t=json.loads((r/'tensor-command.json').read_text());assert t['exit_code']==0
for p,s in t['source_sha256'].items():assert sha(r/'tensor-source'/p)==s,p
assert sha(r/'tensor-binary')==t['binary_sha256']
a=json.loads((r/'audit.json').read_text());assert not a['char_regressions'] and not a['word_regressions']
assert json.loads((r/'geometry/result.json').read_text())['novel_rgb_geometry_changes']==4
assert json.loads((r/'fresh/tensor-proof.json').read_text())['all_original_auto_and_effective_horizontal_tensors_bit_equal']
q=json.loads((r/'fresh-pixel-audit.json').read_text());assert q['inputs']==8064 and not q['internal_truth_conflicts']
n=json.loads((r/'native-audit.json').read_text());assert len(n['records'])==648 and n['independent_native_qa_redraws']==648
assert all(x['font_advance_glyph_and_rgb_verified'] for x in n['records'])
for folder,count in [('fresh',8064),('horizontal',244)]:
 f=r/folder;m=json.loads((f/'evaluation-manifest.json').read_text());assert len(m['inputs'])==count
 assert sha(f/'atlas.png')==m['atlas_sha256'] and sha(f/'lines.json')==m['lines_sha256'];atlas=Image.open(f/'atlas.png').convert('RGB')
 for x in m['inputs']:
  assert sha(x['rgb'])==x['rgb_sha256'] and sha(x['effective_rgb'])==x['effective_rgb_sha256']
  assert atlas.crop(tuple(x['bounds'])).tobytes()==Path(x['effective_rgb']).read_bytes()
files=['run_fresh_raw.py','run_horizontal_raw.py','freeze_raw.py','profile-lock.json','tensor-command.json','audit.json','geometry/freeze.json','geometry/result.json','fresh/tensor-proof.json','fresh-pixel-audit.json','noise-pixel-audit.json','native-audit.json','contact-review.json','capture-controls-spec.md','fresh/evaluation-manifest.json','horizontal/evaluation-manifest.json','prepare_horizontal.py','test_horizontal.py']
out=r/'pre-nn-freeze';out.mkdir()
for p in files:
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,dest)
record={'files_sha256':{p:sha(r/p) for p in files},'new_raw_forwards':24924,'fresh_condition_inputs':8064,'horizontal_condition_inputs':244,'models':3,'production_candidate_connected':False,'all_pre_nn_gates_passed':True};(r/'pre-nn-freeze.json').write_text(json.dumps(record,indent=2)+'\n');print('All pre-NN gates passed; immutable scripts/QA copied')
