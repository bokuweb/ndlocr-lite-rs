from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();proof=json.loads((r/'pixel-precheck.json').read_text())
for key,h in proof['archives'].items():assert json.loads((r/'packet-media'/(key+'.json')).read_text())['sha256']==h==sha(r/'packet-media'/(key+'.zip'))
assert proof['stats']=={'images':8308,'actual_captures':8308,'pre_jpeg_noise_pairs':2304,'native_records':648,'unique_fresh_rgb':5568,'unique_unseen_rgb':5304};frozen={};caches=[]
for root in [Path('tmp/closer-bridge'),Path('tmp/detached-body')]:
 cache=root/'red-native-target';assert(cache/'CACHEDIR.TAG').read_text().startswith('Signature: 8a477f597d28d172789f06886806bc55');caches.append(str(cache))
 for p in root.iterdir():
  if p.is_file()and(p.name.endswith('-binary')or p.name.endswith('-command.json')):frozen[str(p)]=sha(p)
assert len(frozen)>8
record={'removed_verified_pixel_precheck_copy':str(r/'pixel-precheck'),'pixel_verification_sha256':sha(r/'pixel-precheck.json'),'media_archives_sha256':proof['archives'],'removed_only_old_cargo_red_build_caches':caches,'frozen_binary_and_command_sha256':frozen,'source_models_original_media_and_all_frozen_binaries_preserved':True};(r/'extra-generated-cleanup.json').write_text(json.dumps(record,indent=2)+'\n');shutil.rmtree(r/'pixel-precheck')
for path in caches:shutil.rmtree(path)
assert all(sha(p)==h for p,h in frozen.items());print('Verified pixel restoration copy and two old rebuildable caches removed; originals/frozen evidence retained')
