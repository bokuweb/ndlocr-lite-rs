from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for original,packet in [('tmp/detached-body/final-restored','docs/benchmarks/detached-body-components'),('tmp/closer-bridge/final-restored','docs/benchmarks/single-pixel-body-bridge')]:
 a=Path(original);p=Path(packet);v=json.loads((a/'verification.json').read_text());published=json.loads((p/'verification.json').read_text());assert all(published.get(k)==x for k,x in v.items());dest=r/('cleaned-'+a.parent.name+'-verification.json');assert not dest.exists();shutil.copy2(a/'verification.json',dest)
 for key,expected in v['archive_sha256'].items():assert sha(p/(key+'.zip'))==expected
 record={'removed_only_generated_restore_copy':str(a),'saved_verification':str(dest),'verification_sha256':sha(dest),'published_verification_sha256':sha(p/'verification.json'),'all_base_verification_fields_equal_published':True,'all_current_packet_archives_sha_verified':True};records.append(record)
(r/'prior-restoration-cleanup.json').write_text(json.dumps({'driver_sha256':sha(__file__),'copies':records,'original_datasets_models_binaries_and_source_preserved':True},indent=2)+'\n')
for x in records:shutil.rmtree(x['removed_only_generated_restore_copy']);print('Removed verified generated restoration copy',x['removed_only_generated_restore_copy'],flush=True)
