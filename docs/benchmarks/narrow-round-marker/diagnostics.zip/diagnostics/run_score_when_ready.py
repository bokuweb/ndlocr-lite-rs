from pathlib import Path
import subprocess,sys,time
r=Path('tmp/narrow-round-profile')
while not(r/'existing-driver.stdout').read_text().startswith('actual current product equals'):
 if(r/'existing-driver.stderr').stat().st_size:raise SystemExit((r/'existing-driver.stderr').read_text())
 time.sleep(1)
p=subprocess.run([sys.executable,str(r/'score.py')]);raise SystemExit(p.returncode)
