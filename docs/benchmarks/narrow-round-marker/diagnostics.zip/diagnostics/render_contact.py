from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib
r=Path('tmp/narrow-round-profile');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());xs=m['inputs'];picked=[];modes=[('freetype',None),('coretext',0),('coretext',1)];fonts=['maru','gothic','mincho'];shapes=['none','thin','bar','dot','diagonal','chevron','left_curve','fork']
def choose(engine,palt,**fields):
 return next(x for x in xs if x['engine']==engine and x['palt']==palt and all(x.get(k)==v for k,v in fields.items()))
for engine,palt in modes:
 for fi,font in enumerate(fonts):
  for ci,c in enumerate([')',chr(0xff09)]):
   for leading in [False,True]:picked.append(choose(engine,palt,kind='text',font=font,size=20 if ci==0 else 28,body_id=int(leading),body_spaces=(fi+ci+int(leading))%2,closer=c,leading=leading,spaces=ci,paper=2 if ci==0 else 10,format='jpeg75'if leading else 'png'))
 for si,shape in enumerate(shapes):picked.append(choose(engine,palt,kind='noise',font=fonts[si%3],size=20 if si%2==0 else 28,body_id=si%2,body_spaces=si%2,shape=shape,leading=bool((si//2)%2),gap=si%2,format='jpeg75'if si%2 else 'png'))
 picked.append(choose(engine,palt,kind='text',font='mincho',size=20,body_id=0,body_spaces=0,closer=')',leading=True,spaces=0,paper=0,format='png'))
 picked.append(choose(engine,palt,kind='text',font='mincho',size=20,body_id=1,body_spaces=0,closer=')',leading=True,spaces=0,paper=2,format='jpeg75'))
 for shape in ['fork','left_curve']:picked.append(choose(engine,palt,kind='noise',font='mincho',size=20,body_id=0,body_spaces=0,shape=shape,leading=True,gap=1,format='jpeg75'))
assert len(picked)==72;sheet=Image.new('RGB',(1600,1260),'#eeeeee');draw=ImageDraw.Draw(sheet)
for i,x in enumerate(picked):
 im=Image.open(x['image']).convert('RGB');im=im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST);im.thumbnail((190,100));px=i%8*200;py=i//8*140;sheet.paste(im,(px+3,py+3));kind=x.get('shape','c'+str([')',chr(0xff09)].index(x['closer']))if x['kind']=='text'else x['shape']);draw.text((px+3,py+106),f'{x["engine"]} p{x["palt"]} {x["font"]} {x["size"]}\n{kind} bs{x["body_spaces"]} lead{int(x["leading"])}',fill='black')
sheet.save(f/'contact-shapes.png');(f/'contact-shapes.json').write_text(json.dumps({'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'image_sha256':hashlib.sha256((f/'contact-shapes.png').read_bytes()).hexdigest(),'source_ids':[x['id']for x in picked]},indent=2)+'\n')
