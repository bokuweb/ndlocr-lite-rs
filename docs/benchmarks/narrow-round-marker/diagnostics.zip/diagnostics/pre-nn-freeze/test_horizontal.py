from pathlib import Path
from PIL import Image
import json,unittest,hashlib
class Controls(unittest.TestCase):
 def test_all244_original_auto_rotated_inputs_are_retained_for_explicit_horizontal(self):
  r=Path('tmp/narrow-round-profile');m=json.loads((r/'horizontal/evaluation-manifest.json').read_text());original={x['id']:x for x in json.loads((r/'fresh/evaluation-manifest.json').read_text())['inputs']if x['rotated_for_auto']};self.assertEqual(len(original),244);self.assertEqual({x['id']for x in m['inputs']},set(original));atlas=Image.open(r/'horizontal/atlas.png').convert('RGB')
  for x in m['inputs']:
   self.assertEqual(x['orientation'],'horizontal');self.assertEqual(x['rgb_sha256'],original[x['id']]['rgb_sha256']);self.assertEqual(x['truth_sha256'],original[x['id']]['truth_sha256']);self.assertEqual(x['forward_width'],x['width']);self.assertEqual(x['forward_height'],x['height']);self.assertEqual(x['effective_rgb'],x['rgb']);self.assertEqual(atlas.crop(x['bounds']).tobytes(),Path(x['rgb']).read_bytes())
if __name__=='__main__':unittest.main()
