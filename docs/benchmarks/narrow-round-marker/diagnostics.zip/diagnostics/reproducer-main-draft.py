def main():
 from PIL import Image
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);root=parser.parse_args().output.resolve();root.mkdir(parents=True);packet=Path(__file__).resolve().parent
 owned,internal,detached,bridge,parent_hashes,nested=load_parents(packet,root);hashes=detached.restore(packet,root,['images','pixels','inputs','diagnostics','text']);cases=read(root,'diagnostics/portable-cases.json')['cases'];assert len(cases)==162915;refs={(x['corpus'],x['model'],x['id']):x for x in cases};assert len(refs)==len(cases);prior=read(root,'parent/diagnostics/freetype/portable-cases.json')['cases'];assert len(prior)==137991
 for x in prior:
  y=refs[x['corpus'],x['model'],x['id']];assert(x['raw'],x['truth'],x['expected_after'],x['rgb_sha256'])==(y['raw'],y['truth'],y['expected_before'],y['rgb_sha256'])
 seen=set()
 for x in cases:
  if x['rgb']not in seen:assert sha((root/x['rgb']).read_bytes())==x['rgb_sha256'];seen.add(x['rgb'])
  p=root/'truth'/x['corpus']/(x['id']+'.txt');p.parent.mkdir(parents=True,exist_ok=True)
  if p.exists():assert p.read_bytes()==x['truth'].encode()
  else:p.write_bytes(x['truth'].encode())
  for phase,field in [('baseline','expected_before'),('candidate','expected_after')]:
   p=root/'generated/core'/x['corpus']/x['model']/phase/(x['id']+'.txt');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(x[field].encode())
 corpora=['old','spaces','fresh','horizontal','new','positive','positive-horizontal','internal','internal-horizontal','owned-fresh','owned-horizontal'];tables=detached.reproduce_audit(bridge,root,cases,corpora,'text/scores','diagnostics/audit.json')
 for folder in ['fresh','horizontal']:tables+=reproduce_new_audit(root,bridge,cases,folder)
 assert tables==450
 means={};old=read(root,'parent/parent/parent/parent/diagnostics/parents/old-probe.json')
 for model in old['models']:
  for x in model['rows']:means['old',model['label'].removeprefix('single'),x['id']]=struct.unpack('<I',struct.pack('<f',x['mean_confidence']))[0]
 forwards=0
 for corpus,prefix,folder,n in [('owned-fresh','parent/diagnostics/freetype','fresh',7632),('owned-horizontal','parent/diagnostics/freetype','horizontal',24),('narrow-fresh','diagnostics','fresh',8064),('narrow-horizontal','diagnostics','horizontal',244)]:
  data=('parent/data/ft/'if corpus.startswith('owned-')else'data/')+folder;inputs={x['id']:x for x in read(root,data+'/evaluation-manifest.json')['inputs']}
  for model in ['30','50','100']:
   rows=read(root,prefix+'/'+folder+'/'+model+'-export.json');assert len(rows)==n and{x['id']for x in rows}==set(inputs);assert read(root,prefix+'/'+folder+'/'+model+'-command.json')['exit_code']==0
   for x in rows:
    key=corpus,model,x['id'];assert x['text']==refs[key]['raw']and x['bounds']==inputs[x['id']]['bounds'];assert len(x['chunks'])==1 and x['chunks'][0]['x_range']==[0,inputs[x['id']]['forward_width']]and not x['chunks'][0]['inserted_space_before'];means[key]=bridge.emitted_mean_bits(x);forwards+=corpus.startswith('narrow-')
 assert forwards==24924
 native=read(root,'diagnostics/native-manifest.json');pins={(x['corpus'],x['model'],x['id']):x for x in native['cases']};seen=set()
 for model in ['30','50','100']:
  rows=read(root,'diagnostics/native'+model+'-results.json');assert len(rows)==native['counts'][model];assert read(root,'diagnostics/native'+model+'-command.json')['exit_code']==0
  for x in rows:
   key=x['corpus'],model,x['id'];assert key not in seen and x['raw']==refs[key]['raw']and x['text']==refs[key]['expected_after'];assert x['mean_bits']==pins[key]['mean_bits']==means[key];seen.add(key)
 assert seen==set(pins)and len(pins)==8564
 cli=read(root,'diagnostics/line-cli-results.json');cm=read(root,'diagnostics/cli-manifest.json');inputs={(x['corpus'],x['model'],x['id']):x for x in read(root,'diagnostics/line-cli-command.json')['cases']};assert len(cli)==len(cm['cases'])==3500;expected_changed={(x['corpus'],x['model'],x['id'])for x in cases if x['selected']and x['orientation']=='auto'};assert {(x['corpus'],x['model'],x['id'])for x in cli if x['selected']}==expected_changed
 for x in cli:
  key=x['corpus'],x['model'],x['id'];assert x['exit_code']==0 and x['text']==refs[key]['expected_after'];name=x['model']+'-'+x['corpus']+'-'+x['id'];stdout=(root/'text/line-cli'/(name+'.stdout')).read_bytes();assert stdout[-1:]==b'\n'and stdout[:-1].decode()==x['text'];im=root/'text/line-cli/images'/(x['corpus']+'-'+x['id']+'.png');assert sha(im.read_bytes())==inputs[key]['image_sha256'];assert Image.open(im).convert('RGB').tobytes()==(root/refs[key]['rgb']).read_bytes()
 for table in(root/'text').rglob('*.csv'):
  rows=list(csv.DictReader(table.open()));systems={x['system']for x in rows};assert systems=={'baseline','candidate'};a={(x['file'],x['system']):x for x in rows}
  for file in{x['file']for x in rows}:
   b,c=a[file,'baseline'],a[file,'candidate'];assert int(c['char_errors'])<=int(b['char_errors'])and int(c['word_errors'])<=int(b['word_errors'])
 stats=verify_pixels(root,prior);verify_source(root);selected=[x for x in cases if x['selected']];assert len(selected)==62 and len({(x['width'],x['height'],x['rgb_sha256'])for x in selected})==19
 (root/'product-manifest.json').write_text(json.dumps({'cases':[x|{'rgb':str(root/x['rgb'])}for x in cases]},ensure_ascii=False,indent=2)+'\n');result={'archive_sha256':hashes,'parent_archives':parent_hashes,'nested_parent_archives':nested,'table_files_byte_equal':tables,'audits_recomputed_equal':3,'product_pairs':len(cases),'changes':len(selected),'unique_changed_original_rgb':19,'new_evaluation_raw_forwards':forwards,'native_api_pairs':len(pins),'cli_processes':len(cli),'page_fragment_source_proof_verified':True,'new_page_accuracy_evaluation_runs':0}|stats;(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
