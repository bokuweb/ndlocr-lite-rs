import copy,unittest
from gate import require_adoption_gates
class GateTests(unittest.TestCase):
 def setUp(self):
  self.audit={'char_regressions':[],'word_regressions':[],'summary':[]}
  self.old=copy.deepcopy(self.audit);self.fresh=copy.deepcopy(self.audit);self.horizontal=copy.deepcopy(self.audit)
  self.fresh['summary']=[{'group':'unseen','normalization':'none','changes':1},{'group':'all','normalization':'none','changes':1}]
 def test_unseen_actual_application_and_all_groups_nonregression_are_required(self):
  self.assertEqual(require_adoption_gates(self.old,self.fresh,self.horizontal),1)
 def test_any_word_or_character_regression_rejects_even_with_more_recoveries(self):
  for group in ['old','fresh','horizontal']:
   for metric in ['char_regressions','word_regressions']:
    inputs={k:copy.deepcopy(getattr(self,k)) for k in ['old','fresh','horizontal']};inputs[group][metric]=[['model100','strict','counterexample',0,1]]
    with self.subTest(group=group,metric=metric),self.assertRaisesRegex(AssertionError,'regression'):
     require_adoption_gates(**inputs)
 def test_seen_only_geometry_or_normalized_duplicate_application_is_insufficient(self):
  for summaries in [[],[{'group':'seen','normalization':'none','changes':99}],[{'group':'unseen','normalization':'strict','changes':99}]]:
   self.fresh['summary']=summaries
   with self.subTest(summaries=summaries),self.assertRaisesRegex(AssertionError,'unseen'):
    require_adoption_gates(self.old,self.fresh,self.horizontal)
if __name__=='__main__':unittest.main()
