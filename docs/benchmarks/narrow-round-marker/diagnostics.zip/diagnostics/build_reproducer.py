from pathlib import Path
r=Path('tmp/narrow-round-profile');old=Path('docs/benchmarks/owned-parts-body-bridge/reproduce.py').read_text();header=old[:old.index('def load_parents')].replace('Restore fixed bridge/owned-parts evidence','Restore fixed narrow-round marker evidence')
load='''def load_parents(packet,root):
 refs=read(packet,'parents.json');p=packet.parent/refs['packet'];script=p/'reproduce.py';assert sha(script.read_bytes())==refs['reproducer_sha256'];assert sha((p/'parents.json').read_bytes())==refs['nested_parents_json_sha256'];sys.dont_write_bytecode=True;spec=importlib.util.spec_from_file_location('verified_owned_parent',script);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned);internal,detached,bridge,ih,dh,bh=owned.load_parents(p,root/'parent');h=detached.restore(p,root/'parent',list(refs['archives']));assert h==refs['archives'];return owned,internal,detached,bridge,h,{'internal':ih,'detached':dh,'bridge':bh}

'''
audit=old[old.index('def reproduce_new_audit'):old.index('def verify_source')].replace("'owned-'+folder","'narrow-'+folder").replace('diagnostics/freetype/','diagnostics/').replace('data/ft/','data/').replace('seen_before_115023','seen_before_137991').replace('text/freetype/','text/')
audit=audit.replace(' for group,ids in groups.items():'," for mode in sorted({x['engine']+'-p'+str(x['palt'])for x in xs.values()}):groups[mode]=[k for k,x in xs.items()if x['engine']+'-p'+str(x['palt'])==mode]\n for group,ids in groups.items():")
audit=audit.replace("for id in ids:(truth/(id+'.txt')).write_bytes(refs['30',id]['truth'].encode())","for id in ids:os.link(root/'truth'/corpus/(id+'.txt'),truth/(id+'.txt'))")
audit=audit.replace("for id in ids:(p/(id+'.txt')).write_bytes(refs[model,id][field].encode())","for id in ids:os.link(root/'generated/core'/corpus/model/phase/(id+'.txt'),p/(id+'.txt'))")
header=header.replace('import argparse,csv,','import os,argparse,csv,')
source=header+load+(r/'reproducer-pixels-draft.py').read_text()+'\n'+audit+(r/'reproducer-source-draft.py').read_text()+'\n'+(r/'reproducer-main-draft.py').read_text();(r/'reproduce.py').write_text(source)
