from PIL import Image, ImageChops


def crop_white(image):
    original = image.convert('RGB')
    box = ImageChops.difference(original, Image.new('RGB', original.size, 'white')).getbbox()
    if box is None:
        raise ValueError('native text has no nonwhite pixels')
    ink = original.crop(box)
    output = Image.new('RGB', (ink.width + 4, ink.height + 4), 'white')
    output.paste(ink, (2, 2))
    return output


def shape_pixels(shape, height):
    if height < 6:
        raise ValueError('native body ink height must be at least six pixels')
    if shape == 'none':
        return 0, height, set()
    if shape == 'thin':
        return 1, height, {(0, y) for y in range(height)}
    if shape == 'dot':
        return 4, 4, {(x, y) for y in range(4) for x in range(4)}
    width = max(3, (height + 5) // 6)
    if shape == 'bar':
        return width, height, {(x, y) for y in range(height) for x in range(width)}
    if shape == 'diagonal':
        points = {(y * (width - 1) // (height - 1), y) for y in range(height)}
    elif shape == 'chevron':
        points = {
            ((2 * min(y, height - y - 1) * (width - 1) + (height - 1) // 2) // (height - 1), y)
            for y in range(height)
        }
    elif shape in ['left_curve', 'fork']:
        flank = height // 3
        points = {
            (min(min(y, height - y - 1) * (width - 1) // flank, width - 1), y)
            for y in range(height)
        }
        if shape == 'left_curve':
            points = {(width - x - 1, y) for x, y in points}
        else:
            center = height // 2
            branch = max(0, width - 4)
            points.add((branch, center))
            points.update((x, center - 1) for x in range(branch + 1, width - 1))
    else:
        raise ValueError('unknown shape: ' + shape)
    return width, height, points
