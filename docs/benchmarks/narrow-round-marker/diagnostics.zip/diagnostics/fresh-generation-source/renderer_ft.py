from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,features
import PIL,hashlib
_cache={}
def draw_basic(font,size,text):
    key=(font['path'],size)
    if key not in _cache:
        assert hashlib.sha256(Path(font['path']).read_bytes()).hexdigest()==font['sha256']
        _cache[key]=ImageFont.truetype(font['path'],size,index=0,layout_engine=ImageFont.Layout.BASIC)
    face=_cache[key];assert face.layout_engine==ImageFont.Layout.BASIC
    missing=face.getmask(chr(0x10FFFF),mode='L');missing_key=(missing.size,bytes(missing));glyphs=[]
    for c in dict.fromkeys(text):
        mask=face.getmask(c,mode='L');raw=bytes(mask);different=(mask.size,raw)!=missing_key;assert different,('missing glyph',c,font['id'])
        glyphs.append({'character':c,'size':list(mask.size),'mask_sha256':hashlib.sha256(raw).hexdigest(),'bbox':list(face.getbbox(c)),'length':face.getlength(c),'different_from_missing_glyph':different})
    box=face.getbbox(text);x0,y0,x1,y1=box;im=Image.new('RGB',(x1-x0+16,y1-y0+16),'white');ImageDraw.Draw(im).text((8-x0,8-y0),text,font=face,fill='black')
    trace={'font':font,'font_face':list(face.getname()),'face_index':0,'size':size,'layout_engine':'BASIC','palt':None,'pillow_version':PIL.__version__,'freetype_version':features.version('freetype2'),'raqm_available':features.check('raqm'),'text':text,'bbox':list(box),'length':face.getlength(text),'prefix_lengths':[face.getlength(text[:i])for i in range(len(text)+1)],'glyph_masks':glyphs}
    return im,trace
