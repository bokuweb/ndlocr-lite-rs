def verify_source(root):
 current=root/'diagnostics/verification-source';prior=root/'parent/diagnostics/freetype/verification-source'
 for p in ['src/app.rs','src/infer/page_pool.rs','src/infer/parseq.rs','src/pipeline/run_page.rs','src/infer/visible_repetitions/single_pixel_bridge.rs']:assert(current/p).read_bytes()==(prior/p).read_bytes()
 block=b'\n#[cfg(test)]\n#[path = "../../tests/support/narrow_round_model.rs"]\nmod narrow_round_model_tests;\n';b=(current/'src/infer/cached.rs').read_bytes();assert block in b and b.replace(block,b'')==(prior/'src/infer/cached.rs').read_bytes()
 anchor=b'#[cfg(any(feature = "onnx", test))]\npub(crate) fn sanitize_visible_repetitions';a=(current/'src/infer/visible_repetitions.rs').read_bytes();b=(prior/'src/infer/visible_repetitions.rs').read_bytes();assert a[a.index(anchor):]==b[b.index(anchor):]
 path='src/infer/visible_repetitions/owned_parts_body_bridge.rs';a=(current/path).read_bytes();b=(prior/path).read_bytes();start=b'fn primary_support_mask';end=b'pub(super) fn supports';assert a[a.index(start):a.index(end)]==b[b.index(start):b.index(end)]
 for path in ['src/infer/visible_repetitions/narrow_round_marker.rs','src/infer/visible_repetitions/owned_parts_body_bridge.rs']:
  a=(root/'diagnostics/tensor-source'/path).read_text();b=(current/path).read_text();a=a[:a.index('#[cfg(test)]\nmod tests')];b=b[:b.index('#[cfg(test)]\nmod tests')]
  if path.endswith('/narrow_round_marker.rs'):a=a[a.index('pub(super) fn supports_mark'):];b=b[b.index('pub(super) fn supports_mark'):]
  norm=lambda s:re.sub(r'\s+','',s.replace('#[cfg(test)]',''));assert norm(a)==norm(b)
 for phase in ['probe','tensor','red','verification']:
  meta=read(root,'diagnostics/'+phase+'-command.json')
  for path,expected in meta['source_sha256'].items():assert sha((root/'diagnostics'/(phase+'-source')/path).read_bytes())==expected,(phase,path)
 checked=read(root,'diagnostics/checked-source-command.json');changed=[]
 for path,expected in checked['source_sha256'].items():
  after=(root/'diagnostics/checked-source'/path).read_bytes();assert sha(after)==expected;before=(current/path).read_bytes()
  if after!=before:
   assert path=='src/infer/visible_repetitions/narrow_round_marker.rs';assert after.count(b'rgb.chunks_mut(3)')==2;assert after.replace(b'rgb.chunks_mut(3)',b'rgb.chunks_exact_mut(3)')==before;changed.append(path)
 assert changed==checked['changed_test_source_files']and checked['all_runtime_rust_bytes_equal_measured_sources']
