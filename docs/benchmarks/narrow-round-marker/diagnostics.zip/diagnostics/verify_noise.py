from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
r=Path('tmp/narrow-round-profile');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();audit=[]
def expected_points(name, H):
 W=max(3,(H+5)//6)
 if name=='none':return 0,H,set()
 if name=='thin':return 1,H,{(0,y)for y in range(H)}
 if name=='bar':return W,H,{(x,y)for y in range(H)for x in range(W)}
 if name=='dot':return 4,4,{(x,y)for y in range(4)for x in range(4)}
 if name=='diagonal':points={(y*(W-1)//(H-1),y)for y in range(H)}
 elif name=='chevron':points={((2*min(y,H-1-y)*(W-1)+(H-1)//2)//(H-1),y)for y in range(H)}
 else:
  points={(min(min(y,H-1-y)*(W-1)//(H//3),W-1),y)for y in range(H)}
  if name=='left_curve':points={(W-1-x,y)for x,y in points}
  elif name=='fork':
   left=max(0,W-4);points.add((left,H//2));points.update((x,H//2-1)for x in range(left+1,W-1))
  else:raise AssertionError(name)
 return W,H,points
for x in m['inputs']:
 if x['kind']!='noise' or x['format']!='png':continue
 full=Image.open(f/'native'/(x['native_id']+'.png')).convert('RGB');bb=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();native=Image.new('RGB',(bb[2]-bb[0]+4,bb[3]-bb[1]+4),'white');native.paste(full.crop(bb),(2,2));box=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();H=box[3]-box[1];W,MH,points=expected_points(x['shape'],H);self_points={tuple(p)for p in x['shape_relative_points']};assert points==self_points and len(points)==x['shape_pixel_count'];shift=W+x['gap'];offset=shift if x['leading']else 0;px=2 if x['leading']else box[2]+x['gap'];py=box[1]+(H-MH)//2;assert [px,py,px+W,py+MH]==x['shape_bounds'];expected=Image.new('RGB',(native.width+shift,native.height),'white');expected.paste(native,(offset,0));overlap=0
 for yy in range(native.height):
  for xx in range(native.width):
   if native.getpixel((xx,yy))!=(255,255,255):overlap+=(xx+offset-px,yy-py)in points
 assert overlap==0,x['id']
 for xx,yy in points:expected.putpixel((px+xx,py+yy),(0,0,0))
 actual=Image.open(x['image']).convert('RGB');assert expected.size==actual.size and expected.tobytes()==actual.tobytes();assert sha(expected.tobytes())==x['pre_codec_rgb_sha256'];audit.append({'id':x['id'],'shape_points':len(points),'overlap_pixels':overlap,'reconstructed_rgb_sha256':sha(expected.tobytes())})
assert len(audit)==2304;(r/'noise-pixel-audit.json').write_text(json.dumps({'driver_sha256':sha(Path(__file__).read_bytes()),'pre_jpeg_pairs':len(audit),'all_source_body_nonwhite_pixels_preserved':True,'all_shape_glyph_overlap_counts_zero':True,'all_png_reconstructions_byte_equal':True,'rows':audit},indent=2)+'\n');print('2304 pre-JPEG nontext pairs reconstructed;all original nonwhite body pixels kept;overlap0',flush=True)
