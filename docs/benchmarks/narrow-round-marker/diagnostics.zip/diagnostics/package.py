from pathlib import Path
import json,hashlib,zipfile,sys,shutil
r=Path('tmp/narrow-round-profile');out=Path('docs/benchmarks/narrow-round-marker');out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 (out/(name+'.json')).write_text(json.dumps({'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members},indent=2)+'\n');print(name,len(members),len(aliases),(out/(name+'.zip')).stat().st_size,flush=True);assert(out/(name+'.zip')).stat().st_size<50*1024*1024
for name in ['images','pixels','inputs']:
 for suffix in ['.zip','.json']:shutil.copy2(r/'packet-media'/(name+suffix),out/(name+suffix))
old={(x['corpus'],x['model'],x['id']):x for x in json.loads(zipfile.ZipFile('docs/benchmarks/owned-parts-body-bridge/diagnostics.zip').read('diagnostics/freetype/portable-cases.json'))['cases']};portable=[]
for x in json.loads((r/'product-manifest.json').read_text())['cases']:
 key=x['corpus'],x['model'],x['id'];path='parent/'+old[key]['rgb']if key in old else 'data/fresh/rgb/'+x['id']+'.rgb';portable.append(x|{'rgb':path})
assert len(portable)==162915;(r/'portable-cases.json').write_text(json.dumps({'cases':portable},ensure_ascii=False,indent=2)+'\n')
diag=[];text=[]
for p in r.rglob('*'):
 if not p.is_file()or p.name in ['checkpoint.md','README-draft.md']:continue
 rel=p.relative_to(r)
 if any(x in rel.parts for x in ['final-restored','pixel-precheck','packet-media','scores','truth','subsets','line-cli','whole-rgb-capture','native','original','png','rgb','effective','__pycache__','portable-pixel-work']):continue
 if p.suffix in ['.json','.py','.md','.rs','.log','.stdout','.stderr','.swift','.toml','.lock','.yaml']and not p.name.startswith('package-'):diag.append(('diagnostics/'+str(rel),p))
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if any(x in rel.parts for x in ['final-restored','pixel-precheck','packet-media','__pycache__','portable-pixel-work']):continue
 if any(x in rel.parts for x in ['scores','truth','line-cli'])and p.suffix in ['.csv','.md','.txt','.json','.stdout','.stderr','.png']:text.append(('text/'+str(rel),p))
for p in Path('tests/fixtures/owned_parts_body_bridge').iterdir():diag.append(('diagnostics/fixtures/'+p.name,p))
for p in Path('docs').glob('narrow_round_marker*.md'):diag.append(('diagnostics/specs/'+p.name,p))
diag.append(('diagnostics/source/eval_ocr_metrics.py',Path('tools/eval_ocr_metrics.py')));diag.append(('diagnostics/source/means.py',Path('tmp/punct-matched/means.py')))
packet('diagnostics',diag);packet('text',text)
p=Path('docs/benchmarks/owned-parts-body-bridge');names=['images','pixels','geometry-images','geometry-pixels','screens','inputs','diagnostics','text'];refs={'packet':p.name,'reproducer_sha256':sha((p/'reproduce.py').read_bytes()),'archives':{n:json.loads((p/(n+'.json')).read_text())['sha256']for n in names},'nested_parents_json_sha256':sha((p/'parents.json').read_bytes())};(out/'parents.json').write_text(json.dumps(refs,indent=2)+'\n')
for name in ['reproduce.py','portable_native.py']:shutil.copy2(r/name,out/name)
