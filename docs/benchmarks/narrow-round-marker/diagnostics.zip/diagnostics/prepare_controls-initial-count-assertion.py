from pathlib import Path
import json,hashlib
r=Path('tmp/narrow-round-profile');m=json.loads((r/'fresh/evaluation-manifest.json').read_text());hh=json.loads((r/'horizontal/evaluation-manifest.json').read_text());native_noise=[];native_text=[];cli=[]
for x in m['inputs']:
 if x['kind']=='noise':
  if (x['body_spaces']+x['gap']+(x['format']=='jpeg75')+x['leading'])%2==0:native_noise.append(x['id'])
  if (x['leading'],x['gap'],int(x['format']=='jpeg75'))in[(False,0,0),(True,1,1)]:cli.append(x['id'])
 elif x['body_spaces']==x['spaces']==1 and x['paper']==2:native_text.append(x['id'])
assert(len(native_noise),len(native_text),len(cli),len(hh['inputs']))==(2304,144,1152,244)
result={'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'integration_spec_sha256':hashlib.sha256(Path('docs/narrow_round_marker_integration.md').read_bytes()).hexdigest(),'main_manifest_sha256':hashlib.sha256((r/'fresh/evaluation-manifest.json').read_bytes()).hexdigest(),'horizontal_manifest_sha256':hashlib.sha256((r/'horizontal/evaluation-manifest.json').read_bytes()).hexdigest(),'api_noise_ids':native_noise,'api_spaced_text_ids':native_text,'api_horizontal_ids':[x['id']for x in hh['inputs']],'cli_noise_ids':cli,'selection_does_not_use_nn_outputs':True}
(r/'control-ids.json').write_text(json.dumps(result,indent=2)+'\n');print('API noise/text/horizontal',len(native_noise),len(native_text),len(hh['inputs']),'CLI noise',len(cli),'IDs fixed without reading NN outputs')
