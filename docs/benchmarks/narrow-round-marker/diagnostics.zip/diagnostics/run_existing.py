from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((r/'probe-command.json').read_text());assert sha(r/'probe-binary')==m['binary_sha256'];assert sha(r/'manifest.json')==m['input_manifest_sha256'];artifacts=[json.loads(x)for x in(r/'probe-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x['success']for x in artifacts)
for p,h in m['source_sha256'].items():assert sha(p)==h,p
m.update({'driver_sha256':sha(__file__),'build_json_sha256':sha(r/'probe-build.jsonl'),'build_finished_success':True});(r/'probe-command.json').write_text(json.dumps(m,indent=2)+'\n')
with(r/'probe.stdout').open('wb')as a,(r/'probe.stderr').open('wb')as b:done=subprocess.run(m['argv'],env=os.environ|m['env'],stdout=a,stderr=b)
m['exit_code']=done.returncode;(r/'probe-command.json').write_text(json.dumps(m,indent=2)+'\n');assert done.returncode==0
p=subprocess.run([sys.executable,str(r/'test_existing.py')],capture_output=True);(r/'existing-green.stdout').write_bytes(p.stdout);(r/'existing-green.stderr').write_bytes(p.stderr);assert p.returncode==0;print('actual current product equals all137991 frozen1ec results; candidate replay completed; no NN',flush=True)
