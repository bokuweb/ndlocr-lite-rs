def verify_pixels(root,prior):
 from PIL import Image
 from portable_native import verify_native_trace
 import os
 data=root/'data/fresh';m=read(data,'evaluation-manifest.json');assert len(m['inputs'])==8064
 oldroot=Path('tmp/narrow-round-profile')
 def resolve(path):
  p=Path(path);assert '..'not in p.parts
  return root/'data'/p.relative_to(oldroot)
 work=root/'portable-pixel-work';work.mkdir();(work/'fresh').mkdir();(work/'fresh/native').symlink_to(data/'native',target_is_directory=True)
 for name in ['atlas.png','lines.json']:(work/'fresh'/name).symlink_to(data/name)
 (work/'manifest.json').write_text(json.dumps({'cases':prior},ensure_ascii=False)+'\n')
 port=m|{'inputs':[x|{k:str(resolve(x[k]))for k in ['original','image','rgb','effective_rgb','truth']}for x in m['inputs']]}
 (work/'fresh/evaluation-manifest.json').write_text(json.dumps(port,ensure_ascii=False)+'\n')
 for driver,audit in [('verify_fresh.py','fresh-pixel-audit.json'),('verify_noise.py','noise-pixel-audit.json')]:
  source=(root/'diagnostics'/driver).read_text();expected=read(root,'diagnostics/'+audit);assert sha(source.encode())==expected['driver_sha256']
  source=source.replace("r=Path('tmp/narrow-round-profile')",'r=Path('+repr(str(work))+')')
  source=source.replace("Path(run['font_file']).samefile(rec['argv'][1])","unicodedata.normalize('NFC',run['font_file'])==unicodedata.normalize('NFC',rec['argv'][1])")
  path=work/driver;path.write_text('import unicodedata\n'+source);exec(compile(path.read_text(),str(path),'exec'),{'__file__':str(path)})
  actual=read(work,audit)
  for k,v in actual.items():
   if k!='driver_sha256':assert expected[k]==v,(audit,k)
 assert len({(x['width'],x['height'],x['rgb_sha256'])for x in m['inputs']})==5568
 assert len({(x['width'],x['height'],x['rgb_sha256'])for x in m['inputs']if not x['seen_before_137991']})==5304
 for rec in m['native_records']:
  trace=read(data/'native',rec['id']+'.json');text=rec['call']['text']if rec['engine']=='freetype'else rec['argv'][4];verify_native_trace(rec,trace,text)
 captures=0
 for folder,n in [('fresh',8064),('horizontal',244)]:
  f=root/'data'/folder;manifest=read(f,'evaluation-manifest.json');rows=manifest['inputs'];assert len(rows)==n;xs={x['id']:x for x in rows};atlas=Image.open(f/'atlas.png').convert('RGB');assert sha((f/'atlas.png').read_bytes())==manifest['atlas_sha256']and sha((f/'lines.json').read_bytes())==manifest['lines_sha256']
  if folder=='horizontal':
   assert {x['id']for x in rows}=={x['id']for x in m['inputs']if x['rotated_for_auto']}
   for x in rows:
    for k in ['original','image','rgb','effective_rgb','truth']:assert sha(resolve(x[k]).read_bytes())==x[k+'_sha256']
    assert x['orientation']=='horizontal'and x['effective_rgb']==x['rgb'];assert atlas.crop(x['bounds']).tobytes()==resolve(x['rgb']).read_bytes()
  cap=read(f,'whole-rgb-capture/inputs.json');assert cap['model_input_dimensions']==[256,24]and len(cap['chunks'])==n;assert {c['line_id']for c in cap['chunks']}==set(xs)
  for c in cap['chunks']:
   x=xs[c['line_id']];im=Image.open(f/'whole-rgb-capture'/c['image']).convert('RGB');assert list(im.size)==c['dimensions']==[x['forward_width'],x['forward_height']];assert c['chunk_index']==0 and c['x_range']==[0,x['forward_width']];assert sha(im.tobytes())==x['effective_rgb_sha256'];captures+=1
 proof=read(data,'tensor-proof.json');assert proof=={'images':8064,'model_shapes':3,'all_original_auto_and_effective_horizontal_tensors_bit_equal':True}
 tensor=root/'tensor/fresh';tensor.mkdir(parents=True);(tensor/'evaluation-manifest.json').write_text(json.dumps(port,ensure_ascii=False)+'\n')
 return {'images':8308,'actual_captures':captures,'pre_jpeg_noise_pairs':2304,'native_records':648,'unique_fresh_rgb':5568,'unique_unseen_rgb':5304}
