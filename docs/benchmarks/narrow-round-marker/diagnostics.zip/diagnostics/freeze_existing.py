from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();lock=json.loads((r/'profile-lock.json').read_text());p=Path('src/infer/visible_repetitions/narrow_round_marker.rs');assert hashlib.sha256(p.read_bytes().split(b'#[cfg(test)]')[0]).hexdigest()==lock['condition_prefix_sha256'];assert sha('docs/narrow_round_marker_profile.md')==lock['spec_sha256']
parent=Path('tmp/owned-parts-bridge/freetype/product-manifest.json');m=json.loads(parent.read_text());xs=m['cases'];assert len(xs)==137991;seen={}
for x in xs:
 if x['rgb']not in seen:seen[x['rgb']]=sha(x['rgb'])
 assert seen[x['rgb']]==x['rgb_sha256']
(r/'manifest.json').write_bytes(parent.read_bytes());artifacts=[json.loads(line)for line in(r/'probe-build.jsonl').read_text().splitlines()];bins=[x['executable']for x in artifacts if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(bins)==1;shutil.copy2(bins[0],r/'probe-binary');hs={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),*Path('docs').glob('narrow_round_marker*.md')]:
 q=r/'probe-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
models=json.loads(Path('tmp/owned-parts-bridge/freetype/verification-command.json').read_text())['models']
for p,h in models.items():assert sha(p)==h,p
meta={'baseline_commit':'1ec730a1177f8bbaeb64d7cb0f823850fc68420e','baseline_ci_run':39343510790,'source_sha256':hs,'binary_sha256':sha(r/'probe-binary'),'models':models,'input_manifest_sha256':sha(r/'manifest.json'),'parent_manifest_sha256':sha(parent),'unique_original_rgb_paths_verified':len(seen),'profile_lock_sha256':sha(r/'profile-lock.json'),'argv':[str((r/'probe-binary').resolve()),'infer::visible_repetitions::narrow_round_marker::tests::record_narrow_round_policy','--exact','--ignored','--nocapture'],'env':{'NDLOCR_NARROW_ROUND_ROOT':str(r)},'no_new_nn_forwards':True};(r/'probe-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('frozen',len(xs),'1ec product baselines; RGB paths',len(seen),flush=True)
