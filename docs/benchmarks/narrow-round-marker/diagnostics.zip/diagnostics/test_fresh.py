from pathlib import Path
import json,itertools,unittest
class Controls(unittest.TestCase):
 def test_fixed_modes_native_calls_and_all_text_and_nontext_tuples(self):
  m=json.loads(Path('tmp/narrow-round-profile/fresh/evaluation-manifest.json').read_text());xs=m['inputs'];self.assertEqual(len(xs),8064);self.assertEqual(len({x['id']for x in xs}),8064);self.assertEqual(len(m['native_records']),648);self.assertEqual(sum(x['engine']=='freetype'for x in m['native_records']),216)
  modes=[('freetype',None),('coretext',0),('coretext',1)];text={(x['engine'],x['palt'],x['body_id'],x['font'],x['size'],x['body_spaces'],x['closer'],x['leading'],x['spaces'],x['paper'],x['format'])for x in xs if x['kind']=='text'};expected={(engine,palt,*rest)for(engine,palt)in modes for rest in itertools.product(range(2),['maru','gothic','mincho'],[20,28],[0,1],[')','\uff09'],[False,True],[0,1],[0,2,10],['png','jpeg75'])};self.assertEqual(text,expected)
  noise={(x['engine'],x['palt'],x['body_id'],x['font'],x['size'],x['body_spaces'],x['shape'],x['leading'],x['gap'],x['format'])for x in xs if x['kind']=='noise'};expected={(engine,palt,*rest)for(engine,palt)in modes for rest in itertools.product(range(2),['maru','gothic','mincho'],[20,28],[0,1],['none','thin','bar','dot','diagonal','chevron','left_curve','fork'],[False,True],[0,1],['png','jpeg75'])};self.assertEqual(noise,expected)
if __name__=='__main__':unittest.main()
