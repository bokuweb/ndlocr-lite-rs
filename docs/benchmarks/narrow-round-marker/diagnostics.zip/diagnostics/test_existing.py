from pathlib import Path
import json,unittest
class Replay(unittest.TestCase):
 def test_all_frozen_baselines_and_candidate_records_are_present(self):
  r=Path('tmp/narrow-round-profile');m=json.loads((r/'manifest.json').read_text());xs=m['cases'];rows=json.loads((r/'replay/records.json').read_text());self.assertEqual(len(xs),137991);self.assertEqual(len(rows),137991);refs={(x['corpus'],x['model'],x['id']):x for x in xs};self.assertEqual(len(refs),137991)
  for x in rows:
   y=refs[x['corpus'],x['model'],x['id']];self.assertEqual(x['raw'],y['raw']);self.assertEqual(x['baseline'],y['expected_after']);self.assertEqual(x['selected'],x['baseline']!=x['candidate'])
if __name__=='__main__':unittest.main()
