from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots=[Path('tmp/closer-bridge'),Path('tmp/detached-body')];frozen={}
for root in roots:
 assert(root/'target/CACHEDIR.TAG').read_text().startswith('Signature: 8a477f597d28d172789f06886806bc55')
 for p in root.iterdir():
  if p.is_file()and (p.name.endswith('-binary')or p.name.endswith('-command.json')):frozen[str(p)]=sha(p)
assert len(frozen)>8
record={'removed_only_old_cargo_build_caches':[str(p/'target')for p in roots],'all_frozen_binary_and_command_sha256':frozen,'reason':'reserve capacity for independent full evidence restoration; active workspace target and green native target retained','source_models_raw_media_and_frozen_binaries_preserved':True};(r/'build-cache-cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
for root in roots:shutil.rmtree(root/'target');print('Removed old rebuildable Cargo cache',root/'target',flush=True)
assert all(sha(Path(p))==s for p,s in frozen.items())
