from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/narrow-round-profile');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=json.loads((r/'verification-command.json').read_text());sources={};changed=[]
for path,expected in old['source_sha256'].items():
 p=Path(path)
 if p.suffix!='.rs'and p.name not in ['Cargo.toml','Cargo.lock']:continue
 before=(r/'verification-source'/path).read_bytes();assert hashlib.sha256(before).hexdigest()==expected;after=p.read_bytes()
 if after!=before:
  assert path=='src/infer/visible_repetitions/narrow_round_marker.rs';assert after.count(b'rgb.chunks_mut(3)')==2;assert after.replace(b'rgb.chunks_mut(3)',b'rgb.chunks_exact_mut(3)')==before
  marker=b'#[cfg(test)]\nmod tests';assert before[:before.index(marker)]==after[:after.index(marker)];changed.append(path)
 target=r/'checked-source'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);sources[path]=sha(p)
assert len(changed)==1
xs=[json.loads(x)for x in(r/'clippy-after-tests.log').read_text().splitlines()if x.startswith('{')];assert any(x.get('reason')=='build-finished'and x.get('success')for x in xs)
assert not json.loads((r/'clippy-audit-final.json').read_text())['new_warnings'];assert '1 passed; 0 failed'in(r/'test-loop-green.stdout').read_text()
record={'source_sha256':sources,'measured_native_source_record_sha256':sha(r/'verification-command.json'),'all_runtime_rust_bytes_equal_measured_sources':True,'only_differences':'Two chunks_exact_mut(3) to chunks_mut(3) substitutions inside the existing RGB-sum test; the fixture RGB length is divisible by3. No runtime or public API test changes.','changed_test_source_files':changed,'clippy_build_log_sha256':sha(r/'clippy-after-tests.log'),'focused_test_stdout_sha256':sha(r/'test-loop-green.stdout'),'new_clippy_warnings':0};(r/'checked-source-command.json').write_text(json.dumps(record,indent=2)+'\n');print(len(sources),'final Rust/Cargo sources frozen; runtime byte-identical to measured native and CLI snapshots')
