from pathlib import Path
import copy,json,unittest
from portable_native import verify_native_trace
class PortableNativeTests(unittest.TestCase):
 def setUp(self):
  r=Path('tmp/narrow-round-profile/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());self.records={}
  for engine in ['freetype','coretext']:
   rec=next(x for x in m['native_records']if x['engine']==engine);trace=json.loads((r/'native'/(rec['id']+'.json')).read_text());self.records[engine]=(rec,trace,trace['text'])
 def test_actual_freetype_and_coretext_traces_pass_without_font_files(self):
  for engine,args in self.records.items():
   with self.subTest(engine=engine):verify_native_trace(*args)
 def test_wrong_native_text_or_freetype_missing_glyph_and_prefix_count_reject(self):
  rec,trace,text=self.records['freetype']
  for mutate in [lambda t:t.update(text='wrong'),lambda t:t['glyph_masks'][0].update(different_from_missing_glyph=False),lambda t:t['prefix_lengths'].pop()]:
   bad=copy.deepcopy(trace);mutate(bad)
   with self.assertRaises(AssertionError):verify_native_trace(rec,bad,text)
 def test_wrong_palt_fallback_font_and_zero_glyph_reject(self):
  rec,trace,text=self.records['coretext']
  for mutate in [lambda t:t.update(palt=1-t['palt']),lambda t:t['runs'][0].update(font_file='/a/different/font.ttc'),lambda t:t['runs'][0]['glyphs'].__setitem__(0,0),lambda t:t['runs'][0]['string_indices'].pop()]:
   bad=copy.deepcopy(trace);mutate(bad)
   with self.assertRaises(AssertionError):verify_native_trace(rec,bad,text)
if __name__=='__main__':unittest.main()
