def require_adoption_gates(old,fresh,horizontal):
 for name,audit in [('old',old),('fresh',fresh),('horizontal',horizontal)]:
  assert not audit['char_regressions'] and not audit['word_regressions'],name+' metric regression; reject frozen candidate without retuning'
 unseen=sum(x['changes'] for x in fresh['summary'] if x['group']=='unseen' and x['normalization']=='none')
 assert unseen>0,'no actual unseen RGB application; do not adopt'
 return unseen
