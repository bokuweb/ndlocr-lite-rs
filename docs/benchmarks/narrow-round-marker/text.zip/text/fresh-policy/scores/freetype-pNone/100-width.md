# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2688`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2688 | 0 | 0.4489 | 0.8173 |
| baseline | 2688 | 0 | 0.4492 | 0.8179 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
