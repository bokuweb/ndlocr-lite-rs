# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2688`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2688 | 0 | 0.4446 | 0.8262 |
| baseline | 2688 | 0 | 0.4451 | 0.8270 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
