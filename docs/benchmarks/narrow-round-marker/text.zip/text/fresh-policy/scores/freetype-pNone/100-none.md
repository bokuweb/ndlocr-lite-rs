# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2688`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2688 | 0 | 0.4686 | 0.8331 |
| baseline | 2688 | 0 | 0.4690 | 0.8338 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
