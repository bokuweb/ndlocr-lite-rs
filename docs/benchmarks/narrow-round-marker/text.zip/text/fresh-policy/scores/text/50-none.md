# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `3456`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3456 | 0 | 0.4672 | 0.9068 |
| baseline | 3456 | 0 | 0.4675 | 0.9074 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
