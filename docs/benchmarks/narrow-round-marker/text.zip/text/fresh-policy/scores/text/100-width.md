# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `3456`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3456 | 0 | 0.4356 | 0.8785 |
| baseline | 3456 | 0 | 0.4358 | 0.8789 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
