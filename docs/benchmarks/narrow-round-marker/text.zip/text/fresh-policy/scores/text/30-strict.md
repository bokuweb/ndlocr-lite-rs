# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `3456`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 3456 | 0 | 0.2642 | 0.5576 |
| candidate | 3456 | 0 | 0.2642 | 0.5576 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
