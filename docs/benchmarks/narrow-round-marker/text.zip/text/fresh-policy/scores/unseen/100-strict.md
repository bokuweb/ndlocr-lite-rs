# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `7776`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 7776 | 0 | 0.2822 | 0.4554 |
| candidate | 7776 | 0 | 0.2822 | 0.4554 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
