# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `7776`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 7776 | 0 | 0.4901 | 0.8701 |
| baseline | 7776 | 0 | 0.4903 | 0.8704 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
