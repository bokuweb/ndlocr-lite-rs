# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `8064`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 8064 | 0 | 0.4031 | 0.8436 |
| baseline | 8064 | 0 | 0.4033 | 0.8439 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
