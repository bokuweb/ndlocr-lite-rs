# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `8064`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 8064 | 0 | 0.3643 | 0.8263 |
| baseline | 8064 | 0 | 0.3645 | 0.8266 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
