# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `8064`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 8064 | 0 | 0.1450 | 0.2758 |
| candidate | 8064 | 0 | 0.1450 | 0.2758 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
