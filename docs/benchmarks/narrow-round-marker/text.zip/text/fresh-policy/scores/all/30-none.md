# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `8064`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 8064 | 0 | 0.4331 | 0.8514 |
| baseline | 8064 | 0 | 0.4333 | 0.8517 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
