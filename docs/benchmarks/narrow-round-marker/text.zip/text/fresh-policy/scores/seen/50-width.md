# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `288`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 288 | 0 | 0.2444 | 0.7130 |
| candidate | 288 | 0 | 0.2444 | 0.7130 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
