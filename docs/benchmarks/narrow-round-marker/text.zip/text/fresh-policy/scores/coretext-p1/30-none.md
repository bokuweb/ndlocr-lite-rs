# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2688`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 2688 | 0 | 0.4295 | 0.8644 |
| candidate | 2688 | 0 | 0.4295 | 0.8644 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
