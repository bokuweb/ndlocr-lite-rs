# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `4608`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 4608 | 0 | 0.3262 | 0.7804 |
| candidate | 4608 | 0 | 0.3262 | 0.7804 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
