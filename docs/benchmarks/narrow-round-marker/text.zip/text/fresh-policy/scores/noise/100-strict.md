# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `4608`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 4608 | 0 | 0.2394 | 0.3312 |
| candidate | 4608 | 0 | 0.2394 | 0.3312 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
