# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2688`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 2688 | 0 | 0.4485 | 0.8637 |
| candidate | 2688 | 0 | 0.4485 | 0.8637 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
