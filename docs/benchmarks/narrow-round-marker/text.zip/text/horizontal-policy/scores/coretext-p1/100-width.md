# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `86`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 86 | 0 | 0.2619 | 0.7623 |
| candidate | 86 | 0 | 0.2619 | 0.7623 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
