# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `86`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 86 | 0 | 0.2449 | 0.8197 |
| candidate | 86 | 0 | 0.2449 | 0.8197 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
