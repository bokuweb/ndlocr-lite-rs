# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `84`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 84 | 0 | 0.3733 | 0.7984 |
| baseline | 84 | 0 | 0.3801 | 0.8145 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
