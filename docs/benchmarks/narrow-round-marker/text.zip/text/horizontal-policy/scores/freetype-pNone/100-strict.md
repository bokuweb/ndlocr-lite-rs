# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `84`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 84 | 0 | 0.2333 | 0.3452 |
| candidate | 84 | 0 | 0.2333 | 0.3452 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
