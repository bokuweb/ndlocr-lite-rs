# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `84`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 84 | 0 | 0.4315 | 0.7742 |
| baseline | 84 | 0 | 0.4384 | 0.7903 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
