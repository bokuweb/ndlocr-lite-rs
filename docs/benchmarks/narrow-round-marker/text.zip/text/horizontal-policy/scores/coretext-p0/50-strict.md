# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `74`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 74 | 0 | 0.0750 | 0.1622 |
| candidate | 74 | 0 | 0.0750 | 0.1622 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
