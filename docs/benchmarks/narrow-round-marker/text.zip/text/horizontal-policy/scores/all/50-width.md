# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `244`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 244 | 0 | 0.2500 | 0.7219 |
| baseline | 244 | 0 | 0.2524 | 0.7275 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
