# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `244`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 244 | 0 | 0.2855 | 0.8062 |
| baseline | 244 | 0 | 0.2879 | 0.8118 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
