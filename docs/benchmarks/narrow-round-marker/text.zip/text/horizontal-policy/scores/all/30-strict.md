# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `244`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 244 | 0 | 0.1828 | 0.3115 |
| candidate | 244 | 0 | 0.1828 | 0.3115 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
