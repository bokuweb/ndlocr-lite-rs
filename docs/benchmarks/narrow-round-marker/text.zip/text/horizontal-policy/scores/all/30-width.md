# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `244`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 244 | 0 | 0.3128 | 0.7612 |
| baseline | 244 | 0 | 0.3152 | 0.7669 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
