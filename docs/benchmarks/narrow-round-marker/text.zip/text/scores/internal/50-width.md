# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `5088`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 5088 | 0 | 0.5682 | 0.8571 |
| candidate | 5088 | 0 | 0.5682 | 0.8571 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
