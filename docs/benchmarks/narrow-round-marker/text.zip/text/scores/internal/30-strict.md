# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `5088`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 5088 | 0 | 0.5197 | 0.8673 |
| candidate | 5088 | 0 | 0.5197 | 0.8673 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
