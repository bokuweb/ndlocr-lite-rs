# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `10944`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 10944 | 0 | 0.5318 | 0.9257 |
| candidate | 10944 | 0 | 0.5318 | 0.9257 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
