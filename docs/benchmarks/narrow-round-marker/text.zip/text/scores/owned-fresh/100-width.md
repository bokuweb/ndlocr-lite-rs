# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `7632`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 7632 | 0 | 0.5610 | 0.8995 |
| baseline | 7632 | 0 | 0.5612 | 0.8999 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
