# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `7632`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 7632 | 0 | 0.2953 | 0.6542 |
| candidate | 7632 | 0 | 0.2953 | 0.6542 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
