def unique(rows):
    result = {}
    for row in rows:
        if row['id'] in result:
            raise ValueError('duplicate ID')
        result[row['id']] = row
    return result


def paired_rows(auto_inputs, horizontal_inputs, auto_rows, horizontal_rows):
    a, h, ar, hr = map(unique, [auto_inputs, horizontal_inputs, auto_rows, horizontal_rows])
    if not (set(a) == set(h) == set(ar) == set(hr)):
        raise ValueError('unmatched IDs')
    result = []
    for id in sorted(a):
        x, y = a[id], h[id]
        if any(x[k] != y[k] for k in ['width', 'height', 'rgb_sha256', 'truth_sha256']):
            raise ValueError('different source')
        w, ht = x['width'], x['height']
        if not x['rotated_for_auto'] or not 5 * ht > 4 * w:
            raise ValueError('not Auto rotated')
        if (x['forward_width'], x['forward_height']) != (ht, w) or (y['forward_width'], y['forward_height']) != (w, ht):
            raise ValueError('incorrect forward geometry')
        result.append((id, ar[id]['text'], hr[id]['text']))
    return result
