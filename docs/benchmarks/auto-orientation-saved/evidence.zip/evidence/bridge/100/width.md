# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `128`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| horizontal | 128 | 0 | 0.0312 | 0.0938 |
| auto | 128 | 0 | 1.3281 | 1.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

