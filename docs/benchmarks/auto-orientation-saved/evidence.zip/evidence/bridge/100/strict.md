# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `128`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| horizontal | 128 | 0 | 0.0893 | 0.2344 |
| auto | 128 | 0 | 1.1726 | 1.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

