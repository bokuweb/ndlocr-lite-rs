# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1271`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 1271 | 0 | 0.6179 | 0.8425 |
| before | 1271 | 0 | 0.6195 | 0.8553 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
