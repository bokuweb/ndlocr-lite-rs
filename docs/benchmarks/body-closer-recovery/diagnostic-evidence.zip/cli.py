from pathlib import Path
import hashlib,json,zipfile,os,sys,subprocess,concurrent.futures,collections
r=Path('tmp/body-closer-recovery');phase=sys.argv[1];m=json.loads((r/'evaluation-manifest.json').read_text());inputs={x['id']:x for x in m['inputs']};models={f'single{n}':next(p for p in m['models']if f'-{n}-tiny-'in p)for n in [30,50,100]};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if phase=='before':
 b=json.loads((r/'before-records.json').read_text());jobs=set()
 for model in b['models']:
  for row in model['rows']:
   if row['baseline']!=row['closer_body']:jobs.add((model['label'],row['id']))
 parent=Path('docs/benchmarks/closer-geometry-probe');index=json.loads((parent/'diagnostic-evidence.json').read_text());assert sha(parent/'diagnostic-evidence.zip')==index['sha256']
 with zipfile.ZipFile(parent/'diagnostic-evidence.zip')as z:
  data=z.read('audit.json');assert hashlib.sha256(data).hexdigest()==index['members']['audit.json'];a=json.loads(data)
 for x in a['regressions']:
  if x['policy']=='no_space':jobs.add((x['model'],x['id']))
 groups=collections.defaultdict(list)
 for id,x in inputs.items():groups[x['cohort']].append(id)
 for label in models:
  for ids in groups.values():
   for id in sorted(ids)[:2]:jobs.add((label,id))
  for fmt in ['_png','_jpeg75']:
   id=next(id for id in sorted(inputs)if id.startswith('geometry_figure_')and id.endswith(fmt));jobs.add((label,id))
  for id,x in inputs.items():
   if x['kind']=='new_boundary':jobs.add((label,id))
 jobs=sorted(jobs);(r/'cli-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
else:jobs=json.loads((r/'cli-jobs.json').read_text())
binary=r/('baseline-ndlocr'if phase=='before'else'candidate-ndlocr');binary_sha=sha(binary)
if phase=='before':assert binary_sha==m['baseline_cli_binary_sha256']
def run(job):
 label,id=job;x=inputs[id];assert sha(x['image'])==x['image_sha256'];p=r/('cli-'+phase)/label/(id+'.txt');p.parent.mkdir(parents=True,exist_ok=True);argv=[str(binary.resolve()),'recognize','--model',models[label],'--image',x['image'],'--charset','models/NDLmoji.yaml'];o=subprocess.run(argv,capture_output=True,env={**os.environ,'NDLOCR_INTRA_THREADS':'1'});p.with_suffix('.stdout').write_bytes(o.stdout);p.with_suffix('.stderr').write_bytes(o.stderr);assert o.returncode==0,(argv,o.stderr);assert o.stdout.endswith(b'\n')and b'\n'not in o.stdout[:-1];body=o.stdout[:-1];p.write_bytes(body);expected=(r/phase/label/(id+'.txt')).read_bytes();assert body==expected,(phase,label,id,body,expected);return {'id':id,'mode':label,'argv':argv,'exit_code':o.returncode,'body_sha256':sha(p)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:records=list(pool.map(run,jobs))
(r/('cli-'+phase+'-runs.json')).write_text(json.dumps({'binary_sha256':binary_sha,'fresh_calls':len(records),'runs':records},indent=2)+'\n');print(phase,len(records),'fresh CLI bodies match actual API')
