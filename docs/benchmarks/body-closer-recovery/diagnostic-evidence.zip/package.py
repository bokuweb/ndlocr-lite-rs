from pathlib import Path
import json,hashlib,zipfile,shutil,collections
r=Path('tmp/body-closer-recovery');out=Path('docs/benchmarks/body-closer-recovery');out.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pack(stem,files):
 archive=out/(stem+'.zip');members={}
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,p in sorted(files.items()):
   data=Path(p).read_bytes();members[name]=hashlib.sha256(data).hexdigest();i=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,data,compresslevel=9)
 (out/(stem+'.json')).write_text(json.dumps({'sha256':sha(archive),'members':members},indent=2)+'\n')
 with zipfile.ZipFile(archive)as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(members)
  for name,h in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
 print(stem,len(members),'verified members',flush=True)
def under(names):return {str(p.relative_to(r)):p for name in names for p in(r/name).rglob('*')if p.is_file()}
m=json.loads((r/'evaluation-manifest.json').read_text());before=json.loads((r/'baseline-test-binary.json').read_text());candidate=json.loads((r/'candidate-test-binary.json').read_text());cli=json.loads((r/'candidate-cli-binary.json').read_text());portable=json.loads((r/'portable-test-binary.json').read_text());assert [p for p,h in candidate['source_sha256'].items()if h!=before['source_sha256'][p]]==['src/infer/visible_repetitions.rs']
for p,h in candidate['source_sha256'].items():assert sha(p)==h,p
for p,h in cli['source_sha256'].items():assert sha(p)==h,p
for p,h in m['models'].items():assert sha(p)==h,p
assert sha('models/NDLmoji.yaml')==m['charset_sha256']
for x in m['inputs']:assert sha(x['image'])==x['image_sha256']and sha(x['truth'])==x['truth_sha256']
assert sha(r/'baseline-visible.rs')==before['source_sha256']['src/infer/visible_repetitions.rs'];assert sha(r/'candidate-visible.rs')==candidate['source_sha256']['src/infer/visible_repetitions.rs'];assert sha(r/'baseline-driver.rs')==before['support_source_sha256']['tests/support/body_closer_recovery.rs'];assert sha(r/'candidate-driver.rs')==candidate['support_source_sha256']['tests/support/body_closer_recovery.rs']
for phase in ['before','after']:
 data=json.loads((r/('cli-'+phase+'-runs.json')).read_text());assert data['fresh_calls']==257
 for x in data['runs']:
  p=r/('cli-'+phase)/x['mode']/(x['id']+'.txt');assert sha(p)==x['body_sha256'];assert p.with_suffix('.stdout').read_bytes()==p.read_bytes()+b'\n';assert p.read_bytes()==(r/phase/x['mode']/p.name).read_bytes()
 m_phase=json.loads((r/('dispatch-'+phase+'-binary.json')).read_text());assert sha(r/'dispatch-cached-instrumented.rs')==m_phase['source_sha256']['src/infer/cached.rs'];assert sha(r/('dispatch-'+phase+'-visible.rs'))==m_phase['source_sha256']['src/infer/visible_repetitions.rs']
a=json.loads((r/'audit.json').read_text());assert a['comparisons']==11727 and not a['regressions']and not a['word_regressions'];assert not a['cascade_route_changes'];summary={'comparisons':11727,'native_comparisons':11439,'cascade_comparisons':288,'modes':a['summary'],'remaining':json.loads((r/'remaining.json').read_text()),'native_confidence_bits_unchanged':3813,'cascade_dispatch_histories_unchanged':96,'fresh_cli_each_phase':257};(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
m['baseline_test']=before;m['candidate_test']=candidate;m['candidate_cli']=cli;m['portable_test']=portable;m['score_script_sha256']=sha(r/'evaluate.py');m['score_tool_sha256']=sha('tools/eval_ocr_metrics.py');m['capture_manifest_before_sha256']=sha(r/'capture-manifest-before.json');m['spec_before_sha256']=sha(r/'spec-before.md');m['dispatch_observation']={'baseline_source_commit':m['baseline_commit'],'test_only_instrumentation_sha256':sha(r/'dispatch-instrumentation.patch'),'before_binary':json.loads((r/'dispatch-before-binary.json').read_text()),'after_binary':json.loads((r/'dispatch-after-binary.json').read_text()),'before_observed_sha256':sha(r/'before-dispatch-observed.json'),'after_observed_sha256':sha(r/'after-dispatch-observed.json'),'cargo_lock_sha256':sha(r/'dispatch-Cargo.lock'),'no_instrumentation_in_product':True};(r/'evaluation-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
for name in ['evaluation-manifest.json','summary.json','tests-summary.json','evaluate.py']:shutil.copy2(r/name,out/name)
files=under(['before','after','truth','cascade-truth','cli-before','cli-after']);files.update({name:r/name for name in ['before-dispatch-observed.json','after-dispatch-observed.json']});pack('text-evidence',files)
metrics={p.name:p for p in(r/'metrics').glob('*')};assert len(metrics)==36;pack('metrics',metrics)
diag=under(['inputs']);diag.update({p.name:p for p in r.iterdir()if p.is_file()and p.suffix in ['.json','.jsonl','.log','.py','.rs','.md','.patch','.lock']and p.name not in ['evaluation-manifest.json','summary.json','tests-summary.json','package.log','package-final.log']})
for name in ['src/infer/visible_repetitions.rs','tests/support/visible_repetitions_policy.rs','tests/support/body_closer_recovery.rs','tests/support/closer_geometry_probe.rs','tests/body_closer_boundary_fixture_tests.rs','docs/body_closer_recovery.md','tools/eval_ocr_metrics.py']:
 diag['source/'+name]=Path(name)
pack('diagnostic-evidence',diag)
s=Path('docs/benchmarks/closer-geometry-probe/unpack_evidence.py').read_text();s=s.replace("unpack(directory, 'diagnostic-evidence', args.output / 'diagnostics')", "unpack(directory, 'diagnostic-evidence', args.output / 'diagnostics')\n        (args.output / 'diagnostics' / 'evaluation-manifest.json').write_bytes((directory / 'evaluation-manifest.json').read_bytes())");(out/'unpack_evidence.py').write_text(s)
print(json.dumps(summary,indent=2))
