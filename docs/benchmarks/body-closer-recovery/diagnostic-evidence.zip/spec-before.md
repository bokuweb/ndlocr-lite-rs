# 本文の整列を保ちながら低い閉じ括弧を単行APIで回復する

## 実装前仕様

9f6a5e2のtest-only診断 `docs/closer_geometry_probe.md` では、固定1239画像×3モデルの
3717本文組に対する11151文字/単語指標が非悪化の `closer_body` 案を得た。
64完全一致改善・3626byte同一・27生距離同値変更で、元の未回復80組中44と新対照20を含む。
本段階は、この方針を実際の画像付き単行APIとCLIへ適用し、全件で確認する。

現在の単行結果と同じ/短いfragment、空白あり、縦向きAuto、不正RGBは従来結果を保持する。
従来の独立成分数・共通高さ支持が満たされれば既存の回復も維持する。
従来支持がなくても、x順の成分とfragment字数が一致し重ならず、本文が2成分以上あり、
本文の共通高さ>=本文最大高さの3/4を保ち、closer高さ>=本文最大の1/2かつ
本文の共通区間との交差>=min(closer高さ,本文最大)の3/4なら元fragmentを保持する。
全成分の幅<=本文最大高さの2倍を要求する。対象closerは既存の5種だけで文書種類に依存しない。
RGB和<660・8連結・area>=3かつ>=ceil(最大高さ/2)の抽出と、従来支持の数式を変えない。
shared抽出を両方針で共用し、ページfragment/反復には従来の厳密な高さ条件を適用し続ける。

文字の推測挿入/置換、追加モデル・forwardは行わない。原RGBとconfidenceを保持する。
text-only/raw/候補API・Pool Auto・option・失敗時の再利用とページ経路を維持する。
同値変更を改善と数えず、診断の64件を製品で回復済みと扱わずに先にRedを確認する。

低いcloserのprefix/suffix/internalの純粋Red、本文のずれ/小さすぎるcloser/間違う数/空白/方向/RGBの負例と
拡大/移動/明度PBTを先行し、実画像の公開APIもRed→Greenで確認する。
全1239×3のbefore/afterを実Session APIで新規実行し、保存rawのconfidenceと期待baseline/候補の全byteを照合する。
before/afterそれぞれ実行前にbinaryとsource/driver SHAを凍結する。
実APIの全11151文字/単語指標が非悪化であり、全fragmentと従来成分支持の再生が不変なことを要求する。
ページ全287×6を今回新規実行する主張はせず、sourceの到達性・従来方針の再生と既存実ページ回帰で検査する。

CLIは全ての変更91組と、空白なし一律案の全退行反例、各model/cohortで先頭2対照、図形の各形式1例を
前後とも新規実行し、APIの全字列と照合する。stdoutから終端LFを厳密に1個だけ除く。
公開stateless/Session/Pool、batch/単一Session batch/cascade、raw/候補・不正入力後の再利用も検査する。
全表・失敗案・source/binary/model/input SHAを保存し、別rootで再採点・方針再生を確認する。

この回復後も原rawの正読を壊す265組（成分数216、x重複47、eligible除外2）が残る。
成分と文字の対応、複数成分/接触・空白の別施策を後続で調べ、全体目的をこの64組へ限定しない。

## 前後API捕捉前のCascade境界追加

呼出sourceの確認で、単行の文字数回復が公開Cascadeの25/45字の再認識条件をまたぐ可能性を確認した。
OCR前に23/24/43/44字のASCII大文字alphabet巡回＋ `」/』` の8文字列を、角ゴシック/明朝28px・
PNG/JPEG75・余白8pxで32画像に固定する。truth/画像は結果で変更しない。通常fixture Red→Greenを先行する。
単行は全1271画像×3モデル×3正規化=11439比較へ拡張し、境界32×3開始bucket×3正規化のCascade288比較も加える。
全11727文字・単語指標の非悪化を要求し、Cascadeの実際の経路変更数と出力を別に記録する。
新32×3 rawの96 forwardはbeforeから記録し、既存の固定prototype方針から予測を得る。
単行before/after各3813 APIを新規実行し、Cascadeも前後各96入力を新規実行する。
CLIは上の対照集合へ新境界32×3を全て加える。先行1239画像での効果と追加32画像を分けて採点する。
