from pathlib import Path
import subprocess,tarfile,io,shutil,os,json,hashlib
root=Path.cwd();r=root/'tmp/body-closer-recovery';work=r/'dispatch-source';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();work.mkdir(exist_ok=True);manifest=json.loads((r/'evaluation-manifest.json').read_text());data=subprocess.check_output(['git','archive',manifest['baseline_commit'],'Cargo.toml','src','tests/support','examples','benches','tests/fixtures/line_segment/jma-notice-body.png'])
with tarfile.open(fileobj=io.BytesIO(data))as archive:
 for member in archive.getmembers():
  p=Path(member.name);assert not p.is_absolute()and'..'not in p.parts and not member.issym()and not member.islnk();archive.extract(member,work)
shutil.copy2(root/'Cargo.lock',work/'Cargo.lock');shutil.copy2(root/'Cargo.lock',r/'dispatch-Cargo.lock');
if not(work/'models').exists():(work/'models').symlink_to(root/'models',target_is_directory=True)
assert(work/'models').resolve()==(root/'models').resolve()
shutil.copy2(r/'dispatch_probe.rs',work/'tests/support/dispatch_probe.rs');visible=work/'src/infer/visible_repetitions.rs';old_visible=visible.read_text();tail='\n#[cfg(all(test, feature = "onnx"))]\n#[path = "../../tests/support/dispatch_probe.rs"]\nmod dispatch_probe;\n';visible.write_text(old_visible+tail);cached=work/'src/infer/cached.rs';original=cached.read_text();stub='\n#[cfg(test)]\npub(crate) fn take_cascade_dispatch_models() -> Vec<Vec<u16>> { Vec::new() }\n';cached.write_text(original+stub)
def build(name):
 with(r/(name+'-build.jsonl')).open('w')as out,(r/(name+'-build.log')).open('w')as err:p=subprocess.run(['cargo','test','--features','onnx','--lib','--no-run','--message-format=json'],cwd=work,env={**os.environ,'CARGO_TARGET_DIR':str(root/'target')},stdout=out,stderr=err)
 assert p.returncode==0,name
 rows=[json.loads(s)for s in(r/(name+'-build.jsonl')).read_text().splitlines()];a=[x for x in rows if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['kind']==['lib']][-1];dest=r/(name+'-binary');shutil.copy2(a['executable'],dest);(r/(name+'-binary.json')).write_text(json.dumps({'binary_sha256':sha(dest),'source_sha256':{str(p.relative_to(work)):sha(p)for p in work.rglob('*.rs')}},indent=2)+'\n');return dest

def run(binary,phase,log):
 with(r/log).open('w')as f:p=subprocess.run([str(binary),'infer::visible_repetitions::dispatch_probe::record_actual_cascade_dispatch','--exact','--include-ignored'],cwd=work,env={**os.environ,'NDLOCR_DISPATCH_ROOT':str(r),'NDLOCR_DISPATCH_PHASE':phase,'NDLOCR_DISPATCH_REPOSITORY_ROOT':str(root),'NDLOCR_INTRA_THREADS':'1'},stdout=f,stderr=subprocess.STDOUT)
 return p.returncode
binary=build('dispatch-red');assert run(binary,'before','dispatch-red.log')!=0
patched=original.replace('        all.extend(r30?);','''        #[cfg(test)]
        let mut traced_models=vec![Vec::<u16>::new();items.len()];
        #[cfg(test)] if let Ok(values)=&r30 {for (i,_)in values {traced_models[*i].push(30);}}
        #[cfg(test)] if let Ok(values)=&r50 {for (i,_)in values {traced_models[*i].push(50);}}
        #[cfg(test)] if let Ok(values)=&r100 {for (i,_)in values {traced_models[*i].push(100);}}
        all.extend(r30?);''',1)
patched=patched.replace('            for (i, r) in rd50? {','            for (i, r) in rd50? {\n                #[cfg(test)] {traced_models[i].push(50);}',1).replace('                        all[i].1 = rr;','                        all[i].1 = rr;\n                        #[cfg(test)] {traced_models[i].push(100);}',1).replace('            for (i, r) in rd100? {','            for (i, r) in rd100? {\n                #[cfg(test)] {traced_models[i].push(100);}',1).replace('        Ok(all.into_iter().map(|(_, r)| r).collect())','        #[cfg(test)] CASCADE_DISPATCH_MODELS.with(|value| {value.replace(traced_models);});\n        Ok(all.into_iter().map(|(_, r)| r).collect())',1)
patched+='''
#[cfg(test)]
thread_local! { static CASCADE_DISPATCH_MODELS: std::cell::RefCell<Vec<Vec<u16>>> = const {std::cell::RefCell::new(Vec::new())}; }
#[cfg(test)]
pub(crate) fn take_cascade_dispatch_models() -> Vec<Vec<u16>> { CASCADE_DISPATCH_MODELS.with(|value|std::mem::take(&mut *value.borrow_mut())) }
''';assert patched!=original;cached.write_text(patched);(r/'dispatch-cached-instrumented.rs').write_text(patched);(r/'dispatch-instrumentation.patch').write_text(subprocess.run(['git','diff','--no-index','--','/dev/null',str(cached)],capture_output=True,text=True).stdout)
binary=build('dispatch-before');assert run(binary,'before','dispatch-before.log')==0
current=(root/'src/infer/visible_repetitions.rs').read_text();prefix=current[:current.index('\n#[cfg(test)]')];old_tail=old_visible[old_visible.index('\n#[cfg(test)]'):];visible.write_text(prefix+old_tail+tail);(r/'dispatch-after-visible.rs').write_text(visible.read_text());binary=build('dispatch-after');assert run(binary,'after','dispatch-after.log')==0
before=json.loads((r/'before-dispatch-observed.json').read_text());after=json.loads((r/'after-dispatch-observed.json').read_text());assert len(before)==len(after)==96;changes=[{'before':b,'after':a}for b,a in zip(before,after)if b['model_history']!=a['model_history']];(r/'dispatch-audit.json').write_text(json.dumps({'inputs_each':96,'actual_model_history_changes':changes,'observed_at_pool_result_receipts':True,'all_outputs_and_confidence_match_original_capture':True},indent=2)+'\n');print('observed actual96 dispatch histories per phase; changes',len(changes))
