from pathlib import Path
import json,hashlib,zipfile,sys
r=Path('tmp/internal-detached');out=Path('docs/benchmarks/internal-detached-closer');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 if len(sys.argv)>1 and name not in sys.argv[1:]:return
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 index={'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members};(out/(name+'.json')).write_text(json.dumps(index,indent=2)+'\n');print(name,len(members),len(aliases),(out/(name+'.zip')).stat().st_size,flush=True)
images=[];inputs=[]
for folder in ['fresh','horizontal']:
 f=r/folder
 for sub in ['native','original','png','rgb','effective','truth']:
  if(f/sub).exists():images.extend(('data/'+str(p.relative_to(r)),p)for p in(f/sub).rglob('*')if p.is_file())
 for name in ['atlas.png','lines.json','evaluation-manifest.json','contact-shapes.png','contact-shapes.json','tensor-proof.json']:
  p=f/name
  if p.exists():images.append(('data/'+str(p.relative_to(r)),p))
 if(f/'whole-rgb-capture').exists():inputs.extend(('data/'+str(p.relative_to(r)),p)for p in(f/'whole-rgb-capture').rglob('*')if p.is_file())
packet('images',images);packet('inputs',inputs)
diag=[];text=[]
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.py','.md','.rs','.log','.stdout','.stderr','.swift'] and not p.name.startswith('package-'):
  diag.append(('diagnostics/'+p.name,p))
for folder in ['probe-source','tensor-source','integration-red-source','integration-green-source','verification-source']:
 for p in(r/folder).rglob('*'):
  if p.is_file():diag.append(('diagnostics/'+str(p.relative_to(r)),p))
for folder in ['fresh','horizontal']:
 for p in(r/folder).iterdir():
  if p.is_file()and p.suffix in ['.json','.stdout','.stderr']:diag.append(('diagnostics/'+str(p.relative_to(r)),p))
 for p in(r/folder/'export-source').rglob('*'):
  if p.is_file():diag.append(('diagnostics/'+str(p.relative_to(r)),p))
for folder in ['fresh-baseline','horizontal-baseline','fresh-policy','horizontal-policy']:
 for p in(r/folder).rglob('*'):
  if p.is_file()and p.suffix=='.json':diag.append(('diagnostics/'+str(p.relative_to(r)),p))
for p in(r/'fresh-initial-failed').rglob('*'):
 if p.is_file():diag.append(('diagnostics/generation-initial-failed/'+str(p.relative_to(r/'fresh-initial-failed')),p))
for key,p in [('specification.md',r/'capture-spec.md'),('integration-specification.md',r/'verification-source/docs/internal_detached_closer_integration.md'),('fixture/info_internal40.png',Path('tests/fixtures/internal_detached_closer/info_internal40.png')),('source/eval_ocr_metrics.py',Path('tools/eval_ocr_metrics.py')),('source/means.py',Path('tmp/punct-matched/means.py'))]:diag.append(('diagnostics/'+key,p))
if(r/'product-manifest.json').exists():
 m=json.loads((r/'product-manifest.json').read_text());portable=[]
 for x in m['cases']:
  corpus=x['corpus'];id=x['id']
  if corpus in ['old','spaces','fresh','horizontal']:path=f'parent/parent/data/rgb/{corpus}/{id}.rgb'
  elif corpus=='new':path=f'parent/initial/fresh/rgb/{id}.rgb'
  elif corpus in ['positive','positive-horizontal']:path=f'parent/positive/fresh/rgb/{id}.rgb'
  elif corpus in ['internal','internal-horizontal']:path=f'data/fresh/rgb/{id}.rgb'
  else:raise AssertionError(corpus)
  portable.append(x|{'rgb':path})
 p=r/'portable-cases.json';p.write_text(json.dumps({'cases':portable},ensure_ascii=False,indent=2)+'\n');diag=[(k,f)for k,f in diag if k!='diagnostics/portable-cases.json'];diag.append(('diagnostics/portable-cases.json',p))
for folder in ['scores','truth','replay','fresh-policy','horizontal-policy']:
 for p in(r/folder).rglob('*'):
  if p.is_file()and(p.suffix in ['.csv','.md','.txt']):text.append(('text/'+str(p.relative_to(r)),p))
for p in(r/'line-cli').rglob('*'):
 if p.is_file():text.append(('text/'+str(p.relative_to(r)),p))
packet('diagnostics',diag);packet('text',text)
parent=Path('docs/benchmarks/detached-body-components');names=['initial-images','initial-inputs','positive-images','positive-inputs','diagnostics','text'];parents={'packet':'detached-body-components','reproducer_sha256':sha((parent/'reproduce.py').read_bytes()),'archives':{n:json.loads((parent/(n+'.json')).read_text())['sha256']for n in names},'nested_parents_json_sha256':sha((parent/'parents.json').read_bytes())};(out/'parents.json').write_text(json.dumps(parents,indent=2)+'\n')
