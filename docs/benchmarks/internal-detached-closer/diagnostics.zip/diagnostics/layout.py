from PIL import Image, ImageChops

def choose_cut(im):
    box=ImageChops.difference(im,Image.new('RGB',im.size,'white')).getbbox()
    if box is None:
        raise ValueError('blank body')
    white=[x for x in range(box[0]+1,box[2]-1)if all(im.getpixel((x,y))==(255,255,255)for y in range(im.height))]
    if white:
        return min(white,key=lambda x:(abs(2*x+1-box[0]-box[2]),x)),'white'
    return (box[0]+box[2])//2,'bbox-center'
