import Foundation
import CoreText
import CoreGraphics
import ImageIO

let args = CommandLine.arguments
let url = URL(fileURLWithPath: args[1])
let size = Double(args[2])!
let palt = Int(args[3])!
let text = args[4]
let destination = URL(fileURLWithPath: args[5])
let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as! [CTFontDescriptor]
let settings = [[kCTFontOpenTypeFeatureTag as String: "palt",
                 kCTFontOpenTypeFeatureValue as String: palt]] as [[String: Any]]
let descriptor = CTFontDescriptorCreateCopyWithAttributes(descriptors[0], [kCTFontFeatureSettingsAttribute as String: settings] as CFDictionary)
let font = CTFontCreateWithFontDescriptor(descriptor, size, nil)
let attrs: [NSAttributedString.Key: Any] = [NSAttributedString.Key(kCTFontAttributeName as String): font,
    NSAttributedString.Key(kCTForegroundColorAttributeName as String): CGColor(gray: 0, alpha: 1)]
let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attrs))
let bounds = CTLineGetBoundsWithOptions(line, [.useGlyphPathBounds])
let w = Int(ceil(bounds.maxX) - floor(bounds.minX)) + 12
let h = Int(ceil(bounds.maxY) - floor(bounds.minY)) + 12
let context = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
context.setFillColor(CGColor(gray: 1, alpha: 1)); context.fill(CGRect(x: 0, y: 0, width: w, height: h))
context.textPosition = CGPoint(x: 6 - floor(bounds.minX), y: 6 - floor(bounds.minY))
CTLineDraw(line, context)
let image = context.makeImage()!
let writer = CGImageDestinationCreateWithURL(destination as CFURL, "public.png" as CFString, 1, nil)!
CGImageDestinationAddImage(writer, image, nil)
guard CGImageDestinationFinalize(writer) else { fatalError("PNG write failed") }
let runs = CTLineGetGlyphRuns(line) as! [CTRun]
var traces: [[String: Any]] = []
for run in runs {
    let n = CTRunGetGlyphCount(run)
    var glyphs = [CGGlyph](repeating: 0, count: n)
    var positions = [CGPoint](repeating: .zero, count: n)
    var advances = [CGSize](repeating: .zero, count: n)
    var indices = [CFIndex](repeating: 0, count: n)
    CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
    CTRunGetPositions(run, CFRange(location: 0, length: 0), &positions)
    CTRunGetAdvances(run, CFRange(location: 0, length: 0), &advances)
    CTRunGetStringIndices(run, CFRange(location: 0, length: 0), &indices)
    let attributes = CTRunGetAttributes(run) as NSDictionary
    let actual = attributes[kCTFontAttributeName] as! CTFont
    traces.append(["font": CTFontCopyPostScriptName(actual) as String,
        "font_file": (CTFontCopyAttribute(actual, kCTFontURLAttribute) as! URL).path,
        "glyphs": glyphs, "positions": positions.map { [$0.x, $0.y] },
        "advances": advances.map { [$0.width, $0.height] }, "string_indices": indices])
}
let record: [String: Any] = ["text": text, "palt": palt, "size": size,
    "font": CTFontCopyPostScriptName(font) as String,
    "font_file": (CTFontCopyAttribute(font, kCTFontURLAttribute) as! URL).path,
    "width": w, "height": h, "typographic_width": CTLineGetTypographicBounds(line, nil, nil, nil), "runs": traces]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys]))
