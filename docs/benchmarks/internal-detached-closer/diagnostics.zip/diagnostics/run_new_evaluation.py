from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('tmp/internal-detached');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
folder=sys.argv[1];assert folder in ['fresh','horizontal']
py='/Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
scripts=['assemble_fresh.py','assemble_candidate.py','score_fresh.py']if folder=='fresh'else['assemble_horizontal.py','assemble_horizontal_candidate.py','score_horizontal.py']
(r/(folder+'-evaluation-command.json')).write_text(json.dumps({'driver_sha256':sha(__file__),'scripts_sha256':{s:sha(r/s)for s in scripts},'scorer_sha256':sha('tools/eval_ocr_metrics.py'),'means_helper_sha256':sha('tmp/punct-matched/means.py'),'no_additional_nn_forwards':True},indent=2)+'\n')
def execute(name,argv,env={}):
 cmd=r/(name+'-command.json');assert not cmd.exists();record={'argv':argv,'env':env};cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as stdout,(r/(name+'.stderr')).open('wb')as stderr:d=subprocess.run(argv,env=os.environ|env,stdout=stdout,stderr=stderr)
 record['exit_code']=d.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert d.returncode==0,name;print(name,'terminal success',flush=True)
def script(name):execute(folder+'-script-'+name,[py,str(r/name)])
def saved(name,path):
 m=json.loads(path.read_text());execute(name,m['argv'],m['env'])
script(scripts[0]);saved(folder+'-current-baseline',r/(folder+'-baseline/baseline-command.json'));script(scripts[1]);saved(folder+'-candidate',r/(folder+'-policy/candidate-command.json'));script(scripts[2])
