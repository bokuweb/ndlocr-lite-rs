from pathlib import Path
from PIL import Image
import itertools,json,hashlib,unittest

class FreshControls(unittest.TestCase):
 def test_all_fixed_internal_spaces_shapes_and_original_auto_pixels(self):
  r=Path('tmp/internal-detached/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());rows=m['inputs'];self.assertEqual(len(rows),5088);self.assertEqual(len(m['native_commands']),1104);self.assertEqual(len({x['id']for x in rows}),5088)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[24,40],[0,1],[')','）','」','』','】'],[0,1,2],[0,1,2],[0,8],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['palt'],x['closer'],x['spaces_before'],x['spaces_after'],x['paper'],x['format'])for x in rows if x['kind']=='text'};self.assertEqual(actual,expected)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[24,40],[0,1],['none','thin','thick','dot'],[0,1],[0,8],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['palt'],x['shape'],x['gap'],x['paper'],x['format'])for x in rows if x['kind']=='noise'};self.assertEqual(actual,expected)
  atlas=Image.open(r/'atlas.png').convert('RGB')
  for x in rows:
   for key in ['rgb','effective_rgb','truth','image','original']:self.assertEqual(hashlib.sha256(Path(x[key]).read_bytes()).hexdigest(),x[key+'_sha256'])
   body=['情天','稲木'][x['body_id']];expected=body
   if x['kind']=='text':expected=body[0]+' '*x['spaces_before']+x['closer']+' '*x['spaces_after']+body[1]
   self.assertEqual(Path(x['truth']).read_text(),expected)
   im=Image.open(x['image']).convert('RGB');self.assertEqual(im.tobytes(),Path(x['rgb']).read_bytes());rotated=5*im.height>4*im.width;self.assertEqual(x['rotated_for_auto'],rotated);effective=im.transpose(Image.Transpose.ROTATE_90)if rotated else im
   self.assertEqual(effective.tobytes(),Path(x['effective_rgb']).read_bytes());self.assertEqual(atlas.crop(x['bounds']).tobytes(),effective.tobytes());self.assertEqual(effective.size,(x['forward_width'],x['forward_height']))

if __name__=='__main__':unittest.main()
