from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/internal-detached');f=r/'horizontal';f.mkdir();m=json.loads((r/'fresh/evaluation-manifest.json').read_text());rows=[];tiles=[];x=y=row_h=0;maxw=0
for original in m['inputs']:
 if not original['rotated_for_auto']:continue
 row={**original};row.pop('rotated_for_auto');row.update({'requested_orientation':'horizontal','original_auto_would_rotate':True,'effective_rgb':row['rgb'],'effective_rgb_sha256':row['rgb_sha256'],'forward_width':row['width'],'forward_height':row['height']})
 tile=Image.frombytes('RGB',(row['width'],row['height']),Path(row['rgb']).read_bytes())
 if x and x+tile.width>4096:y+=row_h+4;x=0;row_h=0
 row['bounds']=[x,y,x+tile.width,y+tile.height];rows.append(row);tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
assert len(rows)==56
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for row,tile in zip(rows,tiles):atlas.paste(tile,(row['bounds'][0],row['bounds'][1]))
atlas.save(f/'atlas.png');(f/'lines.json').write_text(json.dumps([{'id':x['id'],'bounds':x['bounds']}for x in rows],indent=2)+'\n');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for row in rows:assert hashlib.sha256(atlas.crop(row['bounds']).tobytes()).hexdigest()==row['rgb_sha256']
out={**m,'inputs':rows,'native_commands':[],'source_manifest_sha256':sha(r/'fresh/evaluation-manifest.json'),'generator_sha256':sha(__file__),'atlas_sha256':sha(f/'atlas.png'),'lines_sha256':sha(f/'lines.json')};(f/'evaluation-manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('all56 Auto-rotated originals retained as Horizontal;RGB bit exact')
