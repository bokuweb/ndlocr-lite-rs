from PIL import Image
import unittest
from layout import choose_cut

class Cut(unittest.TestCase):
 def test_nearest_white_column_and_left_tie(self):
  im=Image.new('RGB',(12,8),'white');im.paste((0,0,0),(1,1,11,7));im.paste((255,255,255),(4,1,5,7));im.paste((255,255,255),(7,1,8,7))
  self.assertEqual(choose_cut(im),(4,'white'))
 def test_fully_joined_foreground_keeps_input_and_uses_center(self):
  im=Image.new('RGB',(12,8),'white');im.paste((0,0,0),(1,1,11,7));self.assertEqual(choose_cut(im),(6,'bbox-center'))
 def test_blank_has_no_body_boundary(self):
  with self.assertRaises(ValueError):choose_cut(Image.new('RGB',(12,8),'white'))

if __name__=='__main__':unittest.main()
