# 生候補exportでROIを一回のforwardに固定する

## 実装前仕様

横縮尺の追加対照の初回captureで、30モデルの2,304 ROI中14 ROIが既存の自動分割により
2chunkとなった。単一区間の測定条件を満たさないため、このcaptureでは精度を採点しない。
画像・真値・条件を変更せず、初回のbinary/source/コマンド/全出力も保存する。

- 診断example `export_parseq_candidates` に明示opt-inの `--whole-roi` を追加する。
  既定値falseは既存の分割結果とエラーをそのまま返す。
- trueなら、各manifest bboxのRGB全体を `[0,width)` の単一水平区間として同じ供給Sessionへ渡す。
  連結空白や端のcrop、余白追加をせず、既存の候補/停止理由export書式を保つ。
  空の幅は拒否する。モデル・向き・文字集合・rawデコーダの条件は変更しない。
- callbackで既定のsplitter呼出しとエラー保持、whole時の無呼出し/単一区間、幅0をRed先行で検査する。
- 追加対照全2,304 ROIを、同じRGBのまま3モデルとも新規に再実行する。
  全ROI各1chunk、全元画素と追加純白を要求する。
  初回captureで1chunkだったROIは、候補・確率・停止理由を含むJSON全体の値一致を要求する。
  差分があれば測定方法の問題として調査し、精度差と混ぜない。

このオプションは診断の入力を指定するだけで、通常のページ分割や製品APIを変更しない。
