use super::preprocess::{checked_tensor_len, zeroed_tensor};
use crate::io;
use anyhow::{Context, Result, bail};
use std::fs;
use std::path::Path;

mod candidates;
use candidates::DecodeStep;
pub use candidates::{
    ParseqCandidate, ParseqCandidateResult, ParseqStepCandidates, ParseqStopReason,
    predict_text_from_flat_logits_with_candidates,
};

#[derive(Debug, Clone)]
pub struct RecognizeResult {
    pub text: String,
    pub mean_confidence: f32,
}

/// PARSeq入力画像の方向。既存APIはAutoを使用する。
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum ParseqOrientation {
    /// 公式upstreamと同じアスペクト比による自動回転。
    #[default]
    Auto,
    /// 横書き行の切り出し。寸法にかかわらず回転しない。
    Horizontal,
}

/// PARSEQ 入力テンソルを作る（`ndlocr/src/parseq.py` と同じ方針）。
///
/// - 高さが幅の80%を超えたら 90° 反時計回りに回転（`h > w * 0.8` のとき `cv2.ROTATE_90_COUNTERCLOCKWISE` に相当）
/// - `cv2.resize(..., INTER_LINEAR)` に相当する **バイリニア**で `(input_w, input_h)` へ **全面ストレッチ**
/// - PIL RGB を `[:, :, ::-1]` したのと同じ **BGR 順**で NCHW（学習・Python 推論と整合）
pub fn preprocess_rgb_u8(
    rgb: &[u8],
    width: usize,
    height: usize,
    input_width: usize,
    input_height: usize,
) -> Result<Vec<f32>> {
    preprocess_rgb_u8_with_orientation(
        rgb,
        width,
        height,
        input_width,
        input_height,
        ParseqOrientation::Auto,
    )
}

/// 入力を確保前に検証し、方向を明示してBGR/NCHWテンソルを作る。
pub fn preprocess_rgb_u8_with_orientation(
    rgb: &[u8],
    width: usize,
    height: usize,
    input_width: usize,
    input_height: usize,
    orientation: ParseqOrientation,
) -> Result<Vec<f32>> {
    let output_len = checked_tensor_len(rgb, width, height, input_width, input_height)?;
    let mut out = zeroed_tensor(output_len)?;
    let mut scratch = PreprocessScratch::with_orientation(orientation);
    preprocess_rgb_u8_into_with_scratch(
        &mut out,
        rgb,
        width,
        height,
        input_width,
        input_height,
        &mut scratch,
    )?;
    Ok(out)
}

/// 再利用する補間座標と、入力に適用する方向指定。
#[derive(Default)]
pub struct PreprocessScratch {
    /// 入力画像の方向。
    orientation: ParseqOrientation,
    xs: Vec<SampleCoord>,
    ys: Vec<SampleCoord>,
    xs_key: Option<(usize, usize)>,
    ys_key: Option<(usize, usize)>,
}

impl PreprocessScratch {
    /// 従来どおり自動方向判定する作業領域を作る。
    pub fn new() -> Self {
        Self::default()
    }

    /// 入力方向を固定した作業領域を作る。座標キャッシュは寸法ごとに更新する。
    pub fn with_orientation(orientation: ParseqOrientation) -> Self {
        Self {
            orientation,
            ..Self::default()
        }
    }
}

pub fn preprocess_rgb_u8_into(
    out: &mut [f32],
    rgb: &[u8],
    width: usize,
    height: usize,
    input_width: usize,
    input_height: usize,
) -> Result<()> {
    let mut scratch = PreprocessScratch::new();
    preprocess_rgb_u8_into_with_scratch(
        out,
        rgb,
        width,
        height,
        input_width,
        input_height,
        &mut scratch,
    )
}

/// 作業領域の方向指定と補間座標を使い、呼び出し元のバッファへ書き込む。
pub fn preprocess_rgb_u8_into_with_scratch(
    out: &mut [f32],
    rgb: &[u8],
    width: usize,
    height: usize,
    input_width: usize,
    input_height: usize,
    scratch: &mut PreprocessScratch,
) -> Result<()> {
    let output_len = checked_tensor_len(rgb, width, height, input_width, input_height)?;
    if out.len() != output_len {
        bail!(
            "invalid output buffer length: expected {}, got {}",
            output_len,
            out.len()
        );
    }
    let rotated = scratch.orientation == ParseqOrientation::Auto
        && (height as u128) * 5 > (width as u128) * 4;
    let (source_w, source_h) = if rotated {
        (height, width)
    } else {
        (width, height)
    };
    let plane = input_width * input_height;
    scratch.ensure_xs(input_width, source_w);
    scratch.ensure_ys(input_height, source_h);
    if rotated {
        write_rotated_bgr_nchw(
            out,
            rgb,
            width,
            &scratch.xs,
            &scratch.ys,
            input_width,
            plane,
        );
    } else {
        write_bgr_nchw(
            out,
            rgb,
            width,
            &scratch.xs,
            &scratch.ys,
            input_width,
            plane,
        );
    }
    Ok(())
}

#[derive(Clone, Copy)]
struct SampleCoord {
    lo: usize,
    hi: usize,
    weight: f32,
}

impl PreprocessScratch {
    fn ensure_xs(&mut self, dst_len: usize, src_len: usize) {
        if self.xs_key != Some((dst_len, src_len)) {
            build_sample_coords(dst_len, src_len, &mut self.xs);
            self.xs_key = Some((dst_len, src_len));
        }
    }

    fn ensure_ys(&mut self, dst_len: usize, src_len: usize) {
        if self.ys_key != Some((dst_len, src_len)) {
            build_sample_coords(dst_len, src_len, &mut self.ys);
            self.ys_key = Some((dst_len, src_len));
        }
    }
}

fn build_sample_coords(dst_len: usize, src_len: usize, out: &mut Vec<SampleCoord>) {
    out.clear();
    if out.capacity() < dst_len {
        out.reserve(dst_len - out.capacity());
    }
    for dst in 0..dst_len {
        let s = resize_source_coord(dst, dst_len, src_len);
        let lo = s.floor() as usize;
        out.push(SampleCoord {
            lo,
            hi: (lo + 1).min(src_len - 1),
            weight: s - lo as f32,
        });
    }
}

fn write_bgr_nchw(
    out: &mut [f32],
    rgb: &[u8],
    width: usize,
    xs: &[SampleCoord],
    ys: &[SampleCoord],
    input_width: usize,
    plane: usize,
) {
    for (y, sy) in ys.iter().copied().enumerate() {
        for (x, sx) in xs.iter().copied().enumerate() {
            let rgb_px = bilinear_rgb_direct(
                rgb,
                (sy.lo * width + sx.lo) * 3,
                (sy.lo * width + sx.hi) * 3,
                (sy.hi * width + sx.lo) * 3,
                (sy.hi * width + sx.hi) * 3,
                sx.weight,
                sy.weight,
            );
            let i = y * input_width + x;
            out[i] = rgb_px[2] / 127.5 - 1.0;
            out[plane + i] = rgb_px[1] / 127.5 - 1.0;
            out[plane * 2 + i] = rgb_px[0] / 127.5 - 1.0;
        }
    }
}

fn write_rotated_bgr_nchw(
    out: &mut [f32],
    rgb: &[u8],
    width: usize,
    xs: &[SampleCoord],
    ys: &[SampleCoord],
    input_width: usize,
    plane: usize,
) {
    for (y, sy) in ys.iter().copied().enumerate() {
        for (x, sx) in xs.iter().copied().enumerate() {
            let rgb_px = bilinear_rgb_direct(
                rgb,
                (sx.lo * width + (width - 1 - sy.lo)) * 3,
                (sx.hi * width + (width - 1 - sy.lo)) * 3,
                (sx.lo * width + (width - 1 - sy.hi)) * 3,
                (sx.hi * width + (width - 1 - sy.hi)) * 3,
                sx.weight,
                sy.weight,
            );
            let i = y * input_width + x;
            out[i] = rgb_px[2] / 127.5 - 1.0;
            out[plane + i] = rgb_px[1] / 127.5 - 1.0;
            out[plane * 2 + i] = rgb_px[0] / 127.5 - 1.0;
        }
    }
}

fn resize_source_coord(dst: usize, dst_len: usize, src_len: usize) -> f32 {
    if dst_len <= 1 {
        return 0.0;
    }
    (((dst as f32 + 0.5) * src_len as f32 / dst_len as f32) - 0.5).clamp(0.0, (src_len - 1) as f32)
}

fn bilinear_rgb_direct(
    rgb: &[u8],
    p00: usize,
    p10: usize,
    p01: usize,
    p11: usize,
    wx: f32,
    wy: f32,
) -> [f32; 3] {
    let mut out = [0.0f32; 3];
    for c in 0..3 {
        let top = rgb[p00 + c] as f32 * (1.0 - wx) + rgb[p10 + c] as f32 * wx;
        let bottom = rgb[p01 + c] as f32 * (1.0 - wx) + rgb[p11 + c] as f32 * wx;
        out[c] = top * (1.0 - wy) + bottom * wy;
    }
    out
}

pub fn decode_indices(indices: &[i64], charset: &[char]) -> String {
    let mut out = String::new();
    for &idx in indices {
        if idx == 0 {
            break;
        }
        if idx <= 0 {
            continue;
        }
        if let Some(ch) = charset.get((idx - 1) as usize) {
            out.push(*ch);
        }
    }
    out
}

pub fn argmax_token_ids(logits: &[Vec<f32>]) -> Result<Vec<i64>> {
    let mut ids = Vec::with_capacity(logits.len());
    for row in logits {
        if row.is_empty() {
            bail!("logits row must not be empty");
        }
        let mut bi = 0usize;
        let mut bv = row[0];
        for (i, &v) in row.iter().enumerate().skip(1) {
            if v > bv {
                bv = v;
                bi = i;
            }
        }
        ids.push(bi as i64);
    }
    Ok(ids)
}

pub fn predict_text_from_logits(logits: &[Vec<f32>], charset: &[char]) -> Result<String> {
    Ok(decode_indices(&argmax_token_ids(logits)?, charset))
}

pub fn sanitize_recognized_text(input: &str) -> String {
    sanitize_with_bracket_policy(input, true)
}

/// 行やchunkの断片を整え、別の断片で開かれた閉じ括弧を保持する。
/// 対応する括弧を推測・挿入せず、同じ入力内の不均衡だけでは削除しない。
pub fn sanitize_recognized_fragment(input: &str) -> String {
    sanitize_with_bracket_policy(input, false)
}

fn sanitize_with_bracket_policy(input: &str, remove_unmatched: bool) -> String {
    sanitize_with_policies(input, remove_unmatched, true)
}

pub(crate) fn sanitize_fragment_preserving_repetitions(input: &str) -> String {
    sanitize_with_policies(input, false, false)
}

pub(crate) fn sanitize_line_preserving_repetitions(input: &str) -> String {
    sanitize_with_policies(input, true, false)
}

fn sanitize_with_policies(input: &str, remove_unmatched: bool, limit_repetitions: bool) -> String {
    let mut out = String::with_capacity(input.len());
    let mut prev: Option<char> = None;
    let mut run = 0usize;
    let mut last_was_space = false;
    for ch in input.chars() {
        if ch.is_whitespace() {
            if !last_was_space && !out.is_empty() {
                out.push(' ');
                last_was_space = true;
            }
            prev = None;
            run = 0;
            continue;
        }
        last_was_space = false;
        if Some(ch) == prev {
            run += 1;
        } else {
            prev = Some(ch);
            run = 1;
        }

        let too_many_digits = ch.is_ascii_digit() && run > 4;
        let too_many_symbols = !ch.is_alphanumeric() && run > 3;
        let too_many_same_char = run > 8;
        if limit_repetitions && (too_many_digits || too_many_symbols || too_many_same_char) {
            continue;
        }
        out.push(ch);
    }
    let out = out.trim().to_string();
    let out = if limit_repetitions {
        let out = collapse_repeated_chunks(&out, 2, 2, 10);
        collapse_repeated_phrases(&out, &["という。", "このように, "], 1)
    } else {
        out
    };
    let out = if remove_unmatched {
        remove_unmatched_closing_brackets(&out)
    } else {
        out
    };
    apply_common_japanese_ocr_replacements(&out)
}

/// 平坦モデル出力を検証して本文を取得する。
///
/// # Errors
/// 形状不正、EOSを含むクラス数と文字集合の不一致、形状内の非有限値を拒否する。
pub fn predict_text_from_flat_logits(
    logits: &[f32],
    timesteps: usize,
    classes: usize,
    charset: &[char],
) -> Result<String> {
    Ok(predict_text_from_flat_logits_with_confidence(logits, timesteps, classes, charset)?.text)
}

/// 平坦モデル出力を検証し、本文と平均信頼度を返す。
///
/// # Errors
/// 形状不正、EOSを含むクラス数と文字集合の不一致、形状内の非有限値を拒否する。
/// 停止後のステップも検証し、形状外の末尾データは無視する。
pub fn predict_text_from_flat_logits_with_confidence(
    logits: &[f32],
    timesteps: usize,
    classes: usize,
    charset: &[char],
) -> Result<RecognizeResult> {
    decode_flat_logits_with_observer(logits, timesteps, classes, charset, |_| {})
}

/// 既存の演算順序を維持し、処理したステップを必要な呼び出し元だけに通知する。
fn decode_flat_logits_with_observer(
    logits: &[f32],
    timesteps: usize,
    classes: usize,
    charset: &[char],
    mut observe: impl FnMut(DecodeStep<'_>),
) -> Result<RecognizeResult> {
    if timesteps == 0 || classes == 0 {
        bail!("timesteps/classes must be > 0");
    }
    let expected = timesteps
        .checked_mul(classes)
        .ok_or_else(|| anyhow::anyhow!("logits shape overflow"))?;
    if logits.len() < expected {
        bail!("flat logits length is shorter than shape");
    }
    if charset.len().checked_add(1) != Some(classes) {
        bail!("logits classes and charset mismatch");
    }
    // 短絡しない集約で、全形状の検証を自動ベクトル化できるようにする。
    if logits[..expected]
        .iter()
        .fold(false, |invalid, value| invalid | !value.is_finite())
    {
        bail!("logits must be finite");
    }
    let mut text = String::new();
    let mut conf_sum = 0.0f32;
    let mut conf_count = 0usize;
    let min_tokens_before_low_conf_stop = 2usize;
    let low_confidence_threshold = 0.35f32;
    for t in 0..timesteps {
        let row = &logits[(t * classes)..((t + 1) * classes)];
        let mut bi = 0usize;
        let mut bv = row[0];
        for (i, &v) in row.iter().enumerate().skip(1) {
            if v > bv {
                bv = v;
                bi = i;
            }
        }
        let mut exp_sum = 0.0f32;
        for &v in row {
            exp_sum += (v - bv).exp();
        }
        let pmax = if exp_sum > 0.0 { 1.0 / exp_sum } else { 0.0 };

        let stop_reason = if bi == 0 {
            Some(ParseqStopReason::EndOfSequence)
        } else if conf_count >= min_tokens_before_low_conf_stop && pmax < low_confidence_threshold {
            Some(ParseqStopReason::LowConfidence)
        } else {
            None
        };
        let mut text_range = None;
        if stop_reason.is_none()
            && let Some(ch) = charset.get(bi - 1)
        {
            let start = text.len();
            text.push(*ch);
            text_range = Some(start..text.len());
            conf_sum += pmax;
            conf_count += 1;
        }
        observe(DecodeStep {
            timestep: t,
            row,
            winner: bi,
            probability: pmax,
            text_range,
            stop_reason,
        });
        if stop_reason.is_some() {
            break;
        }
    }
    let mean_confidence = if conf_count > 0 {
        conf_sum / conf_count as f32
    } else {
        0.0
    };
    Ok(RecognizeResult {
        text,
        mean_confidence,
    })
}

pub fn load_charset_from_yaml_str(yaml_body: &str) -> Result<Vec<char>> {
    let value: serde_yaml::Value = serde_yaml::from_str(yaml_body)?;
    let charset_value = value
        .get("model")
        .and_then(|v| v.get("charset_train"))
        .ok_or_else(|| anyhow::anyhow!("model.charset_train is missing"))?;
    if let Some(s) = charset_value.as_str() {
        return Ok(s.chars().collect());
    }
    if let Some(seq) = charset_value.as_sequence() {
        let mut out = Vec::new();
        for item in seq {
            let Some(s) = item.as_str() else {
                bail!("model.charset_train sequence item must be string")
            };
            out.extend(s.chars());
        }
        return Ok(out);
    }
    bail!("model.charset_train must be string or sequence of strings")
}

pub fn smoke_recognize(model_path: &Path, image_path: &Path, charset_path: &Path) -> Result<()> {
    if !image_path.is_file() || !model_path.is_file() || !charset_path.is_file() {
        bail!("file not found");
    }
    let yaml_body = fs::read_to_string(charset_path)
        .with_context(|| format!("failed to read {}", charset_path.display()))?;
    let _charset = load_charset_from_yaml_str(&yaml_body)?;
    let img = io::load_rgb_u8(image_path)?;
    let _ = preprocess_rgb_u8(&img.data, img.width, img.height, 384, 32)?;
    smoke_recognize_impl(model_path)
}

pub fn recognize_image(
    model_path: &Path,
    image_path: &Path,
    charset_path: &Path,
) -> Result<String> {
    if !image_path.is_file() || !model_path.is_file() || !charset_path.is_file() {
        bail!("file not found");
    }
    let yaml_body = fs::read_to_string(charset_path)
        .with_context(|| format!("failed to read {}", charset_path.display()))?;
    let charset = load_charset_from_yaml_str(&yaml_body)?;
    let img = io::load_rgb_u8(image_path)?;
    Ok(recognize_image_impl(model_path, &img.data, img.width, img.height, &charset)?.text)
}

pub fn recognize_rgb_u8(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset_path: &Path,
) -> Result<String> {
    if !model_path.is_file() || !charset_path.is_file() {
        bail!("file not found");
    }
    let yaml_body = fs::read_to_string(charset_path)
        .with_context(|| format!("failed to read {}", charset_path.display()))?;
    let charset = load_charset_from_yaml_str(&yaml_body)?;
    Ok(recognize_image_impl(model_path, rgb, width, height, &charset)?.text)
}

pub fn recognize_rgb_u8_with_score(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset_path: &Path,
) -> Result<RecognizeResult> {
    if !model_path.is_file() || !charset_path.is_file() {
        bail!("file not found");
    }
    let yaml_body = fs::read_to_string(charset_path)
        .with_context(|| format!("failed to read {}", charset_path.display()))?;
    let charset = load_charset_from_yaml_str(&yaml_body)?;
    recognize_image_impl(model_path, rgb, width, height, &charset)
}

/// RGB画像のデコード本文と信頼度を、置換・反復除去・空白整理せずに返す。
///
/// EOSと低信頼度によるデコーダの停止条件は従来どおり適用する。
/// 推論自体の誤認識や欠落を補正するAPIではない。
pub fn recognize_rgb_u8_with_score_unprocessed(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset_path: &Path,
) -> Result<RecognizeResult> {
    if !model_path.is_file() || !charset_path.is_file() {
        bail!("file not found");
    }
    let yaml_body = fs::read_to_string(charset_path)
        .with_context(|| format!("failed to read {}", charset_path.display()))?;
    let charset = load_charset_from_yaml_str(&yaml_body)?;
    recognize_image_unprocessed_impl(model_path, rgb, width, height, &charset)
}

/// 同じモデルの余白確認後に、同じRGBによる既存の画像支持方針を適用する。
fn recognize_image_impl(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset: &[char],
) -> Result<RecognizeResult> {
    #[cfg(feature = "onnx")]
    let mut result =
        recognize_image_with_context_impl(model_path, rgb, width, height, charset, true)?;
    #[cfg(not(feature = "onnx"))]
    let mut result = recognize_image_unprocessed_impl(model_path, rgb, width, height, charset)?;
    result.text = super::visible_repetitions::sanitize_visible_single_line(
        &result.text,
        rgb,
        width,
        height,
        ParseqOrientation::Auto,
    );
    Ok(result)
}

#[cfg(feature = "onnx")]
fn smoke_recognize_impl(model_path: &Path) -> Result<()> {
    use crate::infer::ort_init::OrtAnyhow;
    use ort::session::Session;
    use ort::session::builder::GraphOptimizationLevel;
    crate::infer::ort_init::ensure_init();
    let _session = Session::builder()
        .anyort()?
        .with_optimization_level(GraphOptimizationLevel::Level3)
        .anyort()?
        .with_intra_threads(1)
        .anyort()?
        .commit_from_file(model_path)
        .anyort()?;
    Ok(())
}

#[cfg(feature = "onnx")]
/// RGB画像を推論し、文字単位のデコード結果を変更せず返す。
fn recognize_image_unprocessed_impl(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset: &[char],
) -> Result<RecognizeResult> {
    recognize_image_with_context_impl(model_path, rgb, width, height, charset, false)
}

#[cfg(feature = "onnx")]
/// 単発APIの元推論と追加候補で、同じthread=1のsessionを共用する。
fn recognize_image_with_context_impl(
    model_path: &Path,
    rgb: &[u8],
    width: usize,
    height: usize,
    charset: &[char],
    select_context: bool,
) -> Result<RecognizeResult> {
    use crate::infer::ort_init::OrtAnyhow;
    use anyhow::anyhow;
    use ort::session::Session;
    use ort::session::builder::GraphOptimizationLevel;

    crate::infer::ort_init::ensure_init();
    let mut session = Session::builder()
        .anyort()?
        .with_optimization_level(GraphOptimizationLevel::Level3)
        .anyort()?
        .with_intra_threads(1)
        .anyort()?
        .commit_from_file(model_path)
        .anyort()?;

    let inputs_meta = session.inputs();
    let input_meta = inputs_meta
        .first()
        .ok_or_else(|| anyhow!("model has no input"))?;
    let shape_meta = input_meta
        .dtype()
        .tensor_shape()
        .ok_or_else(|| anyhow!("input is not a tensor"))?;
    let dims: &[i64] = shape_meta;
    if dims.len() < 4 {
        bail!("unexpected model input rank");
    }
    if dims[2] <= 0 || dims[3] <= 0 {
        bail!("dynamic input H/W is unsupported");
    }
    let input_h = dims[2] as usize;
    let input_w = dims[3] as usize;
    let input_name = input_meta.name().to_string();
    let outputs_meta = session.outputs();
    let output_name = outputs_meta
        .first()
        .ok_or_else(|| anyhow!("model has no output"))?
        .name()
        .to_string();
    let _ = outputs_meta;
    let _ = inputs_meta;

    let names = (input_name.as_str(), output_name.as_str());
    let model = (input_w, input_h);
    let mut result = recognize_on_loaded_session(
        &mut session,
        names,
        model,
        charset,
        (rgb, width, height),
        ParseqOrientation::Auto,
    )?;
    if select_context
        && let Some(candidate) = super::punctuation_context::select(
            &result,
            rgb,
            width,
            height,
            model,
            ParseqOrientation::Auto,
            |p, w, h| {
                recognize_on_loaded_session(
                    &mut session,
                    names,
                    model,
                    charset,
                    (p, w, h),
                    ParseqOrientation::Horizontal,
                )
            },
        )
    {
        result = candidate;
    }
    Ok(result)
}

#[cfg(feature = "onnx")]
fn recognize_on_loaded_session(
    session: &mut ort::session::Session,
    names: (&str, &str),
    model: (usize, usize),
    charset: &[char],
    image: (&[u8], usize, usize),
    orientation: ParseqOrientation,
) -> Result<RecognizeResult> {
    use crate::infer::ort_init::OrtAnyhow;
    use ndarray::Array4;
    use ort::{inputs, value::TensorRef};
    let tensor = preprocess_rgb_u8_with_orientation(
        image.0,
        image.1,
        image.2,
        model.0,
        model.1,
        orientation,
    )?;
    let input_array: Array4<f32> = Array4::from_shape_vec((1, 3, model.1, model.0), tensor)?;
    let tref = TensorRef::from_array_view(input_array.view()).anyort()?;
    let outputs = session.run(inputs![names.0 => tref]).anyort()?;
    let (shape, data) = outputs[names.1].try_extract_tensor::<f32>().anyort()?;
    let shape: Vec<i64> = shape.to_vec();
    let result = match shape.as_slice() {
        [1, t, c] => {
            predict_text_from_flat_logits_with_confidence(data, *t as usize, *c as usize, charset)
        }
        [t, c] => {
            predict_text_from_flat_logits_with_confidence(data, *t as usize, *c as usize, charset)
        }
        _ => bail!("unsupported output shape: {:?}", shape),
    }?;
    Ok(result)
}

#[cfg(not(feature = "onnx"))]
fn smoke_recognize_impl(_model_path: &Path) -> Result<()> {
    bail!("onnx feature is disabled. Rebuild with `--features onnx`.");
}

#[cfg(not(feature = "onnx"))]
/// 推論runtimeを持たない構成は明示的に失敗する。
fn recognize_image_unprocessed_impl(
    _model_path: &Path,
    _rgb: &[u8],
    _width: usize,
    _height: usize,
    _charset: &[char],
) -> Result<RecognizeResult> {
    bail!("onnx feature is disabled. Rebuild with `--features onnx`.");
}

fn collapse_repeated_chunks(
    input: &str,
    max_repeat: usize,
    min_chunk_len: usize,
    max_chunk_len: usize,
) -> String {
    let chars: Vec<char> = input.chars().collect();
    let mut out = String::new();
    let mut i = 0usize;
    while i < chars.len() {
        let mut collapsed = false;
        for chunk_len in (min_chunk_len..=max_chunk_len).rev() {
            if i + chunk_len * (max_repeat + 1) > chars.len() {
                continue;
            }
            let first = &chars[i..i + chunk_len];
            let mut repeat_count = 1usize;
            while i + chunk_len * (repeat_count + 1) <= chars.len() {
                let start = i + chunk_len * repeat_count;
                let end = start + chunk_len;
                if &chars[start..end] == first {
                    repeat_count += 1;
                } else {
                    break;
                }
            }
            if repeat_count > max_repeat {
                for _ in 0..max_repeat {
                    for ch in first {
                        out.push(*ch);
                    }
                }
                i += chunk_len * repeat_count;
                collapsed = true;
                break;
            }
        }
        if !collapsed {
            out.push(chars[i]);
            i += 1;
        }
    }
    out
}

fn remove_unmatched_closing_brackets(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut stack: Vec<char> = Vec::new();

    for ch in input.chars() {
        match ch {
            '(' | '（' | '「' | '『' | '【' => {
                stack.push(ch);
                out.push(ch);
            }
            ')' => {
                if pop_if_matches(&mut stack, '(') {
                    out.push(ch);
                }
            }
            '）' => {
                if pop_if_matches(&mut stack, '（') {
                    out.push(ch);
                }
            }
            '」' => {
                if pop_if_matches(&mut stack, '「') {
                    out.push(ch);
                }
            }
            '』' => {
                if pop_if_matches(&mut stack, '『') {
                    out.push(ch);
                }
            }
            '】' => {
                if pop_if_matches(&mut stack, '【') {
                    out.push(ch);
                }
            }
            _ => out.push(ch),
        }
    }
    out
}

fn pop_if_matches(stack: &mut Vec<char>, open: char) -> bool {
    if let Some(&last) = stack.last()
        && last == open
    {
        stack.pop();
        return true;
    }
    false
}

fn collapse_repeated_phrases(input: &str, phrases: &[&str], max_repeat: usize) -> String {
    let mut out = input.to_string();
    for &phrase in phrases {
        if phrase.is_empty() {
            continue;
        }
        let repeated = phrase.repeat(max_repeat + 1);
        let kept = phrase.repeat(max_repeat);
        while out.contains(&repeated) {
            out = out.replace(&repeated, &kept);
        }
    }
    out
}

fn apply_common_japanese_ocr_replacements(input: &str) -> String {
    let mut out = input.to_string();
    let replacements = [("調示", "開示"), ("圖示", "開示"), ("単又は乙", "甲又は乙")];
    for (from, to) in replacements {
        out = out.replace(from, to);
    }
    out
}
