from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib,subprocess,shutil,PIL
from layout import choose_cut
r=Path('tmp/internal-detached');out=r/'fresh';out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['native','original','png','rgb','effective','truth']:(out/name).mkdir()
renderer=r/'render';shutil.copy2('tmp/closer-bridge/render',renderer);shutil.copy2('tmp/closer-bridge/render.swift',r/'render.swift')
fonts=json.loads(Path('tmp/punct-proportional/new/data/evaluation-manifest.json').read_text())['fonts'];rows=[];traces=[]
def draw_native(font,size,palt,text,id):
 path=out/'native'/(id+'.png');argv=[str(renderer),font['path'],str(size),str(palt),text,str(path)];p=subprocess.run(argv,capture_output=True,check=True);trace=json.loads(p.stdout);assert Path(trace['font_file']).samefile(font['path'])
 for run in trace['runs']:assert Path(run['font_file']).samefile(font['path'])and run['font']==trace['font']and 0 not in run['glyphs']
 assert sorted(i for run in trace['runs']for i in run['string_indices'])==list(range(len(text)))
 (out/'native'/(id+'.json')).write_bytes(p.stdout+b'\n');traces.append({'id':id,'argv':argv,'exit_code':0,'png_sha256':sha(path.read_bytes()),'trace_sha256':sha(p.stdout+b'\n')})
 full=Image.open(path).convert('RGB');box=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();assert box
 return full.crop((box[0]-2,box[1]-2,box[2]+2,box[3]+2))
def save(im,text,id,metadata):
 for fmt in ['png','jpeg75']:
  key=id+'_'+fmt;path=out/'original'/(key+('.png'if fmt=='png'else'.jpg'));im.save(path,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(path).convert('RGB');assert decoded.getchannel('R').tobytes()==decoded.getchannel('G').tobytes()==decoded.getchannel('B').tobytes();image=out/'png'/(key+'.png');decoded.save(image);rgb=out/'rgb'/(key+'.rgb');rgb.write_bytes(decoded.tobytes());gt=out/'truth'/(key+'.txt');gt.write_text(text);rotated=5*decoded.height>4*decoded.width;effective=decoded.transpose(Image.Transpose.ROTATE_90)if rotated else decoded;fp=out/'effective'/(key+'.rgb');fp.write_bytes(effective.tobytes())
  row=metadata|{'id':key,'format':fmt,'width':decoded.width,'height':decoded.height,'rotated_for_auto':rotated,'forward_width':effective.width,'forward_height':effective.height,'original':str(path),'original_sha256':sha(path.read_bytes())}
  for name,p in [('image',image),('rgb',rgb),('effective_rgb',fp),('truth',gt)]:row[name]=str(p);row[name+'_sha256']=sha(p.read_bytes())
  rows.append(row)
for font in fonts:
 assert sha(Path(font['path']).read_bytes())==font['sha256']
 for size in [24,40]:
  for palt in [0,1]:
   for tid,body in enumerate(['情天','稲木']):
    prefix=f'i_t{tid}_{font["id"]}_{size}_p{palt}'
    for ci,closer in enumerate([')','）','」','』','】']):
     for spaces_before in [0,1,2]:
      for spaces_after in [0,1,2]:
       text=body[0]+' '*spaces_before+closer+' '*spaces_after+body[1]
       id=prefix+f'_c{ci}_sb{spaces_before}_sa{spaces_after}';im=draw_native(font,size,palt,text,id)
       for paper in [0,8]:
        padded=Image.new('RGB',(im.width,im.height+2*paper),'white');padded.paste(im,(0,paper))
        save(padded,text,id+f'_paper{paper}',{'kind':'text','body_id':tid,'font':font['id'],'size':size,'palt':palt,'closer':closer,'spaces_before':spaces_before,'spaces_after':spaces_after,'paper':paper})
    native=draw_native(font,size,palt,body,prefix+'_bare');ink=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();height=ink[3]-ink[1]
    cut,cut_kind=choose_cut(native)
    for shape in ['none','thin','thick','dot']:
     mw={'none':0,'thin':1,'thick':(height+3)//4,'dot':4}[shape];mh=4 if shape=='dot'else height
     for gap in [0,1]:
      shift=mw+2*gap;image=Image.new('RGB',(native.width+shift,native.height),'white')
      image.paste(native.crop((0,0,cut,native.height)),(0,0));image.paste(native.crop((cut,0,native.width,native.height)),(cut+shift,0))
      x=cut+gap;y=ink[1]+(height-mh)//2
      if mw:image.paste((0,0,0),(x,y,x+mw,y+mh))
      for yy in range(native.height):
       for xx in range(native.width):
        if native.getpixel((xx,yy))!=(255,255,255):assert image.getpixel((xx+(shift if xx>=cut else 0),yy))==native.getpixel((xx,yy))
      for paper in [0,8]:
       padded=Image.new('RGB',(image.width,image.height+2*paper),'white');padded.paste(image,(0,paper))
       id=prefix+f'_noise{shape}_gap{gap}_paper{paper}'
       save(padded,body,id,{'kind':'noise','body_id':tid,'font':font['id'],'size':size,'palt':palt,'shape':shape,'gap':gap,'paper':paper,'cut':cut,'cut_kind':cut_kind,'shift':shift,'shape_bounds':[x,y+paper,x+mw,y+mh+paper]})

assert len(rows)==5088
tiles=[];x=y=row_h=0;maxw=0
for row in rows:
 tile=Image.frombytes('RGB',(row['forward_width'],row['forward_height']),Path(row['effective_rgb']).read_bytes())
 if x and x+tile.width>4096:y+=row_h+4;x=0;row_h=0
 row['bounds']=[x,y,x+tile.width,y+tile.height];tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for row,tile in zip(rows,tiles):atlas.paste(tile,(row['bounds'][0],row['bounds'][1]))
atlas.save(out/'atlas.png');(out/'lines.json').write_text(json.dumps([{'id':x['id'],'bounds':x['bounds']}for x in rows],indent=2)+'\n')
meta={'inputs':rows,'fonts':fonts,'native_commands':traces,'generator_sha256':sha(Path(__file__).read_bytes()),'renderer_binary_sha256':sha(renderer.read_bytes()),'renderer_source_sha256':sha((r/'render.swift').read_bytes()),'spec_sha256':sha(Path('docs/internal_detached_closer.md').read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((out/'atlas.png').read_bytes()),'lines_sha256':sha((out/'lines.json').read_bytes())};(out/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');shutil.copy2('docs/internal_detached_closer.md',r/'capture-spec.md');print('5088 fresh controls fixed;Auto-rotation cases',sum(x['rotated_for_auto']for x in rows),'atlas',atlas.size,flush=True)
