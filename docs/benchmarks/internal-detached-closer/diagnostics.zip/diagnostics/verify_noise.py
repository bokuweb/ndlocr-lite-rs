from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib,collections
r=Path('tmp/internal-detached');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());rows=[]
for x in m['inputs']:
 if x['kind']!='noise' or x['format']!='png':continue
 key=f'i_t{x["body_id"]}_{x["font"]}_{x["size"]}_p{x["palt"]}_bare';native=Image.open(f/'native'/(key+'.png')).convert('RGB');box=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();body=native.crop((box[0]-2,box[1]-2,box[2]+2,box[3]+2))
 ink=ImageChops.difference(body,Image.new('RGB',body.size,'white')).getbbox();white=[xx for xx in range(ink[0]+1,ink[2]-1)if all(body.getpixel((xx,yy))==(255,255,255)for yy in range(body.height))]
 cut=min(white,key=lambda xx:(abs(2*xx+1-ink[0]-ink[2]),xx))if white else(ink[0]+ink[2])//2;kind='white'if white else'bbox-center';assert(cut,kind)==(x['cut'],x['cut_kind'])
 sx,sy,ex,ey=x['shape_bounds'];mw=ex-sx;shift=mw+2*x['gap'];assert shift==x['shift'];paper=x['paper'];overlap=0
 expected=Image.new('RGB',(body.width+shift,body.height+2*paper),'white')
 for yy in range(body.height):
  for xx in range(body.width):
   dx=xx+(shift if xx>=cut else 0);dy=yy+paper;v=body.getpixel((xx,yy));expected.putpixel((dx,dy),v)
   overlap+=v!=(255,255,255)and sx<=dx<ex and sy<=dy<ey
 assert overlap==0
 if mw:expected.paste((0,0,0),(sx,sy,ex,ey))
 actual=Image.open(x['image']).convert('RGB');assert expected.size==actual.size and expected.tobytes()==actual.tobytes();rows.append({'id':x['id'],'native_body':key,'cut_kind':kind,'pre_jpeg_glyph_overlap_pixels':overlap,'reconstructed_png_rgb_sha256':hashlib.sha256(expected.tobytes()).hexdigest()})
assert len(rows)==384;out={'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'png_and_jpeg_pairs':384,'all_shape_glyph_overlap_counts_zero':True,'all_png_reconstructions_byte_equal':True,'cut_kinds':dict(collections.Counter(x['cut_kind']for x in rows)),'rows':rows};(r/'noise-pixel-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('384 pre-JPEG controls reconstructed;all shape/glyph overlaps0',out['cut_kinds'],flush=True)
