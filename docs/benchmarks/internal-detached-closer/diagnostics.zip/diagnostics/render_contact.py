from pathlib import Path
from PIL import Image,ImageDraw
import json,sys,hashlib
r=Path(sys.argv[1]);m=json.loads((r/'fresh/evaluation-manifest.json').read_text());picked=[]
for font in ['maru','gothic','mincho']:
 pool=[x for x in m['inputs']if x['font']==font and x['kind']=='text']
 for closer in [')','）','」','』','】']:
  group=[x for x in pool if x['closer']==closer];picked.extend([group[0],group[-1]])
 for tid in [0,1]:picked.append(next(x for x in pool if x['body_id']==tid and x['spaces_before']==1 and x['spaces_after']==1))
 pool=[x for x in m['inputs']if x['font']==font and x['kind']=='noise']
 for shape in ['none','thin','thick','dot']:
  group=[x for x in pool if x['shape']==shape];picked.extend([group[0],next(x for x in group if x['gap']==1 and x['palt']==1),group[-1]])
assert len(picked)==72;out=Image.new('RGB',(1200,900),'#eeeeee');d=ImageDraw.Draw(out)
for i,x in enumerate(picked):
 im=Image.open(x['image']);im.thumbnail((142,70));a=(i%8*150,i//8*100);out.paste(im,(a[0]+2,a[1]+2));d.text((a[0]+2,a[1]+74),x['font']+' '+x.get('shape',str(x.get('closer','')))+' '+str(x.get('spaces_before',''))+'/'+str(x.get('spaces_after','')),fill='black')
out.save(r/'fresh/contact-shapes.png');(r/'fresh/contact-shapes.json').write_text(json.dumps({'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'image_sha256':hashlib.sha256((r/'fresh/contact-shapes.png').read_bytes()).hexdigest(),'source_ids':[x['id']for x in picked]},indent=2)+'\n')
