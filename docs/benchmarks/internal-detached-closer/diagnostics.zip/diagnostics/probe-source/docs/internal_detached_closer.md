# 語中closerの左右に分離した本文部品を支持する

## 実装・追加認識前仕様

比較元は0b7595c。既知の `geometry_round_japanese_internal_maru40_png` は3モデルとも
raw `情)報` が正読だが、単行の後処理で `情報` になる。端のcloser用処理は変更しない。
文言や文書種別の補正を追加せず、元RGB/成分/デコーダ/確率を維持した支持viewをtest-onlyで先行する。

- 対象は正確に3 scalar、中央が既存closer5種の1個で、左右はcloserでない表示幅2の文字。
  空白/他文字数/複数closer/端closerは対象外。元fragmentをそのまま保持するだけで文字置換しない。
- 既存RGB和660・8近傍・面積フィルタをそのまま使い、filtered成分4〜7個。
  mark候補は独立した1成分。残りの全成分をbboxがmarkの左/右にある群へ分け、
  markとの水平bbox重複があるもの、片側が空のものを除く。
- 両本文群unionの高さHで、mark幅ceil(H/4)〜floor(H/2)、高さceil(H/2)〜floor(3H/2)、
  塗りつぶしたbboxは除く。markと左右本文それぞれの水平gapは0〜max(1,floor(H/4))。
  内側markの左右bearingを扱う固定値で、追加結果を見て緩めない。
- 各本文群の支持は前段のgroup_viewと同じ。主部品を高さ/面積/左端で決め、
  主部品高ceil(3H/4)以上、他部品のyは主部品内、水平gap max(1,floor(H/12))以内。
  union幅ceil(3H/4)〜floor(3H/2)。少なくとも一方に、幅/高さceil(H/2)以上で
  主部品の3辺にstrict包含・1辺だけ一致する大部品があること。
- 全成分のunion bbox内の前景画素数が全filtered成分面積和と一致すること。
  markを含む全前景を所有し、無視された内部点の混入を除く。
- `[左字形,元mark,右字形]` の支持viewを既存supports_collectedにも渡す。
  条件を満たすmark候補が正確に1個の場合だけ支持する。候補2個以上は曖昧として除く。
- 既存の単行fallbackがすべて失敗した場合だけ適用候補とする。明示Horizontalまたは
  既存Autoで回転しない元画像に限り、fragment用/ページ用処理と方向判定は維持する。
  NN追加forwardやRGB編集を行わない。

## 小さなRed→Greenと評価順序

まず合成の分離部品+中央markのRed→Green、次に既知画像で支持を確認する。
文字列/不正RGB、markが細線/塗りつぶし/大きすぎるgap、本文の高さ/幅/part gap、
全前景の所属、複数候補の曖昧性を例示する。紙/平行移動/灰度/整数block倍率のPBT64例も先行する。
同じgroup_viewを再利用するvisibility変更以外に前段の判定条件を変えない。

旧99,591保存raw組すべてを製品基準/案で比較する。none/width/strictの文字/単語どれかが
悪化すれば案を棄却し、同じ結果へ閾値を合わせ直さない。通過した場合だけ次の新規認識へ進む。

新本文 `情天` / `稲木`、同3font file、24/40px、palt=0/1、中央closer5種、
markの前/後ASCII空白を独立に0/1/2、上下紙0/8、PNG/JPEG75で12,960入力。
情の既知部品を用いた適用対照を含み、未知字形/font/実資料holdoutとは扱わない。
本文だけのnative画像の中央に近い白列で左右を分け、元の全非白画素を保って、
none/1px細線/幅ceil(H/4)太線/4×4点を、左右gap0/1、上下紙0/8、PNG/JPEG75で
1,536非文字負例も固定する。計14,496入力、native renderer 3,264記録。
ノイズと本文の重なり0、全元画素保持、font file/glyph/advance/全SHAと組合せを先に検査する。

Auto回転は除外しない。元Autoと有効Horizontalのtensorを全3形状でbit照合してから全ROI認識を行う。
回転対象は元Horizontal指定も別監査し、方向の条件を独立標本へ数えない。
新旧全群で文字/単語が非悪化かつ実NNの適用がある場合だけ公開APIのRed→接続→Greenへ進む。
全変更/代表境界の実API/CLI、raw/候補/fragment/mean bit、全スイート、
fragment用ページ経路の不変性も前段と同様に確認する。新規推論と保存raw再生を区別する。
