from pathlib import Path
import json,hashlib
r=Path('tmp/internal-detached');m=json.loads((r/'fresh/evaluation-manifest.json').read_text());hh=json.loads((r/'horizontal/evaluation-manifest.json').read_text());native_noise=[];native_text=[];cli=[]
for x in m['inputs']:
 if x['kind']=='noise':
  if (x['palt']+x['gap']+x['paper']//8+(x['format']=='jpeg75'))%2==0:native_noise.append(x['id'])
  if (x['palt'],x['gap'],x['paper'],int(x['format']=='jpeg75'))in[(0,0,0,0),(1,1,8,1),(0,1,8,0),(1,0,0,1)]:cli.append(x['id'])
 elif x['spaces_before']==x['spaces_after']==1 and x['paper']==8:native_text.append(x['id'])
assert(len(native_noise),len(native_text),len(cli),len(hh['inputs']))==(384,240,192,56)
result={'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'integration_spec_sha256':hashlib.sha256(Path('docs/internal_detached_closer_integration.md').read_bytes()).hexdigest(),'main_manifest_sha256':hashlib.sha256((r/'fresh/evaluation-manifest.json').read_bytes()).hexdigest(),'horizontal_manifest_sha256':hashlib.sha256((r/'horizontal/evaluation-manifest.json').read_bytes()).hexdigest(),'api_noise_ids':native_noise,'api_spaced_text_ids':native_text,'api_horizontal_ids':[x['id']for x in hh['inputs']],'cli_noise_ids':cli,'selection_does_not_use_nn_outputs':True}
(r/'control-ids.json').write_text(json.dumps(result,indent=2)+'\n');print('API384noise/240text/56Horizontal,CLI192noise IDs fixed without reading NN outputs')
