import math,struct
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def emitted_means(row):
 assert len(row['chunks'])==1
 chunk=row['chunks'][0];assert not chunk['inserted_space_before']and chunk['text']==row['text']
 encoded=chunk['text'].encode();cursor=0;total=body_total=f32(0);count=body_count=0
 for step in chunk['steps']:
  if step['byte_range']is None:continue
  start,end=step['byte_range'];candidate=step['candidates'][0];ch=candidate['character'];p=f32(candidate['probability'])
  assert start==cursor and ch is not None and len(ch)==1 and encoded[start:end]==ch.encode()
  assert math.isfinite(p)and 0<=p<=1
  cursor=end;total=f32(total+p);count+=1
  if ch!=' ':body_total=f32(body_total+p);body_count+=1
 assert cursor==len(encoded)
 return(f32(total/f32(count))if count else f32(0),f32(body_total/f32(body_count))if body_count else None)
