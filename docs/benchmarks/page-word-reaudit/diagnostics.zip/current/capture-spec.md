# 過去のページ単語距離退行の再監査

## 先行仕様

- 基準は `1a66fce`。`page-band-fallback` の単語距離退行12指標
  （3画像・6画像設定組）を、最新の実モデルで再確認する。
- 入力と正解は過去のmanifestのSHA-256に一致させる。正解の再描画・編集はしない。
- 既存の `record_missing_context_runtime_matrix` をそのまま利用し、
  `missing-line-context` の287画像全体を30/100モデル・評価/既定設定で実行する。
  実行前に実バイナリ・driver・全production source・model・charset・入力をハッシュで固定する。
- ページ本文は公開PageRecognizerの行をLFで接続したものとする。
  画像ごとの本文・矩形・confidenceと既存context traceを保存する。
- `tools/eval_ocr_metrics.py` のnone/width/strictで文字距離と単語距離を比較する。
  当時のbefore/after、直近ページ評価と最新実行を区別する。
  改善、同点変更、非変更、退行を別々に数え、合計で退行を相殺しない。
- 退行が残る場合は入力/crop/生モデル/構造処理を分離して原因を特定する。
  製品変更の前に追加仕様と失敗する回帰テストを固定し、小さいRed→Greenで進める。
  文書固有の語句補正はcoreに追加しない。
- これは既知の開発回帰の再監査であり、未知の実資料への一般化や性能改善は主張しない。
