from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,os,sys
r=Path('tmp/page-word-reaudit');c=Path('tmp/page-word-tail-candidate');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
phase=sys.argv[1];root=r if phase=='before' else c
meta=json.loads((root/'cli-command.json').read_text());binary=root/'cli-binary';assert sha(binary)==meta['binary_sha256']
rows=json.loads((r/'evaluation-manifest.json').read_text())['inputs']
def run(job):
 row,mode=job;out=root/'cli'/mode/(row['id']+'.txt');out.parent.mkdir(parents=True,exist_ok=True)
 assert sha(row['image'])==row['image_sha256'];assert sha(row['truth'])==row['truth_sha256']
 argv=[str(binary.resolve()),'recognize-page','--image',row['image'],'--charset','models/NDLmoji.yaml','--use-deim-detection',str(mode=='deim').lower(),'--output-txt',str(out)]
 p=subprocess.run(argv,capture_output=True,env=os.environ|{'NDLOCR_INTRA_THREADS':'1'})
 out.with_suffix('.stdout').write_bytes(p.stdout);out.with_suffix('.stderr').write_bytes(p.stderr)
 record={'argv':argv,'returncode':p.returncode,'stdout_sha256':sha(out.with_suffix('.stdout')),'stderr_sha256':sha(out.with_suffix('.stderr'))}
 if p.returncode==0:record['body_sha256']=sha(out)
 out.with_suffix('.command.json').write_text(json.dumps(record,indent=2)+'\n');assert p.returncode==0,(argv,p.stderr)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(run,[(row,mode)for row in rows for mode in ['deim','bands']]))
(root/'cli-runs.json').write_text(json.dumps({'binary_sha256':sha(binary),'fresh_processes':len(results),'runs':results},indent=2)+'\n')
print(phase,len(results),'CLI processes completed')
