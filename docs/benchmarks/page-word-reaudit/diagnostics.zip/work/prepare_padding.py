from pathlib import Path
from PIL import Image
import hashlib,json
r=Path('tmp/page-word-reaudit');out=r/'raw-space-padding';out.mkdir(exist_ok=False);rows=[]
for id,index,truth in [('dense_observations_maru24_half',1,'測定場所、時刻、'),('dense_observations_maru36_half',1,'定場所、時刻、')]:
 source=r/(id+'-chunks')/f'{index:06}.png';img=Image.open(source).convert('RGB')
 for xpad in [0,1,2]:
  for ypad in [0,1,2]:
   id2=f'{id}_x{xpad}_y{ypad}';p=out/(id2+'.png');pad=Image.new('RGB',(img.width+2*xpad,img.height+2*ypad),'white');pad.paste(img,(xpad,ypad));assert pad.crop((xpad,ypad,xpad+img.width,ypad+img.height)).tobytes()==img.tobytes();pad.save(p);manifest=out/(id2+'.json');manifest.write_text(json.dumps([{'id':id2,'bounds':[0,0,pad.width,pad.height]}])+'\n');rows.append({'id':id2,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'image':str(p),'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dimensions':[pad.width,pad.height],'padding':[xpad,ypad],'truth':truth,'manifest':str(manifest)})
(out/'manifest.json').write_text(json.dumps({'spec_sha256':hashlib.sha256(Path('docs/page_word_regression_reaudit.md').read_bytes()).hexdigest(),'inputs':rows},ensure_ascii=False,indent=2)+'\n')
