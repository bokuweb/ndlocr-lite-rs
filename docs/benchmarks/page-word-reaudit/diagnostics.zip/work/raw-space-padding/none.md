# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `18`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| 50 | 18 | 0 | 0.0000 | 0.0000 |
| 100 | 18 | 0 | 0.0370 | 0.5556 |
| 30 | 18 | 0 | 0.0519 | 0.7778 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

