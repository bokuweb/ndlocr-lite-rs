from pathlib import Path
import json,zipfile,hashlib,subprocess,sys
r=Path('tmp/page-word-reaudit');c=Path('tmp/page-word-tail-candidate');out=Path('docs/benchmarks/page-word-reaudit');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();manifest=json.loads((r/'evaluation-manifest.json').read_text());modes=['deim','bands','runtime30_eval','runtime30_default','runtime100_eval','runtime100_default'];datasets={};diagnostics={}
for row in manifest['inputs']:
 datasets['images/'+row['id']+Path(row['image']).suffix]=Path(row['image']).read_bytes();datasets['truth/'+row['id']+'.txt']=Path(row['truth']).read_bytes()
for row in manifest['inputs']:
 for ancestor in list(Path(row['image']).parents)[:3]:
  readme=ancestor/'README.md'
  if readme.exists()and str(readme).startswith(('tests/fixtures/','docs/benchmarks/')):
   datasets['attribution/'+str(readme)]=readme.read_bytes()
for label,root,kind in [('previous_page',r,'previous-page'),('current',r,None),('candidate',c,None)]:
 for mode in modes:
  directory=root/kind/mode if kind else root/('cli'if mode in ['deim','bands']else'after')/mode
  for row in manifest['inputs']:datasets[f"{label}/{mode}/{row['id']}.txt"]=(directory/(row['id']+'.txt')).read_bytes()
for label,root in [('current',r),('candidate',c)]:
 for path in root.glob('after/*/results.json'):diagnostics[label+'/'+str(path.relative_to(root))]=path.read_bytes()
 for path in root.glob('cli/*/*'):
  if path.suffix!='.txt':diagnostics[label+'/'+str(path.relative_to(root))]=path.read_bytes()
 for name in ['capture-command.json','capture-spec.md','api-capture.log','cli-command.json','cli-runs.json','cli-capture.log']:
  diagnostics[label+'/'+name]=(root/name).read_bytes()
for name in ['reaudit-metrics','metrics']:
 root=r if name=='reaudit-metrics' else c
 for path in (root/name).glob('*'):datasets['expected/'+name+'/'+path.name]=path.read_bytes()
for path in r.iterdir():
 if path.is_file()and path.suffix in ['.json','.jsonl','.py','.log','.md','.txt']and path.name!='package.log'and not path.name.startswith('pr-'):
  diagnostics['work/'+path.name]=path.read_bytes()
for directory in ['raw-space-padding','dense_observations_maru24_half-chunks','dense_observations_maru36_half-chunks','crop_ja_heavy40_pad6-chunks','heavy-merged-chunks']:
 for path in (r/directory).rglob('*'):
  if path.is_file():diagnostics['work/'+str(path.relative_to(r))]=path.read_bytes()
# 実行時のsourceと先行仕様を、後の追記から区別して保存する。
for root,label in [(r,'current'),(c,'candidate')]:
 meta=json.loads((root/'capture-command.json').read_text());
 for p,expected in meta['sha256'].items():
  path=Path(p)
  if p=='docs/page_word_regression_reaudit.md':data=(root/'capture-spec.md').read_bytes()
  elif root==r and p.startswith(('src/','tests/')):data=subprocess.check_output(['git','show','1a66fce:'+p])
  else:data=path.read_bytes()
  assert sha(data)==expected,(label,p)
  if p.startswith('models/')or p.endswith('evaluation-manifest.json'):continue
  diagnostics[label+'/source/'+p]=data
for p,expected in json.loads((r/'export-command.json').read_text())['source_sha256'].items():
 if p.startswith('examples/'):
  data=Path(p).read_bytes();assert sha(data)==expected,p;diagnostics['export/source/'+p]=data
# 画像/本文を含むoriginal manifestと新しい仕様・検証結果。
for p in [Path('docs/page_word_regression_reaudit.md'),r/'evaluation-manifest.json',r/'verification.json']:
 diagnostics['final/'+p.name]=p.read_bytes()
for name,files in [('data',datasets),('diagnostics',diagnostics)]:
 path=out/(name+'.zip')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for key,data in sorted(files.items()):
   info=zipfile.ZipInfo(key,date_time=(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
 index={'sha256':sha(path.read_bytes()),'member_count':len(files),'members':{key:sha(data)for key,data in sorted(files.items())}}
 (out/(name+'.json')).write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
 print(name,len(files),path.stat().st_size)
