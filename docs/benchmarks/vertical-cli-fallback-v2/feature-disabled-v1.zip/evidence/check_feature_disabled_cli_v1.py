from pathlib import Path
from PIL import Image
import json,hashlib,subprocess
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
output=r/'feature-disabled-v1';output.mkdir();Image.new('RGB',(600,900),'white').save(output/'white.png')
images={'body':Path('tests/fixtures/vertical_fallback_page/arial121.png').resolve(),'white':output/'white.png'}
missing=output/'absent-model.onnx';assert not missing.exists();dummy=output/'dummy.onnx';dummy.write_bytes(b'dummy');charset=output/'charset.yaml';charset.write_text('model:\n  charset_train: "abc"\n')
before=json.loads((r/'before-NN-v1.json').read_text());bindings=dict(before['files_sha256'])
for path in [Path(__file__),r/'default-cli-baseline-frozen.json',r/'default-cli-candidate-frozen.json',Path(json.loads((r/'default-cli-baseline-frozen.json').read_text())['path']),Path(json.loads((r/'default-cli-candidate-frozen.json').read_text())['path']),dummy,charset,*images.values()]:bindings[str(path)]=sha(path)
assert all(sha(Path(n))==h for n,h in bindings.items())
(output/'before.json').write_text(json.dumps({'files_sha256':bindings,'CLI_processes_planned':16,'new_NN_calls':0,'model_loads':0,'production_change':False},indent=2)+'\n')
values={};receipts=[]
for variant in ['baseline','candidate']:
 meta=json.loads((r/f'default-cli-{variant}-frozen.json').read_text());binary=Path(meta['path']);assert sha(binary)==meta['sha256'];assert 'onnx' not in meta['compiler_artifact']['features']
 for asset in ['missing','dummy']:
  model=missing if asset=='missing' else dummy;chars=missing if asset=='missing' else charset
  for name,image in images.items():
   for deim in [False,True]:
    case=f'{variant}-{asset}-{name}-{deim}';text=output/(case+'.txt')
    argv=[str(binary),'recognize-page','--image',str(image),'--model',str(model),'--model30',str(missing),'--model50',str(missing),'--det-model',str(model),'--charset',str(chars),'--use-deim-detection',str(deim).lower(),'--output-txt',str(text)]
    actual=subprocess.run(argv,capture_output=True);(output/(case+'.stdout')).write_bytes(actual.stdout);(output/(case+'.stderr')).write_bytes(actual.stderr)
    value=(actual.returncode,actual.stdout,actual.stderr,text.read_bytes() if text.exists() else None);values[variant,asset,name,deim]=value
    receipts.append({'variant':variant,'asset':asset,'case':name,'deim':deim,'argv':argv,'exit_code':actual.returncode,'stdout_sha256':hashlib.sha256(actual.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(actual.stderr).hexdigest(),'body_exists':text.exists(),'body_sha256':sha(text) if text.exists() else None,'binary_sha256':sha(binary),'image_sha256':sha(image)})
(output/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
for asset in ['missing','dummy']:
 for name in images:
  for deim in [False,True]:
   before=values['baseline',asset,name,deim];after=values['candidate',asset,name,deim];assert before==after,(asset,name,deim,before,after)
   if name=='body':
    assert before[0]==1 and before[1]==b'' and before[3] is None
    assert (b'Error: file not found' if asset=='missing' else b'Error: onnx feature is disabled') in before[2]
   else:assert before[0]==0 and before[1]==b'\n' and before[3]==b''
assert all(sha(Path(n))==h for n,h in bindings.items())
summary={'CLI_processes':len(receipts),'cases':8,'identical_exit_stdout_stderr_body':True,'body_missing':'file not found, output absent','body_dummy':'feature disabled, output absent','white':'success,empty body,stdout single LF','new_NN_calls':0,'model_loads':0,'not_an_ONNX_accuracy_gate':True,'protocol':'existing v1 sixteen-case contract reused on v2 source; no model recognition','frozen_bytes_after_unchanged':True}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
