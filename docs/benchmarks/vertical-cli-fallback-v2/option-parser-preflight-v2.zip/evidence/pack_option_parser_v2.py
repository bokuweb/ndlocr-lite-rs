from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();p=repo/'tmp/vertical-cli-fallback-v2';folder=repo/'docs/benchmarks/vertical-cli-fallback-v2';sha=lambda b:hashlib.sha256(b).hexdigest();success=json.loads((p/'option-parse-preflight-v3/job.json').read_text());assert success['complete'] and success['CLI_processes']==48 and success['new_NN_calls']==success['model_loads']==0
assert all(r['exit_code']==1 for r in success['commands']);assert '10 passed; 0 failed;' in (p/'options-real-parser-green.stdout').read_text()
members={};archive=folder/'option-parser-preflight-v2.zip';files=[]
for label in ['option-parse-preflight-v2','option-parse-preflight-v3']:
 files.extend(('run/'+label+'/'+f.relative_to(p/label).as_posix(),f) for f in sorted((p/label).rglob('*')) if f.is_file())
 for ext in ['stdout','stderr']:files.append(('run/'+label+'.'+ext,p/(label+'.'+ext)))
for name in ['run_option_parse_preflight_v2.py','run_option_parse_preflight_v3.py','options-real-parser-red.stdout','options-real-parser-red.stderr','options-real-parser-green.stdout','options-real-parser-green.stderr','options-flag-red.stdout','options-flag-red.stderr','options-flag-green.stdout','options-flag-green.stderr','pack_option_parser_v2.py']:files.append(('evidence/'+name,p/name))
for name in ['docs/vertical_cli_fallback_v2_option_parser.md','tests/cli_tests.rs','tests/fixtures/cli_options/v2-plan-argv.json','tools/vertical_cli_fallback_v2_options.py']:files.append((name,repo/name))
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in files:
  raw=path.read_bytes();z.writestr(name,raw);members[name]={'bytes':len(raw),'sha256':sha(raw)}
meta={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members,'plan_v2_sha256':json.loads((folder/'options-plan-before-nn-v2.index.json').read_text())['sha256'],'actual_Rust_parser_argv':384,'actual_Rust_cli_tests_passed':10,'native_setting_vectors':48,'model_loads':0,'NN_calls':0,'failed_preflight_wrapper_preserved':'first preflight had correct exit1/OS error2 but validator expected a different error wording; no model recognition','first_option_matrix_parse_failure':'one CLI exit2 before any successful image result; preserved in options-plan-before-nn-v2 packet'};(folder/'option-parser-preflight-v2.index.json').write_text(json.dumps(meta,indent=2)+'\n');print({k:v for k,v in meta.items() if k!='members'})
