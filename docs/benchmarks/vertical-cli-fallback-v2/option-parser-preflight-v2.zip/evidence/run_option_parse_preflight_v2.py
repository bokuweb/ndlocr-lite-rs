from pathlib import Path
import hashlib,json,os,subprocess,sys
sys.path.insert(0,'tools')
from verify_vertical_cli_fallback_v2 import verify_option_plan
from verify_additional_real_baseline import _packet
repo=Path.cwd();p=repo/'tmp/vertical-cli-fallback-v2';folder=repo/'docs/benchmarks/vertical-cli-fallback-v2';assert verify_option_plan(folder)['planned_commands']==384
_,data=_packet(folder,'options-plan-before-nn-v2.index.json');plans=json.loads(data['evidence/option-plan-before-NN-v2.json']);before=json.loads((p/'before-NN-v1.json').read_text());sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();bindings=dict(before['files_sha256']);assert sha(repo/'src/cli.rs')==before['source_files']['src/cli.rs']
for q in [Path(__file__),repo/'src/cli.rs',repo/'tools/vertical_cli_fallback_v2_options.py',folder/'options-plan-before-nn-v2.zip',folder/'options-plan-before-nn-v2.index.json']:bindings[str(q)]=sha(q)
assert all(sha(n)==h for n,h in bindings.items());out=p/'option-parse-preflight-v2';out.mkdir();missing=out/'permanently-absent-input.png';assert not missing.exists();unique={}
for row in plans:unique.setdefault((row['variant'],row['profile'],row['deim'],row['cascade']),row)
assert len(unique)==48
meta={'complete':False,'files_sha256':bindings,'planned_CLI_processes':48,'new_NN_calls':0,'model_loads':0,'commands':[]};(out/'before.json').write_text(json.dumps(meta,indent=2)+'\n')
for index,row in enumerate(unique.values()):
 argv=list(row['argv']);argv[argv.index('--image')+1]=str(missing);r=subprocess.run(argv,cwd=repo,env=os.environ|{'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1'},capture_output=True)
 (out/(str(index)+'.stdout')).write_bytes(r.stdout);(out/(str(index)+'.stderr')).write_bytes(r.stderr)
 meta['commands'].append({'argv':argv,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()});(out/'job.json').write_text(json.dumps(meta,indent=2)+'\n')
 assert r.returncode==1 and r.stdout==b'' and b'file not found' in r.stderr.lower() and str(missing).encode() in r.stderr
assert not missing.exists() and all(sha(n)==h for n,h in bindings.items());meta.update({'complete':True,'CLI_processes':48,'all_missing_image_errors_after_parse':True,'frozen_files_after_unchanged':True});(out/'job.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({'complete':True,'CLI_processes':48,'parser_pass':True,'new_NN_calls':0,'model_loads':0}))
