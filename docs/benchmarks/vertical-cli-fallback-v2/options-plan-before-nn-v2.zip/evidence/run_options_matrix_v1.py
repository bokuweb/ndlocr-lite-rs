from pathlib import Path
import csv,hashlib,json,os,subprocess,sys
sys.path.insert(0,'tools')
import vertical_page_matrix as matrix
from verify_additional_real_baseline import _packet
from verify_low_stop_evidence import metric_values
from verify_vertical_cli_fallback_v2 import verify_new72,verify_option_plan
from vertical_cli_fallback_v2_option_runner import require_new72_gate
repo=Path.cwd();p=repo/'tmp/vertical-cli-fallback-v2';folder=repo/'docs/benchmarks/vertical-cli-fallback-v2';sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
verified=verify_new72(folder);require_new72_gate(verified);plan_verified=verify_option_plan(folder)
_,packet=_packet(folder,'options-plan-before-nn-v1.index.json');plans=json.loads(packet['evidence/option-plan-before-NN-v1.json']);assert len(plans)==384
out=p/'options-matrix-v1';out.mkdir();(out/'predictions').mkdir();(out/'plan.json').write_bytes(packet['evidence/option-plan-before-NN-v1.json'])
before=json.loads((p/'before-NN-v1.json').read_text());inputs=json.loads((p/'new-manifest.json').read_text())['inputs'];byid={r['id']:r for r in inputs};bindings=dict(before['files_sha256'])
verifier_copy=p/'options-preflight-reader-v1.py';verifier_copy.write_bytes((repo/'tools/verify_vertical_cli_fallback_v2.py').read_bytes())
for q in [Path(__file__),verifier_copy,out/'plan.json',repo/'tools/vertical_cli_fallback_v2_options.py',repo/'tools/vertical_cli_fallback_v2_option_runner.py',folder/'options-plan-before-nn-v1.zip',folder/'options-plan-before-nn-v1.index.json',folder/'new72-cli-matrix-v1.zip',folder/'new72-cli-matrix-v1.index.json']:
 bindings[str(q)]=sha(q)
assert all(sha(n)==h for n,h in bindings.items())
env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1','DYLD_LIBRARY_PATH':str(repo/'target/debug')+os.pathsep+str(repo/'target/debug/deps')}
meta={'complete':False,'files_sha256':bindings,'verified_new72_gate':verified,'verified_option_plan':plan_verified,'commands':[],'runtime_environment':env,'CLI_processes_planned':384,'official_CSV_rows_planned':1152,'internal_forward_calls':None,'model_session_loads':None,'new_accuracy_gain':False,'executed_CLI_processes':0};matrix.write_json(out/'before-NN.json',meta);matrix.write_json(out/'job.json',meta)
try:
 predictions={}
 for index,row in enumerate(plans,1):
  expected=Path(row['body']);assert expected.parent==out/'predictions' and expected.name==row['label']+'.txt'
  matrix.run_command(row['argv'],row['label'],out,meta,env);text=matrix.read_cli_result(out/'commands'/(row['label']+'.stdout'),expected)
  if row['profile']=='reject_all':assert text=='' and (out/'commands'/(row['label']+'.stdout')).read_bytes()==b'\n'
  system='_'.join([row['variant'],row['profile'],'deim',str(row['deim']).lower(),'cascade',str(row['cascade']).lower()]);predictions.setdefault(system,{})[row['id']]=text
  meta['executed_CLI_processes']=index;matrix.write_json(out/'job.json',meta)
  if index%32==0:print(json.dumps({'CLI_processes':index,'of':384}),flush=True)
 ids=list(dict.fromkeys(r['id'] for r in plans));assert len(ids)==8 and len(predictions)==48 and all(set(v)==set(ids) for v in predictions.values())
 truth=out/'metrics/truth';truth.mkdir(parents=True)
 for ident in ids:(truth/(ident+'.txt')).write_bytes(Path(byid[ident]['truth']).read_bytes())
 for system,values in predictions.items():
  d=out/'metrics'/system;d.mkdir()
  for ident,text in values.items():(d/(ident+'.txt')).write_text(text)
 comparisons=[];regressions=[];count=0
 for normalization in ['none','width','strict']:
  table=out/'metrics'/(normalization+'.csv');argv=[sys.executable,str(repo/'tools/eval_ocr_metrics.py'),'--truth-dir',str(truth)]
  for system in predictions:argv+=['--system',system+'='+str(out/'metrics'/system)]
  argv+=['--normalize',normalization,'--require-all','--output-csv',str(table)];matrix.run_command(argv,'metrics-'+normalization,out,meta)
  rows=list(csv.DictReader(table.open()));assert len(rows)==384 and len({(r['system'],r['file']) for r in rows})==384
  for r in rows:
   expected=metric_values((truth/r['file']).read_text(),(out/'metrics'/r['system']/r['file']).read_text(),normalization)
   assert tuple(int(r[k]) for k in ['char_errors','char_total','word_errors','word_total'])==expected;count+=1
  indexed={(r['system'],r['file']):r for r in rows}
  for row in plans:
   if row['variant']!='baseline':continue
   suffix='_'.join([row['profile'],'deim',str(row['deim']).lower(),'cascade',str(row['cascade']).lower()]);a=indexed['baseline_'+suffix,row['id']+'.txt'];b=indexed['candidate_'+suffix,row['id']+'.txt']
   entry={'normalization':normalization,'id':row['id'],'profile':row['profile'],'deim':row['deim'],'cascade':row['cascade'],'before':a,'after':b};comparisons.append(entry)
   if any(int(b[k])>int(a[k]) for k in ['char_errors','word_errors']):regressions.append(entry)
 assert count==1152 and len(comparisons)==576 and all(sha(n)==h for n,h in bindings.items())
 meta.update({'complete':True,'frozen_files_after_unchanged':True,'verified_CSV_rows':count,'comparisons':len(comparisons),'regressions':len(regressions),'option_gate_pass':not regressions})
 matrix.write_json(out/'comparisons.json',comparisons);matrix.write_json(out/'regressions.json',regressions);matrix.write_json(out/'summary.json',{k:v for k,v in meta.items() if k not in ['files_sha256','commands']});print(json.dumps({'complete':True,'CLI_processes':384,'verified_CSV_rows':count,'regressions':len(regressions),'option_gate_pass':not regressions}),flush=True)
except Exception as error:meta['error']=repr(error);raise
finally:matrix.write_json(out/'job.json',meta)
