from pathlib import Path
import hashlib,json,subprocess,sys
repo=Path.cwd();p=Path(__file__).resolve().parent;sys.path.insert(0,str(repo/'tools'));from vertical_cli_fallback_v2_option_runner import require_root_v2_full_gate
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
summary=json.loads((p/'full-comparison-v1/summary.json').read_text());require_root_v2_full_gate(summary)
run=json.loads((p/'full-complete-run-v1.json').read_text());assert run['databaseId']==39593424953 and run['headSha']=='fe0e359371fb7ca7b289092103f6d7f16d41d62f' and run['conclusion']=='success' and len(run['jobs'])==59 and all(r['conclusion']=='success' for r in run['jobs'])
replay=json.loads((p/'full-independent-replay-v1.json').read_text());require_root_v2_full_gate({'complete':replay['complete_workers']==56,**replay});assert replay['scoring_comparison_pairs']==39510
proposal=json.loads((p/'root-runtime-proposed-v1.json').read_text());assert not proposal['applied_to_Root']
for name,meta in proposal['files'].items():
 path=repo/name
 if meta['before_sha256'] is None:assert not path.exists(),name
 else:assert sha(path)==meta['before_sha256'],name
patch=p/'root-runtime-proposed-v1.patch';subprocess.run(['git','apply','--check',str(patch)],check=True);subprocess.run(['git','apply',str(patch)],check=True)
assert all(sha(repo/name)==meta['after_sha256'] for name,meta in proposal['files'].items())
(p/'root-runtime-applied-v1.json').write_text(json.dumps({'applied_to_Root':True,'full_gate_run':39593424953,'full_summary_sha256':sha(p/'full-comparison-v1/summary.json'),'independent_replay_sha256':sha(p/'full-independent-replay-v1.json'),'run_status_sha256':sha(p/'full-complete-run-v1.json'),'patch_sha256':sha(patch),'files':proposal['files']},indent=2)+'\n')
print('Root runtime patch applied only after complete v2 gate and independent replay')
