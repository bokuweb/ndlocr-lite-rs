from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
repo=Path.cwd();p=Path(__file__).resolve().parent;out=p/'root-after-native-v2';out.mkdir();sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
frozen=json.loads((p/'root-candidate-frozen-v2.json').read_text());bindings={str(repo/n):h for n,h in frozen['source_files'].items()}
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets']
for key in ['30','50','100','deim','charset']:bindings[str(repo/'models'/assets[key]['name'])]=assets[key]['sha256']
for value in frozen['binaries'].values():bindings[value['path']]=value['sha256']
for path in [Path(__file__),p/'root-candidate-frozen-v2.json',p/'root-runtime-applied-v1.json']:bindings[str(path)]=sha(path)
assert all(sha(n)==h for n,h in bindings.items())
base={'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1'}
commands=[{'label':'CLI','argv':[frozen['binaries']['test']['path'],'--ignored','--nocapture','--test-threads=1'],'env':base|{'NDLOCR_TEST_CLI_BINARY':frozen['binaries']['bin']['path'],'NDLOCR_TEST_CLI_EVIDENCE':str(out/'CLI-evidence')},'expected_test_result':'2 passed; 0 failed;'}, {'label':'known-quality','argv':[frozen['binaries']['libtest']['path'],'--ignored','--exact','app::vertical_cli_finish_known::accepted_vertical_finishes_like_existing_page_batch_with_quality_options','--nocapture','--test-threads=1'],'env':base|{'NDLOCR_TEST_FVC_FINISH_EVIDENCE':str(out/'known-quality-evidence')},'expected_test_result':'1 passed; 0 failed;'}, {'label':'ONNX-nonignored-lib','argv':[frozen['binaries']['libtest']['path'],'--test-threads=1'],'env':base,'expected_test_result':'; 0 failed;'}]
(out/'CLI-evidence').mkdir();meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files_sha256':bindings,'commands_planned':commands,'commands':[],'complete':False}
(out/'before-NN.json').write_text(json.dumps(meta,indent=2)+'\n')
try:
 for command in commands:
  assert all(sha(n)==h for n,h in bindings.items());started=time.monotonic()
  with (out/(command['label']+'.stdout')).open('xb') as stdout,(out/(command['label']+'.stderr')).open('xb') as stderr:result=subprocess.run(command['argv'],cwd=repo,env=os.environ|command['env'],stdout=stdout,stderr=stderr)
  receipt=command|{'exit_code':result.returncode,'seconds':time.monotonic()-started,'frozen_files_after_unchanged':all(sha(n)==h for n,h in bindings.items())};meta['commands'].append(receipt)
  assert result.returncode==0 and receipt['frozen_files_after_unchanged'];assert command['expected_test_result'] in (out/(command['label']+'.stdout')).read_text()
 meta['complete']=True
finally:(out/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'complete':True,'Root_CLI_literal_Green':2,'Root_known_quality_Green':1,'ONNX_nonignored_suite_pass':True,'source_files':len(frozen['source_files'])}),flush=True)
