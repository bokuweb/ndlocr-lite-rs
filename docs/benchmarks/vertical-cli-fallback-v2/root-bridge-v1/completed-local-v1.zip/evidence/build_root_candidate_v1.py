from pathlib import Path
import hashlib,json,os,shutil,subprocess
repo=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
applied=json.loads((p/'root-runtime-applied-v1.json').read_text());assert applied['applied_to_Root'] and applied['full_gate_run']==39593424953
assert all(sha(repo/n)==m['after_sha256'] for n,m in applied['files'].items())
subprocess.run(['python3',str(p/'audit_root_runtime_source_v1.py'),'--root'],cwd=repo,check=True)
names=set(json.loads((p/'root-baseline-frozen-v1.json').read_text())['source_files'])
names.update(n for n in applied['files'] if n.endswith('.rs'));sources={n:sha(repo/n) for n in sorted(names)}
env=os.environ|{'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_TEST_STRIP':'none','CARGO_PROFILE_DEV_STRIP':'none'}
cargo='/Users/bokuweb/Library/Application Support/mbx/bin/cargo';frozen={};allown=[]
for step,arguments in [('lib',['--lib']),('cli',['--test','vertical_fallback_cli_tests'])]:
 assert all(sha(repo/n)==h for n,h in sources.items())
 # Byte-preserving timestamp change prevents stale own artifacts after copied source.
 for n in sources:
  if n.endswith('.rs'):os.utime(repo/n,None)
 argv=[cargo,'test','--locked','--features','onnx',*arguments,'--no-run','--message-format=json']
 stdout=p/f'root-candidate-{step}-build-v1.jsonl';stderr=p/f'root-candidate-{step}-build-v1.stderr'
 with stdout.open('xb') as out,stderr.open('xb') as err:subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=err,check=True)
 events=[json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
 own=[r for r in events if r.get('reason')=='compiler-artifact' and r.get('manifest_path')==str(repo/'Cargo.toml')];assert own and all(r['fresh'] is False for r in own),own
 allown.extend(own)
 for event in own:
  if not event['executable']:continue
  kind=event['target']['kind'];label='libtest' if kind==['lib'] else 'test' if kind==['test'] else 'bin' if kind==['bin'] else None;assert label
  assert label not in frozen;binary=Path(event['executable']);dest=p/f'root-candidate-{label}-v1';assert not dest.exists();shutil.copy2(binary,dest);assert sha(binary)==sha(dest)
  frozen[label]={'path':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest),'compiler_artifact':event,'build_stdout_sha256':sha(stdout)}
 assert all(sha(repo/n)==h for n,h in sources.items())
 (p/'root-candidate-frozen-progress-v1.json').write_text(json.dumps({'source_files':sources,'binaries':frozen,'own_artifacts':allown},indent=2)+'\n')
assert set(frozen)=={'libtest','test','bin'}
(p/'root-candidate-frozen-v1.json').write_text(json.dumps({'source_files':sources,'binaries':frozen,'own_artifacts':allown,'root_patch_receipt_sha256':sha(p/'root-runtime-applied-v1.json'),'runtime_source_bridge_sha256':sha(p/'root-runtime-source-bridge-actual-v1.json'),'all_primary_own_artifacts_fresh':False},indent=2)+'\n')
print(json.dumps({'frozen':{k:{x:v[x] for x in ['bytes','sha256']} for k,v in frozen.items()},'source_files':len(sources)}),flush=True)
