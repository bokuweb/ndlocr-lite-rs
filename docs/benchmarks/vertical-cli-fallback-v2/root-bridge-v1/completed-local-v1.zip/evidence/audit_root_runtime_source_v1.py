from pathlib import Path
import hashlib,json,sys
repo=Path.cwd();p=Path(__file__).resolve().parent;frozen=p/'source';proposal=json.loads((p/'root-runtime-proposed-v1.json').read_text());actual='--root' in sys.argv
sha=lambda b:hashlib.sha256(b).hexdigest();files={str(f.relative_to(frozen)) for f in (frozen/'src').rglob('*.rs')};root_files={str(f.relative_to(repo)) for f in (repo/'src').rglob('*.rs')};root_files.update(n for n in proposal['files'] if n.startswith('src/') and n.endswith('.rs'));assert files==root_files
all_files={};different=[]
for name in sorted(files):
 before=(frozen/name).read_bytes();path=repo/name if actual or name not in proposal['files'] else p/'root-runtime-staging-v1'/name;after=path.read_bytes();expected=before
 if name=='src/infer/vertical_capacity.rs':
  expected=expected.replace(b'mod prefix;\n',b'mod prefix;\n\n#[cfg(test)]\n#[path = "../../tests/support/vertical_primary_partition_geometry.rs"]\nmod primary_partition_geometry;\n',1)
 elif name=='src/infer/vertical_fallback.rs':
  expected=expected.replace(b'rgb.chunks_exact(3).enumerate()',b'rgb.as_chunks::<3>().0.iter().enumerate()',1)
  for block in [b'\n#[cfg(test)]\n#[path = "../../tests/support/vertical_fallback_capture.rs"]\nmod capture;\n',b'\n#[cfg(test)]\n#[path = "../../tests/support/vertical_cli_geometry.rs"]\nmod cli_geometry_capture;\n']:
   assert expected.count(block)==1;expected=expected.replace(block,b'',1)
 assert after==expected,name
 all_files[name]={'frozen_v2_sha256':sha(before),'Root_sha256':sha(after)}
 if before!=after:different.append(name)
assert different==['src/infer/vertical_capacity.rs','src/infer/vertical_fallback.rs']
result={'actual_Root_runtime':actual,'src_Rust_files':len(files),'all_src_files':all_files,'different_files':different,'allowed_difference':'test-only geometry registration; omit2privatecfgtestcapture modules; preserve already-tested Root32 chunks_exact->as_chunks iterator','audit_script_sha256':sha(Path(__file__).read_bytes())}
dest=p/('root-runtime-source-bridge-actual-v1.json' if actual else 'root-runtime-source-bridge-predicted-v1.json');dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='all_src_files'}),flush=True)
