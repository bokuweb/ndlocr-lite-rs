from pathlib import Path
from PIL import Image
import hashlib,json,os,shutil,subprocess
repo=Path.cwd();p=Path(__file__).resolve().parent;out=p/'root-feature-disabled-v1';out.mkdir();sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
applied=json.loads((p/'root-runtime-applied-v1.json').read_text());assert applied['applied_to_Root']
native=json.loads((p/'root-candidate-frozen-v2.json').read_text());sources=native['source_files'];assert all(sha(repo/n)==h for n,h in sources.items())
env=os.environ|{'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_TEST_STRIP':'none','CARGO_PROFILE_DEV_STRIP':'none'}
cargo='/Users/bokuweb/Library/Application Support/mbx/bin/cargo';frozen={};own_all=[]
for label,arguments in [('bin',['build','--bin','ndlocr-lite-rs']),('libtest',['test','--lib','--no-run'])]:
 for n in sources:
  if n.endswith('.rs'):os.utime(repo/n,None)
 stdout=p/f'root-default-candidate-{label}-build-v1.jsonl';stderr=p/f'root-default-candidate-{label}-build-v1.stderr';argv=[cargo,*arguments,'--locked','--message-format=json']
 with stdout.open('xb') as f,stderr.open('xb') as e:subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=e,check=True)
 events=[json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')];own=[r for r in events if r.get('reason')=='compiler-artifact' and r.get('manifest_path')==str(repo/'Cargo.toml')]
 assert own and all(r['fresh'] is False and 'onnx' not in r['features'] for r in own);own_all.extend(own)
 event,=[r for r in own if r['executable']];binary=Path(event['executable']);dest=p/f'root-default-candidate-{label}-v1';assert not dest.exists();shutil.copy2(binary,dest);assert sha(dest)==sha(binary)
 frozen[label]={'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'compiler_artifact':event,'build_stdout_sha256':sha(stdout)}
 assert all(sha(repo/n)==h for n,h in sources.items())
 (p/'root-default-candidate-frozen-progress-v1.json').write_text(json.dumps({'source_files':sources,'binaries':frozen,'own_artifacts':own_all},indent=2)+'\n')
(p/'root-default-candidate-frozen-v1.json').write_text(json.dumps({'source_files':sources,'binaries':frozen,'own_artifacts':own_all,'NN_calls':0,'model_loads':0},indent=2)+'\n')
with (out/'default-lib.stdout').open('xb') as f,(out/'default-lib.stderr').open('xb') as e:subprocess.run([frozen['libtest']['path'],'--test-threads=1'],cwd=repo,stdout=f,stderr=e,check=True)
assert '; 0 failed;' in (out/'default-lib.stdout').read_text()
baseline=json.loads((p/'root-default-baseline-frozen-v1.json').read_text());assert sha(baseline['path'])==baseline['sha256'] and all(r['fresh'] is False and 'onnx' not in r['features'] for r in baseline['own_artifacts'])
Image.new('RGB',(600,900),'white').save(out/'white.png');images={'body':repo/'tests/fixtures/vertical_fallback_page/arial121.png','white':out/'white.png'}
missing=out/'absent.onnx';assert not missing.exists();dummy=out/'dummy.onnx';dummy.write_bytes(b'dummy');charset=out/'charset.yaml';charset.write_text('model:\n  charset_train: "abc"\n')
bindings={str(repo/n):h for n,h in sources.items()}
for path in [Path(__file__),p/'root-default-baseline-frozen-v1.json',p/'root-default-candidate-frozen-v1.json',Path(baseline['path']),Path(frozen['bin']['path']),Path(frozen['libtest']['path']),dummy,charset,*images.values()]:bindings[str(path)]=sha(path)
assert all(sha(n)==h for n,h in bindings.items());commands=[];values={}
(out/'before-CLI.json').write_text(json.dumps({'files_sha256':bindings,'CLI_processes_planned':16,'NN_calls':0,'model_loads':0,'complete':False},indent=2)+'\n')
for variant,binary in [('baseline',baseline['path']),('candidate',frozen['bin']['path'])]:
 for asset in ['missing','dummy']:
  model=missing if asset=='missing' else dummy;chars=missing if asset=='missing' else charset
  for name,image in images.items():
   for deim in [False,True]:
    case=f'{variant}-{asset}-{name}-{deim}';body=out/(case+'.txt');argv=[binary,'recognize-page','--image',str(image),'--model',str(model),'--model30',str(missing),'--model50',str(missing),'--det-model',str(model),'--charset',str(chars),'--use-deim-detection',str(deim).lower(),'--output-txt',str(body)]
    result=subprocess.run(argv,cwd=repo,capture_output=True);(out/(case+'.stdout')).write_bytes(result.stdout);(out/(case+'.stderr')).write_bytes(result.stderr)
    value=(result.returncode,result.stdout,result.stderr,body.read_bytes() if body.exists() else None);values[variant,asset,name,deim]=value
    commands.append({'variant':variant,'asset':asset,'case':name,'deim':deim,'argv':argv,'exit_code':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),'body_exists':body.exists(),'body_sha256':sha(body) if body.exists() else None,'binary_sha256':sha(binary),'image_sha256':sha(image)})
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for asset in ['missing','dummy']:
 for name in images:
  for deim in [False,True]:
   before=values['baseline',asset,name,deim];assert before==values['candidate',asset,name,deim],(asset,name,deim)
   if name=='body':assert before[0]==1 and before[1]==b'' and before[3] is None and (b'Error: file not found' if asset=='missing' else b'Error: onnx feature is disabled') in before[2]
   else:assert before[0]==0 and before[1]==b'\n' and before[3]==b''
assert all(sha(n)==h for n,h in bindings.items())
summary={'CLI_processes':len(commands),'cases':8,'identical_exit_stdout_stderr_body':True,'NN_calls':0,'model_loads':0,'default_lib_passed':True,'frozen_bytes_after_unchanged':True,'not_an_ONNX_accuracy_gate':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
