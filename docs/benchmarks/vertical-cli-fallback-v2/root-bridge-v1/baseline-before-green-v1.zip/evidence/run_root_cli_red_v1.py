from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
repo=Path.cwd();p=Path(__file__).resolve().parent;out=p/'root-before-cli-red-v1';out.mkdir();(out/'evidence').mkdir();sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();frozen=json.loads((p/'root-baseline-frozen-v1.json').read_text());bindings={str(repo/n):h for n,h in frozen['source_files'].items()};assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets']
for key in ['30','deim','charset']:bindings[str(repo/'models'/assets[key]['name'])]=assets[key]['sha256']
for value in frozen['binaries'].values():bindings[value['path']]=value['sha256']
for path in [Path(__file__),p/'root-baseline-frozen-v1.json',p/'root-baseline-build-v1.jsonl',repo/'docs/vertical_cli_fallback_v2_root_bridge.md']:bindings[str(path)]=sha(path)
assert all(sha(n)==h for n,h in bindings.items())
argv=[frozen['binaries']['test']['path'],'--ignored','--nocapture','--test-threads=1'];env={'NDLOCR_TEST_CLI_BINARY':frozen['binaries']['bin']['path'],'NDLOCR_TEST_CLI_EVIDENCE':str(out/'evidence'),'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1'};meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files_sha256':bindings,'argv':argv,'env':env,'CLI_processes_planned':2,'complete':False};(out/'before-NN.json').write_text(json.dumps(meta,indent=2)+'\n');started=time.monotonic()
with (out/'run.stdout').open('xb') as stdout,(out/'run.stderr').open('xb') as stderr:process=subprocess.run(argv,cwd=repo,env=os.environ|env,stdout=stdout,stderr=stderr)
meta.update(exit_code=process.returncode,seconds=time.monotonic()-started,frozen_files_after_unchanged=all(sha(n)==h for n,h in bindings.items()))
commands=[json.loads(path.read_text()) for path in sorted((out/'evidence').glob('*/command.json'))];assert len(commands)==2 and all(r['exit_code']==0 for r in commands) and meta['frozen_files_after_unchanged'];assert process.returncode==101 and '2 failed;' in (out/'run.stdout').read_text();meta.update(complete=True,expected_literal_failures=2,successful_CLI_processes=2,internal_forward_calls=None)
(out/'command.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({'complete_expected_Red':True,'CLI_processes':2,'literal_failures':2,'exit_code':process.returncode}),flush=True)
