from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;out=repo/'docs/benchmarks/vertical-cli-fallback-v2/root-bridge-v1';sha=lambda b:hashlib.sha256(b).hexdigest();data={}
proposal=json.loads((p/'root-runtime-proposed-v1.json').read_text());names=set(proposal['files'])|{'tests/support/vertical_cli_finish_known.rs','tools/root_source_coverage.py','tests/test_root_source_coverage.py','docs/benchmarks/vertical-cli-fallback-v2/options-plan-before-nn-v2.zip'}
names.update(str(f.relative_to(repo)) for f in (repo/'tests/fixtures/vertical_fallback_cli_finish').iterdir() if f.is_file())
for name in names:data['source/'+name]=(repo/name).read_bytes()
evidence=['root-runtime-proposed-v1.patch','root-runtime-proposed-v1.json','root-runtime-applied-v1.json','apply_root_runtime_v1.py','audit_root_runtime_source_v1.py','root-runtime-source-bridge-actual-v1.json','root-default-candidate-frozen-v2.json','root-default-baseline-frozen-v1.json','check_root_disabled_v2.py','root-disabled-driver-v2.stdout','root-disabled-driver-v2.stderr','root-onnx-clippy-v1.stdout','root-onnx-clippy-v1.stderr','root-default-clippy-v1.stdout','root-default-clippy-v1.stderr','root-fmt-check-v1.stdout','root-fmt-check-v1.stderr','root-candidate-frozen-v3.json','build_root_candidate_v3.py','root-candidate-build-driver-v3.stdout','root-candidate-build-driver-v3.stderr','run_root_native_green_v3.py','root-native-green-driver-v3.stdout','root-native-green-driver-v3.stderr','root-source-coverage-audit-v1.json','root-source-coverage-red-v1.stdout','root-source-coverage-red-v1.stderr','root-source-coverage-green-v1.stdout','root-source-coverage-green-v1.stderr','root-completed-reader-red-v1.stdout','root-completed-reader-red-v1.stderr','root-completed-reader-green-v1.stdout','root-completed-reader-green-v1.stderr','root-completed-reader-initial-v1.py']
for step in ['lib','cli']:evidence += [f'root-candidate-{step}-build-v3.jsonl',f'root-candidate-{step}-build-v3.stderr']
for step in ['bin','libtest']:evidence += [f'root-default-candidate-{step}-build-v2.jsonl',f'root-default-candidate-{step}-build-v2.stderr']
for name in evidence:data['evidence/'+name]=(p/name).read_bytes()
for prefix,folder in [('native-v3','root-after-native-v3'),('disabled','root-feature-disabled-v2')]:
 for path in (p/folder).rglob('*'):
  if path.is_file():data[prefix+'/'+str(path.relative_to(p/folder))]=path.read_bytes()
for name in ['docs/vertical_cli_fallback_v2_root_bridge.md','docs/vertical_cli_finish_root_assets.md','docs/vertical_cli_fallback_v2_root_completed_packet.md','docs/vertical_cli_fallback_v2_root_source_coverage.md']:data[name]=(repo/name).read_bytes()
archive=out/'completed-local-v2.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in data.items()},'before_Root_packet_sha256':json.loads((out/'baseline-before-green-v1.index.json').read_text())['sha256'],'full_completed_packet_sha256':json.loads((out.parent/'full-matrix-v1/completed-linux-v1.index.json').read_text())['sha256'],'old_incomplete_packet_sha256':json.loads((out/'completed-local-v1.index.json').read_text())['sha256'],'native_executables_in_public_packet':False,'complete_source_files':852,'new_model_calls_in_replay':0}
(out/'completed-local-v2.index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='members'}))
(out/'completed-local-v1-status.json').write_text(json.dumps({'archive':'completed-local-v1.zip','complete_source_freeze':False,'declared_files':847,'missing_registered_quality_and_fixture_files':4,'also_unbound_embedded_option_plan':1,'not_the_adopted_Root_evidence':True,'successor':'completed-local-v2.index.json'},indent=2)+'\n')
