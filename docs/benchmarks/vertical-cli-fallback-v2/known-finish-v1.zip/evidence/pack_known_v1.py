from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;folder=repo/'docs/benchmarks/vertical-cli-fallback-v2';members={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
def add(z,name,raw):
 assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts;z.writestr(name,raw);members[name]={'bytes':len(raw),'sha256':sha(raw)}
archive=folder/'known-finish-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for label in ['known-finish-v1','known-finish-v2','known-finish-v3','known-finish-v4','known-cli-v1']:
  for f in sorted((p/label).rglob('*')):
   if f.is_file():add(z,'run/'+label+'/'+f.relative_to(p/label).as_posix(),f.read_bytes())
  for ext in ['stdout','stderr']:add(z,'run/'+label+'.'+ext,(p/(label+'.'+ext)).read_bytes())
 for name in ['run_known_finish_v1.py','run_known_finish_v2.py','run_known_finish_v3.py','run_known_finish_v4.py','run_known_cli_v1.py','known-uncertain-arial30-origin.json','known-fva-arial12-origin.json','known-reader-red.stdout','known-reader-red.stderr']:add(z,'evidence/'+name,(p/name).read_bytes())
 for name in ['known-uncertain-arial30.png','known-fva-arial12.png']:add(z,'known-inputs/'+name,(p/name).read_bytes())
 image=repo/'tmp/vertical-cli-fallback/inputs/fvc_arial_43_pad4.png';add(z,'known-inputs/'+image.name,image.read_bytes())
 old=repo/'tmp/vertical-cli-fallback/source/tests/fixtures/vertical_fallback_page';case=json.loads((old/'case.json').read_text());add(z,'known-cli-fixture/case.json',(old/'case.json').read_bytes());add(z,'known-cli-fixture/'+case['image'],(old/case['image']).read_bytes())
 add(z,'known-cli-test.rs',(repo/'tmp/vertical-cli-fallback/source/tests/vertical_fallback_cli_tests.rs').read_bytes());add(z,'protocol/vertical_cli_fallback_known_finish.md',(repo/'docs/vertical_cli_fallback_known_finish.md').read_bytes());add(z,'evidence/pack_known_v1.py',Path(__file__).read_bytes())
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members,'before_NN_packet_sha256':json.loads((folder/'before-nn-v1.index.json').read_text())['sha256'],'known_only':True,'failed_attempts_preserved':3,'successful_settings':3,'all_recorded_settings':9,'native_forward_calls':None,'explicit_PARSeq_pool_loads_across_three_executed_attempts':9,'model_session_loads_first_charset_failure':0,'Page_API_results':0,'known_literal_CLI_processes':2,'literal_CLI_raw_body_capture':'Rust literal assertion passed; tempfile body not retained separately','new_accuracy_gain':False}
(folder/'known-finish-v1.index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='members'},indent=2))
