from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,struct
repo=Path.cwd();p=Path(__file__).resolve().parent;sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();write=lambda q,v:Path(q).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
before=json.loads((p/'before-NN-v1.json').read_text());bindings=dict(before['files_sha256']);origin=json.loads((p/'known-uncertain-arial30-origin.json').read_text());image=Path(origin['image']);assert sha(image)==origin['image_sha256'];bindings[str(image)]=origin['image_sha256'];bindings[str(p/'known-uncertain-arial30-origin.json')]=sha(p/'known-uncertain-arial30-origin.json')
for path in [Path(__file__),p/'before-NN-v1.json',repo/'docs/benchmarks/vertical-cli-fallback-v2/before-nn-v1.zip',repo/'docs/benchmarks/vertical-cli-fallback-v2/before-nn-v1.index.json']:bindings[str(path)]=sha(path)
work=p/'known-finish-v3-work';work.mkdir();(work/'models').symlink_to(repo/'models',target_is_directory=True)
charset=work/'ndlocr/src/config/NDLmoji.yaml';charset.parent.mkdir(parents=True);charset.write_bytes((repo/'models/NDLmoji.yaml').read_bytes());bindings[str(charset)]=sha(repo/'models/NDLmoji.yaml')
assert all(sha(n)==h for n,h in bindings.items());out=p/'known-finish-v3';out.mkdir()
argv=[before['frozen_candidate_test']['path'],'--ignored','--exact','app::vertical_cli_finish_known::accepted_vertical_finishes_like_existing_page_batch_with_quality_options','--nocapture','--test-threads=1']
env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1','NDLOCR_FVC_V2_KNOWN_IMAGE':str(image.resolve()),'NDLOCR_FVC_V2_KNOWN_OUTPUT':str(out/'results')}
meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'env':env,'cwd':str(work),'files_sha256':bindings,'physical_known_inputs':1,'settings':3,'successful_initial_batch_invocations_planned':6,'successful_finish_invocations_planned':6,'ParseqPool_loads_planned':3,'internal_forward_calls':None,'Page_API_results':0,'GT_passed':False,'new_accuracy_gain':False,'complete':False};write(out/'before.json',meta);start=time.monotonic()
with (out/'run.stdout').open('xb') as stdout,(out/'run.stderr').open('xb') as stderr:process=subprocess.run(argv,cwd=work,env=os.environ|env,stdout=stdout,stderr=stderr)
meta.update({'exit_code':process.returncode,'seconds':time.monotonic()-start,'frozen_bytes_after_unchanged':all(sha(n)==h for n,h in bindings.items())});write(out/'command.json',meta)
assert process.returncode==0 and meta['frozen_bytes_after_unchanged']
assert '1 passed; 0 failed; 0 ignored;' in (out/'run.stdout').read_text()
rows=json.loads((out/'results/results.json').read_text());assert len(rows)==3
assert [(r['quality_boost'],struct.pack('!f',r['quality_boost_min_delta'])) for r in rows]==[(q,struct.pack('!f',d)) for q,d in [(False,.03),(True,.03),(True,-100.0)]]
assert (work/'models').resolve()==repo/'models'
assert all(r['actual_text']==r['expected_text'] and r['actual_mean_bits']==r['expected_mean_bits'] for r in rows)
assert any(r['quality_boost'] and (r['actual_text']!=r['initial_text'] or r['actual_mean_bits']!=r['initial_mean_bits']) for r in rows)
meta['complete']=True;write(out/'command.json',meta);print(json.dumps({'complete':True,'settings':3,'old_full_pipeline_matches':3,'quality_changes_initial':True,'GT_used':False,'new_accuracy_gain':False},indent=2))
