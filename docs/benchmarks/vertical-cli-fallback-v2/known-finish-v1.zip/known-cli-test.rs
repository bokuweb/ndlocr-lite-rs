#![cfg(feature = "onnx")]

use std::path::{Path, PathBuf};

#[test]
#[ignore = "mandatory pinned models; run only after the frozen FVB gate is resolved"]
fn supported_vertical_cli_fallback_restores_literal_body_without_stdout_framing_changes() {
    let asset = |name: &str, fallback: &str| {
        std::env::var_os(name)
            .map(PathBuf::from)
            .unwrap_or_else(|| fallback.into())
    };
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let model = asset(
        "NDLOCR_TEST_PARSEQ_MODEL",
        "models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
    );
    let detector = asset("NDLOCR_TEST_DEIM_MODEL", "models/deim-s-1024x1024.onnx");
    let charset = asset("NDLOCR_TEST_CHARSET", "models/NDLmoji.yaml");
    for file in [&model, &detector, &charset] {
        assert!(
            file.is_file(),
            "mandatory regression asset missing: {}",
            file.display()
        );
    }
    let fixture = root.join("tests/fixtures/vertical_fallback_page");
    let case: serde_json::Value =
        serde_json::from_slice(&std::fs::read(fixture.join("case.json")).unwrap()).unwrap();
    let expected = case["expected"].as_str().unwrap().as_bytes();
    let image = fixture.join(case["image"].as_str().unwrap());
    let before = std::fs::read(&image).unwrap();
    let output = tempfile::tempdir().unwrap();
    let absent = output.path().join("not-provided.onnx");
    assert!(!absent.exists());
    let binary = std::env::var_os("NDLOCR_TEST_CLI_BINARY")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_BIN_EXE_ndlocr-lite-rs")));
    for deim in [false, true] {
        let body = output.path().join(format!("body-{deim}.txt"));
        let result = std::process::Command::new(&binary)
            .current_dir(root)
            .args(["recognize-page", "--image"])
            .arg(&image)
            .arg("--model")
            .arg(&model)
            .arg("--model30")
            .arg(&absent)
            .arg("--model50")
            .arg(&absent)
            .arg("--det-model")
            .arg(&detector)
            .arg("--charset")
            .arg(&charset)
            .args([
                "--use-deim-detection",
                if deim { "true" } else { "false" },
                "--enable-cascade",
                "false",
                "--structure-rules",
                "false",
                "--line-crop-padding",
                "0",
                "--output-txt",
            ])
            .arg(&body)
            .output()
            .unwrap();
        assert!(
            result.status.success(),
            "{deim}: {}",
            String::from_utf8_lossy(&result.stderr)
        );
        assert_eq!(
            std::fs::read(body).unwrap(),
            expected,
            "literal CLI body, deim={deim}"
        );
        let mut stdout = expected.to_vec();
        stdout.push(b'\n');
        assert_eq!(result.stdout, stdout, "stdout LF framing, deim={deim}");
        assert_eq!(std::fs::read(&image).unwrap(), before);
    }
}
