from pathlib import Path
import hashlib,json,re,zipfile
repo=Path.cwd();p=repo/'tmp/vertical-cli-fallback-v2';folder=repo/'docs/benchmarks/vertical-cli-fallback-v2';sha=lambda data:hashlib.sha256(data).hexdigest();before=json.loads((p/'before-NN-v1.json').read_text());assert all(sha(Path(n).read_bytes())==h for n,h in before['files_sha256'].items())
qa=json.loads((p/'onnx-nonignored-v1/command.json').read_text());assert qa['exit_code']==0 and qa['all_frozen_files_after_unchanged'];stdout=(p/'onnx-nonignored-v1/run.stdout').read_text();assert '465 passed; 0 failed; 115 ignored;' in stdout
clippy=[json.loads(line) for line in (p/'onnx-clippy-all-targets.jsonl').read_text().splitlines() if line.startswith('{')];assert any(r.get('reason')=='build-finished' and r['success'] for r in clippy)
new_warnings=[]
for event in clippy:
 if event.get('reason')=='compiler-message' and event['message']['level']=='warning':
  m=event['message']
  if any(s['file_name'] in ['src/app.rs','src/app/vertical_fallback.rs'] or 'vertical_cli_finish_known.rs' in s['file_name'] for s in m['spans']):new_warnings.append(m['message'])
assert new_warnings==[]
meta={'source_before_NN_packet_sha256':json.loads((folder/'before-nn-v1.index.json').read_text())['sha256'],'ONNX_nonignored_lib':{'passed':465,'failed':0,'ignored':115,'internal_forward_calls':None,'not_an_accuracy_matrix':True},'onnx_all_targets_Clippy_success':True,'FVC_app_and_new_finish_test_warning_messages':new_warnings,'existing_frozen_FVB_iterator_and_test_identity_warnings':'preserved in logs; equivalent cleanup already in root32ef proof, do not edit running frozen candidate','all_original_frozen_files_after_same':True,'full_scope':{'physical':1311,'scoring':1317,'unique_RGB':1310,'planned_image_results':26220,'planned_CSV_rows':79020,'new_full_NN_calls':0,'tests_passed':3,'source_before_new72_gate':'preparation only; no full dispatch'}}
(p/'QA-and-full-scope-v1.json').write_text(json.dumps(meta,indent=2)+'\n');members={};archive=folder/'QA-and-full-scope-v1.zip'
files=['QA-and-full-scope-v1.json','onnx-nonignored-v1/before.json','onnx-nonignored-v1/command.json','onnx-nonignored-v1/run.stdout','onnx-nonignored-v1/run.stderr','onnx-clippy-all-targets.jsonl','onnx-clippy-all-targets.stderr','full-scope-red.stdout','full-scope-red.stderr','full-scope-green.stdout','full-scope-green.stderr','full-scope-final-green.stdout','full-scope-final-green.stderr','pack_qa_and_scope_v1.py']
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in [('evidence/'+name,p/name) for name in files]+[(name,repo/name) for name in ['docs/vertical_cli_fallback_v2_full_gate.md','tools/vertical_cli_fallback_v2_full_scope.py','tests/test_vertical_cli_fallback_v2_full_scope.py']]:
  raw=path.read_bytes();z.writestr(name,raw);members[name]={'bytes':len(raw),'sha256':sha(raw)}
(folder/'QA-and-full-scope-v1.index.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':members,**meta},indent=2)+'\n');print({'archive_bytes':archive.stat().st_size,'members':len(members),'NN_accuracy_matrix_complete':False})
