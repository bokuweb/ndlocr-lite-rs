use super::*;
#[test]
#[ignore = "fixed918 input geometry before FVB NN; new output directory"]
fn capture_all_geometry_before_nn() {
    use std::io::Write;
    let Some(path) = std::env::var_os("NDLOCR_FVA_MANIFEST") else {
        return;
    };
    let manifest: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let inputs = manifest["inputs"].as_array().unwrap();
    assert_eq!(inputs.len(), 918);
    let out = std::path::PathBuf::from(std::env::var_os("NDLOCR_FVA_OUTPUT").unwrap());
    std::fs::create_dir(&out).unwrap();
    let mut crops = zip::ZipWriter::new(std::fs::File::create(out.join("crops.zip")).unwrap());
    let mut source_zip =
        zip::ZipWriter::new(std::fs::File::create(out.join("source-pixels.zip")).unwrap());
    let mut prepared_zip =
        zip::ZipWriter::new(std::fs::File::create(out.join("prepared.zip")).unwrap());
    let options = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);
    let mut rows = Vec::new();
    let mut cuts = Vec::new();
    let mut selected = 0;
    for input in inputs {
        let id = input["id"].as_str().unwrap();
        assert!(
            id.bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
        );
        let image =
            crate::io::load_rgb_u8(std::path::Path::new(input["image"].as_str().unwrap())).unwrap();
        let before = image.data.clone();
        let prepared = crate::pipeline::background::normalize_chromatic_panels(
            &image.data,
            image.width,
            image.height,
        )
        .unwrap();
        let changed = prepared.as_ref() != image.data;
        let prepared_member = if changed {
            let file = format!("{id}.rgb");
            prepared_zip.start_file(&file, options).unwrap();
            prepared_zip.write_all(prepared.as_ref()).unwrap();
            Some(file)
        } else {
            None
        };
        let mut source_written = false;
        for (label, rgb) in [
            ("raw", image.data.as_slice()),
            ("fallback_prepared", prepared.as_ref()),
        ] {
            let support = supported_column(rgb, image.width, image.height);
            let b = support.map(|(bounds, _)| bounds);
            let mut row = serde_json::json!({"id":id,"preparation":label,"source_width":image.width,"source_height":image.height,"selected":b,"prepared_changed":changed,"prepared_member":prepared_member,"annotation_present":input["glyph_boxes"].is_array()});
            row["anchor_count"] = serde_json::json!(support.map(|(_, anchors)| anchors));
            if let Some(b) = b {
                let source_member = format!("{id}.rgb");
                if !source_written {
                    source_zip.start_file(&source_member, options).unwrap();
                    source_zip.write_all(&image.data).unwrap();
                    source_written = true;
                }
                row["source_pixels_member"] = serde_json::json!(source_member);

                selected += 1;
                let bbox = crate::pipeline::crop::BBox::new(
                    b[0] as usize,
                    b[1] as usize,
                    b[2] as usize,
                    b[3] as usize,
                );
                let crop = crate::pipeline::crop::crop_rgb_u8(rgb, image.width, image.height, bbox)
                    .unwrap();
                let file = format!("{id}-{label}.rgb");
                crops.start_file(&file, options).unwrap();
                crops.write_all(&crop.data).unwrap();
                row["crop"] =
                    serde_json::json!({"file":file,"width":crop.width,"height":crop.height});
                let mut lost = 0;
                for y in 0..image.height {
                    for x in 0..image.width {
                        let p = (y * image.width + x) * 3;
                        if rgb[p..p + 3].iter().map(|&v| u16::from(v)).sum::<u16>() < 765
                            && !(bbox.xmin <= x && x < bbox.xmax && bbox.ymin <= y && y < bbox.ymax)
                        {
                            lost += 1;
                        }
                    }
                }
                row["prepared_nonwhite_outside"] = serde_json::json!(lost);
                assert_eq!(lost, 0, "all prepared nonwhite pixels must remain");
                if let Some(glyphs) = input["glyph_boxes"].as_array() {
                    for (index, glyph) in glyphs.iter().enumerate() {
                        let Some(a) = glyph.as_array() else {
                            continue;
                        };
                        let coords: Vec<_> = a.iter().map(|n| n.as_i64().unwrap()).collect();
                        if !(i64::from(b[0]) <= coords[0]
                            && i64::from(b[1]) <= coords[1]
                            && coords[2] <= i64::from(b[2])
                            && coords[3] <= i64::from(b[3]))
                        {
                            cuts.push(serde_json::json!({"id":id,"preparation":label,"glyph_index":index,"source_glyph_bbox":coords,"selected_bbox":b}));
                        }
                    }
                }
            }
            rows.push(row);
        }
        assert_eq!(image.data, before);
    }
    source_zip.finish().unwrap();
    crops.finish().unwrap();
    prepared_zip.finish().unwrap();
    std::fs::write(
        out.join("records.json"),
        serde_json::to_vec_pretty(&rows).unwrap(),
    )
    .unwrap();
    std::fs::write(
        out.join("glyph-violations.json"),
        serde_json::to_vec_pretty(&cuts).unwrap(),
    )
    .unwrap();
    println!(
        "{}raw/prepared geometry cases;{selected}selected;{}glyph violations;NN0",
        rows.len(),
        cuts.len()
    );
    assert_eq!(rows.len(), 1836);
    assert!(
        cuts.is_empty(),
        "hold entire proposal before NN if any annotated glyph is clipped"
    );
}
