use super::*;
#[test]
#[ignore = "explicit fixed new72 geometry only, NN0"]
fn capture_fvc_new72_geometry_before_nn() {
    use std::io::Write;
    let path = std::env::var_os("NDLOCR_FVC_MANIFEST").expect("explicit manifest required");
    let manifest: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let inputs = manifest["inputs"].as_array().unwrap();
    assert_eq!(inputs.len(), 72);
    let out = std::path::PathBuf::from(std::env::var_os("NDLOCR_FVC_GEOMETRY").unwrap());
    std::fs::create_dir(&out).unwrap();
    let mut zip = zip::ZipWriter::new(std::fs::File::create(out.join("crops.zip")).unwrap());
    let options = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);
    let mut rows = Vec::new();
    for input in inputs {
        let id = input["id"].as_str().unwrap();
        assert!(id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_'));
        let image =
            crate::io::load_rgb_u8(std::path::Path::new(input["image"].as_str().unwrap())).unwrap();
        let original = image.data.clone();
        let prepared = crate::pipeline::background::normalize_chromatic_panels(
            &image.data,
            image.width,
            image.height,
        )
        .unwrap();
        for (label, rgb) in [
            ("raw", image.data.as_slice()),
            ("prepared", prepared.as_ref()),
        ] {
            let fake = || crate::infer::parseq::RecognizeResult {
                text: "あいうえお".repeat(1000),
                mean_confidence: 0.97,
            };
            let old = try_recognize(rgb, image.width, image.height, 0.3, |_, _, _| Ok(fake()));
            for (pad_label, padding) in [("zero", 0), ("three", 3), ("maximum", usize::MAX)] {
                let mut callback = None;
                let result = try_recognize_with_padding(
                    rgb,
                    image.width,
                    image.height,
                    0.3,
                    padding,
                    |pixels, w, h| {
                        callback = Some((pixels.to_vec(), w, h));
                        Ok(fake())
                    },
                );
                assert_eq!(callback.is_some(), result.is_some());
                if padding == 0 {
                    assert_eq!(
                        old.as_ref().map(|(b, r)| (
                            *b,
                            r.text.as_str(),
                            r.mean_confidence.to_bits()
                        )),
                        result.as_ref().map(|(b, r)| (
                            *b,
                            r.text.as_str(),
                            r.mean_confidence.to_bits()
                        ))
                    );
                }
                let mut row = serde_json::json!({"id":id,"preparation":label,"padding":pad_label,"width":image.width,"height":image.height,"prepared_changed":prepared.as_ref()!=image.data,"bounds":null});
                if let Some((b, _)) = result {
                    let (pixels, w, h) = callback.unwrap();
                    assert_eq!((w, h), ((b[2] - b[0]) as usize, (b[3] - b[1]) as usize));
                    let expected: Vec<_> = (b[1] as usize..b[3] as usize)
                        .flat_map(|y| {
                            rgb[(y * image.width + b[0] as usize) * 3
                                ..(y * image.width + b[2] as usize) * 3]
                                .iter()
                                .copied()
                        })
                        .collect();
                    assert_eq!(pixels, expected);
                    for y in 0..image.height {
                        for x in 0..image.width {
                            if rgb[(y * image.width + x) * 3..(y * image.width + x + 1) * 3]
                                .iter()
                                .map(|&v| u16::from(v))
                                .sum::<u16>()
                                < 765
                            {
                                assert!(
                                    b[0] as usize <= x
                                        && x < b[2] as usize
                                        && b[1] as usize <= y
                                        && y < b[3] as usize,
                                    "nonwhite outside {id}"
                                );
                            }
                        }
                    }
                    if let Some(glyphs) = input["glyph_boxes"].as_array() {
                        for g in glyphs {
                            if g.is_null() {
                                continue;
                            }
                            assert!(
                                i64::from(b[0]) <= g[0].as_i64().unwrap()
                                    && i64::from(b[1]) <= g[1].as_i64().unwrap()
                                    && g[2].as_i64().unwrap() <= i64::from(b[2])
                                    && g[3].as_i64().unwrap() <= i64::from(b[3]),
                                "glyph outside {id}"
                            );
                        }
                    }
                    let member = format!("{id}-{label}-{pad_label}.rgb");
                    zip.start_file(&member, options).unwrap();
                    zip.write_all(&pixels).unwrap();
                    row["bounds"] = serde_json::json!(b);
                    row["crop_member"] = serde_json::json!(member);
                }
                rows.push(row);
            }
        }
        assert_eq!(original, image.data);
    }
    zip.finish().unwrap();
    assert_eq!(rows.len(), 432);
    std::fs::write(
        out.join("records.json"),
        serde_json::to_vec_pretty(&rows).unwrap(),
    )
    .unwrap();
    println!(
        "432 geometry records; {} selected; zero glyph cuts; NN0",
        rows.iter().filter(|r| !r["bounds"].is_null()).count()
    );
}
