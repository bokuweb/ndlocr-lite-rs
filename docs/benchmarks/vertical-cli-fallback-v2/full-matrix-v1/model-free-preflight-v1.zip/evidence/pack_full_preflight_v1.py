from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();p=repo/'tmp/vertical-cli-fallback-v2';folder=repo/'docs/benchmarks/vertical-cli-fallback-v2/full-matrix-v1';sha=lambda b:hashlib.sha256(b).hexdigest();files=[]
for name in ['full-bundle-red.stdout','full-bundle-red.stderr','full-bundle-green.stdout','full-bundle-green.stderr','full-harness-red.stdout','full-harness-red.stderr','full-harness-green.stdout','full-harness-green.stderr','full-bundle-validate.stdout','full-bundle-validate.stderr','original-full-contracts-green.stdout','original-full-contracts-green.stderr','pack_full_preflight_v1.py']:files.append(('evidence/'+name,p/name))
for name in ['tools/vertical_cli_fallback_v2_full_matrix.py','tools/vertical_cli_fallback_v2_full_scope.py','tools/vertical_cli_fallback_v2_option_runner.py','tools/verify_vertical_cli_fallback_v2.py','tests/test_vertical_cli_fallback_v2_full_bundle.py','.github/workflows/vertical-cli-fallback-v2-full-matrix.yml']:files.append((name,repo/name))
for name in ['bundle.json','plan.json','protocol-before-nn.md','create_full_bundle_v1.py']:files.append(('bundle/'+name,folder/name))
members={};archive=folder/'model-free-preflight-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in files:
  raw=path.read_bytes();z.writestr(name,raw);members[name]={'bytes':len(raw),'sha256':sha(raw)}
(folder/'model-free-preflight-v1.index.json').write_text(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members,'full_v2_NN_calls':0,'new72_gate_pass':True,'options_gate_pass_local':True,'option_results_path':'tmp/vertical-cli-fallback-v2/options-matrix-v2','contracts':'new bundle2Red->2Green;dependency pin1Red->3Green;scope3Green;old shared11Green'},indent=2)+'\n');print({'bytes':archive.stat().st_size,'members':len(members),'NN_calls':0})
