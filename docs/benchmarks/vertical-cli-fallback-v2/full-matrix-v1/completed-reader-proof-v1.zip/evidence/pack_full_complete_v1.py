from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
repo=Path.cwd();p=Path(__file__).resolve().parent;out=repo/'docs/benchmarks/vertical-cli-fallback-v2/full-matrix-v1';rawdir=p/'full-success-artifact-zips-v1'
sha=lambda b:hashlib.sha256(b).hexdigest();run=json.loads(subprocess.check_output(['gh','run','view','39593424953','--json','databaseId,status,conclusion,headSha,jobs']))
assert run['status']=='completed' and run['conclusion']=='success' and run['databaseId']==39593424953 and run['headSha']=='fe0e359371fb7ca7b289092103f6d7f16d41d62f'
assert len(run['jobs'])==59 and all(j['conclusion']=='success' for j in run['jobs'])
downloaded=json.loads((rawdir/'downloaded.json').read_text());assert downloaded['run']==run['databaseId'] and len(downloaded['artifacts'])==59
data={};build_artifact,=[a for a in downloaded['artifacts'] if a['name']=='fvc-v2-full-build-attempt1'];omitted={}
for artifact in downloaded['artifacts']:
 raw=(rawdir/(artifact['name']+'.zip')).read_bytes();assert len(raw)==artifact['bytes'] and sha(raw)==artifact['sha256']
 if artifact!=build_artifact:data['artifacts/'+artifact['name']+'.zip']=raw;continue
 with zipfile.ZipFile(rawdir/(artifact['name']+'.zip')) as z:
  build_raw=z.read('build.json');build=json.loads(build_raw);assert set(z.namelist())=={'build.json'}|set(build['stage_files'])
  data['stage/build.json']=build_raw
  for name,meta in build['stage_files'].items():
   blob=z.read(name);assert {'bytes':len(blob),'sha256':sha(blob)}==meta,name
   if name.startswith(('binaries/','runtime/')):omitted[name]=meta
   else:data['stage/'+name]=blob
assert len(omitted)==4
assert len([n for n in data if n.startswith('artifacts/') and '-result-' in n])==56
omission={'all_original_stage_bytes_verified':True,'original_build_artifact':build_artifact,'omitted_native_members':omitted,'native_bytes_in_public_packet':False}
for name,value in [('downloaded',downloaded),('run',run),('native-omissions',omission)]:data['evidence/'+name+'.json']=(json.dumps(value,indent=2)+'\n').encode()
archive=out/'completed-linux-v1.zip';assert not archive.exists()
partial=p/('full-public-packet-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.partial.zip')
with zipfile.ZipFile(partial,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
partial.rename(archive)
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in data.items()},'run':run['databaseId'],'head':run['headSha'],'bundle_sha256':sha((out/'bundle.json').read_bytes()),'native_members_omitted':len(omitted),'worker_artifacts':56,'new_model_calls_in_replay':0}
(out/'completed-linux-v1.index.json').write_text(json.dumps(index,indent=2)+'\n');(p/'full-complete-run-v1.json').write_text(json.dumps(run,indent=2)+'\n')
comparison,=[a for a in downloaded['artifacts'] if a['name']=='fvc-v2-full-comparison-attempt1']
with zipfile.ZipFile(rawdir/(comparison['name']+'.zip')) as z:
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist());z.extractall(p/'full-comparison-v1')
print(json.dumps({k:v for k,v in index.items() if k!='members'}),flush=True)
