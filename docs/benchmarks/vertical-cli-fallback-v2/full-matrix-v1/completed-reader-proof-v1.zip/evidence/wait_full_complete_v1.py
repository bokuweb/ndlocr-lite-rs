from pathlib import Path
import json,subprocess,sys
repo=Path.cwd();p=Path(__file__).resolve().parent;python='/Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
with (p/'full-watch-v1.stdout').open('xb') as out,(p/'full-watch-v1.stderr').open('xb') as err:subprocess.run(['gh','run','watch','39593424953','--interval','60','--exit-status'],stdout=out,stderr=err,check=True)
for script in ['download_full_v1.py','pack_full_complete_v1.py']:
 with (p/(script+'.stdout')).open('xb') as out,(p/(script+'.stderr')).open('xb') as err:subprocess.run([python,str(p/script)],cwd=repo,stdout=out,stderr=err,check=True)
with (p/'full-completed-reader-green-v1.stdout').open('xb') as out,(p/'full-completed-reader-green-v1.stderr').open('xb') as err:subprocess.run([python,'-m','unittest','discover','-s','tests','-p','test_vertical_cli_fallback_v2_full_completed.py','-v'],cwd=repo,stdout=out,stderr=err,check=True)
sys.path.insert(0,str(repo/'tools'));from verify_vertical_cli_full_completed import verify
from vertical_cli_fallback_v2_full_matrix import FullBundleV2
folder=repo/'docs/benchmarks/vertical-cli-fallback-v2/full-matrix-v1';result=verify(folder,FullBundleV2(folder));(p/'full-independent-replay-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
