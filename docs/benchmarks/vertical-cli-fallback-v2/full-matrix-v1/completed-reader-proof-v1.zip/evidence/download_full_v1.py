from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess

p=Path(__file__).resolve().parent;run=39593424953
out=p/'full-success-artifact-zips-v1';out.mkdir(exist_ok=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
api=json.loads(subprocess.check_output(['gh','api',f'repos/bokuweb/ndlocr-lite-rs/actions/runs/{run}/artifacts?per_page=100']))
assert len(api['artifacts'])==api['total_count']
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
(p/f'full-artifacts-{stamp}.json').write_text(json.dumps(api,indent=2)+'\n')
old=json.loads((p/'full-artifacts-progress-v1.json').read_text())
previous={r['id']:r for r in old['artifacts']}
def download(a):
 assert a['workflow_run']['id']==run and a['workflow_run']['head_sha']=='fe0e359371fb7ca7b289092103f6d7f16d41d62f' and not a['expired']
 dest=out/(a['name']+'.zip');cached=p/'full-progress-cli-v1'/dest.name
 if not dest.exists() and cached.exists():
  assert previous[a['id']]['name']==a['name'];shutil.copyfile(cached,dest)
 if not dest.exists():
  partial=dest.with_suffix('.partial')
  with partial.open('wb') as f:subprocess.run(['gh','api',f'repos/bokuweb/ndlocr-lite-rs/actions/artifacts/{a["id"]}/zip'],stdout=f,check=True)
  partial.rename(dest)
 assert dest.stat().st_size==a['size_in_bytes'],a['name']
 digest=sha(dest)
 if a.get('digest'):assert a['digest']=='sha256:'+digest,a['name']
 return {'id':a['id'],'name':a['name'],'bytes':dest.stat().st_size,'sha256':digest}
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(download,api['artifacts']))
receipt={'run':run,'artifacts':rows}
(out/'downloaded.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'downloaded':len(rows),'bytes':sum(r['bytes'] for r in rows),'run_still_requires_completion':True}),flush=True)
