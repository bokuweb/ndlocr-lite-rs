from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path.cwd();root=repo/'tmp/vertical-cli-fallback';out=root/'known-CLI-regression-v1';out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ci=json.loads((root/'root-FVB-CI-before-actual-cli.json').read_text());assert ci['conclusion']=='success' and ci['headSha']=='e559efb7976226da4a1a9ad9c7cefe848248ea69' and len(ci['jobs'])==5 and all(j['conclusion']=='success' for j in ci['jobs'])
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets']
for a in assets.values():assert sha(repo/'models'/a['name'])==a['sha256']
plans={}
for variant,source in [('baseline','baseline-source'),('candidate','source')]:
 frozen=json.loads((root/f'cli-regression-{variant}-frozen.json').read_text())
 for name,digest in frozen['source_files'].items():assert sha(root/source/name)==digest,(variant,name)
 for key in ['cli','test']:assert sha(Path(frozen[key]['path']))==frozen[key]['sha256']
 plans[variant]={'frozen':frozen,'source':source}
receipt={'complete':False,'driver_sha256':sha(Path(__file__)),'CI':ci,'assets':assets,'plans':plans,'runs':[],'internal_forward_calls':None,'model_session_loads':None}
def save(): (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
save()
env=os.environ.copy();env.update({'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1','DYLD_LIBRARY_PATH':str(repo/'target/debug')+os.pathsep+str(repo/'target/debug/deps'),'NDLOCR_TEST_PARSEQ_MODEL':str(repo/'models'/assets['30']['name']),'NDLOCR_TEST_DEIM_MODEL':str(repo/'models'/assets['deim']['name']),'NDLOCR_TEST_CHARSET':str(repo/'models'/assets['charset']['name'])})
try:
 for variant,plan in plans.items():
  env['NDLOCR_TEST_CLI_BINARY']=plan['frozen']['cli']['path'];argv=[plan['frozen']['test']['path'],'--include-ignored','--nocapture'];start=time.monotonic()
  with (out/(variant+'.stdout')).open('wb') as stdout,(out/(variant+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root/plan['source'],env=env,stdout=stdout,stderr=stderr)
  receipt['runs'].append({'variant':variant,'argv':argv,'cwd':str(root/plan['source']),'CLI_binary':env['NDLOCR_TEST_CLI_BINARY'],'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(out/(variant+'.stdout')),'stderr_sha256':sha(out/(variant+'.stderr'))});save()
  assert result.returncode==({'baseline':101,'candidate':0}[variant]),(variant,result.returncode)
 for variant,plan in plans.items():
  for name,digest in plan['frozen']['source_files'].items():assert sha(root/plan['source']/name)==digest
  for key in ['cli','test']:assert sha(Path(plan['frozen'][key]['path']))==plan['frozen'][key]['sha256']
 for a in assets.values():assert sha(repo/'models'/a['name'])==a['sha256']
 receipt.update(complete=True,frozen_materials_after_unchanged=True,known_case_only=True,new_control_gain_count=0)
except Exception as error:receipt['error']=repr(error);raise
finally:save()
print(json.dumps({'complete':True,'runs':receipt['runs']},ensure_ascii=False))
