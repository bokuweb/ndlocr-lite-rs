from pathlib import Path
import csv,hashlib,json,os,subprocess,sys,time
sys.path.insert(0,'tools')
import vertical_page_matrix as matrix
from verify_low_stop_evidence import metric_values
repo=Path.cwd();root=repo/'tmp/vertical-cli-fallback';out=root/'new72-matrix-v1';out.mkdir();manifest_path=root/'new-manifest.json';manifest=json.loads(manifest_path.read_text());inputs=manifest['inputs'];assert len(inputs)==72 and len({r['id'] for r in inputs})==72
sha=lambda p:matrix.sha(p.read_bytes())
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets'];models=repo/'models'
ci=json.loads((root/'root-FVB-CI-before-actual-cli.json').read_text());assert ci['conclusion']=='success' and all(j['conclusion']=='success' for j in ci['jobs'])
known=json.loads((root/'known-CLI-regression-v1/receipt.json').read_text());assert known['complete'] and [r['exit_code'] for r in known['runs']]==[101,0]
plans={v:{'frozen':json.loads((root/f'cli-regression-{v}-frozen.json').read_text()),'source':s} for v,s in [('baseline','baseline-source'),('candidate','source')]}
def check():
 assert sha(manifest_path)==manifest_sha
 for a in assets.values():assert sha(models/a['name'])==a['sha256']
 for row in inputs:
  for key in ['image','rgb','truth']:assert sha(Path(row[key]))==row[key+'_sha256'],(row['id'],key)
 for v,plan in plans.items():
  for n,h in plan['frozen']['source_files'].items():assert sha(root/plan['source']/n)==h,(v,n)
  for key in ['cli','test']:assert sha(Path(plan['frozen'][key]['path']))==plan['frozen'][key]['sha256']
 assert plans['baseline']['frozen']['cli']['sha256']!=plans['candidate']['frozen']['cli']['sha256']
manifest_sha=sha(manifest_path);check()
meta={'complete':False,'driver_sha256':sha(Path(__file__)),'manifest_sha256':manifest_sha,'plans':plans,'assets':assets,'CI':ci,'known_regression_receipt_sha256':sha(root/'known-CLI-regression-v1/receipt.json'),'commands':[],'target_image_results':576,'target_CSV_rows':1728,'internal_forward_calls':None,'model_session_loads':None}
def save():matrix.write_json(out/'job.json',meta)
save();env={'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1','DYLD_LIBRARY_PATH':str(repo/'target/debug')+os.pathsep+str(repo/'target/debug/deps')};meta['runtime_environment']=env
try:
 predictions={}
 for v,plan in plans.items():
  for mode in ['deim','bands']:
   for cascade in [True,False]:
    route=mode+'_cascade_'+str(cascade).lower();key=v+'_'+route;directory=out/'predictions'/key;directory.mkdir(parents=True);values={}
    for row in inputs:
     body=directory/(row['id']+'.txt');label=key+'_'+row['id'];argv=matrix.cli_command(plan['frozen']['cli']['path'],row['image'],models,assets,mode,body)+['--enable-cascade',str(cascade).lower()]
     matrix.run_command(argv,label,out,meta,env);values[row['id']]=matrix.read_cli_result(out/'commands'/(label+'.stdout'),body);save()
    predictions[key]=values;print(json.dumps({'completed_route':key,'image_results':len(meta['commands'])}),flush=True)
 truth=out/'metrics/truth';truth.mkdir(parents=True)
 for row in inputs:(truth/(row['id']+'.txt')).write_bytes(Path(row['truth']).read_bytes())
 verified=0;comparisons=[];new_gains=[];regressions=[]
 for normalization in ['none','width','strict']:
  table=out/'metrics'/(normalization+'.csv');argv=[sys.executable,str(repo/'tools/eval_ocr_metrics.py'),'--truth-dir',str(truth)]
  for key in predictions:argv+=['--system',key+'='+str(out/'predictions'/key)]
  argv+=['--normalize',normalization,'--require-all','--output-csv',str(table)];matrix.run_command(argv,'metrics-'+normalization,out,meta)
  rows=list(csv.DictReader(table.open()));assert len(rows)==576 and len({(r['system'],r['file']) for r in rows})==576
  for r in rows:
   expected=metric_values((truth/r['file']).read_text(),(out/'predictions'/r['system']/r['file']).read_text(),normalization);assert tuple(int(r[k]) for k in ['char_errors','char_total','word_errors','word_total'])==expected;verified+=1
  indexed={(r['system'],r['file']):r for r in rows}
  for row in inputs:
   for mode in ['deim','bands']:
    for cascade in [True,False]:
     route=mode+'_cascade_'+str(cascade).lower();before=indexed['baseline_'+route,row['id']+'.txt'];after=indexed['candidate_'+route,row['id']+'.txt'];entry={'normalization':normalization,'id':row['id'],'cohort':row['cohort'],'route':route,'before':before,'after':after,'body_unchanged':predictions['baseline_'+route][row['id']]==predictions['candidate_'+route][row['id']]};comparisons.append(entry)
     if any(int(after[k])>int(before[k]) for k in ['char_errors','word_errors']):regressions.append(entry)
     if normalization=='none' and row['cohort']=='new_fvc_vertical_text' and int(after['char_errors'])<int(before['char_errors']) and int(after['word_errors'])<=int(before['word_errors']):new_gains.append(entry)
 check();assert verified==1728
 meta.update(complete=True,frozen_materials_after_unchanged=True,verified_CSV_rows=verified,image_results=576,new_body_raw_gain_pairs=len(new_gains),regression_pairs=len(regressions),matrix_gate_pass=not regressions and bool(new_gains))
 matrix.write_json(out/'comparisons.json',comparisons);matrix.write_json(out/'new-body-gains.json',new_gains);matrix.write_json(out/'regressions.json',regressions);matrix.write_json(out/'summary.json',{k:v for k,v in meta.items() if k not in ['plans','CI','commands']});print(json.dumps({'complete':True,'verified_CSV_rows':verified,'new_body_raw_gain_pairs':len(new_gains),'regression_pairs':len(regressions),'matrix_gate_pass':meta['matrix_gate_pass']}),flush=True)
except Exception as error:meta['error']=repr(error);raise
finally:save()
