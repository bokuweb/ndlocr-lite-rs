from pathlib import Path
from PIL import Image
import json,hashlib,shutil,subprocess
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=r/'baseline-source';events=[json.loads(l) for l in (r/'default-cli-baseline-build.jsonl').read_text().splitlines() if l.startswith('{')];own=[x for x in events if x.get('reason')=='compiler-artifact' and x.get('manifest_path')==str(source/'Cargo.toml')];assert set(x['target']['name'] for x in own)=={'ndlocr_lite_rs','ndlocr-lite-rs'}
for x in own:assert not x['fresh'] and 'onnx' not in x['features']
x=next(x for x in own if x['target']['name']=='ndlocr-lite-rs');out=r/'default-cli-baseline';assert not out.exists();shutil.copy2(x['executable'],out)
(r/'default-cli-baseline-frozen.json').write_text(json.dumps({'path':str(out),'sha256':sha(out),'compiler_artifact':x,'new_NN_calls':0},indent=2)+'\n')
output=r/'feature-disabled-v1';output.mkdir();Image.new('RGB',(600,900),'white').save(output/'white.png');body=Path('tests/fixtures/vertical_fallback_page/arial121.png').resolve();missing=output/'absent-model.onnx';assert not missing.exists()
images={'body':body,'white':output/'white.png'};values={};receipts=[]
for variant in ['baseline','candidate']:
 meta=json.loads((r/f'default-cli-{variant}-frozen.json').read_text());binary=Path(meta['path']);assert sha(binary)==meta['sha256']
 for name,image in images.items():
  for deim in [False,True]:
   case=f'{variant}-{name}-{deim}';text=output/(case+'.txt')
   argv=[str(binary),'recognize-page','--image',str(image),'--model',str(missing),'--model30',str(missing),'--model50',str(missing),'--det-model',str(missing),'--charset',str(missing),'--use-deim-detection',str(deim).lower(),'--output-txt',str(text)]
   actual=subprocess.run(argv,capture_output=True);(output/(case+'.stdout')).write_bytes(actual.stdout);(output/(case+'.stderr')).write_bytes(actual.stderr)
   value=(actual.returncode,actual.stdout,actual.stderr,text.read_bytes() if text.exists() else None);values[variant,name,deim]=value
   receipts.append({'variant':variant,'case':name,'deim':deim,'argv':argv,'exit_code':actual.returncode,'stdout_sha256':hashlib.sha256(actual.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(actual.stderr).hexdigest(),'body_exists':text.exists(),'body_sha256':sha(text) if text.exists() else None,'binary_sha256':sha(binary),'image_sha256':sha(image)})
(output/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
for name in images:
 for deim in [False,True]:
  before=values['baseline',name,deim];after=values['candidate',name,deim];assert before==after,(name,deim,before,after)
  if name=='body':assert before[0]==1 and before[1]==b'' and b'onnx feature is disabled' in before[2] and before[3] is None
  else:assert before[0]==0 and before[1]==b'\n' and before[3]==b''
summary={'CLI_processes':len(receipts),'cases':4,'identical_exit_stdout_stderr_body':True,'body_cases':'feature-disabled error, output file absent','white_cases':'success, empty body, stdout single LF','new_NN_calls':0,'model_loads':0,'not_an_ONNX_accuracy_gate':True}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
