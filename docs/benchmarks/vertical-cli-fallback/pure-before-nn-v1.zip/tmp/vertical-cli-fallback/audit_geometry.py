from pathlib import Path
from PIL import Image
from collections import Counter
import hashlib,json,zipfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'new-manifest.json').read_text());inputs={r['id']:r for r in manifest['inputs']}
p=root/'geometry-new72-v1';rows=json.loads((p/'records.json').read_text());assert len(rows)==432
seen=set();checked=0;glyphs=0;cohorts=Counter()
with zipfile.ZipFile(p/'crops.zip') as z:
 for row in rows:
  item=inputs[row['id']];key=(row['id'],row['preparation'],row['padding']);assert key not in seen;seen.add(key)
  # All actual normalization outputs were unchanged, hence independent source PNG crops apply to both labels.
  assert row['prepared_changed'] is False
  if row['bounds'] is None:continue
  b=row['bounds'];source=Image.open(item['image']).convert('RGB');assert source.tobytes()==Path(item['rgb']).read_bytes()
  assert hashlib.sha256(source.tobytes()).hexdigest()==item['rgb_sha256']
  assert z.read(row['crop_member'])==source.crop(b).tobytes();checked+=1;cohorts[item['cohort']]+=1
  for g in item.get('glyph_boxes',[]):
   if g is None:continue
   assert b[0]<=g[0] and b[1]<=g[1] and g[2]<=b[2] and g[3]<=b[3];glyphs+=1
 assert len(z.namelist())==checked
assert len(seen)==72*2*3
summary={'geometry_records':len(rows),'selected_crops':checked,'Pillow_independent_RGB_crops_exact':checked,'selected_by_cohort':dict(cohorts),'annotated_glyph_bound_checks':glyphs,'glyph_cuts':0,'all_prepared_RGB_unchanged':True,'zero_padding_old_Page_helper_result_equal':True,'source_archive_sha256':hashlib.sha256((root/'pure-stage-green-source.zip').read_bytes()).hexdigest(),'NN_calls':0,'model_loads':0,'CLI_runtime_hook_connected':False,'accuracy_gate_pass':False}
(p/'independent-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
