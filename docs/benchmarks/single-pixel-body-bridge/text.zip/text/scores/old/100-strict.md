# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `2871`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2871 | 0 | 0.5161 | 0.7227 |
| baseline | 2871 | 0 | 0.5163 | 0.7248 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
