# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2871`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2871 | 0 | 0.6044 | 0.8389 |
| baseline | 2871 | 0 | 0.6047 | 0.8408 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
