# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `2871`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 2871 | 0 | 0.6151 | 0.8563 |
| baseline | 2871 | 0 | 0.6154 | 0.8580 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
