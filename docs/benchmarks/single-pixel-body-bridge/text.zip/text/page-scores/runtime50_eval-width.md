# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 287 | 0 | 0.2490 | 0.6437 |
| after | 287 | 0 | 0.2490 | 0.6437 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
