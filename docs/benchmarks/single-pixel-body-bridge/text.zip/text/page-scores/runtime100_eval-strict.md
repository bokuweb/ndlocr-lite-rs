# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 287 | 0 | 0.2222 | 0.5622 |
| after | 287 | 0 | 0.2222 | 0.5622 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
