# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `3648`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3648 | 0 | 0.3624 | 0.7337 |
| baseline | 3648 | 0 | 0.3627 | 0.7344 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
