# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `3648`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 3648 | 0 | 0.1879 | 0.4221 |
| baseline | 3648 | 0 | 0.1881 | 0.4227 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
