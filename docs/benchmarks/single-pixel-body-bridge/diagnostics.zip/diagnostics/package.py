from pathlib import Path
import json,hashlib,zipfile,sys
r=Path('tmp/closer-bridge');out=Path(sys.argv[1]if len(sys.argv)>1 else'docs/benchmarks/single-pixel-body-bridge');out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();data={};diag={};texts={};cases=json.loads((r/'product-manifest.json').read_text())['cases'];refs={}
for p in [r/'existing-replay/records.json',r/'fresh-policy/existing-replay/records.json',r/'horizontal-policy/existing-replay/records.json']:
 for x in json.loads(p.read_text()):refs[x['corpus'],x['model'],x['id']]=x
portable=[]
for x in cases:
 key=x['corpus'],x['model'],x['id'];rec=refs[key];stem=x['corpus']+'/'+x['id'];rgb=Path(x['rgb']).read_bytes();path='data/rgb/'+stem+'.rgb';data[path]=rgb;data['data/truth/'+stem+'.txt']=x['truth'].encode();assert rec['candidate']==x['expected'];portable.append(x|{'rgb':path,'rgb_sha256':sha(rgb),'baseline':rec['baseline'],'candidate':rec['candidate']})
diag['diagnostics/portable-cases.json']=(json.dumps({'cases':portable},ensure_ascii=False,indent=2)+'\n').encode()
for folder in ['fresh','horizontal']:
 for p in(r/folder).rglob('*'):
  if not p.is_file()or 'export-source'in p.parts or p.name=='export-binary':continue
  key='data/'+str(p.relative_to(r)) if any(k in p.parts for k in ['original','png','rgb','effective','native','truth','whole-rgb-capture'])or p.name in['atlas.png','lines.json','evaluation-manifest.json','contact.png']else'diagnostics/'+str(p.relative_to(r));(data if key.startswith('data/')else diag)[key]=p.read_bytes()
for p in r.iterdir():
 if p.is_file()and p.suffix in['.json','.jsonl','.py','.swift','.md','.log','.stdout','.stderr']:diag['diagnostics/'+p.name]=p.read_bytes()
for folder in ['probe-source','fresh-probe-source','horizontal-probe-source','integration-red-source','integration-green-source','verification-source','fresh/export-source','horizontal/export-source']:
 for p in(r/folder).rglob('*'):
  if p.is_file():diag['diagnostics/'+str(p.relative_to(r))]=p.read_bytes()
for folder in ['fresh-policy','horizontal-policy']:
 for p in(r/folder).iterdir():
  if p.is_file()and p.suffix=='.json':diag['diagnostics/'+str(p.relative_to(r))]=p.read_bytes()
for folder in ['scores','fresh-policy/scores','horizontal-policy/scores','page-scores','page-before','page-after','cli-after','line-cli']:
 for p in(r/folder).rglob('*'):
  if not p.is_file()or p.name=='evaluation-manifest.json'or p.parent.name=='images':continue
  if folder in['cli-after','line-cli']and p.suffix not in['.json','.txt','.stdout','.stderr']:continue
  texts['text/'+str(p.relative_to(r))]=p.read_bytes()
pages=json.loads((r/'page-after/evaluation-manifest.json').read_text());data['data/page/evaluation-manifest.json']=(r/'page-after/evaluation-manifest.json').read_bytes()
for x in pages['inputs']:
 for kind in ['image','truth']:
  p=Path(x[kind]);b=p.read_bytes();assert sha(b)==x[kind+'_sha256'];data['data/page/'+kind+'/'+x['id']+('.txt'if kind=='truth'else p.suffix)]=b
for folder in ['page-prepare-initial']:
 for p in(r/folder).glob('*'):
  if p.is_file():diag['diagnostics/'+str(p.relative_to(r))]=p.read_bytes()
old_index=json.loads(Path('docs/benchmarks/contained-closer-components/diagnostics.json').read_text())
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:
 for name in ['probe.json','after-api.json']:
  b=z.read(name);assert sha(b)==old_index['members'][name];diag['diagnostics/parents/old-'+name]=b
matched_index=json.loads(Path('docs/benchmarks/punctuation-space-context/matched.json').read_text());p=Path('tmp/punct-retirement-final-replayed/matched/native-rows.json');b=p.read_bytes();assert sha(b)==matched_index['members']['native-rows.json'];diag['diagnostics/parents/space-native-rows.json']=b
diag['diagnostics/dependencies/means.py']=Path('tmp/punct-matched/means.py').read_bytes()
diag['diagnostics/source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py').read_bytes();diag['diagnostics/spec-results.md']=Path('docs/single_pixel_body_bridge.md').read_bytes()
for name,files in [('data',data),('diagnostics',diag),('text',texts)]:
 seen={};unique={};aliases={}
 for key,b in sorted(files.items()):
  h=sha(b)
  if h in seen:aliases[key]={'source':seen[h],'sha256':h}
  else:unique[key]=b;seen[h]=key
 unique[name+'-aliases.json']=(json.dumps(aliases,indent=2)+'\n').encode();path=out/(name+'.zip')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for key,b in sorted(unique.items()):
   info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 (out/(name+'.json')).write_text(json.dumps({'sha256':sha(path.read_bytes()),'member_count':len(unique),'logical_member_count':len(files),'members':{k:sha(b)for k,b in sorted(unique.items())}},indent=2)+'\n');print(name,len(unique),len(files),path.stat().st_size,flush=True)
