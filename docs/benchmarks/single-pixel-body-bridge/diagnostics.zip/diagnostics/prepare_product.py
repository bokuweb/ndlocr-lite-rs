from pathlib import Path
import json,zipfile,struct,sys,hashlib
sys.path.insert(0,'tmp/punct-matched');from means import emitted_means
r=Path('tmp/closer-bridge');cases=[];batches=[(r/'existing-manifest.json',r/'existing-replay/records.json'),(r/'fresh-policy/existing-manifest.json',r/'fresh-policy/existing-replay/records.json'),(r/'horizontal-policy/existing-manifest.json',r/'horizontal-policy/existing-replay/records.json')]
for manifest,records in batches:
 m=json.loads(manifest.read_text());rs={(x['corpus'],x['model'],x['id']):x for x in json.loads(records.read_text())}
 for x in m['cases']:
  y=rs[x['corpus'],x['model'],x['id']];assert x['raw']==y['raw'];cases.append(x|{'expected':y['candidate'],'selected':y['selected']})
assert len(cases)==33735;(r/'product-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');means={}
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:
 p=json.loads(z.read('probe.json'))
for m in p['models']:
 for x in m['rows']:means['old',m['label'].removeprefix('single'),x['id']]=x['mean_confidence']
for corpus,folder in [('fresh','fresh'),('horizontal','horizontal')]:
 for model in ['30','50','100']:
  for x in json.loads((r/folder/(model+'-export.json')).read_text()):means[corpus,model,x['id']]=emitted_means(x)[0]
selected={corpus:{x['id']for x in cases if x['corpus']==corpus and x['selected']}for corpus in ['old','fresh']};fresh=json.loads((r/'fresh/evaluation-manifest.json').read_text());noise={x['id']for x in fresh['inputs']if x['kind']=='noise'};native=[]
for x in cases:
 if x['corpus']=='horizontal' or x['corpus']in selected and (x['id']in selected[x['corpus']] or x['corpus']=='fresh'and x['id']in noise):
  key=x['corpus'],x['model'],x['id'];native.append(x|{'mean_bits':struct.unpack('<I',struct.pack('<f',means[key]))[0]})
assert len(native)==2745
(r/'native-manifest.json').write_text(json.dumps({'cases':native},ensure_ascii=False,indent=2)+'\n');print('33735 product replay cases;915 native cases per model;selected old11/fresh8,noise768,horizontal128',flush=True)
