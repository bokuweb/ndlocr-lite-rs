from pathlib import Path
from PIL import Image
import json,hashlib,shutil
r=Path('tmp/closer-bridge');f=r/'fresh';out=r/'fresh-policy';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((f/'evaluation-manifest.json').read_text());xs={x['id']:x for x in m['inputs']};cap=json.loads((f/'whole-rgb-capture/inputs.json').read_text());assert len(cap['chunks'])==3648;assert cap['model_input_dimensions']==[256,24];assert {c['line_id']for c in cap['chunks']}==set(xs)
for c in cap['chunks']:
 x=xs[c['line_id']];im=Image.open(f/'whole-rgb-capture'/c['image']).convert('RGB');assert list(im.size)==c['dimensions']==[x['forward_width'],x['forward_height']];assert c['chunk_index']==0 and c['x_range']==[0,x['forward_width']];assert hashlib.sha256(im.tobytes()).hexdigest()==x['effective_rgb_sha256']
cases=[]
for model in ['30','50','100']:
 rows=json.loads((f/(model+'-export.json')).read_text());assert len(rows)==3648 and {x['id']for x in rows}==set(xs)
 for row in rows:
  x=xs[row['id']];assert row['bounds']==x['bounds'] and len(row['chunks'])==1;c=row['chunks'][0];assert c['x_range']==[0,x['forward_width']] and c['text']==row['text'] and not c['inserted_space_before'];assert sha(x['rgb'])==x['rgb_sha256'] and sha(x['truth'])==x['truth_sha256'];cases.append({'corpus':'fresh','model':model,'id':x['id'],'rgb':x['rgb'],'width':x['width'],'height':x['height'],'raw':row['text'],'expected_baseline':None,'truth':Path(x['truth']).read_text()})
(out/'existing-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');binary=r/'fresh-probe-binary';shutil.copy2(binary,out/'probe-binary');meta={'binary_sha256':sha(binary),'source_command_sha256':sha(r/'fresh-tensor-command.json'),'manifest_sha256':sha(out/'existing-manifest.json'),'assembly_driver_sha256':sha(__file__),'actual_rgb_captures_verified':3648,'original_auto_tensor_checks':10944,'argv':[str((out/'probe-binary').resolve()),'infer::visible_repetitions::single_pixel_bridge::tests::record_existing_bridge_policy','--exact','--ignored','--nocapture'],'env':{'NDLOCR_BRIDGE_ROOT':str(out)}};(out/'replay-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('10944 raw pairs and3648 actual RGB inputs verified',flush=True)
