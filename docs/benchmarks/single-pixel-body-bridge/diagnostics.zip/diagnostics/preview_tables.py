from pathlib import Path
import json,importlib.util,sys
sys.dont_write_bytecode=True;p=Path('docs/benchmarks/single-pixel-body-bridge/reproduce.py');spec=importlib.util.spec_from_file_location('bridge_repro',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);root=Path('tmp/closer-bridge/preview-fixed-restored');cases=json.loads((root/'diagnostics/portable-cases.json').read_text())['cases']
for x in cases:
 for phase in ['baseline','candidate']:
  p=root/'replayed'/x['corpus']/x['model']/phase/(x['id']+'.txt');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x[phase])
count=0
for corpus,folder in [('old','scores'),('spaces','scores'),('fresh','fresh-policy/scores'),('horizontal','horizontal-policy/scores')]:
 for model in ['30','50','100']:
  for norm in ['none','width','strict']:
   base=root/'replayed'/corpus/model;expected=root/'text'/folder/corpus/(model+'-'+norm+'.csv');mod.score(root/'diagnostics/source/eval_ocr_metrics.py',root/'data/truth'/corpus,base/'baseline',base/'candidate',norm,root/'reproduced'/folder/corpus/expected.name,expected,['baseline','candidate']);count+=2
print(count,'preliminary non-page tables byte reproduced',flush=True)
