from pathlib import Path
from PIL import Image
import itertools,json,hashlib,unittest
class FreshControls(unittest.TestCase):
 def test_pre_registered_cases_and_effective_auto_pixels(self):
  r=Path('tmp/closer-bridge/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());rows=m['inputs'];self.assertEqual(len(rows),3648)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[18,30],[0,1],[')','）','」','』','】'],[False,True],[0,1,2],[0,8],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['palt'],x['closer'],x['leading'],x['spaces'],x['paper'],x['format'])for x in rows if x['kind']=='text'};self.assertEqual(actual,expected)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[18,30],[0,1],['none','thin','thick','dot'],[False,True],[0,1],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['palt'],x['shape'],x['leading'],x['gap'],x['format'])for x in rows if x['kind']=='noise'};self.assertEqual(actual,expected)
  atlas=Image.open(r/'atlas.png').convert('RGB')
  for x in rows:
   for key in ['rgb','effective_rgb','truth','image']:self.assertEqual(hashlib.sha256(Path(x[key]).read_bytes()).hexdigest(),x[key+'_sha256'])
   im=Image.open(x['image']).convert('RGB');self.assertEqual(im.tobytes(),Path(x['rgb']).read_bytes());rotated=5*im.height>4*im.width;self.assertEqual(x['rotated_for_auto'],rotated);effective=im.transpose(Image.Transpose.ROTATE_90)if rotated else im
   self.assertEqual(effective.tobytes(),Path(x['effective_rgb']).read_bytes());self.assertEqual(atlas.crop(x['bounds']).tobytes(),effective.tobytes());self.assertEqual(effective.size,(x['forward_width'],x['forward_height']))
if __name__=='__main__':unittest.main()
