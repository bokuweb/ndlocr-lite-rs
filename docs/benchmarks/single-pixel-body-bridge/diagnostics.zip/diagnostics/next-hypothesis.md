# 次の仮説のメモ（未実装・未固定）

現在の単一ピクセル案の製品/CLI/ページ証拠を先に完了する。次は現raw正読損失546組を扱う。
`geometry_round_japanese_suffix_maru40_png` は3モデルともraw 情報) が正読だが 情報 になる。
filtered8CCの旧bbox順(x0,x1,y0,y1,area):
[[9,13,17,29,37],[14,47,9,47,408],[23,44,27,47,281],[49,87,9,47,748],[90,100,12,50,173]]。
「情」の大きな部品のbbox内に別部品があり、bottomだけ一致するため従来の4辺厳密包含で分離できない。
「忄」の独立した画線もあるので、包含を1個除くだけでは本文を3成分と数えてしまう。
`next-losses-contact.png` と `next-losses.json` は残差の目視/分類用。変更条件の探索には使っていない。

検討候補: 空白なし3scalar、端closer1+表示幅2本文2限定。既存fallback成功時は保持。
3辺strict+残る1辺一致の大きな本文部品(H/2以上の幅/高さ)が存在する場合だけ、
白列で分かれた左右各1字のbbox/area viewを作る。body成分数3..6、全成分の所有画素一致、
主部品とsidecarのy/小gap、各字形高さ>=3H/4・幅[3H/4,3H/2]等を候補にする。
mark幅>=ceilH/4、gap<=max(1,H/12)、非filled、既存supports_collectedも確認する。
元RGB・collector・NN・textを変更しない。これは未固定の草案なので、実装前にdocsへ正式条件を固定し直す。

旧maru40のbodyH38、markgap3、W10/H38。本文白列x47/48は2glyphの境界を明確に分ける。
新規未知本文候補は 稲穂 / 樹枝、3font・22/38px・palt0/1、5closer/prefixsuffix/ASCIIspace0..2/
PNGJPEG75/上下paper0/8=2880、既存形式のnoise768。変更案を読む前に固定し、結果後に閾値を調整しない。
旧closer2871、space4598、今回fresh3648+Horizontal128の全固定rawとも非悪化を要求。
3辺/同bbox/2辺一致/内部細dot/sidecargap/各body幅高、支持pixel不変・紙/平行移動/gray/整数block拡大をTDD/PBTで検査する。
1ピクセル案と同様にtest-onlyから始め、1退行でも棄却し、その場合は新しい独立対照がある別仮説へ進む。
