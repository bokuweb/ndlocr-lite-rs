from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,os
r=Path('tmp/closer-bridge');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'verification-command.json').read_text());b=r/'verification-binary';assert sha(b)==meta['binary_sha256']
for p,h in meta['models'].items():assert sha(p)==h
meta.update({'driver_sha256':sha(__file__),'product_manifest_sha256':sha(r/'product-manifest.json'),'native_manifest_sha256':sha(r/'native-manifest.json')});(r/'verification-command.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,test,extra):
 argv=[str(b.resolve()),test,'--exact','--ignored','--nocapture'];env={'NDLOCR_INTRA_THREADS':'1'}|extra;cmd={'argv':argv,'env':env};p=r/(name+'-command.json');p.write_text(json.dumps(cmd,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as stdout,(r/(name+'.stderr')).open('wb')as stderr:done=subprocess.run(argv,env=os.environ|env,stdout=stdout,stderr=stderr)
 cmd['exit_code']=done.returncode;p.write_text(json.dumps(cmd,indent=2)+'\n');assert done.returncode==0,name;print(name,'terminal success',flush=True)
run('product-replay','infer::visible_repetitions::single_pixel_bridge::tests::verify_product_matches_frozen_bridge_policy',{'NDLOCR_BRIDGE_PRODUCT_MANIFEST':str(r/'product-manifest.json')})
def native(model):return run('native'+model,'infer::cached::single_pixel_bridge_model_tests::verify_selected_and_noise_cases_through_public_session',{'NDLOCR_BRIDGE_NATIVE_MANIFEST':str(r/'native-manifest.json'),'NDLOCR_BRIDGE_MODEL':model,'NDLOCR_BRIDGE_NATIVE_OUTPUT':str(r/('native'+model+'-results.json'))})
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(native,['30','50','100']))
