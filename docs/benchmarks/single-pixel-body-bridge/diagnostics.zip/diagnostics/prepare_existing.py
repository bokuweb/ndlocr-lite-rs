from pathlib import Path
from PIL import Image
import json,hashlib,zipfile,io
r=Path('tmp/closer-bridge');data=r/'data';data.mkdir();(data/'old-rgb').mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();cases=[];proof={}
old=Path('docs/benchmarks/contained-closer-components')
indices={name:json.loads((old/(name+'.json')).read_text())for name in ['diagnostics','images','text']}
for name,index in indices.items():assert sha((old/(name+'.zip')).read_bytes())==index['sha256']
def read_member(z,index,name):
 b=z.read(name);assert sha(b)==index['members'][name];return b
with zipfile.ZipFile(old/'diagnostics.zip')as z:
 probe=json.loads(read_member(z,indices['diagnostics'],'probe.json'));api=json.loads(read_member(z,indices['diagnostics'],'after-api.json'));manifest=json.loads(read_member(z,indices['diagnostics'],'evaluation-manifest.json'))
actual={m['label']:{x['id']:x for x in m['actual']}for m in api['models']};images={}
with zipfile.ZipFile(old/'images.zip')as z,zipfile.ZipFile(old/'text.zip')as truthzip:
 for x in manifest['inputs']:
  id=x['id'];body=read_member(z,indices['images'],'decoded/'+id+'.png');im=Image.open(io.BytesIO(body)).convert('RGB');p=data/'old-rgb'/(id+'.rgb');p.write_bytes(im.tobytes());truth=read_member(truthzip,indices['text'],'truth/'+id+'.txt').decode();images[id]=(p,im.size,sha(im.tobytes()),truth)
for model in probe['models']:
 for row in model['rows']:
  p,(w,h),rgbsha,truth=images[row['id']];assert truth==row['truth']and(w,h)==(row['width'],row['height']);expected=actual[model['label']][row['id']]['text'];assert expected==row['prototype']
  cases.append({'corpus':'old','model':model['label'].removeprefix('single'),'id':row['id'],'raw':row['raw'],'truth':truth,'rgb':str(p),'rgb_sha256':rgbsha,'width':w,'height':h,'expected_baseline':expected})
assert len(cases)==8613
parent=Path('tmp/punct-retirement-final-replayed/matched');verify=json.loads(Path('docs/benchmarks/punctuation-space-context/verification.json').read_text());idx=json.loads(Path('docs/benchmarks/punctuation-space-context/matched.json').read_text());assert verify['archive_sha256']['matched']==idx['sha256']
m=json.loads((parent/'evaluation-manifest.json').read_text());images={x['id']:x for x in m['inputs']};native=json.loads((parent/'native-rows.json').read_text());frozen={(x['id'],x['model']):x for x in json.loads((parent/'frozen-f-selection.json').read_text())}
for row in native:
 x=images[row['id']];p=parent/'corpus/rgb'/(x['id']+'.rgb');rgb=p.read_bytes();assert sha(rgb)==x['rgb_sha256'];gt=(parent/'corpus/truth'/(x['id']+'.txt')).read_bytes();assert sha(gt)==x['truth_sha256'];before=frozen.get((row['id'],row['model']))
 cases.append({'corpus':'spaces','model':row['model'],'id':row['id'],'raw':row['base']['text'],'truth':gt.decode(),'rgb':str(p),'rgb_sha256':x['rgb_sha256'],'width':x['width'],'height':x['height'],'expected_baseline':before['policies']['single']['before']if before else None})
assert len(cases)==22407
meta={'cases':cases,'sources':{name:index['sha256']for name,index in indices.items()},'matched_sha256':idx['sha256'],'generator_sha256':sha(Path(__file__).read_bytes()),'spec_sha256':sha(Path('docs/single_pixel_body_bridge.md').read_bytes())};(r/'existing-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print('22407 fixed native pairs from2871/4598 images;all hashes checked',flush=True)
