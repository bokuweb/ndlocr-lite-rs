//! Experimental dotted Latin geometry; no product caller.

use super::Component;

fn marker_supported(
    _mark: &Component,
    _rgb: &[u8],
    _width: usize,
    _height: usize,
    _body_height: usize,
    _core_top: usize,
    _core_bottom: usize,
) -> bool {
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    fn curve(mw: usize, mh: usize) -> (Vec<u8>, Component, usize, usize) {
        let (w, h) = (mw + 6, mh + 6);
        let mut rgb = vec![255; w * h * 3];
        let flank = mh / 3;
        for y in 0..mh {
            let x = ((y.min(mh - y - 1) * (mw - 1)) / flank).min(mw - 1);
            rgb[((y + 3) * w + x + 3) * 3..((y + 3) * w + x + 4) * 3].fill(0);
        }
        (
            rgb,
            Component {
                x0: 3,
                y0: 3,
                x1: 3 + mw,
                y1: 3 + mh,
                area: mh,
            },
            w,
            h,
        )
    }

    #[test]
    fn round_outline_keeps_its_own_width_and_body_height_bounds() {
        for (mw, expected) in [(3, false), (4, true), (8, true), (9, false)] {
            let (rgb, mark, w, h) = curve(mw, 24);
            assert_eq!(
                marker_supported(&mark, &rgb, w, h, 24, 9, 21),
                expected,
                "width {mw}"
            );
        }
        for (mh, expected) in [(17, false), (18, true), (36, true), (37, false)] {
            let (rgb, mark, w, h) = curve(6, mh);
            assert_eq!(
                marker_supported(&mark, &rgb, w, h, 24, 8, 18),
                expected,
                "height {mh}"
            );
        }
    }

    #[test]
    fn marker_must_cover_the_whole_common_body_interval() {
        let (rgb, mark, w, h) = curve(6, 24);
        assert!(marker_supported(&mark, &rgb, w, h, 24, 3, 27));
        assert!(!marker_supported(&mark, &rgb, w, h, 24, 2, 27));
        assert!(!marker_supported(&mark, &rgb, w, h, 24, 3, 28));
        assert!(!marker_supported(&mark, &rgb, w, h, 24, 8, 8));
    }

    #[test]
    fn rectangles_branches_empty_rows_and_a_mirrored_curve_are_rejected() {
        let (rgb, mark, w, h) = curve(6, 24);
        for kind in 0..4 {
            let mut changed = rgb.clone();
            if kind == 0 {
                for y in mark.y0..mark.y1 {
                    for x in mark.x0..mark.x1 {
                        changed[(y * w + x) * 3..(y * w + x + 1) * 3].fill(0);
                    }
                }
            } else if kind == 1 {
                let y = mark.y0 + 12;
                changed[(y * w + mark.x0) * 3..(y * w + mark.x0 + 1) * 3].fill(0);
            } else if kind == 2 {
                let y = mark.y0 + 12;
                changed[(y * w + mark.x0) * 3..(y * w + mark.x1) * 3].fill(255);
            } else {
                for y in mark.y0..mark.y1 {
                    for x in mark.x0..mark.x1 {
                        let target = (y * w + x) * 3;
                        let source = (y * w + mark.x0 + mark.x1 - x - 1) * 3;
                        changed[target..target + 3].copy_from_slice(&rgb[source..source + 3]);
                    }
                }
            }
            let mut parts = super::super::collect_all(&changed, w, h).unwrap();
            if parts.len() == 1 {
                let actual = parts.remove(0);
                assert!(
                    !marker_supported(&actual, &changed, w, h, 24, 9, 21),
                    "outline {kind}"
                );
            } else {
                assert!(
                    !marker_supported(&mark, &changed, w, h, 24, 9, 21),
                    "outline {kind}"
                );
            }
        }
    }

    #[test]
    fn invalid_shapes_and_foreign_foreground_are_rejected() {
        let (rgb, mut mark, w, h) = curve(6, 24);
        mark.area += 1;
        assert!(!marker_supported(&mark, &rgb, w, h, 24, 9, 21));
        mark.area -= 1;
        assert!(!marker_supported(
            &mark,
            &rgb[..rgb.len() - 1],
            w,
            h,
            24,
            9,
            21
        ));
        assert!(!marker_supported(&mark, &rgb, 0, h, 24, 9, 21));
        assert!(!marker_supported(&mark, &rgb, w, 0, 24, 9, 21));
        assert!(!marker_supported(
            &mark,
            &rgb,
            usize::MAX,
            usize::MAX,
            24,
            9,
            21
        ));
        mark.x1 = w + 1;
        assert!(!marker_supported(&mark, &rgb, w, h, 24, 9, 21));
    }
}
