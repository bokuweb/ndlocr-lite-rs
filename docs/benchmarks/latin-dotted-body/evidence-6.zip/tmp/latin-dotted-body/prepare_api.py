from pathlib import Path
import json,hashlib,zipfile,struct,collections
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();cases=json.loads((r/'product-manifest.json').read_text())['cases'];key=lambda x:(x['corpus'],x['model'],x['id']);bykey={key(x):x for x in cases};assert len(bykey)==282465
updates={('old',x['model'],x['id'])for x in json.loads((r/'policy-results.json').read_text())['changes']}
selected=[x for x in cases if key(x)in updates or x.get('selected')and x['corpus'].startswith('dotted-')];assert len(selected)==102
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:old=json.loads(z.read('probe.json'))
means={(m['label'].removeprefix('single'),x['id']):struct.unpack('<I',struct.pack('<f',x['mean_confidence']))[0]for m in old['models']for x in m['rows']}
api={}
for x in selected:
 y=x|{'selected':True,'mean_bits':x['raw_mean_bits']if'raw_mean_bits'in x else means[x['model'],x['id']]};api[key(x)]=y
fixed=json.loads((r/'fixed-api-noise-selection.json').read_text())['inputs'];assert len(fixed)==324
for x in fixed:
 y=bykey['dotted-fresh',x['model'],x['id']];assert y['rgb_sha256']==x['rgb_sha256'] and not y['selected'];assert key(y)not in api;api[key(y)]=y|{'mean_bits':y['raw_mean_bits'],'selected':False}
assert len(api)==426
cli={}
for x in api.values():
 if x['orientation']=='horizontal':
  y=bykey['dotted-fresh',x['model'],x['id']];assert y['orientation']=='auto';y=y|{'selected':False,'horizontal_counterpart':True}
 else:y=x
 cli[key(y)]=y
assert len(cli)==426 and all(x['orientation']=='auto'for x in cli.values())
for name,rows in [('api',list(api.values())),('cli',list(cli.values()))]:
 for x in rows:assert sha(x['rgb'])==x['rgb_sha256']
 counts=dict(collections.Counter(x['model']for x in rows));assert counts=={'30':142,'50':165,'100':119},counts
 (r/(name+'-manifest.json')).write_text(json.dumps({'cases':rows,'counts':counts},ensure_ascii=False,indent=2)+'\n')
record={'api_cases':426,'cli_cases':426,'changed_api':102,'fixed_noise_auto':324,'horizontal_api':26,'cli_horizontal_counterparts_auto':26,'actual_cli_has_no_horizontal_option':True,'driver_sha256':sha(__file__),'product_manifest_sha256':sha(r/'product-manifest.json'),'fixed_noise_sha256':sha(r/'fixed-api-noise-selection.json'),'api_manifest_sha256':sha(r/'api-manifest.json'),'cli_manifest_sha256':sha(r/'cli-manifest.json')};(r/'api-prepare.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
