from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib
r=Path('tmp/latin-dotted-body');m=json.loads((r/'fresh/evaluation-manifest.json').read_text());rows=m['inputs'];chosen=[];contact=[];font=ImageFont.load_default(size=13)
for engine,palt in [('freetype',None),('coretext',0),('coretext',1)]:
 image=Image.new('RGB',(1920,1020),'white');draw=ImageDraw.Draw(image);block=0
 for family in ['maru','gothic','mincho']:
  for size in [20,32]:
   base={'engine':engine,'palt':palt,'font':family,'size':size}
   filters=[{'body':'Abjp','body_spaces':0,'kind':'text','closer':')','leading':False,'spaces':0,'paper':0,'format':'png'},
            {'body':'Adip','body_spaces':0,'kind':'text','closer':'）','leading':True,'spaces':0,'paper':10,'format':'jpeg75'},
            {'body':'Apji','body_spaces':1,'kind':'text','closer':')','leading':False,'spaces':1,'paper':2,'format':'png'},
            {'body':'Bpjg','body_spaces':0,'kind':'noise','shape':'chevron','leading':False,'gap':0,'format':'jpeg75'},
            {'body':'Aimq','body_spaces':0,'kind':'noise','shape':'fork_inner','leading':True,'gap':1,'format':'png'},
            {'body':'Apji','body_spaces':1,'kind':'noise','shape':'left_curve','leading':False,'gap':1,'format':'png'}]
   for slot,query in enumerate(filters):
    spec=base|query;matches=[x for x in rows if all(x.get(k)==v for k,v in spec.items())];assert len(matches)==1;row=matches[0];chosen.append(row['id']);tile=Image.open(row['image']).convert('RGB');assert tile.tobytes()==Path(row['rgb']).read_bytes();scaled=tile.resize((tile.width*2,tile.height*2),Image.Resampling.NEAREST);assert scaled.width<=316 and scaled.height<=140
    x,y=slot*320,block*170;draw.text((x+2,y+2),f'{family}{size} #{slot+1} '+row['body']+' '+row['kind'],fill='black',font=font);image.paste(scaled,(x+2,y+25));draw.rectangle((x,y,x+319,y+169),outline=(180,180,180))
   block+=1
 out=r/f'visual-{engine}-p{palt}.png';image.save(out);contact.append({'file':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
assert len(chosen)==108 and len(set(chosen))==108;(r/'visual-selection.json').write_text(json.dumps({'ids':chosen,'count':108,'contacts':contact,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_manifest_sha256':hashlib.sha256((r/'fresh/evaluation-manifest.json').read_bytes()).hexdigest(),'new_nn_before_visual':0},indent=2)+'\n');print('108 preregistered QA IDs with lossless x2 nearest-neighbor contacts')
