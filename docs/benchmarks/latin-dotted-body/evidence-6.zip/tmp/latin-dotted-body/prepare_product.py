from pathlib import Path
import json,hashlib,collections
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=json.loads(Path('tmp/latin-pair-policy/product-manifest.json').read_text())['cases'];updates=json.loads((r/'policy-results.json').read_text())['changes'];changes=[]
for c in updates:
 x=cases[c['index']];assert all(x[k]==c[k]for k in ['corpus','model','id','raw','truth','rgb_sha256']);assert x['expected_after']==c['before'];x['before']=c['before'];x['expected_after']=c['after'];changes.append(x)
for phase in ['fresh','horizontal']:
 for model in ['30','50','100']:
  p=r/'comparison'/(phase+'-'+model);audit=json.loads((p/'score-audit.json').read_text());assert audit['accepted_on_this_job']and not audit['regressions']
  for x in json.loads((p/'outputs.json').read_text())['cases']:
   x['expected_after']=x['after'];cases.append(x)
   if x['selected']:changes.append(x)
assert len(cases)==282465 and len(changes)==102
(r/'product-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n')
inputs={}
for x in cases:
 d={k:x[k]for k in ['rgb_sha256','width','height']}
 if x['rgb']in inputs:assert inputs[x['rgb']]==d
 inputs[x['rgb']]=d
for p,d in inputs.items():assert sha(p)==d['rgb_sha256'] and Path(p).stat().st_size==d['width']*d['height']*3
(r/'product-rgb-inventory.json').write_text(json.dumps(inputs,indent=2)+'\n')
record={'cases':len(cases),'changed':len(changes),'rgb_paths':len(inputs),'manifest_sha256':sha(r/'product-manifest.json'),'rgb_inventory_sha256':sha(r/'product-rgb-inventory.json'),'driver_sha256':sha(__file__),'new_nn_forwards':0,'old_changes':12,'new_changes':90}
(r/'product-prepare.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
