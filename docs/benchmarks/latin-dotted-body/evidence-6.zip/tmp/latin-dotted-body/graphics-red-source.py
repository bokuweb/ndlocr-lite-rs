from PIL import Image, ImageChops


def crop_white(image):
    original = image.convert('RGB')
    box = ImageChops.difference(original, Image.new('RGB', original.size, 'white')).getbbox()
    if box is None:
        raise ValueError('native text has no nonwhite pixels')
    ink = original.crop(box)
    output = Image.new('RGB', (ink.width + 4, ink.height + 4), 'white')
    output.paste(ink, (2, 2))
    return output



def foreground_bbox(image):
    rgb = image.convert('RGB')
    data = rgb.tobytes()
    points = [(i % rgb.width, i // rgb.width) for i in range(rgb.width * rgb.height)
              if sum(data[i * 3:i * 3 + 3]) < 660]
    if not points:
        raise ValueError('body has no foreground pixels')
    return (min(x for x, y in points), min(y for x, y in points),
            max(x for x, y in points) + 1, max(y for x, y in points) + 1)


def shape_pixels(shape, height):
    if height < 6:
        raise ValueError('foreground height must be at least six pixels')
    if shape == 'none':
        return 0, 0, set()
    if shape == 'dot':
        return 4, 4, {(x, y) for y in range(4) for x in range(4)}
    mh = (4 * height + 2) // 3
    width = 1 if shape == 'thin' else max(3, (height + 3) // 4)
    if shape in ['thin', 'bar']:
        return width, mh, {(x, y) for y in range(mh) for x in range(width)}
    if shape == 'diagonal':
        points = {(y * (width - 1) // (mh - 1), y) for y in range(mh)}
    elif shape == 'chevron':
        points = {((2 * min(y, mh - y - 1) * (width - 1) + (mh - 1) // 2) // (mh - 1), y)
                  for y in range(mh)}
    elif shape in ['left_curve', 'fork_inner', 'fork_outer']:
        points = {(min(min(y, mh - y - 1) * (width - 1) // (mh // 3), width - 1), y)
                  for y in range(mh)}
        if shape == 'left_curve':
            points = {(width - x - 1, y) for x, y in points}
        else:
            center = mh // 2
            branch = max(0, width - 4) if shape == 'fork_inner' else (width - 1) // 4
            points.add((branch, center))
            points.update((x, center - 1) for x in range(branch + 1, width - 1))
    else:
        raise ValueError('unknown shape: ' + shape)
    return width, mh, points


def compose_noise(body, shape, leading, gap):
    source = body.convert('RGB')
    before = body.tobytes()
    fg = foreground_bbox(source)
    reference_height = fg[3] - fg[1]
    width, height, points = shape_pixels(shape, reference_height)
    ink = ImageChops.difference(source, Image.new('RGB', source.size, 'white')).getbbox()
    desired_y = fg[1] + (reference_height - height) // 2
    dy = max(0, 2 - desired_y)
    sy = desired_y + dy
    dx = width + gap if leading else 0
    sx = ink[0] if leading else ink[2] + gap
    output = Image.new('RGB', (source.width + width + gap,
                              max(source.height + dy, sy + height + 2)), 'white')
    output.paste(source, (dx, dy))
    for x, y in points:
        assert output.getpixel((sx + x, sy + y)) == (255, 255, 255)
        output.putpixel((sx + x, sy + y), (0, 0, 0))
    for y in range(source.height):
        for x in range(source.width):
            value = source.getpixel((x, y))
            if value != (255, 255, 255):
                assert output.getpixel((x + dx, y + dy)) == value
                assert (x + dx - sx, y + dy - sy) not in points
    assert body.tobytes() == before
    return output, {'body_offset': [dx, dy], 'reference_fg_bbox': list(fg),
                    'reference_fg_height': reference_height,
                    'shape_bounds': [sx, sy, sx + width, sy + height],
                    'shape_pixel_count': len(points),
                    'shape_relative_points': sorted([list(p) for p in points], key=lambda p: (p[1], p[0]))}


def component_height(image):
    bbox = foreground_bbox(image)
    return bbox[3] - bbox[1]
