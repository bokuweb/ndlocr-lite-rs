from pathlib import Path
import json,hashlib,sys,collections
r=Path('tmp/latin-dotted-body');source=Path('tmp/latin-pair-policy/product-manifest.json');cases=json.loads(source.read_text())['cases'];sha=lambda b:hashlib.sha256(b).hexdigest();groups={}
for x in cases:
 s=x['raw'];body=s[1:] if s.startswith((')','）')) else s[:-1] if s.endswith((')','）')) else ''
 if not(3<=len(body)<=8 and all(c.isascii() and c.isalpha() for c in body) and any(c in 'ij' for c in body)):continue
 assert sum(c in ')）' for c in s)==1
 key=x['rgb_sha256'];row=groups.setdefault(key,{'rgb':x['rgb'],'rgb_sha256':key,'width':x['width'],'height':x['height'],'references':[]})
 assert row['width']==x['width'] and row['height']==x['height'];row['references'].append(x)
rows=[]
for row in groups.values():
 rgb=Path(row['rgb']).read_bytes();assert sha(rgb)==row['rgb_sha256'];w,h=row['width'],row['height'];assert len(rgb)==w*h*3
 pixels={i for i in range(w*h) if sum(rgb[i*3:i*3+3])<660};fg=len(pixels);parts=[]
 while pixels:
  pending=[pixels.pop()];found=[]
  while pending:
   i=pending.pop();found.append(i)
   for yy in range(max(0,i//w-1),min(h,i//w+2)):
    for xx in range(max(0,i%w-1),min(w,i%w+2)):
     j=yy*w+xx
     if j in pixels:pixels.remove(j);pending.append(j)
  parts.append([min(i%w for i in found),min(i//w for i in found),max(i%w for i in found)+1,max(i//w for i in found)+1,len(found)])
 row['parts']=sorted(parts);row['foreground']=fg;rows.append(row)
record={'source_manifest_sha256':sha(source.read_bytes()),'driver_sha256':sha(Path(__file__).read_bytes()),'python':sys.version,'rows':rows};(r/'component-input.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('unique RGB',len(rows),'references',sum(len(x['references'])for x in rows),'components',sum(len(x['parts'])for x in rows),'too large',sum(x['width']*x['height']>65536 for x in rows))
