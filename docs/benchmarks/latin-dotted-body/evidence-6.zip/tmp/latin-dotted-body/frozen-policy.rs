//! Experimental dotted Latin geometry; no product caller.

use super::Component;

pub(super) fn supports(text: &str, rgb: &[u8], width: usize, height: usize) -> bool {
    let chars: Vec<_> = text.chars().take(10).collect();
    let round = |c| matches!(c, ')' | '）');
    if !(4..=9).contains(&chars.len()) || chars.iter().filter(|&&c| round(c)).count() != 1 {
        return false;
    }
    let leading = round(chars[0]);
    if !leading && !round(*chars.last().unwrap()) {
        return false;
    }
    let body = if leading {
        &chars[1..]
    } else {
        &chars[..chars.len() - 1]
    };
    let dotted = |c| matches!(c, 'i' | 'j');
    let dot_count = body.iter().filter(|&&c| dotted(c)).count();
    if body.iter().any(|c| !c.is_ascii_alphabetic()) || !(1..=2).contains(&dot_count) {
        return false;
    }
    let Some(mut parts) = super::collect_all(rgb, width, height) else {
        return false;
    };
    if parts.len() != body.len() + dot_count + 1 || parts.iter().any(|c| c.area < 3) {
        return false;
    }
    if parts.iter().any(|c| {
        (c.y0..c.y1)
            .map(|y| {
                (c.x0..c.x1)
                    .filter(|&x| {
                        let p = (y * width + x) * 3;
                        rgb[p..p + 3].iter().map(|&v| u16::from(v)).sum::<u16>() < 660
                    })
                    .count()
            })
            .sum::<usize>()
            != c.area
    }) {
        return false;
    }
    let mark = if leading {
        parts.remove(0)
    } else {
        parts.pop().unwrap()
    };
    let h = parts.iter().map(|c| c.y1 - c.y0).max().unwrap();
    if h < 8 {
        return false;
    }
    let (stems, dots): (Vec<_>, Vec<_>) = parts
        .into_iter()
        .partition(|c| (c.y1 - c.y0) as u128 * 4 >= h as u128 * 3);
    if stems.len() != body.len()
        || dots.len() != dot_count
        || dots.iter().any(|c| c.y1 - c.y0 > h / 3)
        || stems.iter().any(|c| {
            c.x1 - c.x0 < h.div_ceil(8)
                || (c.x1 - c.x0) as u128 * 2 > h as u128 * 3
                || c.area < h.div_ceil(2).max(3)
        })
        || stems
            .windows(2)
            .any(|p| p[0].x1 > p[1].x0 || p[1].x0 - p[0].x1 > h.div_ceil(4))
    {
        return false;
    }
    let top = stems.iter().map(|c| c.y0).max().unwrap();
    let bottom = stems.iter().map(|c| c.y1).min().unwrap();
    let max_bottom = stems.iter().map(|c| c.y1).max().unwrap();
    if bottom.saturating_sub(top) as u128 * 3 < h as u128 * 2 || max_bottom - bottom > h.div_ceil(3)
    {
        return false;
    }
    let gap = if leading {
        stems[0].x0.checked_sub(mark.x1)
    } else {
        mark.x0.checked_sub(stems.last().unwrap().x1)
    };
    if gap.is_none_or(|g| g > h.div_ceil(4))
        || !marker_supported(&mark, rgb, width, height, h, top, bottom)
    {
        return false;
    }
    let mut owned = vec![false; stems.len()];
    for dot in dots {
        let Some(index) = super::owner(&dot, &stems, h) else {
            return false;
        };
        if !dotted(body[index]) || owned[index] {
            return false;
        }
        owned[index] = true;
    }
    body.iter().enumerate().all(|(i, &c)| dotted(c) == owned[i])
}

fn marker_supported(
    mark: &Component,
    rgb: &[u8],
    width: usize,
    height: usize,
    body_height: usize,
    core_top: usize,
    core_bottom: usize,
) -> bool {
    if body_height < 8
        || width == 0
        || height == 0
        || width.checked_mul(height).and_then(|n| n.checked_mul(3)) != Some(rgb.len())
        || mark.x0 >= mark.x1
        || mark.y0 >= mark.y1
        || mark.x1 > width
        || mark.y1 > height
        || core_top >= core_bottom
        || mark.y0 > core_top
        || mark.y1 < core_bottom
    {
        return false;
    }
    let (mw, mh) = (mark.x1 - mark.x0, mark.y1 - mark.y0);
    if mh as u128 * 4 < body_height as u128 * 3
        || mh as u128 * 2 > body_height as u128 * 3
        || mw < mh.div_ceil(6).max(3)
        || mw > mh / 3
    {
        return false;
    }
    let rows: Vec<Vec<_>> = (mark.y0..mark.y1)
        .map(|y| {
            (mark.x0..mark.x1)
                .filter(|&x| {
                    let p = (y * width + x) * 3;
                    rgb[p..p + 3].iter().map(|&v| u16::from(v)).sum::<u16>() < 660
                })
                .collect()
        })
        .collect();
    if rows.iter().any(|r| {
        r.is_empty() || r.len() > (mw * 3).div_ceil(4) || r.windows(2).any(|p| p[1] != p[0] + 1)
    }) || *rows.first().unwrap().last().unwrap() >= mark.x0 + mw.div_ceil(2)
        || *rows.last().unwrap().last().unwrap() >= mark.x0 + mw.div_ceil(2)
        || rows.iter().map(Vec::len).sum::<usize>() != mark.area
    {
        return false;
    }
    let right_band = |r: &[usize]| r[0] >= mark.x0 + mw / 2;
    let center = mh / 2;
    if !right_band(&rows[center]) || *rows[center].last().unwrap() != mark.x1 - 1 {
        return false;
    }
    let (mut top, mut bottom) = (center, center + 1);
    while top > 0 && right_band(&rows[top - 1]) {
        top -= 1;
    }
    while bottom < mh && right_band(&rows[bottom]) {
        bottom += 1;
    }
    bottom - top >= mh.div_ceil(3)
}
