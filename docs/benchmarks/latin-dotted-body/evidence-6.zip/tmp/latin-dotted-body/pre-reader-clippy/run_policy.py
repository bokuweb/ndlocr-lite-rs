from pathlib import Path
import json,hashlib,subprocess,os,shutil,time
r=Path('tmp/latin-dotted-body');sha=lambda b:hashlib.sha256(b).hexdigest();p=Path('src/infer/visible_repetitions/dotted_body/policy.rs');policy=p.read_text().split('\n#[cfg(test)]')[0].rstrip()+'\n';kp=Path('src/infer/visible_repetitions/dotted_body.rs');s=kp.read_text();owner=s[s.index('fn owner('):s.index('\nfn collect_all(')].rstrip()+'\n';kernel=json.loads((r/'kernel-lock.json').read_text());assert sha(owner.encode())==kernel['owner_sha256'];(r/'frozen-policy.rs').write_text(policy)
lock={'policy_prefix_sha256':sha(policy.encode()),'owner_sha256':kernel['owner_sha256'],'policy_spec_sha256':sha(Path('docs/latin_dotted_body_policy.md').read_bytes()),'pure_tests':30,'ignored_component_diagnostic':1,'property_cases_per_property':64,'new_nn_forwards':0,'product_caller':False};(r/'policy-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
source=Path('tmp/latin-pair-policy/product-manifest.json');cases=json.loads(source.read_text())['cases'];assert len(cases)==223143;inputs={}
for x in cases:
 desc={'rgb_sha256':x['rgb_sha256'],'width':x['width'],'height':x['height']}
 if x['rgb'] in inputs:assert inputs[x['rgb']]==desc
 inputs[x['rgb']]=desc
for path,x in inputs.items():
 b=Path(path).read_bytes();assert sha(b)==x['rgb_sha256'] and len(b)==x['width']*x['height']*3
(r/'policy-rgb-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');meta={'cases_source':str(source),'cases_source_sha256':sha(source.read_bytes()),'expected_cases':len(cases)};(r/'policy-input.json').write_text(json.dumps(meta,indent=2)+'\n')
events=[json.loads(x)for x in (r/'policy-build.jsonl').read_text().splitlines()];exes=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(exes)==1;exe=r/'policy-binary';shutil.copy2(exes[0],exe);exe.chmod(0o755)
files=sorted(p for folder in ['src','tests','benches','examples'] for p in Path(folder).rglob('*.rs'));files += [Path('Cargo.toml'),Path('Cargo.lock')]+sorted(Path('docs').glob('latin_dotted*.md'))+sorted(Path('tests/fixtures/latin_dotted_body').glob('*'));snap={}
for p in files:
 t=r/'policy-source'/p;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);snap[str(p)]=sha(p.read_bytes())
argv=[str(exe.resolve()),'infer::visible_repetitions::dotted_body::policy::tests::record_fixed_policy_on_saved_raw','--exact','--ignored','--nocapture'];env=os.environ.copy();env['NDLOCR_DOTTED_POLICY_ROOT']=str(r.resolve());record={'command':argv,'binary_sha256':sha(exe.read_bytes()),'sources_sha256':snap,'cases_source_sha256':meta['cases_source_sha256'],'input_metadata_sha256':sha((r/'policy-input.json').read_bytes()),'rgb_inventory_sha256':sha((r/'policy-rgb-inputs.json').read_bytes()),'rgb_paths':len(inputs),'driver_sha256':sha(Path(__file__).read_bytes()),'policy_lock':lock,'new_nn_forwards':0,'environment_override':{'NDLOCR_DOTTED_POLICY_ROOT':str(r.resolve())}};(r/'policy-freeze.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (r/'policy-replay.stdout').open('wb')as out,(r/'policy-replay.stderr').open('wb')as err:done=subprocess.run(argv,env=env,stdout=out,stderr=err)
record['exit_code']=done.returncode;record['seconds']=time.monotonic()-start
for p,h in snap.items():assert sha(Path(p).read_bytes())==h
for path,x in inputs.items():assert sha(Path(path).read_bytes())==x['rgb_sha256']
assert sha(source.read_bytes())==meta['cases_source_sha256'];record['all_source_and_inputs_unchanged_after']=True;(r/'policy-command.json').write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0
result=json.loads((r/'policy-results.json').read_text());print('baseline checked',result['cases_checked'],'candidate changes',len(result['changes']),'new NN 0',flush=True)
