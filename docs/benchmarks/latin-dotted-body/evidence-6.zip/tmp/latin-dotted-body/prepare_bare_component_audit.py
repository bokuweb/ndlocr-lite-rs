from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
r=Path('tmp/latin-dotted-body');out=r/'bare-component-audit';out.mkdir();(out/'rgb').mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((r/'fresh/evaluation-manifest.json').read_text());rows=[]
for rec in m['native_records']:
 if not rec['id'].endswith('_bare'):continue
 full=Image.open(r/'fresh/native'/(rec['id']+'.png')).convert('RGB');box=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();im=Image.new('RGB',(box[2]-box[0]+4,box[3]-box[1]+4),'white');im.paste(full.crop(box),(2,2));rgb=im.tobytes();assert sha(rgb)==rec['cropped_rgb_sha256'];w,h=im.size;p=out/'rgb'/(rec['id']+'.rgb');p.write_bytes(rgb);pixels={i for i in range(w*h) if sum(rgb[i*3:i*3+3])<660};fg=len(pixels);parts=[]
 while pixels:
  seed=pixels.pop();pending=[seed];found=[]
  while pending:
   i=pending.pop();found.append(i)
   for y in range(max(0,i//w-1),min(h,i//w+2)):
    for x in range(max(0,i%w-1),min(w,i%w+2)):
     j=y*w+x
     if j in pixels:pixels.remove(j);pending.append(j)
  parts.append([min(i%w for i in found),min(i//w for i in found),max(i%w for i in found)+1,max(i//w for i in found)+1,len(found)])
 rows.append({'native_id':rec['id'],'rgb':str(p),'rgb_sha256':sha(rgb),'width':w,'height':h,'parts':sorted(parts),'foreground':fg,'references':[]})
assert len(rows)==126;(out/'component-input.json').write_text(json.dumps({'rows':rows,'driver_sha256':sha(Path(__file__).read_bytes()),'manifest_sha256':sha((r/'fresh/evaluation-manifest.json').read_bytes())},indent=2)+'\n');print('126 bare native crops and independent component boxes frozen')
