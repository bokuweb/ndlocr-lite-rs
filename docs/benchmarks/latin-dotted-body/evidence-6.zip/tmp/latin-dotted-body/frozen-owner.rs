fn owner(dot: &Component, stems: &[Component], body_height: usize) -> Option<usize> {
    let valid = |c: &Component| {
        c.x0 < c.x1
            && c.y0 < c.y1
            && c.area >= 3
            && c.area as u128 <= (c.x1 - c.x0) as u128 * (c.y1 - c.y0) as u128
    };
    if body_height < 8 || !valid(dot) || stems.iter().any(|s| !valid(s)) {
        return None;
    }
    let (dw, dh) = (dot.x1 - dot.x0, dot.y1 - dot.y0);
    if [dw, dh]
        .iter()
        .any(|&n| n < body_height.div_ceil(8) || n > body_height / 3)
    {
        return None;
    }
    let mut result = None;
    for (index, stem) in stems.iter().enumerate() {
        let (sw, sh) = (stem.x1 - stem.x0, stem.y1 - stem.y0);
        let Some(gap) = stem.y0.checked_sub(dot.y1) else {
            continue;
        };
        let overlap = stem.x1.min(dot.x1).saturating_sub(stem.x0.max(dot.x0));
        let center = dot.x0 as u128 + dot.x1 as u128;
        if sh as u128 * 4 < body_height as u128 * 3
            || sh > body_height
            || sw < body_height.div_ceil(8)
            || sw as u128 * 2 > body_height as u128 * 3
            || gap == 0
            || gap > body_height.div_ceil(4)
            || overlap as u128 * 2 < dw as u128
            || center < stem.x0 as u128 * 2
            || center > stem.x1 as u128 * 2
            || dot.area as u128 * 2 > stem.area as u128
            || (stem.y1 - dot.y0) as u128 * 2 > body_height as u128 * 3
        {
            continue;
        }
        if result.is_some() {
            return None;
        }
        result = Some(index);
    }
    result
}
