# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `19440`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| candidate | 19440 | 0 | 0.3468 | 0.8548 | -0.0001 | -0.0001 |
| baseline | 19440 | 0 | 0.3469 | 0.8549 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

