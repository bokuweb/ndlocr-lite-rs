# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `334`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| candidate | 334 | 0 | 0.2193 | 0.8247 | -0.0023 | -0.0103 |
| baseline | 334 | 0 | 0.2216 | 0.8351 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

