# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `334`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| candidate | 334 | 0 | 0.2135 | 0.7990 | -0.0052 | -0.0232 |
| baseline | 334 | 0 | 0.2187 | 0.8222 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

