BODIES = ['Abjp', 'Ajbp', 'Bpjg', 'Adip', 'Aimq', 'Apji']
MODES = [('freetype', None), ('coretext', 0), ('coretext', 1)]
FONTS = ['maru', 'gothic', 'mincho']
SIZES = [20, 32]
SHAPES = ['none', 'thin', 'bar', 'dot', 'diagonal', 'chevron', 'left_curve', 'fork_inner', 'fork_outer']

def expected_conditions():
    return []
