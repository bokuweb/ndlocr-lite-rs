import unittest,collections
from controls import expected_conditions

class Controls(unittest.TestCase):
 def setUp(self):self.rows=expected_conditions()
 def test_all_condition_ids_and_mode_font_sizes_are_frozen(self):
  self.assertEqual(len(self.rows),19440);self.assertEqual(len({x['id']for x in self.rows}),19440)
  actual=collections.Counter((x['engine'],x['palt'],x['font'],x['size'])for x in self.rows)
  self.assertEqual(actual,{(e,p,f,s):1080 for e,p in [('freetype',None),('coretext',0),('coretext',1)]for f in ['maru','gothic','mincho']for s in [20,32]})
 def test_text_and_noise_crosses_keep_the_specified_scope(self):
  text=[x for x in self.rows if x['kind']=='text'];noise=[x for x in self.rows if x['kind']=='noise'];self.assertEqual((len(text),len(noise)),(10368,9072))
  self.assertEqual({x['body']for x in text},{'Abjp','Ajbp','Bpjg','Adip','Aimq','Apji'})
  self.assertEqual({x['body']for x in noise if x['body_spaces']}, {'Apji'})
  self.assertEqual(collections.Counter(x['shape']for x in noise),{s:1008 for s in ['none','thin','bar','dot','diagonal','chevron','left_curve','fork_inner','fork_outer']})
  self.assertEqual(collections.Counter(x['paper']for x in text),{0:3456,2:3456,10:3456})
  self.assertEqual(collections.Counter(x['format']for x in self.rows),{'png':9720,'jpeg75':9720})
 def test_native_records_are_reused_only_for_the_same_actual_text(self):
  natives={}
  for x in self.rows:
   desc=(x['engine'],x['palt'],x['font'],x['size'],x['truth'])
   if x['native_id']in natives:self.assertEqual(natives[x['native_id']],desc)
   natives[x['native_id']]=desc
  self.assertEqual(len(natives),1854)
 def test_truth_preserves_internal_and_outer_spaces(self):
  rows=[x for x in self.rows if x['engine']=='freetype'and x['font']=='maru'and x['size']==20 and x['body']=='Abjp'and x['body_spaces']==1 and x['kind']=='text'and x['closer']==')'and x['leading']and x['spaces']==1 and x['paper']==0 and x['format']=='png']
  self.assertEqual(len(rows),1);self.assertEqual(rows[0]['truth'],') A b j p');self.assertIsNone(rows[0]['palt'])

if __name__=='__main__':unittest.main()
