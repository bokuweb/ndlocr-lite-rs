import unittest
from PIL import Image
from graphics import component_height, compose_noise

class Graphics(unittest.TestCase):
 def body_with_dot(self):
  image=Image.new('RGB',(20,26),'white')
  for y in range(12,22):
   for x in range(5,9):image.putpixel((x,y),(0,0,0))
  for y in range(4,7):
   for x in range(6,9):image.putpixel((x,y),(0,0,0))
  image.putpixel((0,0),(254,254,254));return image
 def test_reference_uses_each_connected_component_without_dropping_islands(self):
  image=Image.new('RGB',(12,14),'white')
  for xy in [(1,1),(2,2),(3,3),(6,10)]:image.putpixel(xy,(0,0,0))
  self.assertEqual(component_height(image),3)
  self.assertEqual(component_height(self.body_with_dot()),10)
 def test_shape_scales_from_component_height_and_centers_on_full_foreground(self):
  body=self.body_with_dot();before=body.tobytes();out,meta=compose_noise(body,'bar',True,1)
  self.assertEqual(meta['reference_component_height'],10);self.assertEqual(meta['reference_fg_height'],18)
  self.assertEqual(meta['shape_bounds'],[0,6,3,20]);self.assertEqual(meta['body_offset'],[4,0]);self.assertEqual(meta['shape_pixel_count'],42)
  for y in range(body.height):
   for x in range(body.width):
    if body.getpixel((x,y))!=(255,255,255):self.assertEqual(out.getpixel((x+4,y)),body.getpixel((x,y)))
  self.assertEqual(body.tobytes(),before)
 def test_large_shape_expands_canvas_and_keeps_nearwhite_source_pixels(self):
  body=Image.new('RGB',(12,16),'white')
  for y in range(3,15):
   for x in range(4,7):body.putpixel((x,y),(0,0,0))
  body.putpixel((10,15),(254,254,254));out,meta=compose_noise(body,'thin',False,0)
  self.assertEqual(meta['body_offset'],[0,1]);self.assertEqual(out.getpixel((10,16)),(254,254,254));self.assertEqual(out.height,20)
 def test_no_foreground_is_rejected_but_nearwhite_does_not_change_components(self):
  image=Image.new('RGB',(10,20),(220,220,220))
  with self.assertRaises(ValueError):component_height(image)
  for y in range(2,10):image.putpixel((3,y),(0,0,0))
  image.putpixel((8,18),(219,220,220));self.assertEqual(component_height(image),8)

if __name__=='__main__':unittest.main()
