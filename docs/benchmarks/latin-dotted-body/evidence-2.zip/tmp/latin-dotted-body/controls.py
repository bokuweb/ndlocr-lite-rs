BODIES = ['Abjp', 'Ajbp', 'Bpjg', 'Adip', 'Aimq', 'Apji']
MODES = [('freetype', None), ('coretext', 0), ('coretext', 1)]
FONTS = ['maru', 'gothic', 'mincho']
SIZES = [20, 32]
SHAPES = ['none', 'thin', 'bar', 'dot', 'diagonal', 'chevron', 'left_curve', 'fork_inner', 'fork_outer']

def expected_conditions():
    rows = []
    for engine, palt in MODES:
        for font in FONTS:
            for size in SIZES:
                for body_id, unspaced in enumerate(BODIES):
                    for body_spaces in [0, 1]:
                        body = (' ' * body_spaces).join(unspaced)
                        prefix = f'd_{engine}_p{palt}_b{body_id}_{font}_{size}_bs{body_spaces}'
                        common = dict(engine=engine, palt=palt, font=font, size=size, body_id=body_id, body=unspaced, body_spaces=body_spaces)
                        for ci, closer in enumerate([')', '）']):
                            for leading in [False, True]:
                                for spaces in [0, 1]:
                                    text = closer + ' ' * spaces + body if leading else body + ' ' * spaces + closer
                                    native_id = prefix + f'_c{ci}_lead{int(leading)}_sp{spaces}'
                                    for paper in [0, 2, 10]:
                                        for fmt in ['png', 'jpeg75']:
                                            rows.append(common | dict(kind='text', native_id=native_id, closer=closer, leading=leading, spaces=spaces, paper=paper, format=fmt, truth=text, id=native_id+f'_paper{paper}_'+fmt))
                        if body_spaces and unspaced != 'Apji':
                            continue
                        for shape in SHAPES:
                            for leading in [False, True]:
                                for gap in [0, 1]:
                                    for fmt in ['png', 'jpeg75']:
                                        rows.append(common | dict(kind='noise', native_id=prefix+'_bare', shape=shape, leading=leading, gap=gap, format=fmt, truth=body, id=prefix+f'_noise{shape}_lead{int(leading)}_gap{gap}_'+fmt))
    return rows
