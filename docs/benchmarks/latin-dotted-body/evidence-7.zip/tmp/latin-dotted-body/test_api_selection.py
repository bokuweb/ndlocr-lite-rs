import unittest,copy,hashlib
from controls import expected_conditions
from api_selection import select_noise_api

class Selection(unittest.TestCase):
 def setUp(self):
  self.rows=[x|{'rgb_sha256':'rgb-'+x['id'],'truth_sha256':'truth-'+x['id'],'rotated_for_auto':False}for x in expected_conditions()]
 def test_all_324_strata_select_one_hash_minimum_and_fixed_model(self):
  selected=select_noise_api(self.rows);self.assertEqual(len(selected),324)
  byid={x['id']:x for x in self.rows};seen=set()
  for x in selected:
   row=byid[x['id']];key=tuple(row[k]for k in ['engine','palt','font','size','shape','format']);self.assertNotIn(key,seen);seen.add(key)
   candidates=[r for r in self.rows if r['kind']=='noise'and tuple(r[k]for k in ['engine','palt','font','size','shape','format'])==key]
   expected=min(candidates,key=lambda r:(hashlib.sha256(r['id'].encode()).hexdigest(),r['id']))
   self.assertEqual(x['id'],expected['id']);self.assertEqual(x['model'],['30','50','100'][hashlib.sha256(x['id'].encode()).digest()[0]%3]);self.assertEqual(x['orientation'],'auto');self.assertEqual(x['rgb_sha256'],row['rgb_sha256'])
 def test_order_does_not_change_selection_and_rotated_originals_add_horizontal(self):
  self.assertEqual(select_noise_api(self.rows),select_noise_api(list(reversed(self.rows))))
  for r in self.rows:r['rotated_for_auto']=True
  selected=select_noise_api(self.rows);self.assertEqual(len(selected),648)
  for id in {x['id']for x in selected}:self.assertEqual({x['orientation']for x in selected if x['id']==id},{'auto','horizontal'})
 def test_duplicate_missing_and_extra_strata_are_rejected(self):
  bads=[self.rows+[copy.deepcopy(self.rows[0])],[x for x in self.rows if not(x['kind']=='noise'and x['shape']=='none')]]
  extra=next(copy.deepcopy(x)for x in self.rows if x['kind']=='noise');extra['id']='extra';extra['font']='unregistered-font';bads.append(self.rows+[extra])
  for rows in bads:
   with self.subTest(size=len(rows)),self.assertRaises(ValueError):select_noise_api(rows)

if __name__=='__main__':unittest.main()
