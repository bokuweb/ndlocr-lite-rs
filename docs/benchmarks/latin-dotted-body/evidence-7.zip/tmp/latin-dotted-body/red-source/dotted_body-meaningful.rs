//! Experimental ownership of a detached upper dot; no product caller.

use super::Component;

fn owner(_dot: &Component, _stems: &[Component], _body_height: usize) -> Option<usize> {
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cell(x0: usize, y0: usize, x1: usize, y1: usize, area: usize) -> Component {
        Component { x0, y0, x1, y1, area }
    }

    fn dot() -> Component {
        cell(14, 2, 18, 6, 12)
    }

    fn stem() -> Component {
        cell(12, 10, 22, 34, 120)
    }

    #[test]
    fn one_upper_dot_has_one_owner_without_changing_the_boxes() {
        let d = dot();
        let stems = [cell(0, 10, 9, 34, 100), stem()];
        assert_eq!(owner(&d, &stems, 24), Some(1));
        assert_eq!((d.x0, d.y0, d.x1, d.y1, d.area), (14, 2, 18, 6, 12));
        assert_eq!(stems[1].area, 120);
    }

    #[test]
    fn ambiguous_or_missing_owners_are_rejected() {
        assert_eq!(owner(&dot(), &[], 24), None);
        assert_eq!(owner(&dot(), &[stem(), stem()], 24), None);
        assert_eq!(owner(&dot(), &[cell(0, 10, 9, 34, 100)], 24), None);
    }

    #[test]
    fn dot_width_and_height_have_inclusive_eighth_and_third_bounds() {
        for size in [2, 3, 8, 9] {
            let expected = if (3..=8).contains(&size) { Some(0) } else { None };
            let wide_stem = cell(10, 10, 24, 34, 200);
            assert_eq!(owner(&cell(12, 1, 12 + size, 4, size * 3), &[wide_stem], 24), expected, "dot width {size}");
            let lowered_stem = cell(12, 12, 22, 36, 180);
            assert_eq!(owner(&cell(14, 10 - size, 18, 10, 3 * size), &[lowered_stem], 24), expected, "dot height {size}");
        }
        assert_eq!(owner(&dot(), &[stem()], 7), None);
    }

    #[test]
    fn stem_width_and_height_keep_the_fixed_bounds() {
        for width in [2, 3, 36, 37] {
            let d = cell(13, 4, 16, 8, 10);
            let s = cell(12, 10, 12 + width, 34, width * 12);
            assert_eq!(owner(&d, &[s], 24), if (3..=36).contains(&width) { Some(0) } else { None }, "stem width {width}");
        }
        for height in [17, 18, 24, 25] {
            let s = cell(12, 10, 22, 10 + height, 100);
            assert_eq!(owner(&dot(), &[s], 24), if (18..=24).contains(&height) { Some(0) } else { None }, "stem height {height}");
        }
    }

    #[test]
    fn dot_must_be_above_with_a_positive_bounded_gap() {
        for gap in [0, 1, 6, 7] {
            let d = cell(14, 8 - gap, 18, 10 - gap, 6);
            assert_eq!(owner(&d, &[stem()], 24), None, "two-pixel dot is always too short, gap {gap}");
            let d = cell(14, 7 - gap, 18, 10 - gap, 9);
            assert_eq!(owner(&d, &[stem()], 24), if (1..=6).contains(&gap) { Some(0) } else { None }, "vertical gap {gap}");
        }
        assert_eq!(owner(&cell(14, 12, 18, 16, 12), &[stem()], 24), None);
    }

    #[test]
    fn horizontal_overlap_and_center_both_have_to_support_the_owner() {
        for (x, expected) in [(8, None), (9, None), (10, Some(0)), (20, Some(0)), (21, None), (22, None)] {
            assert_eq!(owner(&cell(x, 2, x + 4, 6, 12), &[stem()], 24), expected, "dot x {x}");
        }
    }

    #[test]
    fn dot_area_and_total_height_do_not_grow_unbounded() {
        assert_eq!(owner(&cell(14, 2, 18, 6, 12), &[cell(12, 10, 22, 34, 23)], 24), None);
        assert_eq!(owner(&cell(14, 2, 18, 6, 12), &[cell(12, 10, 22, 34, 24)], 24), Some(0));
        for (top, expected) in [(1, Some(0)), (0, Some(0))] {
            assert_eq!(owner(&cell(14, top, 18, 4, 12), &[cell(12, 10, 22, 34, 120)], 24), expected);
        }
        assert_eq!(owner(&cell(14, 0, 18, 8, 24), &[cell(12, 14, 22, 38, 120)], 24), None);
        assert_eq!(owner(&cell(14, 0, 18, 6, 18), &[cell(12, 12, 22, 36, 120)], 24), Some(0));
    }

    #[test]
    fn invalid_boxes_and_impossible_areas_in_any_input_are_rejected() {
        for d in [cell(18, 2, 14, 6, 12), cell(14, 6, 18, 2, 12), cell(14, 2, 18, 2, 12), cell(14, 2, 18, 6, 2), cell(14, 2, 18, 6, 17)] {
            assert_eq!(owner(&d, &[stem()], 24), None);
        }
        assert_eq!(owner(&dot(), &[stem(), cell(0, 0, 0, 1, 3)], 24), None);
        assert_eq!(owner(&dot(), &[cell(12, 10, 22, 34, 241)], 24), None);
        assert_eq!(owner(&dot(), &[stem()], 0), None);
    }
}
