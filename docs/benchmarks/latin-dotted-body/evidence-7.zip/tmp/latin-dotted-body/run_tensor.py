from pathlib import Path
import json,hashlib,subprocess,os,time
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();binary=r/'policy-binary';source=json.loads((r/'policy-command.json').read_text());assert source['binary_sha256']==sha(binary)and source['exit_code']==0
for p,h in source['sources_sha256'].items():
 if p.endswith('.rs')or p in ['Cargo.toml','Cargo.lock']:assert sha(p)==h,p
m=r/'fresh/evaluation-manifest.json';inputs=json.loads(m.read_text())['inputs'];inventory={}
for x in inputs:
 for k in ['rgb','effective_rgb']:
  assert sha(x[k])==x[k+'_sha256'];inventory[x[k]]=x[k+'_sha256']
argv=[str(binary.resolve()),'infer::visible_repetitions::latin_pair_policy::tests::verify_fresh_latin_pair_auto_tensors','--exact','--ignored','--nocapture'];record={'argv':argv,'binary_sha256':sha(binary),'source_record_sha256':sha(r/'policy-command.json'),'manifest_sha256':sha(m),'model_input_shapes':[[256,24],[384,24],[768,24]],'models':{str(p):sha(p)for p in Path('models').iterdir()if p.suffix in ['.onnx','.yaml']},'inputs_sha256':inventory,'driver_sha256':sha(__file__),'new_nn_forwards':0};(r/'tensor-freeze.json').write_text(json.dumps(record,indent=2)+'\n');env=os.environ.copy();env['NDLOCR_LATIN_PAIR_POLICY_ROOT']=str(r.resolve());start=time.monotonic()
with (r/'tensor.stdout').open('wb')as out,(r/'tensor.stderr').open('wb')as err:done=subprocess.run(argv,env=env,stdout=out,stderr=err)
record['exit_code']=done.returncode;record['seconds']=time.monotonic()-start
for p,h in inventory.items():assert sha(p)==h
for p,h in record['models'].items():assert sha(p)==h
assert sha(m)==record['manifest_sha256']and sha(binary)==record['binary_sha256'];record['all_inputs_models_binary_unchanged_after']=True;(r/'tensor-command.json').write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0;print('19440 originals x3 input shapes Auto/effective Horizontal bit equal; no NN',flush=True)
