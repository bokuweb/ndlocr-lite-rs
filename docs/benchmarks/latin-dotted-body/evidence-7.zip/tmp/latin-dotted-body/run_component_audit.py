from pathlib import Path
import json,hashlib,subprocess,os,shutil,time
r=Path('tmp/latin-dotted-body');sha=lambda b:hashlib.sha256(b).hexdigest();p=Path('src/infer/visible_repetitions/dotted_body.rs');s=p.read_text();owner=s[s.index('fn owner('):s.index('\nfn collect_all(')].rstrip()+'\n';lock=json.loads((r/'kernel-lock.json').read_text());assert sha(owner.encode())==lock['owner_sha256']
events=[json.loads(x) for x in (r/'build.jsonl').read_text().splitlines()];exes=[x['executable'] for x in events if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='ndlocr_lite_rs'];assert len(exes)==1;exe=r/'audit-binary';shutil.copy2(exes[0],exe);exe.chmod(0o755)
files=sorted(p for folder in ['src','tests','benches','examples'] for p in Path(folder).rglob('*.rs'));files += [Path('Cargo.toml'),Path('Cargo.lock'),Path('docs/latin_dotted_body_kernel.md'),Path('docs/latin_dotted_component_audit.md')]
source={}
for p in files:
 target=r/'audit-source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);source[str(p)]=sha(p.read_bytes())
inputs=json.loads((r/'component-input.json').read_text())['rows']
for x in inputs:assert sha(Path(x['rgb']).read_bytes())==x['rgb_sha256']
argv=[str(exe.resolve()),'infer::visible_repetitions::dotted_body::tests::record_saved_component_owners','--exact','--ignored','--nocapture'];env=os.environ.copy();env['NDLOCR_DOTTED_BODY_AUDIT_ROOT']=str(r.resolve());record={'command':argv,'source_sha256':source,'binary_sha256':sha(exe.read_bytes()),'input_sha256':sha((r/'component-input.json').read_bytes()),'driver_sha256':sha(Path(__file__).read_bytes()),'owner_sha256':lock['owner_sha256'],'new_nn_forwards':0,'environment_override':{'NDLOCR_DOTTED_BODY_AUDIT_ROOT':str(r.resolve())}};(r/'audit-freeze.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (r/'audit.stdout').open('wb') as out,(r/'audit.stderr').open('wb') as err:done=subprocess.run(argv,env=env,stdout=out,stderr=err)
record['exit_code']=done.returncode;record['seconds']=time.monotonic()-start
for p,h in source.items():assert sha(Path(p).read_bytes())==h
for x in inputs:assert sha(Path(x['rgb']).read_bytes())==x['rgb_sha256']
record['source_and_all_inputs_unchanged_after']=True;(r/'audit-command.json').write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0
records=json.loads((r/'component-results.json').read_text());assert len(records)==len(inputs)
contexts=[c for row in records for c in row['contexts']];dots=[d for c in contexts for d in c['dot_hypotheses'] if d['owner_index'] is not None];summary={'images':len(records),'references':sum(len(x['references']) for x in inputs),'components':sum(len(x['parts'])for x in records),'contexts':len(contexts),'owned_dot_hypotheses':len(dots),'images_with_an_owned_dot':sum(any(d['owner_index'] is not None for c in row['contexts'] for d in c['dot_hypotheses'])for row in records),'new_nn_forwards':0,'not_an_accuracy_measurement':True};(r/'audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
