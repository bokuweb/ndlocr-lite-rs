from pathlib import Path
import unittest,json
class Raw(unittest.TestCase):
 def test_every_auto_and_original_horizontal_input_has_one_raw_record_in_each_model(self):
  root=Path('tmp/latin-dotted-body')
  for phase,count in [('fresh',19440),('horizontal',334)]:
   inputs=json.loads((root/phase/'evaluation-manifest.json').read_text())['inputs'];self.assertEqual(len(inputs),count);byid={x['id']:x for x in inputs}
   for model in ['30','50','100']:
    with self.subTest(phase=phase,model=model):
     rows=json.loads((root/phase/(model+'-export.json')).read_text());self.assertEqual(len(rows),count);self.assertEqual({x['id']for x in rows},set(byid))
     for x in rows:self.assertEqual(len(x['chunks']),1);self.assertEqual(x['chunks'][0]['x_range'],[0,byid[x['id']]['forward_width']])
if __name__=='__main__':unittest.main()
