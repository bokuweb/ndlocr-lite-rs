from pathlib import Path
import tempfile,unittest,hashlib,copy
from assemble_raw import assemble

class Assembly(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);r=Path(self.temp.name);rgb=r/'x.rgb';rgb.write_bytes(bytes(range(6)));truth=r/'x.txt';truth.write_bytes(' A ）\n'.encode());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();self.input=dict(id='x',rgb=str(rgb),rgb_sha256=sha(rgb),truth=str(truth),truth_sha256=sha(truth),width=2,height=1,forward_width=2,forward_height=1,bounds=[0,0,2,1])
 def output(self,id,text):
  cursor=0;steps=[]
  for c in text:
   end=cursor+len(c.encode());steps.append({'byte_range':[cursor,end],'candidates':[{'character':c,'probability':0.5}]});cursor=end
  steps.append({'byte_range':None,'candidates':[{'character':None,'probability':0.99}]})
  return dict(id=id,bounds=[0,0,2,1],text=text,chunks=[dict(x_range=[0,2],text=text,inserted_space_before=False,steps=steps)])
 def test_utf8_spaces_newline_and_f32_mean_are_preserved(self):
  rows=assemble([self.input],[self.output('x',' A ） ')],'30','fresh');self.assertEqual(len(rows),1);row=rows[0];self.assertEqual(row['raw'],' A ） ');self.assertEqual(row['truth'],' A ）\n');self.assertEqual(row['raw_mean_bits'],0x3f000000);self.assertEqual(row['orientation'],'auto');self.assertEqual(row['corpus'],'dotted-fresh')
 def test_pairing_uses_ids_and_explicit_horizontal(self):
  inputs=[self.input,dict(self.input,id='y')];outputs=[self.output('y','B)'),self.output('x','A)')];rows=assemble(inputs,outputs,'100','horizontal');self.assertEqual([x['raw']for x in rows],['A)','B)']);self.assertTrue(all(x['orientation']=='horizontal'for x in rows))
 def test_duplicate_missing_extra_and_invalid_options_are_rejected(self):
  out=self.output('x','A)')
  for inputs,outputs in [([self.input,self.input],[out]),([self.input],[out,out]),([self.input],[]),([self.input],[out,self.output('extra','B)')])]:
   with self.subTest(inputs=len(inputs),outputs=len(outputs)),self.assertRaises(ValueError):assemble(inputs,outputs,'30','fresh')
  for model,phase in [('20','fresh'),('30','unknown')]:
   with self.subTest(model=model,phase=phase),self.assertRaises(ValueError):assemble([self.input],[out],model,phase)
 def test_wrong_roi_and_changed_source_bytes_are_rejected(self):
  for kind in ['bounds','x_range','extra_chunk']:
   out=self.output('x','A)')
   if kind=='bounds':out['bounds']=[0,0,3,1]
   elif kind=='x_range':out['chunks'][0]['x_range']=[1,2]
   else:out['chunks'].append(copy.deepcopy(out['chunks'][0]))
   with self.subTest(kind=kind),self.assertRaises(ValueError):assemble([self.input],[out],'30','fresh')
  Path(self.input['rgb']).write_bytes(b'broken')
  with self.assertRaises(ValueError):assemble([self.input],[self.output('x','A)')],'30','fresh')

if __name__=='__main__':unittest.main()
