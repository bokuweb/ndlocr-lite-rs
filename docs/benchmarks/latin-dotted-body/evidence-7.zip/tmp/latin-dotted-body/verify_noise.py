from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
r=Path('tmp/latin-dotted-body');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();audit=[];heights=json.loads((r/'bare-component-audit/verification.json').read_text())['heights']
# Independent reconstruction: no generator/graphics imports.
def expected_points(name, H):
 W=max(3,(H+3)//4);MH=(4*H+2)//3
 assert H>=6
 if name=='none':return 0,0,set()
 if name=='thin':return 1,MH,{(0,y)for y in range(MH)}
 if name=='bar':return W,MH,{(x,y)for y in range(MH)for x in range(W)}
 if name=='dot':return 4,4,{(x,y)for y in range(4)for x in range(4)}
 if name=='diagonal':points={(y*(W-1)//(MH-1),y)for y in range(MH)}
 elif name=='chevron':points={((2*min(y,MH-1-y)*(W-1)+(MH-1)//2)//(MH-1),y)for y in range(MH)}
 else:
  points={(min(min(y,MH-1-y)*(W-1)//(MH//3),W-1),y)for y in range(MH)}
  if name=='left_curve':points={(W-1-x,y)for x,y in points}
  elif name in ['fork_inner','fork_outer']:
   left=max(0,W-4)if name=='fork_inner'else(W-1)//4
   points.add((left,MH//2));points.update((x,MH//2-1)for x in range(left+1,W-1))
  else:raise AssertionError(name)
 return W,MH,points
for x in m['inputs']:
 if x['kind']!='noise' or x['format']!='png':continue
 full=Image.open(f/'native'/(x['native_id']+'.png')).convert('RGB');bb=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();native=Image.new('RGB',(bb[2]-bb[0]+4,bb[3]-bb[1]+4),'white');native.paste(full.crop(bb),(2,2));box=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox()
 mask=Image.new('L',native.size);mask.putdata([255 if sum(p)<660 else 0 for p in native.getdata()]);fg=mask.getbbox();H=heights[x['native_id']];W,MH,points=expected_points(x['shape'],H)
 assert points=={tuple(p)for p in x['shape_relative_points']}and len(points)==x['shape_pixel_count']
 desired_y=fg[1]+(fg[3]-fg[1]-MH)//2;dy=max(0,2-desired_y);py=desired_y+dy;dx=W+x['gap']if x['leading']else 0;px=box[0]if x['leading']else box[2]+x['gap']
 assert list(fg)==x['reference_fg_bbox']and fg[3]-fg[1]==x['reference_fg_height'] and H==x['reference_component_height']
 assert [dx,dy]==x['body_offset']and [px,py,px+W,py+MH]==x['shape_bounds']
 expected=Image.new('RGB',(native.width+W+x['gap'],max(native.height+dy,py+MH+2)),'white');expected.paste(native,(dx,dy));overlap=0
 for yy in range(native.height):
  for xx in range(native.width):
   if native.getpixel((xx,yy))!=(255,255,255):overlap+=(xx+dx-px,yy+dy-py)in points
 assert overlap==0,x['id']
 for xx,yy in points:expected.putpixel((px+xx,py+yy),(0,0,0))
 for yy in range(native.height):
  for xx in range(native.width):
   value=native.getpixel((xx,yy))
   if value!=(255,255,255):assert expected.getpixel((xx+dx,yy+dy))==value
 actual=Image.open(x['image']).convert('RGB');assert expected.size==actual.size and expected.tobytes()==actual.tobytes();assert sha(expected.tobytes())==x['pre_codec_rgb_sha256']
 audit.append({'id':x['id'],'shape_points':len(points),'overlap_pixels':overlap,'reconstructed_rgb_sha256':sha(expected.tobytes())})
assert len(audit)==4536
(r/'noise-pixel-audit.json').write_text(json.dumps({'driver_sha256':sha(Path(__file__).read_bytes()),'pre_jpeg_pairs':len(audit),'all_source_body_nonwhite_pixels_preserved':True,'all_shape_glyph_overlap_counts_zero':True,'all_png_reconstructions_byte_equal':True,'rows':audit},indent=2)+'\n')
print('4536 pre-JPEG pairs independently reconstructed;body ink preserved;overlap0',flush=True)
