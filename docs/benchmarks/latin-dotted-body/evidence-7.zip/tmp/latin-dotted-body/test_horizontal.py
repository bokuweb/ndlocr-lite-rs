from pathlib import Path
import json,unittest
class Horizontal(unittest.TestCase):
 def test_every_auto_rotated_original_gets_horizontal_case(self):
  r=Path('tmp/latin-dotted-body');m=json.loads((r/'fresh/evaluation-manifest.json').read_text());h=json.loads((r/'horizontal/evaluation-manifest.json').read_text());expected={x['id']for x in m['inputs']if x['rotated_for_auto']};self.assertEqual(len(expected),334);self.assertEqual({x['id']for x in h['inputs']},expected)
  for x in h['inputs']:self.assertEqual(x['orientation'],'horizontal');self.assertEqual(x['forward_width'],x['width']);self.assertEqual(x['forward_height'],x['height']);self.assertEqual(x['effective_rgb_sha256'],x['rgb_sha256'])
if __name__=='__main__':unittest.main()
