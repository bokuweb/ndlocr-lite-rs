# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `4598`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 4598 | 0 | 0.0207 | 0.0413 | +0.0000 | +0.0000 |
| candidate | 4598 | 0 | 0.0207 | 0.0413 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

