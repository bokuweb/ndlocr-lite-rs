# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `2871`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| candidate | 2871 | 0 | 0.6031 | 0.8317 | -0.0002 | -0.0007 |
| baseline | 2871 | 0 | 0.6032 | 0.8324 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

