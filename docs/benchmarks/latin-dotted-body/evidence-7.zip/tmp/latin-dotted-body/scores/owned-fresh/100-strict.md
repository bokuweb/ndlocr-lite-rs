# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `7632`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 7632 | 0 | 0.2891 | 0.6956 | +0.0000 | +0.0000 |
| candidate | 7632 | 0 | 0.2891 | 0.6956 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

