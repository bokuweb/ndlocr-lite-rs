# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `10944`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 10944 | 0 | 0.5908 | 0.9233 | +0.0000 | +0.0000 |
| candidate | 10944 | 0 | 0.5908 | 0.9233 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

