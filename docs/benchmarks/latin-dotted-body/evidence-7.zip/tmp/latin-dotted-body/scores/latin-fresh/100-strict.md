# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `19440`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 19440 | 0 | 0.2128 | 0.4260 | +0.0000 | +0.0000 |
| candidate | 19440 | 0 | 0.2128 | 0.4260 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

