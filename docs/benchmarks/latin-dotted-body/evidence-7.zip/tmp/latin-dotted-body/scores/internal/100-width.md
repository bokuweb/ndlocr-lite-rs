# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `5088`
- baseline system: `baseline`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER | ΔCER vs baseline | ΔWER vs baseline |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 5088 | 0 | 0.6714 | 0.8611 | +0.0000 | +0.0000 |
| candidate | 5088 | 0 | 0.6714 | 0.8611 | +0.0000 | +0.0000 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files

