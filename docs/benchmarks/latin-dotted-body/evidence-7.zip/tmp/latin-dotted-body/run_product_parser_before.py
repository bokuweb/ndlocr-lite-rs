from pathlib import Path
import json,hashlib,shutil,subprocess,os,time
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();events=[json.loads(s)for s in(r/'product-build.jsonl').read_text().splitlines()];assert any(x.get('reason')=='build-finished'and x.get('success')for x in events);bins=[x['executable']for x in events if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(bins)==1;b=r/'product-binary';shutil.copy2(bins[0],b)
sources={}
for p in [*Path('src').rglob('*.rs'),*Path('tests').rglob('*.rs'),*Path('examples').rglob('*.rs'),*Path('benches').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),*Path('docs').glob('latin_dotted*.md')]:
 q=r/'product-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sources[str(p)]=sha(p)
inputs=json.loads((r/'product-rgb-inventory.json').read_text());prepare=json.loads((r/'product-prepare.json').read_text());assert sha(r/'product-manifest.json')==prepare['manifest_sha256'];argv=[str(b.resolve()),'infer::visible_repetitions::dotted_body::tests::product_matches_all_frozen_outputs','--exact','--ignored','--nocapture'];env={'NDLOCR_DOTTED_PRODUCT_MANIFEST':str(r/'product-manifest.json')};meta={'argv':argv,'env':env,'source_sha256':sources,'binary_sha256':sha(b),'prepare':prepare,'driver_sha256':sha(__file__),'new_nn_forwards':0};(r/'product-freeze.json').write_text(json.dumps(meta,indent=2)+'\n');start=time.monotonic()
with(r/'product.stdout').open('wb')as out,(r/'product.stderr').open('wb')as err:d=subprocess.run(argv,env=os.environ|env,stdout=out,stderr=err)
meta['exit_code']=d.returncode;meta['seconds']=time.monotonic()-start
for p,h in sources.items():assert sha(p)==h,p
for p,x in inputs.items():assert sha(p)==x['rgb_sha256'],p
assert sha(r/'product-manifest.json')==prepare['manifest_sha256'];meta['source_and_all_inputs_unchanged_after']=True;(r/'product-command.json').write_text(json.dumps(meta,indent=2)+'\n');assert d.returncode==0;print('282465 actual product outputs equal fixed candidate, all sources and RGB unchanged')
