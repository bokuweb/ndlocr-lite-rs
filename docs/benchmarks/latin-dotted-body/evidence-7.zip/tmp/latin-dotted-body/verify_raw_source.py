from pathlib import Path
import json,hashlib,re
r=Path('tmp/latin-dotted-body');p=Path('tmp/punct-proportional/parent-raw-capture.json');prior=json.loads(p.read_text());root=Path('tmp/punct-proportional/whole-roi-source');sha=lambda b:hashlib.sha256(b).hexdigest()
for name,h in prior['source_sha256'].items():assert sha((root/name).read_bytes())==h
for name,h in prior['models'].items():assert sha(Path(name).read_bytes())==h
assert sha(Path('tmp/punct-width/new/export-binary').read_bytes())==prior['binary_sha256']
files=['Cargo.toml','Cargo.lock','src/infer/preprocess.rs','src/infer/ort_init.rs','src/infer/parseq/candidates.rs','src/io.rs']
for name in files:assert(root/name).read_bytes()==Path(name).read_bytes(),name
old=(root/'src/infer/parseq.rs').read_text();now=Path('src/infer/parseq.rs').read_text();a=old[:old.index('\n/// 同じモデルの余白確認後に')];b=now[:now.index('\n/// 画像を持つ認識APIでは')];assert a==b
cache_old=(root/'src/infer/cached.rs').read_text();cache_now=Path('src/infer/cached.rs').read_text();assert cache_old.split('pub fn recognize_rgb_u8(')[0]==cache_now.split('pub fn recognize_rgb_u8(')[0]
def function(source,name):
 m=re.search(r'\bfn '+re.escape(name)+r'(?:<[^>]*>)?\(',source);assert m,name;start=m.start();i=source.index('{',m.end());depth=0
 for j in range(i,len(source)):
  if source[j]=='{':depth+=1
  if source[j]=='}':
   depth-=1
   if depth==0:return source[start:j+1]
 raise ValueError(name)
functions={}
for name in ['recognize_rgb_u8_unprocessed_with_orientation','recognize_rgb_u8_candidates_with_orientation','run_batch_on_session_with_orientation','run_batch_on_session_with_decoder','use_direct_batch_preprocess']:
 a=function(cache_old,name);b=function(cache_now,name);assert a==b,name;functions[name]=sha(a.encode())
rec={'raw_binary_sha256':prior['binary_sha256'],'prior_capture_sha256':sha(p.read_bytes()),'exact_equal_dependency_files':{name:sha(Path(name).read_bytes())for name in files},'all_preprocess_decode_charset_source_equal':True,'parseq_common_prefix_sha256':sha(old[:old.index('\n/// 同じモデルの余白確認後に')].encode()),'session_constructor_prefix_equal':True,'session_raw_candidate_run_functions_equal':functions,'processed_context_removal_is_not_called_by_export_candidate_path':True,'models_sha256':prior['models'],'driver_sha256':sha(Path(__file__).read_bytes()),'new_nn_forwards':0};(r/'raw-source-audit.json').write_text(json.dumps(rec,indent=2)+'\n');print('Frozen exporter raw candidate path, preprocessing, decoder, constructor, deps/model assets verified')
