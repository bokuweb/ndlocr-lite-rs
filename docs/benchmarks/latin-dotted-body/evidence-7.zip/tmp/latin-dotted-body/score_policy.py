from pathlib import Path
import json,hashlib,subprocess,sys,csv,tempfile,collections,time
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=Path('tmp/latin-pair-policy/product-manifest.json');cases=json.loads(source.read_text())['cases'];result=json.loads((r/'policy-results.json').read_text());assert result['cases_checked']==len(cases)==223143
assert json.loads((r/'policy-command.json').read_text())['exit_code']==0
changed={}
for c in result['changes']:
 i=c['index'];assert i not in changed;changed[i]=c;x=cases[i]
 for field in ['corpus','model','id','raw','truth','rgb_sha256']:assert c[field]==x[field]
 assert c['before']==x['expected_after'] and c['after']!=c['before']
groups=collections.defaultdict(list)
for i,x in enumerate(cases):groups[(x['corpus'],x['model'])].append((i,x))
fresh={x['id']:x for x in json.loads(Path('tmp/latin-pair-policy/fresh/evaluation-manifest.json').read_text())['inputs']};summary=[];regressions=[];commands=[];matched=0;started=time.monotonic();out=r/'scores';out.mkdir(exist_ok=True)
freeze={'driver_sha256':sha(__file__),'scorer_sha256':sha('tools/eval_ocr_metrics.py'),'source_sha256':sha(source),'results_sha256':sha(r/'policy-results.json'),'policy_lock_sha256':sha(r/'policy-lock.json'),'groups':len(groups),'pairs':len(cases),'new_nn_forwards':0};(r/'score-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for (corpus,model),rows in sorted(groups.items()):
 byname={x['id']+'.txt':(i,x) for i,x in rows};assert len(byname)==len(rows);target=out/corpus;target.mkdir(exist_ok=True);digest=hashlib.sha256()
 with tempfile.TemporaryDirectory(prefix='score-',dir=r) as temp:
  temp=Path(temp)
  for phase in ['truth','baseline','candidate']:(temp/phase).mkdir()
  for file,(i,x) in sorted(byname.items()):
   assert Path(file).name==file
   texts={'truth':x['truth'],'baseline':x['expected_after'],'candidate':changed[i]['after'] if i in changed else x['expected_after']}
   for phase,text in texts.items():
    b=text.encode();(temp/phase/file).write_bytes(b);key=(phase+'/'+file).encode();digest.update(len(key).to_bytes(8,'little'));digest.update(key);digest.update(len(b).to_bytes(8,'little'));digest.update(b)
  for norm in ['none','width','strict']:
   table=target/(model+'-'+norm+'.csv');argv=[sys.executable,'tools/eval_ocr_metrics.py','--truth-dir',str(temp/'truth'),'--system','baseline='+str(temp/'baseline'),'--system','candidate='+str(temp/'candidate'),'--normalize',norm,'--require-all','--baseline-system','baseline','--output-csv',str(table),'--output-md',str(table.with_suffix('.md'))]
   with table.with_suffix('.stdout').open('wb') as stdout,table.with_suffix('.stderr').open('wb') as stderr:done=subprocess.run(argv,stdout=stdout,stderr=stderr)
   commands.append({'argv':argv,'exit_code':done.returncode,'written_input_digest':digest.hexdigest(),'input_files':len(rows)*3});assert done.returncode==0
   csvrows=list(csv.DictReader(table.open()));a={x['file']:x for x in csvrows if x['system']=='baseline'};b={x['file']:x for x in csvrows if x['system']=='candidate'};assert set(a)==set(b)==set(byname)
   subsets={'all':list(a)}
   if corpus in ['latin-fresh','latin-horizontal']:
    for kind in ['text','noise']:subsets[kind]=[f for f,(_,x) in byname.items() if fresh[x['id']]['kind']==kind]
   for subset,files in subsets.items():
    s={'corpus':corpus,'model':model,'normalization':norm,'subset':subset,'pairs':len(files),'changes':sum(byname[f][0] in changed for f in files)}
    for metric in ['char','word']:
     before=[int(a[f][metric+'_errors']) for f in files];after=[int(b[f][metric+'_errors']) for f in files]
     s[metric]={'before':sum(before),'after':sum(after),'improved':sum(y<x for x,y in zip(before,after)),'regressed':sum(y>x for x,y in zip(before,after)),'equal':sum(y==x for x,y in zip(before,after)),'exact_recovered':sum(x>0 and y==0 for x,y in zip(before,after)),'exact_lost':sum(x==0 and y>0 for x,y in zip(before,after))}
    summary.append(s)
   for file,(i,x) in byname.items():
    for metric in ['char','word']:
     before,after=int(a[file][metric+'_errors']),int(b[file][metric+'_errors'])
     if after>before:regressions.append({'index':i,'corpus':corpus,'model':model,'id':x['id'],'normalization':norm,'metric':metric,'before_errors':before,'after_errors':after,'raw':x['raw'],'truth':x['truth'],'before':x['expected_after'],'after':changed[i]['after']})
 matched+=len(rows)
 print(corpus,model,len(rows),'pairs scored; elapsed',round(time.monotonic()-started,1),flush=True)
assert matched==len(cases);assert sha(source)==freeze['source_sha256'] and sha('tools/eval_ocr_metrics.py')==freeze['scorer_sha256']
audit={'freeze':freeze,'matched_pairs':matched,'changed_pairs':len(changed),'changed_unique_rgb':len({x['rgb_sha256']for x in changed.values()}),'summary':summary,'regressions':regressions,'commands':commands,'seconds':time.monotonic()-started,'new_nn_forwards':0,'accepted_on_saved_gate':not regressions};(r/'score-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print('changes',len(changed),'regression metric rows',len(regressions),flush=True)
if regressions:sys.exit('Rejected fixed proposal; preserve all evidence, do not tune on outcomes')
