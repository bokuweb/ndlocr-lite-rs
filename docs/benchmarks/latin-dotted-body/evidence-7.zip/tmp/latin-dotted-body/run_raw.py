from pathlib import Path
from PIL import Image
import json,hashlib,subprocess,concurrent.futures,os,shutil,time,datetime
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior_path=Path('tmp/punct-proportional/parent-raw-capture.json');prior=json.loads(prior_path.read_text());source=Path('tmp/punct-proportional/whole-roi-source');binary_path=Path('tmp/punct-width/new/export-binary');assert sha(binary_path)==prior['binary_sha256']
for p,h in prior['source_sha256'].items():assert sha(source/p)==h
for p,h in prior['models'].items():assert sha(p)==h
proofs=['raw-source-audit.json','fresh-generation-postcheck.json','fresh-pixel-audit.json','native-audit.json','noise-pixel-audit.json','visual-audit.json','tensor-command.json','geometry-command.json','geometry-summary.json','fixed-api-noise-selection.json','score-audit.json','reader-api-equivalence.json','clippy-audit.json']
assert json.loads((r/'score-audit.json').read_text())['accepted_on_saved_gate']
assert json.loads((r/'tensor-command.json').read_text())['exit_code']==0
assert json.loads((r/'geometry-summary.json').read_text())['unique_text_rgb_with_supported_correct_raw']>0
assert json.loads((r/'visual-audit.json').read_text())['checked_count']==108
assert json.loads((r/'native-audit.json').read_text())['independent_native_qa_redraws']==1854
assert json.loads((r/'noise-pixel-audit.json').read_text())['pre_jpeg_pairs']==4536
assert json.loads((r/'fixed-api-noise-selection.json').read_text())['new_nn_before_selection']==0
assert not json.loads((r/'clippy-audit.json').read_text())['new_warnings']
shutil.copytree(source,r/'raw-export-source');manifests={};inventory={}
for phase,count in [('fresh',19440),('horizontal',334)]:
 f=r/phase;m=json.loads((f/'evaluation-manifest.json').read_text());assert len(m['inputs'])==count;manifests[phase]=m
 assert sha(f/'atlas.png')==m['atlas_sha256']and sha(f/'lines.json')==m['lines_sha256'];shutil.copy2(binary_path,f/'export-binary');(f/'export-binary').chmod(0o755);assert sha(f/'export-binary')==prior['binary_sha256']
 for x in m['inputs']:
  for k in ['rgb','effective_rgb','truth']:
   assert sha(x[k])==x[k+'_sha256'];inventory[x[k]]=x[k+'_sha256']
h=manifests['horizontal'];a={x['id']:x for x in manifests['fresh']['inputs']if x['rotated_for_auto']};assert set(a)=={x['id']for x in h['inputs']};atlas=Image.open(r/'horizontal/atlas.png').convert('RGB')
for x in h['inputs']:
 old=a[x['id']];assert all(x[k]==old[k]for k in ['width','height','rgb_sha256','truth_sha256']);assert x['orientation']=='horizontal'and x['effective_rgb_sha256']==x['rgb_sha256'];assert atlas.crop(x['bounds']).tobytes()==Path(x['rgb']).read_bytes()
models={'30':'parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx','50':'parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx','100':'parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx'}
record={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_binary_sha256':prior['binary_sha256'],'raw_source_capture':prior,'raw_source_capture_sha256':sha(prior_path),'source_equivalence_audit_sha256':sha(r/'raw-source-audit.json'),'driver_sha256':sha(__file__),'proofs_sha256':{p:sha(r/p)for p in proofs},'spec_sha256':sha('docs/latin_dotted_body_controls.md'),'api_spec_sha256':sha('docs/latin_dotted_body_api_controls.md'),'manifest_sha256':{p:sha(r/p/'evaluation-manifest.json')for p in manifests},'model_charsets_sha256':prior['models'],'expected_fresh_raw_forwards':58320,'expected_original_horizontal_raw_forwards':1002,'expected_total_raw_forwards':59322,'model30_expected_actual_rgb_captures':19774,'new_nn_before_this_run':0,'inputs_sha256':inventory};(r/'raw-freeze.json').write_text(json.dumps(record,indent=2)+'\n');print('All sources/models/19774 inputs and fixed guards frozen; starting 59322 raw forwards',flush=True)
def run(job):
 phase,model=job;f=r/phase;binary=f/'export-binary';out=f/(model+'-export.json');argv=[str(binary.resolve()),'--image',str(f/'atlas.png'),'--model','models/'+models[model],'--charset','models/NDLmoji.yaml','--manifest',str(f/'lines.json'),'--output',str(out),'--top-k','2','--whole-roi']
 if model=='30':argv+=['--chunk-input-dir',str(f/'whole-rgb-capture')]
 meta={'argv':argv,'env':{'NDLOCR_INTRA_THREADS':'1'},'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};cmd=f/(model+'-command.json');cmd.write_text(json.dumps(meta,indent=2)+'\n');start=time.monotonic();p=subprocess.run(argv,capture_output=True,env=os.environ|meta['env']);(f/(model+'.stdout')).write_bytes(p.stdout);(f/(model+'.stderr')).write_bytes(p.stderr);meta['exit_code']=p.returncode;meta['seconds']=time.monotonic()-start;meta['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd.write_text(json.dumps(meta,indent=2)+'\n');assert p.returncode==0,p.stderr
 rows=json.loads(out.read_text());expected={x['id']:x for x in manifests[phase]['inputs']};assert len(rows)==len(expected)and{row['id']for row in rows}==set(expected)
 for row in rows:assert len(row['chunks'])==1 and row['chunks'][0]['x_range']==[0,expected[row['id']]['forward_width']]
 meta['raw_records']=len(rows);meta['output_sha256']=sha(out);cmd.write_text(json.dumps(meta,indent=2)+'\n');print('completed',phase,model,len(rows),'forwards',round(meta['seconds'],2),'seconds',flush=True);return {'phase':phase,'model':model}|meta
jobs=[(phase,model)for phase in ['fresh','horizontal']for model in ['30','50','100']]
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:completed=list(pool.map(run,jobs))
for p,h in inventory.items():assert sha(p)==h
for p,h in prior['models'].items():assert sha(p)==h
for phase in manifests:assert sha(r/phase/'evaluation-manifest.json')==record['manifest_sha256'][phase]and sha(r/phase/'export-binary')==record['raw_binary_sha256']
for p,h in record['proofs_sha256'].items():assert sha(r/p)==h
record['completed']=completed;record['exit_code']=0;record['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['actual_raw_forwards']=sum(x['raw_records']for x in completed);assert record['actual_raw_forwards']==59322;record['all_inputs_models_sources_and_guards_unchanged_after']=True;(r/'raw-command.json').write_text(json.dumps(record,indent=2)+'\n');print('All 59322 raw forwards complete, all frozen input/model/guard hashes unchanged',flush=True)
