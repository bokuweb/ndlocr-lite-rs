def restore(packet, output):
    return None
