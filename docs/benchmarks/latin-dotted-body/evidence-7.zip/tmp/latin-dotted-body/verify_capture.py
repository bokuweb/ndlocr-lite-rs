from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();results=[]
for phase,n in [('fresh',19440),('horizontal',334)]:
 f=r/phase;mp=f/'evaluation-manifest.json';cp=f/'whole-rgb-capture/inputs.json';m=json.loads(mp.read_text());c=json.loads(cp.read_text());assert c['model_input_dimensions']==[256,24]
 byid={x['id']:x for x in m['inputs']};chunks=c['chunks'];assert len(byid)==len(chunks)==n;seen=set();frames={}
 for x in chunks:
  i=x['line_id'];assert i not in seen;seen.add(i);y=byid[i];dims=[y['forward_width'],y['forward_height']];assert x['dimensions']==dims and x['chunk_index']==0 and x['x_range']==[0,dims[0]]
  p=cp.parent/x['image'];im=Image.open(p).convert('RGB');assert list(im.size)==dims and im.tobytes()==Path(y['effective_rgb']).read_bytes();assert sha(y['effective_rgb'])==y['effective_rgb_sha256'];frames[x['image']]=sha(p)
 assert seen==set(byid);results.append({'phase':phase,'captures':n,'manifest_sha256':sha(mp),'capture_index_sha256':sha(cp),'frames_sha256':frames})
(r/'capture-audit.json').write_text(json.dumps({'captures':19774,'all_effective_rgb_equal':True,'driver_sha256':sha(__file__),'phases':results},indent=2)+'\n');print('19774 actual NN RGB frames equal effective RGB, dimensions, IDs and whole ROI')
