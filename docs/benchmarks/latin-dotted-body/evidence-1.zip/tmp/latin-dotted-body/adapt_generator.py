from pathlib import Path
import shutil
r=Path('tmp/latin-dotted-body');s=Path('tmp/latin-pair-policy/prepare_fresh.py').read_text()
s=s.replace('tmp/latin-pair-policy', 'tmp/latin-dotted-body').replace('docs/latin_pair_bridge_controls.md','docs/latin_dotted_body_controls.md')
s=s.replace('from graphics import crop_white, compose_noise','from graphics import crop_white, compose_noise\nfrom controls import BODIES, MODES, SIZES, SHAPES, expected_conditions')
s=s.replace("json.loads((r / 'manifest.json').read_text())['cases']","json.loads(Path('tmp/latin-pair-policy/product-manifest.json').read_text())['cases']")
a=s.index("assert json.loads((r / 'summary.json').read_text())['char_regressions'] == 0");b=s.index('\nrows, records = [], []',a)
s=s[:a]+'''gate = json.loads((r / 'score-audit.json').read_text())
assert gate['accepted_on_saved_gate'] and not gate['regressions'] and gate['matched_pairs'] == 223143
blueprint = expected_conditions()
assert len(blueprint) == 19440
(r / 'fresh-tuples.json').write_text(json.dumps(blueprint, ensure_ascii=False, indent=2) + '\\n')
sources = [Path(__file__), r / 'adapt_generator.py', r / 'controls.py', r / 'test_controls.py', r / 'test_graphics.py',
           r / 'renderer_ft.py', r / 'graphics.py', r / 'render.swift', r / 'render', r / 'capture-controls-spec.md',
           r / 'policy-lock.json', r / 'policy-command.json', r / 'score-audit.json', r / 'fresh-tuples.json',
           Path('tmp/latin-pair-policy/product-manifest.json')]
snapshot = r / 'fresh-generation-source'
snapshot.mkdir()
for path in sources:
    shutil.copy2(path, snapshot / path.name)
(r / 'fresh-generation-lock.json').write_text(json.dumps({
    'source_sha256': {str(p): sha(p.read_bytes()) for p in sources},
    'fonts': fonts, 'expected_conditions': 19440, 'expected_native_draws': 1854,
    'new_nn_before_generation': 0
}, ensure_ascii=False, indent=2) + '\\n')
''' + s[b:]
s=s.replace("bodies = ['KLM', 'XYZ', 'MLK', 'WM', 'VVM', 'qjp']", 'bodies = BODIES')
s=s.replace("shapes = ['none', 'thin', 'bar', 'dot', 'diagonal', 'chevron', 'left_curve', 'fork_inner', 'fork_outer']",'shapes = SHAPES')
s=s.replace("[('freetype', None), ('coretext', 0), ('coretext', 1)]",'MODES').replace('for size in [24, 40]:','for size in SIZES:').replace("unspaced != 'WM'","unspaced != 'Apji'").replace("prefix = f'r_{engine}","prefix = f'd_{engine}")
s=s.replace('seen_before_162915','seen_before_223143')
s=s.replace('    return cropped', "    if len(records) % 100 == 0:\n        print('native draws', len(records), 'conditions', len(rows), flush=True)\n    return cropped")
s=s.replace('        rows.append(row)', "        rows.append(row)\n        if len(rows) % 1000 == 0:\n            print('saved conditions', len(rows), flush=True)")
a=s.index('assert len(rows) == 19440 and len(records) == 1854');s=s[:a]+'''assert len(rows) == 19440 and len(records) == 1854
actual = {row['id']: row for row in rows}
assert len(actual) == len(blueprint)
for expected in blueprint:
    row = actual[expected['id']]
    for field, value in expected.items():
        if field == 'truth':
            assert Path(row['truth']).read_bytes() == value.encode()
        else:
            assert row[field] == value, (expected['id'], field, row.get(field), value)
''' + s[a+len('assert len(rows) == 19440 and len(records) == 1854'):]
(r/'prepare_fresh.py').write_text(s);shutil.copy2('tmp/latin-pair-policy/renderer_ft.py',r/'renderer_ft.py')
