import hashlib,itertools
from controls import MODES,FONTS,SIZES,SHAPES

def select_noise_api(rows):
    ids=set();groups={};fields=['engine','palt','font','size','shape','format']
    for row in rows:
        if row['id'] in ids:
            raise ValueError('duplicate condition ID')
        ids.add(row['id'])
        if row['kind'] != 'noise':
            continue
        key=tuple(row[f] for f in fields)
        groups.setdefault(key,[]).append(row)
    expected={(e,p,f,s,shape,fmt) for (e,p),f,s,shape,fmt in itertools.product(MODES,FONTS,SIZES,SHAPES,['png','jpeg75'])}
    if set(groups)!=expected:
        raise ValueError('missing or extra noise strata')
    output=[]
    for key in sorted(groups,key=lambda k:(k[0],str(k[1]),*k[2:])):
        row=min(groups[key],key=lambda r:(hashlib.sha256(r['id'].encode()).hexdigest(),r['id']))
        digest=hashlib.sha256(row['id'].encode()).hexdigest()
        item=dict(id=row['id'],model=['30','50','100'][int(digest[:2],16)%3],selection_sha256=digest,
                  rgb_sha256=row['rgb_sha256'],truth_sha256=row['truth_sha256'],stratum=list(key))
        for orientation in (['auto','horizontal'] if row['rotated_for_auto'] else ['auto']):
            output.append(item|{'orientation':orientation})
    return output
