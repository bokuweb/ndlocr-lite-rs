from pathlib import Path
import json,hashlib,collections
r=Path('tmp/latin-dotted-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=json.loads((r/'score-audit.json').read_text());assert old['accepted_on_saved_gate']and not old['regressions'];summaries=[x|{'phase':'saved'}for x in old['summary']];audit_files={str(r/'score-audit.json'):sha(r/'score-audit.json')};formal=list((r/'scores').rglob('*.csv'))+list((r/'scores').rglob('*.md'))
for p in sorted((r/'comparison').glob('*/score-audit.json')):
 d=json.loads(p.read_text());assert d['accepted_on_this_job']and not d['regressions'];summaries.extend(d['summary']);audit_files[str(p)]=sha(p);formal+=list((p.parent/'scores').glob('*.csv'))+list((p.parent/'scores').glob('*.md'))
assert len(formal)==306
all_rows=[x for x in summaries if x.get('subset')=='all' or x.get('group')=='all'];totals=[]
for norm in ['none','width','strict']:
 rows=[x for x in all_rows if x['normalization']==norm];assert sum(x['pairs']for x in rows)==282465
 t={'normalization':norm,'pairs':282465,'changes':102}
 for metric in ['char','word']:
  t[metric]={k:sum(x[metric][k]for x in rows)for k in rows[0][metric]}
  assert t[metric]['regressed']==t[metric]['exact_lost']==0
 totals.append(t)
cases=json.loads((r/'product-manifest.json').read_text())['cases'];oldids={(x['corpus'],x['model'],x['id'])for x in json.loads((r/'policy-results.json').read_text())['changes']};changed=[x for x in cases if (x['corpus'],x['model'],x['id'])in oldids or x['corpus'].startswith('dotted-')and x['selected']];assert len(changed)==102
unique={x['rgb_sha256']for x in changed};fresh={x['rgb_sha256']for x in changed if x['corpus']=='dotted-fresh'};h={x['rgb_sha256']for x in changed if x['corpus']=='dotted-horizontal'};new=fresh|h
files={str(p):sha(p)for p in formal};result={'totals':totals,'summary':summaries,'regressions':[],'accepted_all_groups':True,'changed_rgb':len(unique),'changed_unseen_rgb':len(new),'changed_fresh_auto_rgb':len(fresh),'changed_original_horizontal_rgb':len(h),'formal_csv_files':153,'formal_md_files':153,'formal_files_sha256':files,'source_audits_sha256':audit_files,'driver_sha256':sha(__file__),'new_raw_forwards':59322,'product_replay_pairs':282465,'unknown_document_or_font_holdout':False};(r/'aggregate-score-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['summary','formal_files_sha256','source_audits_sha256']},ensure_ascii=False,indent=2))
