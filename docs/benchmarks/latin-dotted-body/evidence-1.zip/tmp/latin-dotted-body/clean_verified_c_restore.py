from pathlib import Path
import json,hashlib,shutil,time
r=Path('tmp/latin-dotted-body');c=Path('tmp/latin-pair-policy');root=c/'final-restored';packet=Path('docs/benchmarks/latin-pair-bridge');sha=lambda b:hashlib.sha256(b).hexdigest();outer=json.loads((packet/'verification.json').read_text());restored=json.loads((root/'verification.json').read_text());assert root.resolve()==Path('/Users/bokuweb/ghq/github.com/bokuweb/ndlocr-lite-rs/tmp/latin-pair-policy/final-restored')
for k,v in restored.items():assert outer[k]==v
assert restored['product_pairs']==223143 and restored['table_files_byte_equal']==1188 and restored['audits_recomputed_equal']==3
for n,h in outer['archive_sha256'].items():assert sha((packet/(n+'.zip')).read_bytes())==h
for n,h in outer['execution_files_sha256'].items():assert sha((packet/'execution'/n).read_bytes())==h
for p in ['reproduce-command.json','restored-product-command.json','restored-tensor-command.json']:assert json.loads((c/p).read_text())['exit_code']==0
inputs=json.loads((r/'policy-rgb-inputs.json').read_text());assert sha((r/'policy-rgb-inputs.json').read_bytes())==json.loads((r/'policy-command.json').read_text())['rgb_inventory_sha256']
for p,x in inputs.items():assert not Path(p).resolve().is_relative_to(root.resolve()) and sha(Path(p).read_bytes())==x['rgb_sha256']
keep=r/'c-restoration-cleanup-proof';keep.mkdir();level=root;receipts=[]
while (level/'verification.json').is_file():
 data=(level/'verification.json').read_bytes();p=keep/('level'+str(len(receipts))+'-verification.json');p.write_bytes(data);receipts.append({'original':str(level/'verification.json'),'preserved':str(p),'sha256':sha(data)});level=level/'parent'
paths=[c/'restored-rust-binary',c/'fresh/export-binary',c/'horizontal/export-binary',c/'tensor-binary',r/'audit-binary',r/'policy-binary']+sorted(p for p in Path('models').iterdir() if p.is_file())
assets={str(p):sha(p.read_bytes()) for p in paths};assert assets[str(c/'restored-rust-binary')]==json.loads((c/'restored-rust-build-command.json').read_text())['binary_sha256'];assert assets[str(r/'policy-binary')]==json.loads((r/'policy-command.json').read_text())['binary_sha256']
for p in paths:assert not p.resolve().is_relative_to(root.resolve())
record={'root':str(root),'reason':'verified generated restoration copy; independent reproduction and compiled replay already succeeded; new control space','archive_sha256':outer['archive_sha256'],'all_execution_hashes_verified':True,'preserved_verifications':receipts,'original_input_paths_verified':len(inputs),'original_input_inventory_sha256':sha((r/'policy-rgb-inputs.json').read_bytes()),'preserved_assets_sha256':assets,'driver_sha256':sha(Path(__file__).read_bytes()),'free_bytes_before':shutil.disk_usage('.').free,'only_generated_copy':True};(r/'c-restoration-cleanup-start.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic();shutil.rmtree(root);record['seconds']=time.monotonic()-start;assert not root.exists()
for n,h in outer['archive_sha256'].items():assert sha((packet/(n+'.zip')).read_bytes())==h
for p,h in assets.items():assert sha(Path(p).read_bytes())==h
for p,x in inputs.items():assert sha(Path(p).read_bytes())==x['rgb_sha256']
record['all_archives_assets_and_original_inputs_unchanged_after']=True;record['free_bytes_after']=shutil.disk_usage('.').free;record['removed_root_exists_after']=root.exists();(r/'c-restoration-cleanup.json').write_text(json.dumps(record,indent=2)+'\n');print('removed verified generated restoration copy; all',len(inputs),'original inputs and all frozen assets/archives unchanged; free GiB',round(record['free_bytes_after']/2**30,2),flush=True)
