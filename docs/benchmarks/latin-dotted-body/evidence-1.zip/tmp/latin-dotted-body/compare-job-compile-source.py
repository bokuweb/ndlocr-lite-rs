from pathlib import Path
import json,hashlib,subprocess,os,sys,shutil,time
from assemble_raw import assemble
r=Path('tmp/latin-dotted-body');phase,model=sys.argv[1:];assert phase in ['fresh','horizontal']and model in ['30','50','100'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=r/phase;command=json.loads((f/(model+'-command.json')).read_text());assert command['exit_code']==0
before_root=subprocess.check_output(['git','show','f31a87d:src/infer/visible_repetitions.rs']);current=Path('src/infer/visible_repetitions.rs').read_bytes();extra=b'#[cfg(test)]\nmod dotted_body;\n';assert current.count(extra)==1 and current.replace(extra,b'')==before_root
changed=subprocess.check_output(['git','diff','--name-only','f31a87d','--','*.rs'],text=True).splitlines();assert changed==['src/infer/visible_repetitions.rs'];source=Path('src/infer/visible_repetitions/dotted_body/policy.rs');prefix=source.read_text().split('\n#[cfg(test)]')[0].rstrip()+'\n';assert hashlib.sha256(prefix.encode()).hexdigest()==json.loads((r/'policy-lock.json').read_text())['policy_prefix_sha256']
manifest=json.loads((f/'evaluation-manifest.json').read_text());raw=json.loads((f/(model+'-export.json')).read_text());cases=assemble(manifest['inputs'],raw,model,phase);assert len(cases)==(19440 if phase=='fresh'else334);out=r/'comparison'/(phase+'-'+model);out.mkdir(parents=True);(out/'existing-manifest.json').write_text(json.dumps({'cases':cases,'expected_cases':len(cases)},ensure_ascii=False,indent=2)+'\n');binary=r/'geometry-binary';record={'phase':phase,'model':model,'pairs':len(cases),'driver_sha256':sha(__file__),'assembly_sha256':sha(r/'assemble_raw.py'),'means_sha256':sha(r/'means.py'),'binary_sha256':sha(binary),'base_source_record_sha256':sha(r/'policy-command.json'),'added_test_source_sha256':sha(r/'geometry-source'/source),'input_manifest_sha256':sha(f/'evaluation-manifest.json'),'raw_output_sha256':sha(f/(model+'-export.json')),'cases_sha256':sha(out/'existing-manifest.json'),'production_baseline_source_equal_f31_except_test_only_module':True,'policy_prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest(),'new_nn_forwards':0};(out/'freeze.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,test,env):
 argv=[str(binary.resolve()),test,'--exact','--ignored','--nocapture'];meta={'argv':argv,'env':env};(out/(name+'-command.json')).write_text(json.dumps(meta,indent=2)+'\n');start=time.monotonic()
 with(out/(name+'.stdout')).open('wb')as a,(out/(name+'.stderr')).open('wb')as b:done=subprocess.run(argv,env=os.environ|env,stdout=a,stderr=b)
 meta['exit_code']=done.returncode;meta['seconds']=time.monotonic()-start;(out/(name+'-command.json')).write_text(json.dumps(meta,indent=2)+'\n');assert done.returncode==0,name
run('baseline','infer::visible_repetitions::single_pixel_bridge::tests::record_existing_bridge_policy',{'NDLOCR_BRIDGE_ROOT':str(out.resolve())})
records=json.loads((out/'existing-replay/records.json').read_text());assert len(records)==len(cases);byid={x['id']:x for x in records};assert len(byid)==len(cases)
for x in cases:
 y=byid[x['id']];assert all(y[k]==x[k]for k in ['corpus','model','raw','id']);x['expected_after']=y['baseline']
(out/'with-baseline.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');(out/'policy-input.json').write_text(json.dumps({'cases_source':str(out/'with-baseline.json'),'expected_cases':len(cases)},indent=2)+'\n')
run('candidate','infer::visible_repetitions::dotted_body::policy::tests::record_fixed_policy_on_saved_raw',{'NDLOCR_DOTTED_POLICY_ROOT':str(out.resolve())})
result=json.loads((out/'policy-results.json').read_text());assert result['cases_checked']==len(cases);updates={x['index']:x for x in result['changes']};assert len(updates)==len(result['changes'])
for index,c in updates.items():
 x=cases[index];assert all(c[k]==x[k]for k in ['corpus','model','id','raw','truth','rgb_sha256']);assert c['before']==x['expected_after']
outputs=[]
for i,x in enumerate(cases):outputs.append(x|{'before':x['expected_after'],'after':updates[i]['after']if i in updates else x['expected_after'],'selected':i in updates})
(out/'outputs.json').write_text(json.dumps({'cases':outputs},ensure_ascii=False,indent=2)+'\n')
for p,h in [(f/'evaluation-manifest.json',record['input_manifest_sha256']),(f/(model+'-export.json'),record['raw_output_sha256']),(binary,record['binary_sha256'])]:assert sha(p)==h
for x in cases:assert sha(x['rgb'])==x['rgb_sha256']
record['exit_code']=0;record['changes']=len(updates);record['all_inputs_binary_and_raw_unchanged_after']=True;record['baseline_records_sha256']=sha(out/'existing-replay/records.json');record['candidate_records_sha256']=sha(out/'policy-results.json');record['outputs_sha256']=sha(out/'outputs.json');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');print(phase,model,'pairs',len(cases),'changes',len(updates),'actual baseline and fixed candidate, no NN',flush=True)
