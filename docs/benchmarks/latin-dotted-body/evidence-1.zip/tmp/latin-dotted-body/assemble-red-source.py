def assemble(inputs, outputs, model, phase):
    return []
