from pathlib import Path
import hashlib,struct
from means import emitted_means

def assemble(inputs, outputs, model, phase):
    if model not in ['30','50','100'] or phase not in ['fresh','horizontal']:
        raise ValueError('invalid model or phase')
    def indexed(rows):
        result={}
        for x in rows:
            if x['id'] in result:raise ValueError('duplicate ID')
            result[x['id']]=x
        return result
    source,predicted=indexed(inputs),indexed(outputs)
    if set(source)!=set(predicted):raise ValueError('missing or extra raw IDs')
    cases=[]
    for x in inputs:
        row=predicted[x['id']]
        if row['bounds']!=x['bounds'] or len(row['chunks'])!=1:
            raise ValueError('wrong source bounds or chunk count')
        chunk=row['chunks'][0]
        if chunk['x_range']!=[0,x['forward_width']]or chunk['text']!=row['text']or chunk['inserted_space_before']:
            raise ValueError('not the same whole-ROI text')
        rgb=Path(x['rgb']).read_bytes();truth=Path(x['truth']).read_bytes()
        if x['width']<=0 or x['height']<=0 or len(rgb)!=x['width']*x['height']*3 or hashlib.sha256(rgb).hexdigest()!=x['rgb_sha256']or hashlib.sha256(truth).hexdigest()!=x['truth_sha256']:
            raise ValueError('modified source RGB or truth')
        try:mean=emitted_means(row)[0]
        except (AssertionError,KeyError,IndexError,TypeError)as exc:raise ValueError('invalid emitted probabilities or UTF-8 ranges')from exc
        cases.append({'corpus':'dotted-'+phase,'model':model,'id':x['id'],'raw':row['text'],'truth':truth.decode('utf-8'),'rgb':x['rgb'],'rgb_sha256':x['rgb_sha256'],'width':x['width'],'height':x['height'],'orientation':'auto'if phase=='fresh'else'horizontal','expected_baseline':None,'raw_mean_confidence':mean,'raw_mean_bits':struct.unpack('<I',struct.pack('<f',mean))[0]})
    return cases
