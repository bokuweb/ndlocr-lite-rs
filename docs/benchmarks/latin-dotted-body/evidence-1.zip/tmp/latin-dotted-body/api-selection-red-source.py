def select_noise_api(rows):
    return []
