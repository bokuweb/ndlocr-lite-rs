# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `24`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 24 | 0 | 0.2361 | 0.6667 |
| candidate | 24 | 0 | 0.2361 | 0.6667 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
