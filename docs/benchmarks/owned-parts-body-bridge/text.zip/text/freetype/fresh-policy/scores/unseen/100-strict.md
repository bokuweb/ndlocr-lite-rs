# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `7610`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 7610 | 0 | 0.2894 | 0.6959 |
| baseline | 7610 | 0 | 0.2898 | 0.6970 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
