# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `7610`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 7610 | 0 | 0.5824 | 0.9160 |
| baseline | 7610 | 0 | 0.5827 | 0.9165 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
