# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `22`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 22 | 0 | 0.2059 | 0.5000 |
| baseline | 22 | 0 | 0.2647 | 0.6667 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
