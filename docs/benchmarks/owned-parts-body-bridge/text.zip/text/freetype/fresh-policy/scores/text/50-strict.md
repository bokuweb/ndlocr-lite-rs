# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `6480`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 6480 | 0 | 0.3181 | 0.7586 |
| baseline | 6480 | 0 | 0.3188 | 0.7605 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
