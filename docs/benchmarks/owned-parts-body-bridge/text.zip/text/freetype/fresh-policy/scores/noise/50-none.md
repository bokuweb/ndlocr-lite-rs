# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1152`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 1152 | 0 | 0.3637 | 0.8292 |
| candidate | 1152 | 0 | 0.3637 | 0.8292 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
