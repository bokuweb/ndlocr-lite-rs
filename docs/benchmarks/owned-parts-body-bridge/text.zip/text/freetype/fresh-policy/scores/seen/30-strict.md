# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `22`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 22 | 0 | 0.1935 | 0.5455 |
| baseline | 22 | 0 | 0.2419 | 0.6818 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
