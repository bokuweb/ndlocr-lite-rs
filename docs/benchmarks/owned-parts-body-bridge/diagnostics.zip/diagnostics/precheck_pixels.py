from pathlib import Path
import importlib.util,json,hashlib
r=Path('tmp/owned-parts-bridge');root=r/'pixel-precheck';root.mkdir();packet=Path('docs/benchmarks/owned-parts-body-bridge')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=load('detached_restore',Path('docs/benchmarks/detached-body-components/reproduce.py'));check=load('owned_media',r/'reproduce-draft.py');names=['images','pixels','geometry-images','geometry-pixels','screens','inputs'];hashes=helper.restore(packet,root,names);prior=json.loads(Path('tmp/internal-detached/product-manifest.json').read_text())['cases'];result=check.verify_pixels(root,prior);expected={'images':18626,'actual_captures':7656,'pre_jpeg_noise_pairs':1728,'native_records':3374,'geometry_only_images':10970};assert result==expected;(r/'pixel-precheck-verification.json').write_text(json.dumps(result|{'archive_sha256':hashes,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps(result,indent=2))
