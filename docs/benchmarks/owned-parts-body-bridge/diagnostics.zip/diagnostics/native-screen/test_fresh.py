from pathlib import Path
from PIL import Image
import json,hashlib,itertools,unittest
class Screen(unittest.TestCase):
 def test_all_predeclared_words_and_native_pixels(self):
  r=Path('tmp/owned-parts-bridge/native-screen/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());rows=m['inputs'];self.assertEqual(len(rows),16)
  self.assertEqual({(x['word'],x['palt'])for x in rows},set(itertools.product(['情本','本情','情木','木情','情車','車情','情生','生情'],[0,1])))
  for x in rows:
   self.assertEqual(Path(x['truth']).read_text(),x['word']+'」')
   for k in ['rgb','image','truth','original']:self.assertEqual(hashlib.sha256(Path(x[k]).read_bytes()).hexdigest(),x[k+'_sha256'])
   self.assertEqual(Image.open(x['image']).convert('RGB').tobytes(),Path(x['rgb']).read_bytes())
if __name__=='__main__':unittest.main()
