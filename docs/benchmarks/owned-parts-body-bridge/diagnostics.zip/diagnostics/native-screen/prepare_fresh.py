from pathlib import Path
from PIL import Image,ImageChops
import hashlib,json,subprocess
r=Path('tmp/owned-parts-bridge/native-screen');f=r/'fresh';f.mkdir();font=next(x for x in json.loads(Path('tmp/owned-parts-bridge/fresh/evaluation-manifest.json').read_text())['fonts']if x['id']=='mincho');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(font['path'])==font['sha256'];renderer=Path('tmp/owned-parts-bridge/render');words=['情本','本情','情木','木情','情車','車情','情生','生情'];rows=[];traces=[]
for idx,word in enumerate(words):
 for palt in [0,1]:
  id=f'screen_w{idx}_p{palt}';text=word+'」';original=f/(id+'-native.png');argv=[str(renderer),font['path'],'20',str(palt),text,str(original)];p=subprocess.run(argv,check=True,capture_output=True);trace=json.loads(p.stdout);assert Path(trace['font_file']).samefile(font['path'])
  for run in trace['runs']:assert Path(run['font_file']).samefile(font['path'])and 0 not in run['glyphs']
  assert sorted(i for run in trace['runs']for i in run['string_indices'])==list(range(len(text)))
  tp=f/(id+'-native.json');tp.write_bytes(p.stdout+b'\n');traces.append({'argv':argv,'exit_code':0,'trace_sha256':sha(tp),'png_sha256':sha(original)})
  full=Image.open(original).convert('RGB');box=ImageChops.difference(full,Image.new('RGB',full.size,'white')).getbbox();im=full.crop((box[0]-2,box[1]-2,box[2]+2,box[3]+2));image=f/(id+'.png');im.save(image);rgb=f/(id+'.rgb');rgb.write_bytes(im.tobytes());truth=f/(id+'.txt');truth.write_text(text);row={'id':id,'word':word,'pair_index':idx//2,'palt':palt,'width':im.width,'height':im.height}
  for k,path in [('original',original),('image',image),('rgb',rgb),('truth',truth)]:row[k]=str(path);row[k+'_sha256']=sha(path)
  rows.append(row)
meta={'inputs':rows,'font':font,'native_commands':traces,'generator_sha256':sha(__file__),'renderer_sha256':sha(renderer),'spec_sha256':sha('docs/owned_parts_body_bridge_native_screen.md')};(f/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
