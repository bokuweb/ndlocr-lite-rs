from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/owned-parts-bridge');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=Path('tmp/internal-detached/product-manifest.json');m=json.loads(source.read_text());assert len(m['cases'])==115023
rgb={}
for x in m['cases']:
 if x['rgb']not in rgb:rgb[x['rgb']]=sha(x['rgb'])
 assert rgb[x['rgb']]==x['rgb_sha256']
(r/'manifest.json').write_bytes(source.read_bytes());xs=[x for line in(r/'probe-build.jsonl').read_text().splitlines()if(x:=json.loads(line)).get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(xs)==1;b=r/'probe-binary';shutil.copy2(xs[0]['executable'],b);hs={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),Path('docs/owned_parts_body_bridge.md')]:
 q=r/'probe-source'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
ci=json.loads(Path('tmp/internal-detached/head-ci.json').read_text());assert ci['headSha']=='fc5da3af1ccd0e73741b1a886f9ba4cc6f648f3b'and ci['conclusion']=='success'
meta={'baseline_commit':ci['headSha'],'baseline_ci':39330988823,'source_sha256':hs,'binary_sha256':sha(b),'manifest_sha256':sha(r/'manifest.json'),'rgb_sha256':rgb,'fixture_sha256':{str(p):sha(p)for p in Path('tests/fixtures/owned_parts_body_bridge').glob('*.png')},'driver_sha256':sha(__file__),'argv':[str(b.resolve()),'infer::visible_repetitions::owned_parts_body_bridge::tests::record_owned_parts_bridge_policy','--exact','--ignored','--nocapture'],'env':{'NDLOCR_OWNED_BRIDGE_ROOT':str(r)},'scope':'115023 captured neural pairs through actualfc5 baseline and test-only combined view;no NN forwards'};(r/'probe-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('actual executable/source/input/RGB frozen before comparison',flush=True)
