from pathlib import Path
import json,time,subprocess
r=Path('tmp/owned-parts-bridge/freetype')
while True:
 records=[json.loads((r/'fresh'/(m+'-command.json')).read_text())for m in ['30','50','100']]
 if all('exit_code'in x for x in records):break
 time.sleep(1)
assert all(x['exit_code']==0 for x in records)
py='/Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
p=subprocess.run([py,str(r/'evaluate.py'),'fresh']);raise SystemExit(p.returncode)
