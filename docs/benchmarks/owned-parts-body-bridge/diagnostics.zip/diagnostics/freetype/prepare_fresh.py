from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib,subprocess,shutil,PIL
from renderer import draw_basic
r=Path('tmp/owned-parts-bridge/freetype');out=r/'fresh';out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['native','original','png','rgb','effective','truth']:(out/name).mkdir()
fonts=json.loads(Path('tmp/owned-parts-bridge/fresh/evaluation-manifest.json').read_text())['fonts'];rows=[];traces=[]
prior={}
for q in json.loads(Path('tmp/internal-detached/product-manifest.json').read_text())['cases']:
 key=(q['width'],q['height'],q['rgb_sha256']);value={k:q.get(k)for k in ['corpus','id','orientation','truth']}
 if value not in prior.setdefault(key,[]):prior[key].append(value)
def draw_native(font,size,text,id):
 im,trace=draw_basic(font,size,text);path=out/'native'/(id+'.png');im.save(path);tp=path.with_suffix('.json');tp.write_text(json.dumps(trace,ensure_ascii=False,indent=2)+'\n')
 traces.append({'id':id,'call':{'font':font,'size':size,'text':text},'png_sha256':sha(path.read_bytes()),'trace_sha256':sha(tp.read_bytes())});return im
def save(im,text,id,metadata):
 for fmt in ['png','jpeg75']:
  key=id+'_'+fmt;path=out/'original'/(key+('.png'if fmt=='png'else'.jpg'));im.save(path,**({}if fmt=='png'else{'quality':75,'subsampling':2}));decoded=Image.open(path).convert('RGB');assert decoded.getchannel('R').tobytes()==decoded.getchannel('G').tobytes()==decoded.getchannel('B').tobytes();image=out/'png'/(key+'.png');decoded.save(image);rgb=out/'rgb'/(key+'.rgb');rgb.write_bytes(decoded.tobytes());gt=out/'truth'/(key+'.txt');gt.write_text(text);rotated=5*decoded.height>4*decoded.width;effective=decoded.transpose(Image.Transpose.ROTATE_90)if rotated else decoded;fp=out/'effective'/(key+'.rgb');fp.write_bytes(effective.tobytes())
  matches=prior.get((decoded.width,decoded.height,sha(decoded.tobytes())),[]);assert all(z['truth']==text for z in matches),(key,matches,text)
  row=metadata|{'layout_engine':'BASIC','seen_before_115023':bool(matches),'prior_rgb_matches':matches,'id':key,'format':fmt,'width':decoded.width,'height':decoded.height,'rotated_for_auto':rotated,'forward_width':effective.width,'forward_height':effective.height,'original':str(path),'original_sha256':sha(path.read_bytes())}
  for name,p in [('image',image),('rgb',rgb),('effective_rgb',fp),('truth',gt)]:row[name]=str(p);row[name+'_sha256']=sha(p.read_bytes())
  rows.append(row)
for font in fonts:
 assert sha(Path(font['path']).read_bytes())==font['sha256']
 for size in [20,32]:
  for palt in [None]:
   for tid,unspaced in enumerate(['情報','報情']):
    for body_spaces in [0,1,2]:
     body=unspaced[0]+' '*body_spaces+unspaced[1]
     prefix=f'd_t{tid}_bs{body_spaces}_{font["id"]}_{size}_p{palt}'
     for ci,closer in enumerate([')','）','」','』','】']):
      for leading in [False,True]:
       for spaces in [0,1,2]:
        text=closer+' '*spaces+body if leading else body+' '*spaces+closer;id=prefix+f'_c{ci}_lead{int(leading)}_sp{spaces}';im=draw_native(font,size,text,id)
        for paper in [0,1,8]:
         padded=Image.new('RGB',(im.width,im.height+2*paper),'white');padded.paste(im,(0,paper));save(padded,text,id+f'_paper{paper}',{'kind':'text','body_id':tid,'body_spaces':body_spaces,'font':font['id'],'size':size,'palt':palt,'closer':closer,'leading':leading,'spaces':spaces,'paper':paper})
     native=draw_native(font,size,body,prefix+'_bare');bb=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();native=native.crop((bb[0]-2,bb[1]-2,bb[2]+2,bb[3]+2));ink=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();height=ink[3]-ink[1]
     for shape in ['none','thin','thick','dot']:
      mw={'none':0,'thin':1,'thick':(height+3)//4,'dot':4}[shape];mh=4 if shape=='dot'else height
      for leading in [False,True]:
       for gap in [0,1]:
        shift=mw+gap;image=Image.new('RGB',(native.width+shift,native.height),'white');offset=shift if leading else 0;image.paste(native,(offset,0));x=2 if leading else ink[2]+gap;y=ink[1]+(height-mh)//2
        if mw:image.paste((0,0,0),(x,y,x+mw,y+mh))
        # Shapes stay outside the original nonwhite glyph pixels, even at gap0.
        for yy in range(native.height):
         for xx in range(native.width):
          if native.getpixel((xx,yy))!=(255,255,255):assert image.getpixel((xx+offset,yy))==native.getpixel((xx,yy))
        id=prefix+f'_noise{shape}_lead{int(leading)}_gap{gap}';save(image,body,id,{'kind':'noise','body_id':tid,'body_spaces':body_spaces,'font':font['id'],'size':size,'palt':palt,'shape':shape,'leading':leading,'gap':gap,'shape_bounds':[x,y,x+mw,y+mh]})
assert len(rows)==7632 and len(traces)==1116
tiles=[];x=y=row_h=0;maxw=0
for row in rows:
 tile=Image.frombytes('RGB',(row['forward_width'],row['forward_height']),Path(row['effective_rgb']).read_bytes())
 if x and x+tile.width>4096:y+=row_h+4;x=0;row_h=0
 row['bounds']=[x,y,x+tile.width,y+tile.height];tiles.append(tile);x+=tile.width+4;row_h=max(row_h,tile.height);maxw=max(maxw,x)
atlas=Image.new('RGB',(maxw,y+row_h),'white')
for row,tile in zip(rows,tiles):atlas.paste(tile,(row['bounds'][0],row['bounds'][1]))
atlas.save(out/'atlas.png');(out/'lines.json').write_text(json.dumps([{'id':x['id'],'bounds':x['bounds']}for x in rows],indent=2)+'\n')
meta={'inputs':rows,'fonts':fonts,'native_records':traces,'generator_sha256':sha(Path(__file__).read_bytes()),'renderer_source_sha256':sha((r/'renderer.py').read_bytes()),'spec_sha256':sha(Path('docs/owned_parts_body_bridge_freetype_controls.md').read_bytes()),'pillow_version':PIL.__version__,'atlas_sha256':sha((out/'atlas.png').read_bytes()),'lines_sha256':sha((out/'lines.json').read_bytes())};(out/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');shutil.copy2('docs/owned_parts_body_bridge_freetype_controls.md',r/'capture-spec.md');print('7632 fresh controls fixed;Auto-rotation cases',sum(x['rotated_for_auto']for x in rows),'seen',sum(x['seen_before_115023']for x in rows),'atlas',atlas.size,flush=True)
