from pathlib import Path
from PIL import Image
import json,hashlib
r=Path('tmp/owned-parts-bridge/freetype');out=r/'horizontal';out.mkdir();m=json.loads((r/'fresh/evaluation-manifest.json').read_text());rows=[];tiles=[];x=0
for row in m['inputs']:
 if not row['rotated_for_auto']:continue
 row=row|{'orientation':'horizontal','forward_width':row['width'],'forward_height':row['height'],'effective_rgb':row['rgb'],'effective_rgb_sha256':row['rgb_sha256']};tile=Image.frombytes('RGB',(row['width'],row['height']),Path(row['rgb']).read_bytes());row['bounds']=[x,0,x+tile.width,tile.height];rows.append(row);tiles.append(tile);x+=tile.width+4
assert len(rows)==24;atlas=Image.new('RGB',(x,max(i.height for i in tiles)),'white')
for row,tile in zip(rows,tiles):atlas.paste(tile,(row['bounds'][0],0))
atlas.save(out/'atlas.png');(out/'lines.json').write_text(json.dumps([{'id':x['id'],'bounds':x['bounds']}for x in rows],indent=2)+'\n');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(out/'evaluation-manifest.json').write_text(json.dumps({'inputs':rows,'source_manifest_sha256':sha(r/'fresh/evaluation-manifest.json'),'driver_sha256':sha(__file__),'atlas_sha256':sha(out/'atlas.png'),'lines_sha256':sha(out/'lines.json')},indent=2)+'\n')
