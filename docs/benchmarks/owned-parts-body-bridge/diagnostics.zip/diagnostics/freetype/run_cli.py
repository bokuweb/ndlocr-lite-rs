from pathlib import Path
from PIL import Image
import json,hashlib,subprocess,concurrent.futures,os
r=Path('tmp/owned-parts-bridge/freetype');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'cli-binary.json').read_text());binary=r/'cli-after-binary';assert sha(binary)==meta['binary_sha256']
for p,h in meta['models'].items():assert sha(p)==h
rows=json.loads((r/'cli-manifest.json').read_text())['cases'];assert len(rows)==946 and sum(x['selected']for x in rows)==82;models={m:next(p for p in meta['models']if '-'+m+'-tiny-'in p)for m in ['30','50','100']};out=r/'line-cli';out.mkdir();images=out/'images';images.mkdir()
for x in rows:
 p=images/(x['corpus']+'-'+x['id']+'.png')
 if not p.exists():Image.frombytes('RGB',(x['width'],x['height']),Path(x['rgb']).read_bytes()).save(p)
 assert Image.open(p).convert('RGB').tobytes()==Path(x['rgb']).read_bytes();x['image']=str(p);x['image_sha256']=sha(p)
(r/'line-cli-command.json').write_text(json.dumps({'driver_sha256':sha(__file__),'binary':meta,'manifest_sha256':sha(r/'cli-manifest.json'),'cases':rows},ensure_ascii=False,indent=2)+'\n')
def run(x):
 name=x['model']+'-'+x['corpus']+'-'+x['id'];argv=[str(binary.resolve()),'recognize','--model',models[x['model']],'--charset','models/NDLmoji.yaml','--image',x['image']];env={'NDLOCR_INTRA_THREADS':'1'};p=subprocess.run(argv,capture_output=True,env=os.environ|env);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0 and p.stdout[-1:]==b'\n',name;body=p.stdout[:-1];(out/(name+'.txt')).write_bytes(body);record={'corpus':x['corpus'],'model':x['model'],'id':x['id'],'argv':argv,'env':env,'exit_code':p.returncode,'text':body.decode(),'selected':x['selected'],'removed_exactly_one_terminal_LF':True};(out/(name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');assert record['text']==x['expected_after'],name;return record
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:records=list(pool.map(run,rows))
(r/'line-cli-results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print('946 real CLI bodies match frozen policy;all82 changed model pairs and864 boundary noise pairs',flush=True)
