from pathlib import Path
from PIL import Image
import itertools,json,hashlib,unittest
class Controls(unittest.TestCase):
 def test_fixed_basic_layout_combinations_truth_rgb_and_prior_duplicate_tags(self):
  r=Path('tmp/owned-parts-bridge/freetype/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());xs=m['inputs'];self.assertEqual(len(xs),7632);self.assertEqual(len({x['id']for x in xs}),7632);self.assertEqual(len(m['native_records']),1116)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[20,32],[0,1,2],[')','）','」','』','】'],[False,True],[0,1,2],[0,1,8],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['body_spaces'],x['closer'],x['leading'],x['spaces'],x['paper'],x['format'])for x in xs if x['kind']=='text'};self.assertEqual(actual,expected)
  expected=set(itertools.product(range(2),['maru','gothic','mincho'],[20,32],[0,1,2],['none','thin','thick','dot'],[False,True],[0,1],['png','jpeg75']))
  actual={(x['body_id'],x['font'],x['size'],x['body_spaces'],x['shape'],x['leading'],x['gap'],x['format'])for x in xs if x['kind']=='noise'};self.assertEqual(actual,expected)
  prior=json.loads(Path('tmp/internal-detached/product-manifest.json').read_text())['cases'];keys={(x['width'],x['height'],x['rgb_sha256'])for x in prior};atlas=Image.open(r/'atlas.png').convert('RGB')
  for x in xs:
   self.assertIsNone(x['palt']);self.assertEqual(x['layout_engine'],'BASIC');self.assertEqual(x['seen_before_115023'],(x['width'],x['height'],x['rgb_sha256'])in keys)
   for k in ['rgb','effective_rgb','truth','image','original']:self.assertEqual(hashlib.sha256(Path(x[k]).read_bytes()).hexdigest(),x[k+'_sha256'])
   body=['情報','報情'][x['body_id']];body=body[0]+' '*x['body_spaces']+body[1];truth=body
   if x['kind']=='text':truth=x['closer']+' '*x['spaces']+body if x['leading']else body+' '*x['spaces']+x['closer']
   self.assertEqual(Path(x['truth']).read_text(),truth);im=Image.open(x['image']).convert('RGB');self.assertEqual(im.tobytes(),Path(x['rgb']).read_bytes());rotated=5*im.height>4*im.width;self.assertEqual(x['rotated_for_auto'],rotated);effective=im.transpose(Image.Transpose.ROTATE_90)if rotated else im;self.assertEqual(effective.tobytes(),Path(x['effective_rgb']).read_bytes());self.assertEqual(atlas.crop(x['bounds']).tobytes(),effective.tobytes())
if __name__=='__main__':unittest.main()
