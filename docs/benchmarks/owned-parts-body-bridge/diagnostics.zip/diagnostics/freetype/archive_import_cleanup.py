from pathlib import Path
import shutil
r=Path('tmp/owned-parts-bridge/freetype');out=r/'before-import-cleanup';out.mkdir();patterns=['verification-binary','verification-command.json','verification-source','verification-driver.*','product-replay-*','native30-*','native50-*','native100-*','native30.stdout','native30.stderr','native50.stdout','native50.stderr','native100.stdout','native100.stderr','default-tests.log','default-exit.json','native-tests.log','native-exit.json','examples-tests.log','examples-exit.json','clippy-tests.log','clippy-exit.json','clippy-audit.json','checks-command.json','checks-driver.*','cli-after-binary','cli-binary.json','cli-driver.*','cli-driver-retry.*','line-cli-command.json','line-cli-before-import-cleanup','cli-import-cleanup-interruption.json']
for pattern in patterns:
 for p in r.glob(pattern):
  assert not(out/p.name).exists();shutil.move(str(p),out/p.name)
print('initial all137991 product/2602 API/full suites and interrupted CLI partials preserved')
