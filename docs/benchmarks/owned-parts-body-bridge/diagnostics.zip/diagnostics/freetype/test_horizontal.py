from pathlib import Path
from PIL import Image
import json,unittest,hashlib
class Controls(unittest.TestCase):
 def test_all_rotated_inputs_retain_original_rgb_for_explicit_horizontal(self):
  r=Path('tmp/owned-parts-bridge/freetype');m=json.loads((r/'horizontal/evaluation-manifest.json').read_text());old={x['id']:x for x in json.loads((r/'fresh/evaluation-manifest.json').read_text())['inputs']if x['rotated_for_auto']};self.assertEqual(len(old),24);self.assertEqual({x['id']for x in m['inputs']},set(old));atlas=Image.open(r/'horizontal/atlas.png').convert('RGB')
  for x in m['inputs']:
   self.assertEqual(x['rgb_sha256'],old[x['id']]['rgb_sha256']);self.assertEqual(x['truth_sha256'],old[x['id']]['truth_sha256']);self.assertEqual(x['forward_width'],x['width']);self.assertEqual(x['forward_height'],x['height']);self.assertEqual(x['effective_rgb'],x['rgb']);self.assertEqual(atlas.crop(x['bounds']).tobytes(),Path(x['rgb']).read_bytes());self.assertEqual(x['orientation'],'horizontal')
if __name__=='__main__':unittest.main()
