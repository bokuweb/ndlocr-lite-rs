from pathlib import Path
import json,hashlib,struct,zipfile,sys,collections
sys.path.insert(0,'tmp/punct-matched');from means import emitted_means
r=Path('tmp/owned-parts-bridge/freetype');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();batches=[(Path('tmp/owned-parts-bridge/manifest.json'),Path('tmp/owned-parts-bridge/replay/records.json')),(r/'fresh-policy/manifest.json',r/'fresh-policy/replay/records.json'),(r/'horizontal-policy/manifest.json',r/'horizontal-policy/replay/records.json')];cases=[];seen=set();rgb_hashes={}
for manifest,records in batches:
 refs={(x['corpus'],x['model'],x['id']):x for x in json.loads(records.read_text())}
 for x in json.loads(manifest.read_text())['cases']:
  key=x['corpus'],x['model'],x['id'];assert key not in seen;seen.add(key);y=refs[key];assert x['raw']==y['raw'];p=x['rgb']
  if p not in rgb_hashes:rgb_hashes[p]=sha(p)
  assert rgb_hashes[p]==x['rgb_sha256'];assert y['selected']==(y['baseline']!=y['candidate'])
  cases.append(x|{'orientation':x.get('orientation','auto'),'expected_before':y['baseline'],'expected_after':y['candidate'],'selected':y['selected']})
assert len(cases)==137991;changed=sum(x['selected']for x in cases)
(r/'product-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');by_key={(x['corpus'],x['model'],x['id']):x for x in cases};means={}
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:old=json.loads(z.read('probe.json'))
for m in old['models']:
 for x in m['rows']:means['old',m['label'].removeprefix('single'),x['id']]=x['mean_confidence']
for corpus,folder in [('owned-fresh',r/'fresh'),('owned-horizontal',r/'horizontal')]:
 for model in ['30','50','100']:
  for x in json.loads((folder/(model+'-export.json')).read_text()):means[corpus,model,x['id']]=emitted_means(x)[0]
controls=json.loads((r/'control-ids.json').read_text());selected={k for k,x in by_key.items()if x['selected']};matrix=set(selected);cli=set(selected)
for id in controls['api_noise_ids']+controls['api_spaced_text_ids']:
 for model in ['30','50','100']:matrix.add(('owned-fresh',model,id))
for id in controls['api_horizontal_ids']:
 for model in ['30','50','100']:matrix.add(('owned-horizontal',model,id))
for id in controls['cli_noise_ids']:
 for model in ['30','50','100']:cli.add(('owned-fresh',model,id))
native=[]
for key in sorted(matrix):
 x=by_key[key];bits=struct.unpack('<I',struct.pack('<f',means[key]))[0];native.append(x|{'mean_bits':bits})
counts=dict(collections.Counter(x['model']for x in native));native_meta={'cases':native,'counts':counts,'control_ids_sha256':sha(r/'control-ids.json'),'selected_model_pairs':changed};(r/'native-manifest.json').write_text(json.dumps(native_meta,ensure_ascii=False,indent=2)+'\n');cli_cases=[by_key[k]for k in sorted(cli)];assert all(x['orientation']=='auto'for x in cli_cases);(r/'cli-manifest.json').write_text(json.dumps({'cases':cli_cases,'selected_model_pairs':changed,'boundary_noise_model_pairs':864},ensure_ascii=False,indent=2)+'\n');print('137991 product pairs;native',len(native),counts,'CLI',len(cli_cases),'all changes included',changed,flush=True)
