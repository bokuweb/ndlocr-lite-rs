from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import json,hashlib
r=Path('tmp/owned-parts-bridge/freetype');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();cache={};rows=[]
for x in m['native_records']:
 png=f/'native'/(x['id']+'.png');p=png.with_suffix('.json');assert sha(png.read_bytes())==x['png_sha256']and sha(p.read_bytes())==x['trace_sha256'];t=json.loads(p.read_text());c=x['call'];font=c['font'];key=(font['path'],c['size'])
 if key not in cache:
  assert sha(Path(font['path']).read_bytes())==font['sha256'];cache[key]=ImageFont.truetype(font['path'],c['size'],index=0,layout_engine=ImageFont.Layout.BASIC)
 face=cache[key];text=c['text'];assert t['text']==text and t['palt']is None and t['layout_engine']=='BASIC'and t['face_index']==0 and t['font_face']==list(face.getname());assert t['bbox']==list(face.getbbox(text))and t['length']==face.getlength(text)and t['prefix_lengths']==[face.getlength(text[:i])for i in range(len(text)+1)]
 for q in t['glyph_masks']:
  g=face.getmask(q['character'],mode='L');assert list(g.size)==q['size']and sha(bytes(g))==q['mask_sha256']and q['different_from_missing_glyph']
 a,b,c,d=face.getbbox(text);im=Image.new('RGB',(c-a+16,d-b+16),'white');ImageDraw.Draw(im).text((8-a,8-b),text,font=face,fill='black');actual=Image.open(png).convert('RGB');assert im.size==actual.size and im.tobytes()==actual.tobytes();rows.append({'id':x['id'],'rgb_sha256':sha(im.tobytes())})
assert len(rows)==1116;(r/'native-audit.json').write_text(json.dumps({'driver_sha256':sha(Path(__file__).read_bytes()),'records':1116,'all_native_trace_mask_advance_and_original_rgb_verified':True,'rows':rows},indent=2)+'\n');print('1116 native traces and bitmap draws verified')
