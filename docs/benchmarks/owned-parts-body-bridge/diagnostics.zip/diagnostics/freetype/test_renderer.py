from pathlib import Path
from PIL import Image
import json,unittest
from renderer import draw_basic
class Renderer(unittest.TestCase):
 def test_matches_original_fixture_with_its_actual_font_layout_and_pixels(self):
  m=json.loads(Path('tmp/owned-parts-bridge/fresh/evaluation-manifest.json').read_text());font=next(x for x in m['fonts']if x['id']=='mincho')
  im,trace=draw_basic(font,20,'情報」')
  expected=Image.open('tests/fixtures/owned_parts_body_bridge/info_corner_mincho20.png').convert('RGB')
  self.assertEqual(im.size,expected.size);self.assertEqual(im.tobytes(),expected.tobytes());self.assertEqual(trace['layout_engine'],'BASIC');self.assertIsNone(trace['palt']);self.assertEqual(trace['prefix_lengths'],[0.0,20.0,40.0,60.0]);self.assertEqual(trace['font_face'],['Hiragino Mincho ProN','W3'])
  self.assertEqual({x['character']for x in trace['glyph_masks']},set('情報」'));self.assertTrue(all(x['different_from_missing_glyph']for x in trace['glyph_masks']))
if __name__=='__main__':unittest.main()
