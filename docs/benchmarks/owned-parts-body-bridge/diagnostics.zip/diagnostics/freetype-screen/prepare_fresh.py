from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'tmp/owned-parts-bridge/freetype');from renderer import draw_basic
r=Path('tmp/owned-parts-bridge/freetype-screen');f=r/'fresh';f.mkdir();font=next(x for x in json.loads(Path('tmp/owned-parts-bridge/fresh/evaluation-manifest.json').read_text())['fonts']if x['id']=='mincho');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[];traces=[]
for idx,word in enumerate(['情事','事情','情本','本情','情木','木情','情車','車情','情生','生情']):
 id=f'ftscreen_w{idx}';text=word+'」';im,trace=draw_basic(font,20,text);image=f/(id+'.png');im.save(image);rgb=f/(id+'.rgb');rgb.write_bytes(im.tobytes());gt=f/(id+'.txt');gt.write_text(text);tp=f/(id+'-trace.json');tp.write_text(json.dumps(trace,ensure_ascii=False,indent=2)+'\n');traces.append({'id':id,'trace_sha256':sha(tp),'png_sha256':sha(image)});row={'id':id,'word':word,'pair_index':idx//2,'layout_engine':'BASIC','palt':None,'width':im.width,'height':im.height}
 for k,path in [('image',image),('original',image),('rgb',rgb),('truth',gt)]:row[k]=str(path);row[k+'_sha256']=sha(path)
 rows.append(row)
meta={'inputs':rows,'font':font,'native_records':traces,'generator_sha256':sha(__file__),'renderer_sha256':sha('tmp/owned-parts-bridge/freetype/renderer.py'),'spec_sha256':sha('docs/owned_parts_body_bridge_freetype_screen.md')};(f/'evaluation-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
