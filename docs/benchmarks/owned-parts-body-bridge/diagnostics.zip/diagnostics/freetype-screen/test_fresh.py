from pathlib import Path
from PIL import Image
import json,hashlib,unittest
class Screen(unittest.TestCase):
 def test_all_ordered_pairs_with_basic_layout_and_real_pixels(self):
  r=Path('tmp/owned-parts-bridge/freetype-screen/fresh');m=json.loads((r/'evaluation-manifest.json').read_text());xs=m['inputs'];self.assertEqual(len(xs),10);self.assertEqual([x['word']for x in xs],['情事','事情','情本','本情','情木','木情','情車','車情','情生','生情'])
  for x in xs:
   self.assertIsNone(x['palt']);self.assertEqual(x['layout_engine'],'BASIC');self.assertEqual(Path(x['truth']).read_text(),x['word']+'」')
   for k in ['image','rgb','truth']:self.assertEqual(hashlib.sha256(Path(x[k]).read_bytes()).hexdigest(),x[k+'_sha256'])
   self.assertEqual(Image.open(x['image']).convert('RGB').tobytes(),Path(x['rgb']).read_bytes())
if __name__=='__main__':unittest.main()
