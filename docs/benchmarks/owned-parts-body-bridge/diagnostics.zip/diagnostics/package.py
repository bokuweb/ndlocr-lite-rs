from pathlib import Path
import json,hashlib,zipfile,sys
r=Path('tmp/owned-parts-bridge');ft=r/'freetype';out=Path('docs/benchmarks/owned-parts-body-bridge');out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,paths):
 if len(sys.argv)>1 and name not in sys.argv[1:]:return
 seen={};members={};aliases={}
 with zipfile.ZipFile(out/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for key,p in sorted(paths):
   b=p.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;z.writestr(key,b);members[key]=h
  b=(json.dumps(aliases,indent=2)+'\n').encode();key=name+'-aliases.json';z.writestr(key,b);members[key]=sha(b)
 index={'sha256':sha((out/(name+'.zip')).read_bytes()),'members':members};(out/(name+'.json')).write_text(json.dumps(index,indent=2)+'\n');print(name,len(members),len(aliases),(out/(name+'.zip')).stat().st_size,flush=True);assert(out/(name+'.zip')).stat().st_size<50*1024*1024
images=[];geo=[];inputs=[]
for folder,prefix,bucket in [(ft/'fresh','data/ft/fresh',images),(ft/'horizontal','data/ft/horizontal',images),(r/'fresh','data/ct/fresh',geo),(r/'native-screen/fresh','data/native-screen/fresh',geo),(r/'freetype-screen/fresh','data/freetype-screen/fresh',geo)]:
 for sub in ['native','original','png','rgb','effective','truth']:
  for p in(folder/sub).rglob('*'):
   if p.is_file():bucket.append((prefix+'/'+str(p.relative_to(folder)),p))
 for name in ['atlas.png','lines.json','evaluation-manifest.json','contact-shapes.png','contact-shapes.json','tensor-proof.json']:
  p=folder/name
  if p.exists():bucket.append((prefix+'/'+name,p))
 for p in(folder/'whole-rgb-capture').rglob('*'):
  if p.is_file():inputs.append((prefix+'/'+str(p.relative_to(folder)),p))
def pixel_file(key):return any(x in Path(key).parts for x in ['rgb','effective'])or Path(key).name=='atlas.png'
pixels=[(k,p)for k,p in images if pixel_file(k)];main=[(k,p)for k,p in images if not pixel_file(k)]
geopixels=[(k,p)for k,p in geo if pixel_file(k)];geoimages=[(k,p)for k,p in geo if not pixel_file(k)]
screens=[('data/'+name+'/fresh/'+p.name,p)for name in ['native-screen','freetype-screen']for p in(r/name/'fresh').iterdir()if p.is_file()]
packet('screens',screens);packet('images',main);packet('pixels',pixels);packet('geometry-images',geoimages);packet('geometry-pixels',geopixels);packet('inputs',inputs)
diag=[];text=[]
for p in r.rglob('*'):
 if not p.is_file()or p.name in ['checkpoint.md','README-draft.md']:continue
 rel=p.relative_to(r)
 if any(x in rel.parts for x in ['final-restored','pixel-precheck','scores','truth','subsets','line-cli','whole-rgb-capture','native','original','png','rgb','effective','__pycache__']):continue
 if p.suffix in ['.json','.py','.md','.rs','.log','.stdout','.stderr','.swift','.toml','.lock','.yaml']and not p.name.startswith('package-'):diag.append(('diagnostics/'+str(rel),p))
for p in r.rglob('*'):
 if not p.is_file()or p.name in ['checkpoint.md','README-draft.md']:continue
 rel=p.relative_to(r)
 if any(x in rel.parts for x in ['final-restored','pixel-precheck','__pycache__']):continue
 if any(x in rel.parts for x in ['scores','truth','line-cli','line-cli-before-import-cleanup'])and p.suffix in ['.csv','.md','.txt','.json','.stdout','.stderr','.png']:text.append(('text/'+str(rel),p))
for p in Path('tests/fixtures/owned_parts_body_bridge').iterdir():diag.append(('diagnostics/fixtures/'+p.name,p))
for p in Path('docs').glob('owned_parts_body_bridge*.md'):diag.append(('diagnostics/specs/'+p.name,p))
for key,p in [('source/eval_ocr_metrics.py',Path('tools/eval_ocr_metrics.py')),('source/means.py',Path('tmp/punct-matched/means.py'))]:diag.append(('diagnostics/'+key,p))
if(ft/'product-manifest.json').exists():
 old={ (x['corpus'],x['model'],x['id']):x for x in json.loads(zipfile.ZipFile('docs/benchmarks/internal-detached-closer/diagnostics.zip').read('diagnostics/portable-cases.json'))['cases']};portable=[]
 for x in json.loads((ft/'product-manifest.json').read_text())['cases']:
  key=x['corpus'],x['model'],x['id'];path='parent/'+old[key]['rgb']if key in old else 'data/ft/fresh/rgb/'+x['id']+'.rgb';portable.append(x|{'rgb':path})
 p=ft/'portable-cases.json';p.write_text(json.dumps({'cases':portable},ensure_ascii=False,indent=2)+'\n');diag=[(k,f)for k,f in diag if k!='diagnostics/freetype/portable-cases.json'];diag.append(('diagnostics/freetype/portable-cases.json',p))
packet('diagnostics',diag);packet('text',text)
parent=Path('docs/benchmarks/internal-detached-closer');names=['images','inputs','diagnostics','text'];parents={'packet':parent.name,'reproducer_sha256':sha((parent/'reproduce.py').read_bytes()),'archives':{n:json.loads((parent/(n+'.json')).read_text())['sha256']for n in names},'nested_parents_json_sha256':sha((parent/'parents.json').read_bytes())};(out/'parents.json').write_text(json.dumps(parents,indent=2)+'\n')
