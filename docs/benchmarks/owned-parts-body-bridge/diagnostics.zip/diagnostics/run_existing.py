from pathlib import Path
import json,hashlib,subprocess,os,sys
r=Path('tmp/owned-parts-bridge');cmd=r/'probe-command.json';m=json.loads(cmd.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(r/'probe-binary')==m['binary_sha256'];assert sha(r/'manifest.json')==m['manifest_sha256']
with(r/'probe.stdout').open('wb')as stdout,(r/'probe.stderr').open('wb')as stderr:d=subprocess.run(m['argv'],env=os.environ|m['env'],stdout=stdout,stderr=stderr)
m['exit_code']=d.returncode;cmd.write_text(json.dumps(m,indent=2)+'\n');assert d.returncode==0 and '115023 fixed raw pairs evaluated' in(r/'probe.stdout').read_text();print('all115023 baseline comparisons: terminal success',flush=True)
with(r/'score.stdout').open('wb')as stdout,(r/'score.stderr').open('wb')as stderr:d=subprocess.run([sys.executable,str(r/'score.py')],stdout=stdout,stderr=stderr)
assert d.returncode==0;print('official nine-group scoring: terminal success',flush=True)
