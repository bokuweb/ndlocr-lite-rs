from pathlib import Path
import json,hashlib,subprocess,os,time,concurrent.futures
r=Path('tmp/owned-parts-bridge');ft=r/'freetype';root=r/'final-restored';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while not(root/'verification.json').exists():
 if(r/'reproduce.stderr').stat().st_size:raise SystemExit((r/'reproduce.stderr').read_text())
 time.sleep(1)
proof=json.loads((root/'verification.json').read_text());assert proof['product_pairs']==137991 and proof['actual_captures']==7656
checks=[('restored-product',ft/'verification-binary',ft/'verification-command.json','infer::visible_repetitions::owned_parts_body_bridge::tests::verify_product_matches_frozen_owned_bridge_policy',{'NDLOCR_OWNED_BRIDGE_PRODUCT_MANIFEST':str(root/'product-manifest.json')}),('restored-tensors',ft/'tensor-binary',ft/'tensor-command.json','infer::visible_repetitions::owned_parts_body_bridge::tests::verify_fresh_owned_bridge_auto_tensors',{'NDLOCR_OWNED_BRIDGE_ROOT':str(root/'tensor')})]
def run(check):
 name,binary,source,test,env=check;meta=json.loads(source.read_text());assert sha(binary)==meta['binary_sha256'];record={'binary_sha256':sha(binary),'source_record_sha256':sha(source),'driver_sha256':sha(__file__),'independent_verification_sha256':sha(root/'verification.json'),'argv':[str(binary.resolve()),test,'--exact','--ignored','--nocapture'],'env':env};cmd=r/(name+'-command.json');assert not cmd.exists();cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as a,(r/(name+'.stderr')).open('wb')as b:d=subprocess.run(record['argv'],env=os.environ|env,stdout=a,stderr=b)
 record['exit_code']=d.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert d.returncode==0,name;print(name,'terminal success',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,checks))
