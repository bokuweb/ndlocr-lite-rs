use super::*;
fn leading_space_from_boxes(
    fragment: &str,
    boxes: &[(usize, usize, usize, usize)],
) -> Option<String> {
    let closer = fragment.chars().next()?;
    let is_closer = |c| matches!(c, ')' | '）' | '」' | '』' | '】');
    if !is_closer(closer) {
        return None;
    }
    let suffix = &fragment[closer.len_utf8()..];
    let body = suffix.strip_prefix(' ').unwrap_or(suffix);
    if body.chars().count() < 3
        || body.chars().any(|c| c.is_whitespace() || is_closer(c))
        || boxes.len() != body.chars().count() + 1
        || boxes.iter().any(|&(x0, x1, y0, y1)| x0 >= x1 || y0 >= y1)
        || boxes.windows(2).any(|p| p[0].1 > p[1].0)
    {
        return None;
    }
    let body_boxes = &boxes[1..];
    let h = body_boxes.iter().map(|g| g.3 - g.2).max()?;
    let gaps: Vec<_> = body_boxes.windows(2).map(|p| p[1].0 - p[0].1).collect();
    let max_gap = *gaps.iter().max()?;
    if gaps.contains(&0) || max_gap as u128 * 4 > h as u128 {
        return None;
    }
    let close = boxes.first()?;
    let gap = body_boxes.first()?.0 - close.1;
    let threshold = (max_gap * 2 + h.div_ceil(8)).max(h.div_ceil(3));
    if close.1 - close.0 < h.div_ceil(4)
        || (close.3 - close.2) as u128 > h as u128 * 2
        || gap < threshold
        || gap > h
    {
        return None;
    }
    Some(format!("{closer} {body}"))
}

fn prototype_leading_space(
    raw: &str,
    rgb: &[u8],
    w: usize,
    h: usize,
    orientation: ParseqOrientation,
) -> String {
    let current = sanitize_visible_single_line(raw, rgb, w, h, orientation);
    let original = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, true);
    let fragment = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, false);
    if fragment.chars().count() <= original.chars().count()
        || !(orientation == ParseqOrientation::Horizontal || h as u128 * 5 <= w as u128 * 4)
        || w == 0
        || h == 0
        || w.checked_mul(h).and_then(|n| n.checked_mul(3)) != Some(rgb.len())
    {
        return current;
    }
    let compact: String = fragment.chars().filter(|&c| c != ' ').collect();
    if !(supports_glyph_count(rgb, w, h, compact.chars().count())
        || supports_closer_body(rgb, w, h, &compact))
    {
        return current;
    }
    leading_space_from_boxes(
        &fragment,
        &super::geometry_probe::frozen_glyph_boxes(rgb, w, h),
    )
    .unwrap_or(current)
}

#[test]
fn leading_space_uses_local_body_gaps_and_closed_boundaries() {
    let row = |gap: usize| {
        vec![
            (8, 16, 14, 30),
            (16 + gap, 28 + gap, 4, 28),
            (30 + gap, 42 + gap, 4, 28),
            (44 + gap, 56 + gap, 4, 28),
        ]
    };
    for text in ["』ABC", "』 ABC"] {
        assert_eq!(
            leading_space_from_boxes(text, &row(8)),
            Some("』 ABC".into())
        );
        assert_eq!(leading_space_from_boxes(text, &row(7)), None);
        assert_eq!(
            leading_space_from_boxes(text, &row(24)),
            Some("』 ABC".into())
        );
        assert_eq!(leading_space_from_boxes(text, &row(25)), None);
    }
    for text in [
        "ABC』",
        "))ABC",
        "』AB C",
        "』  ABC",
        "』AB",
        "』\u{3000}ABC",
    ] {
        assert_eq!(leading_space_from_boxes(text, &row(10)), None);
    }
    let mut thin = row(10);
    thin[0].0 = thin[0].1 - 5;
    assert_eq!(leading_space_from_boxes("』ABC", &thin), None);
    thin[0].0 -= 1;
    assert!(leading_space_from_boxes("』ABC", &thin).is_some());
    let mut tall = row(10);
    tall[0].2 = 4;
    tall[0].3 = 52;
    assert!(leading_space_from_boxes("』ABC", &tall).is_some());
    tall[0].3 += 1;
    assert_eq!(leading_space_from_boxes("』ABC", &tall), None);
    let mut joined = row(10);
    joined[2].0 = joined[1].1;
    assert_eq!(leading_space_from_boxes("』ABC", &joined), None);
    let mut wide = row(16);
    wide[2] = (50, 62, 4, 28);
    wide[3] = (68, 80, 4, 28);
    assert!(leading_space_from_boxes("』ABC", &wide).is_some());
    wide[3].0 += 1;
    wide[3].1 += 1;
    assert_eq!(leading_space_from_boxes("』ABC", &wide), None);
}

use proptest::prelude::*;
proptest! {
    #![proptest_config(proptest::test_runner::Config::with_cases(64))]
    #[test]
    fn leading_space_keeps_scale_translation_tone_and_orientation_guards(
        scale in 1usize..4,dx in 0usize..8,dy in 0usize..8,tone in 0u8..180,
        closer in prop::sample::select(vec![')','）','」','』','】'])
    ) {
        let (w,h)=(100*scale+dx,150*scale+dy);let mut rgb=vec![255;w*h*3];
        for(x0,x1,y0,y1)in [(8,16,14,30),(26,38,4,28),(40,52,4,28),(54,66,4,28)] {
            for y in y0*scale+dy..y1*scale+dy{for x in x0*scale+dx..x1*scale+dx{rgb[(y*w+x)*3..(y*w+x+1)*3].fill(tone);}}
        }
        let raw=format!("{closer}ABC");let expected=format!("{closer} ABC");
        prop_assert_eq!(prototype_leading_space(&raw,&rgb,w,h,ParseqOrientation::Horizontal),expected.clone());
        prop_assert_eq!(prototype_compact_leading_space(&raw,&rgb,w,h,ParseqOrientation::Horizontal),expected.clone());
        prop_assert_eq!(prototype_compact_leading_space(&expected,&rgb,w,h,ParseqOrientation::Horizontal),expected.clone());
        prop_assert_eq!(prototype_leading_space(&expected,&rgb,w,h,ParseqOrientation::Horizontal),expected);
        prop_assert_eq!(prototype_leading_space(&raw,&rgb,w,h,ParseqOrientation::Auto),sanitize_visible_single_line(&raw,&rgb,w,h,ParseqOrientation::Auto));
        prop_assert_eq!(prototype_leading_space(&raw,&rgb[..rgb.len()-1],w,h,ParseqOrientation::Horizontal),sanitize_visible_single_line(&raw,&rgb[..rgb.len()-1],w,h,ParseqOrientation::Horizontal));
    }
}

#[cfg(feature = "onnx")]
#[test]
#[ignore = "diagnostic; explicit frozen leading-space root"]
fn capture_leading_space_candidate() {
    use crate::infer::cached::ParseqSession;
    use std::path::Path;
    let Ok(root) = std::env::var("NDLOCR_LEADING_SPACE_ROOT") else {
        return;
    };
    let root = Path::new(&root);
    let read = |name: &str| -> serde_json::Value {
        serde_json::from_slice(&std::fs::read(root.join(name)).unwrap()).unwrap()
    };
    let m = read("evaluation-manifest.json");
    let frozen = read("frozen-probe.json");
    let frozen_actual = read("frozen-after-api.json");
    let inputs = m["inputs"].as_array().unwrap();
    assert_eq!(inputs.len(), 1703);
    let mut all = Vec::new();
    for (index, file) in [
        "parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx",
    ]
    .iter()
    .enumerate()
    {
        let session = ParseqSession::load(
            &Path::new("models").join(file),
            Path::new("models/NDLmoji.yaml"),
        )
        .unwrap();
        let mut rows = Vec::new();
        let mut fresh = 0;
        for input in inputs {
            let id = input["id"].as_str().unwrap();
            let image =
                crate::io::load_rgb_u8(Path::new(input["image"].as_str().unwrap())).unwrap();
            let record = if input["source"] == "fresh_holdout" {
                fresh += 1;
                let d = session
                    .recognize_rgb_u8_candidates_with_orientation(
                        &image.data,
                        image.width,
                        image.height,
                        ParseqOrientation::Auto,
                        2,
                    )
                    .unwrap();
                serde_json::json!({"raw":d.recognition.text,"mean_confidence":d.recognition.mean_confidence,"stop_reason":format!("{:?}",d.stop_reason),"steps":d.steps.iter().map(|s|serde_json::json!({"timestep":s.timestep,"range":s.text_range.as_ref().map(|r|[r.start,r.end]),"candidates":s.candidates.iter().map(|c|serde_json::json!({"token_id":c.token_id,"char":c.character,"probability":c.probability})).collect::<Vec<_>>()})).collect::<Vec<_>>()})
            } else {
                frozen["models"][index]["rows"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|x| x["id"] == id)
                    .unwrap()
                    .clone()
            };
            let raw = record["raw"].as_str().unwrap();
            let current = sanitize_visible_single_line(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            if input["source"] == "fresh_holdout" {
                let actual = session
                    .recognize_rgb_u8(&image.data, image.width, image.height)
                    .unwrap();
                assert_eq!(actual.text, current);
                assert_eq!(
                    actual.mean_confidence.to_bits(),
                    (record["mean_confidence"].as_f64().unwrap() as f32).to_bits()
                );
            } else {
                assert_eq!(current, record["prototype"].as_str().unwrap());
                let actual = frozen_actual["models"][index]["actual"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|x| x["id"] == id)
                    .unwrap();
                assert_eq!(current, actual["text"].as_str().unwrap());
                assert_eq!(
                    (record["mean_confidence"].as_f64().unwrap() as f32).to_bits(),
                    (actual["mean_confidence"].as_f64().unwrap() as f32).to_bits()
                );
            }
            let prototype = prototype_leading_space(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            let fragment = sanitize_visible_repetitions(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            let boxes =
                super::geometry_probe::frozen_glyph_boxes(&image.data, image.width, image.height);
            let png = root.join("decoded").join(format!("{id}.png"));
            if !png.exists() {
                std::fs::create_dir_all(png.parent().unwrap()).unwrap();
                image::RgbImage::from_raw(
                    image.width as u32,
                    image.height as u32,
                    image.data.clone(),
                )
                .unwrap()
                .save(&png)
                .unwrap();
            }
            assert_eq!(crate::io::load_rgb_u8(&png).unwrap().data, image.data);
            let truth =
                std::fs::read_to_string(Path::new(input["truth"].as_str().unwrap())).unwrap();
            rows.push(serde_json::json!({"id":id,"source":input["source"],"cohort":input["cohort"],"truth":truth,"raw":raw,"mean_confidence":record["mean_confidence"],"stop_reason":record["stop_reason"],"steps":record["steps"],"current":current,"prototype":prototype,"fragment":fragment,"text_only":sanitize_recognized_text(raw),"boxes":boxes,"width":image.width,"height":image.height}));
        }
        assert_eq!(fresh, 176);
        all.push(serde_json::json!({"label":format!("single{}",[30,50,100][index]),"model":file,"rows":rows,"fresh_raw_forwards":176,"fresh_processed_forwards":176,"reused_raw":1527}));
    }
    std::fs::write(
        root.join("probe.json"),
        serde_json::to_vec_pretty(&serde_json::json!({"models":all})).unwrap(),
    )
    .unwrap();
}

fn compact_leading_space_from_boxes(
    fragment: &str,
    boxes: &[(usize, usize, usize, usize)],
) -> Option<String> {
    let spaced = leading_space_from_boxes(fragment, boxes)?;
    let h = boxes[1..].iter().map(|g| g.3 - g.2).max()?;
    (boxes[1].0 - boxes[0].0 <= h).then_some(spaced)
}
#[test]
fn compact_leading_advance_excludes_whole_glyph_width_bearing() {
    let row = |gap: usize| {
        vec![
            (8, 16, 14, 30),
            (16 + gap, 28 + gap, 4, 28),
            (30 + gap, 42 + gap, 4, 28),
            (44 + gap, 56 + gap, 4, 28),
        ]
    };
    assert_eq!(
        compact_leading_space_from_boxes(")ABC", &row(10)),
        Some(") ABC".into())
    );
    assert_eq!(
        compact_leading_space_from_boxes(") ABC", &row(16)),
        Some(") ABC".into())
    );
    assert_eq!(compact_leading_space_from_boxes(")ABC", &row(17)), None);
    // Whole advance27 exceeds body height22 even though gap19 looks large.
    let fullwidth = [
        (9, 17, 8, 36),
        (36, 57, 11, 33),
        (59, 76, 11, 33),
        (78, 97, 11, 33),
    ];
    assert!(leading_space_from_boxes(") ABC", &fullwidth).is_some());
    assert_eq!(compact_leading_space_from_boxes(") ABC", &fullwidth), None);
}

fn prototype_compact_leading_space(
    raw: &str,
    rgb: &[u8],
    w: usize,
    h: usize,
    orientation: ParseqOrientation,
) -> String {
    let current = sanitize_visible_single_line(raw, rgb, w, h, orientation);
    let original = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, true);
    let fragment = sanitize_visible_with_bracket_policy(raw, rgb, w, h, orientation, false);
    if fragment.chars().count() <= original.chars().count()
        || !(orientation == ParseqOrientation::Horizontal || h as u128 * 5 <= w as u128 * 4)
        || w == 0
        || h == 0
        || w.checked_mul(h).and_then(|n| n.checked_mul(3)) != Some(rgb.len())
    {
        return current;
    }
    let compact: String = fragment.chars().filter(|&c| c != ' ').collect();
    if !(supports_glyph_count(rgb, w, h, compact.chars().count())
        || supports_closer_body(rgb, w, h, &compact))
    {
        return current;
    }
    compact_leading_space_from_boxes(
        &fragment,
        &super::geometry_probe::frozen_glyph_boxes(rgb, w, h),
    )
    .unwrap_or(current)
}

#[cfg(feature = "onnx")]
#[test]
#[ignore = "diagnostic; explicit frozen leading-space root"]
fn capture_compact_leading_space_candidate() {
    use crate::infer::cached::ParseqSession;
    use std::path::Path;
    let Ok(root) = std::env::var("NDLOCR_COMPACT_LEADING_SPACE_ROOT") else {
        return;
    };
    let root = Path::new(&root);
    let read = |name: &str| -> serde_json::Value {
        serde_json::from_slice(&std::fs::read(root.join(name)).unwrap()).unwrap()
    };
    let m = read("evaluation-manifest.json");
    let frozen = read("frozen-probe.json");
    let inputs = m["inputs"].as_array().unwrap();
    assert_eq!(inputs.len(), 1879);
    let mut all = Vec::new();
    for (index, file) in [
        "parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx",
        "parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx",
    ]
    .iter()
    .enumerate()
    {
        let session = ParseqSession::load(
            &Path::new("models").join(file),
            Path::new("models/NDLmoji.yaml"),
        )
        .unwrap();
        let mut rows = Vec::new();
        let mut fresh = 0;
        for input in inputs {
            let id = input["id"].as_str().unwrap();
            let image =
                crate::io::load_rgb_u8(Path::new(input["image"].as_str().unwrap())).unwrap();
            let record = if input["source"] == "fresh_holdout" {
                fresh += 1;
                let d = session
                    .recognize_rgb_u8_candidates_with_orientation(
                        &image.data,
                        image.width,
                        image.height,
                        ParseqOrientation::Auto,
                        2,
                    )
                    .unwrap();
                serde_json::json!({"raw":d.recognition.text,"mean_confidence":d.recognition.mean_confidence,"stop_reason":format!("{:?}",d.stop_reason),"steps":d.steps.iter().map(|s|serde_json::json!({"timestep":s.timestep,"range":s.text_range.as_ref().map(|r|[r.start,r.end]),"candidates":s.candidates.iter().map(|c|serde_json::json!({"token_id":c.token_id,"char":c.character,"probability":c.probability})).collect::<Vec<_>>()})).collect::<Vec<_>>()})
            } else {
                frozen["models"][index]["rows"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|x| x["id"] == id)
                    .unwrap()
                    .clone()
            };
            let raw = record["raw"].as_str().unwrap();
            let current = sanitize_visible_single_line(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            if input["source"] == "fresh_holdout" {
                let actual = session
                    .recognize_rgb_u8(&image.data, image.width, image.height)
                    .unwrap();
                assert_eq!(actual.text, current);
                assert_eq!(
                    actual.mean_confidence.to_bits(),
                    (record["mean_confidence"].as_f64().unwrap() as f32).to_bits()
                );
            } else {
                assert_eq!(current, record["current"].as_str().unwrap());
            }
            let prototype = prototype_compact_leading_space(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            let fragment = sanitize_visible_repetitions(
                raw,
                &image.data,
                image.width,
                image.height,
                ParseqOrientation::Auto,
            );
            let boxes =
                super::geometry_probe::frozen_glyph_boxes(&image.data, image.width, image.height);
            let png = root.join("decoded").join(format!("{id}.png"));
            if !png.exists() {
                std::fs::create_dir_all(png.parent().unwrap()).unwrap();
                image::RgbImage::from_raw(
                    image.width as u32,
                    image.height as u32,
                    image.data.clone(),
                )
                .unwrap()
                .save(&png)
                .unwrap();
            }
            assert_eq!(crate::io::load_rgb_u8(&png).unwrap().data, image.data);
            let truth =
                std::fs::read_to_string(Path::new(input["truth"].as_str().unwrap())).unwrap();
            rows.push(serde_json::json!({"id":id,"source":input["source"],"cohort":input["cohort"],"truth":truth,"raw":raw,"mean_confidence":record["mean_confidence"],"stop_reason":record["stop_reason"],"steps":record["steps"],"current":current,"prototype":prototype,"unbounded":prototype_leading_space(raw,&image.data,image.width,image.height,ParseqOrientation::Auto),"fragment":fragment,"text_only":sanitize_recognized_text(raw),"boxes":boxes,"width":image.width,"height":image.height}));
        }
        assert_eq!(fresh, 176);
        all.push(serde_json::json!({"label":format!("single{}",[30,50,100][index]),"model":file,"rows":rows,"fresh_raw_forwards":176,"fresh_processed_forwards":176,"reused_raw":1703}));
    }
    std::fs::write(
        root.join("probe.json"),
        serde_json::to_vec_pretty(&serde_json::json!({"models":all})).unwrap(),
    )
    .unwrap();
}
