use crate::infer::parseq::RecognizeResult;

pub(super) fn recover<F30, F50>(
    base: &RecognizeResult,
    anchors: usize,
    minimum: f32,
    small: F30,
    medium: F50,
) -> Option<RecognizeResult>
where
    F30: FnOnce() -> anyhow::Result<RecognizeResult>,
    F50: FnOnce() -> anyhow::Result<RecognizeResult>,
{
    let nonwhite = |text: &str| text.chars().filter(|c| !c.is_whitespace()).count();
    let needed = anchors.div_ceil(2);
    if anchors < 6
        || minimum.is_nan()
        || !base.mean_confidence.is_finite()
        || !(0.0..=1.0).contains(&base.mean_confidence)
        || nonwhite(&base.text) == 0
        || nonwhite(&base.text) >= needed
    {
        return None;
    }
    let whitespace = |text: &str| {
        text.chars()
            .filter(|c| c.is_whitespace())
            .collect::<Vec<_>>()
    };
    let supported = |candidate: &RecognizeResult| {
        candidate.text.starts_with(&base.text)
            && candidate.text != base.text
            && whitespace(&candidate.text) == whitespace(&base.text)
            && nonwhite(&candidate.text) >= needed
            && candidate
                .text
                .chars()
                .filter(|c| c.is_alphanumeric())
                .collect::<std::collections::BTreeSet<_>>()
                .len()
                >= 4
            && candidate.mean_confidence.is_finite()
            && (0.98..=1.0).contains(&candidate.mean_confidence)
            && candidate.mean_confidence > base.mean_confidence
            && candidate.mean_confidence >= minimum
    };
    let small = small().ok()?;
    if !supported(&small) {
        return None;
    }
    let medium = medium().ok()?;
    if !supported(&medium) || small.text != medium.text {
        return None;
    }
    Some(RecognizeResult {
        text: small.text,
        mean_confidence: small.mean_confidence.min(medium.mean_confidence),
    })
}

pub(super) fn eligible_models(
    enabled: bool,
    bucket: f32,
    large: (usize, usize),
    small: Option<(usize, usize)>,
    medium: Option<(usize, usize)>,
) -> bool {
    enabled
        && bucket == 100.0
        && large == (768, 24)
        && small == Some((256, 24))
        && medium == Some((384, 24))
}

pub(super) fn recover_supported_crop<F30, F50>(
    base: &RecognizeResult,
    rgb: &[u8],
    width: usize,
    height: usize,
    minimum: f32,
    small: F30,
    medium: F50,
) -> Option<RecognizeResult>
where
    F30: FnOnce(&[u8], usize, usize) -> anyhow::Result<RecognizeResult>,
    F50: FnOnce(&[u8], usize, usize) -> anyhow::Result<RecognizeResult>,
{
    let (_, anchors) = crate::infer::vertical_fallback::supported_column(rgb, width, height)?;
    recover(
        base,
        anchors,
        minimum,
        || small(rgb, width, height),
        || medium(rgb, width, height),
    )
}

#[cfg(test)]
#[path = "../../tests/support/vertical_model_agreement.rs"]
mod tests;
