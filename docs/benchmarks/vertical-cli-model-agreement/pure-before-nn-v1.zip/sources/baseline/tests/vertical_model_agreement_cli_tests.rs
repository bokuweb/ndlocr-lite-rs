#![cfg(feature = "onnx")]
use std::path::{Path, PathBuf};

#[test]
#[ignore = "mandatory pinned models; explicit isolated C1 CLI regression"]
fn two_models_restore_the_literal_known_body_with_default_cli_settings() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let assets = [
        (
            "NDLOCR_TEST_PARSEQ_MODEL",
            "models/parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx",
        ),
        (
            "NDLOCR_TEST_PARSEQ30_MODEL",
            "models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
        ),
        (
            "NDLOCR_TEST_PARSEQ50_MODEL",
            "models/parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx",
        ),
        ("NDLOCR_TEST_DEIM_MODEL", "models/deim-s-1024x1024.onnx"),
        ("NDLOCR_TEST_CHARSET", "models/NDLmoji.yaml"),
    ];
    let paths: Vec<PathBuf> = assets
        .iter()
        .map(|(env, fallback)| {
            std::env::var_os(env)
                .map(PathBuf::from)
                .unwrap_or_else(|| fallback.into())
        })
        .collect();
    for path in &paths {
        assert!(
            path.is_file(),
            "mandatory asset missing: {}",
            path.display()
        );
    }
    let fixture = root.join("tests/fixtures/vertical_model_agreement_cli");
    let case: serde_json::Value =
        serde_json::from_slice(&std::fs::read(fixture.join("case.json")).unwrap()).unwrap();
    let image = fixture.join(case["image"].as_str().unwrap());
    let before = std::fs::read(&image).unwrap();
    let expected = case["expected"].as_str().unwrap().as_bytes();
    let directory = tempfile::tempdir().unwrap();
    let body = directory.path().join("body.txt");
    let binary = std::env::var_os("NDLOCR_TEST_CLI_BINARY")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_BIN_EXE_ndlocr-lite-rs")));
    let result = std::process::Command::new(binary)
        .current_dir(root)
        .args(["recognize-page", "--image"])
        .arg(&image)
        .arg("--det-model")
        .arg(&paths[3])
        .arg("--model")
        .arg(&paths[0])
        .arg("--model30")
        .arg(&paths[1])
        .arg("--model50")
        .arg(&paths[2])
        .arg("--charset")
        .arg(&paths[4])
        .args(["--use-deim-detection", "true", "--output-txt"])
        .arg(&body)
        .output()
        .unwrap();
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    assert_eq!(
        std::fs::read(body).unwrap(),
        expected,
        "literal 71-scalar body"
    );
    let mut stdout = expected.to_vec();
    stdout.push(b'\n');
    assert_eq!(result.stdout, stdout, "stdout LF framing");
    assert_eq!(std::fs::read(&image).unwrap(), before);
}
