//! セッションをモデルロード後に保持する高速化版 API (`ort` v2 backend)。
//!
//! 旧実装 (`onnxruntime` 0.0.14) では `Environment` 構築・`Session` ロードが
//! 1 行 OCR ごとに走り、ページあたり数十秒掛かっていた。本モジュールは
//! [`ParseqSession`] / [`ParseqPool`] / [`ParseqCascadePool`] でロード結果を
//! `ort::session::Session` として保持し、`run` だけを繰り返し叩けるようにする。
//!
//! `coreml` feature 有効時は [`super::ort_init`] が CoreML EP を登録するので、
//! macOS (Apple Silicon) では ANE/GPU に乗って CPU 比 ~3-5x 速い。

#![cfg(feature = "onnx")]

use anyhow::{Context, Result, anyhow, bail};
use ndarray::Array;
use ort::inputs;
use ort::session::Session;
use ort::session::builder::GraphOptimizationLevel;
use ort::value::TensorRef;
use std::path::Path;
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering};

use super::ort_init::{OrtAnyhow, auto_intra_threads, ensure_init};
use super::parseq::{
    ParseqCandidateResult, ParseqOrientation, PreprocessScratch, RecognizeResult,
    load_charset_from_yaml_str, predict_text_from_flat_logits_with_candidates,
    predict_text_from_flat_logits_with_confidence, preprocess_rgb_u8_into_with_scratch,
    preprocess_rgb_u8_with_orientation,
};

#[cfg(test)]
use super::parseq::sanitize_recognized_text;

pub fn default_parseq_parallelism() -> usize {
    std::env::var("NDLOCR_PARSEQ_PARALLELISM")
        .ok()
        .and_then(|raw| raw.parse::<usize>().ok())
        .map(|n| n.clamp(1, 4))
        .unwrap_or(1)
}

/// `ort::session::Session` は内部に `*mut OrtSession` を持つだけで、`Send` だが
/// `Run` 自体は thread-safe ではない。Mutex で 1 スレッドずつ叩く。
struct SessionCell(Session);

type IndexedImage<'a> = (usize, &'a [u8], usize, usize);

pub struct ParseqSession {
    session: Mutex<SessionCell>,
    input_name: String,
    output_name: String,
    input_w: usize,
    input_h: usize,
    /// バッチ次元 (= dim[0]) が動的かどうか。`true` なら 1 度の `run` に
    /// 複数枚を詰めてバッチ推論できる。
    batch_dim_dynamic: bool,
    charset: Vec<char>,
}

fn build_session(model_path: &Path, intra_threads: usize) -> Result<Session> {
    ensure_init();
    // intra_threads = 1 を渡すと旧挙動 (1 セッション 1 スレッド)。pool 並列度
    // から `auto_intra_threads` で算出するのが既定。
    let session = Session::builder()
        .anyort()?
        .with_optimization_level(GraphOptimizationLevel::Level3)
        .anyort()?
        .with_intra_threads(intra_threads.max(1))
        .anyort()?
        .commit_from_file(model_path)
        .anyort()?;
    Ok(session)
}

fn extract_input_meta(session: &Session) -> Result<(String, String, usize, usize, bool)> {
    let inputs = session.inputs();
    let input = inputs
        .first()
        .ok_or_else(|| anyhow!("model has no input"))?;
    let shape = input
        .dtype()
        .tensor_shape()
        .ok_or_else(|| anyhow!("input is not a tensor"))?;
    let dims: &[i64] = shape;
    if dims.len() < 4 {
        bail!("unexpected model input rank");
    }
    if dims[2] <= 0 || dims[3] <= 0 {
        bail!("dynamic input H/W is unsupported");
    }
    let input_h = dims[2] as usize;
    let input_w = dims[3] as usize;
    let batch_dim_dynamic = dims[0] <= 0;
    let input_name = input.name().to_string();
    let outputs = session.outputs();
    let output_name = outputs
        .first()
        .ok_or_else(|| anyhow!("model has no output"))?
        .name()
        .to_string();
    Ok((input_name, output_name, input_w, input_h, batch_dim_dynamic))
}

impl ParseqSession {
    /// ロード済みONNXの入力画像寸法を幅・高さの順で返す。
    pub fn input_dimensions(&self) -> (usize, usize) {
        (self.input_w, self.input_h)
    }

    pub fn load(model_path: &Path, charset_path: &Path) -> Result<Self> {
        if !model_path.is_file() {
            bail!("parseq model not found: {}", model_path.display());
        }
        if !charset_path.is_file() {
            bail!("charset not found: {}", charset_path.display());
        }
        let yaml_body = std::fs::read_to_string(charset_path)
            .with_context(|| format!("failed to read {}", charset_path.display()))?;
        let charset = load_charset_from_yaml_str(&yaml_body)?;
        // 単発 Session なので pool=1 として intra を取る (= cpu 数を最大限使う)。
        let session = build_session(model_path, auto_intra_threads(1))?;
        let (input_name, output_name, input_w, input_h, batch_dim_dynamic) =
            extract_input_meta(&session)?;
        Ok(Self {
            session: Mutex::new(SessionCell(session)),
            input_name,
            output_name,
            input_w,
            input_h,
            batch_dim_dynamic,
            charset,
        })
    }

    pub fn supports_batch(&self) -> bool {
        self.batch_dim_dynamic
    }

    pub fn recognize_rgb_u8(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
    ) -> Result<RecognizeResult> {
        let mut result = self.recognize_rgb_u8_unprocessed(rgb, width, height)?;
        result.text = super::visible_repetitions::sanitize_visible_single_line(
            &result.text,
            rgb,
            width,
            height,
            ParseqOrientation::Auto,
        );
        Ok(result)
    }

    /// ロード済みモデルで推論し、反復文字や空白を後処理せず保持する。
    /// 失敗した画像の部分結果を保存せず、同じセッションで次の画像を認識できる。
    pub fn recognize_rgb_u8_unprocessed(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
    ) -> Result<RecognizeResult> {
        self.recognize_rgb_u8_unprocessed_with_orientation(
            rgb,
            width,
            height,
            ParseqOrientation::Auto,
        )
    }

    /// 入力方向を明示し、同じモデルで後処理前の本文と信頼度を返す。
    pub fn recognize_rgb_u8_unprocessed_with_orientation(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
        orientation: ParseqOrientation,
    ) -> Result<RecognizeResult> {
        let single = [(rgb, width, height)];
        let mut out = {
            let mut guard = self
                .session
                .lock()
                .map_err(|_| anyhow!("parseq session mutex poisoned"))?;
            run_batch_on_session_with_orientation(
                &mut guard.0,
                &self.input_name,
                &self.output_name,
                self.input_w,
                self.input_h,
                &self.charset,
                &single,
                orientation,
            )?
        };
        let result = out.pop().ok_or_else(|| anyhow!("empty batch result"))?;
        Ok(result)
    }

    /// ロード済みモデルを一度推論し、方向指定と後処理前の文字候補を返す。
    /// k=0は推論前に拒否する。画像や候補の検証が失敗しても再利用できる。
    pub fn recognize_rgb_u8_candidates_with_orientation(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
        orientation: ParseqOrientation,
        top_k: usize,
    ) -> Result<ParseqCandidateResult> {
        if top_k == 0 {
            bail!("top_k must be > 0");
        }
        let single = [(rgb, width, height)];
        let mut guard = self
            .session
            .lock()
            .map_err(|_| anyhow!("parseq session mutex poisoned"))?;
        let mut out = run_batch_on_session_with_decoder(
            &mut guard.0,
            &self.input_name,
            &self.output_name,
            self.input_w,
            self.input_h,
            &self.charset,
            &single,
            orientation,
            |logits, t, c, charset| {
                predict_text_from_flat_logits_with_candidates(logits, t, c, charset, top_k)
            },
        )?;
        out.pop().ok_or_else(|| anyhow!("empty batch result"))
    }

    pub fn recognize_batch_rgb_u8(
        &self,
        items: &[(&[u8], usize, usize)],
    ) -> Result<Vec<RecognizeResult>> {
        if items.is_empty() {
            return Ok(vec![]);
        }
        if !self.batch_dim_dynamic {
            let mut out = Vec::with_capacity(items.len());
            for (rgb, w, h) in items {
                out.push(self.recognize_rgb_u8(rgb, *w, *h)?);
            }
            return Ok(out);
        }
        let mut guard = self
            .session
            .lock()
            .map_err(|_| anyhow!("parseq session mutex poisoned"))?;
        run_batch_on_session(
            &mut guard.0,
            &self.input_name,
            &self.output_name,
            self.input_w,
            self.input_h,
            &self.charset,
            items,
        )
    }
}

/// 1 つの `Session` で `[N, 3, H, W]` 入力を組み立てて推論する内部関数。
fn run_batch_on_session(
    session: &mut Session,
    input_name: &str,
    output_name: &str,
    input_w: usize,
    input_h: usize,
    charset: &[char],
    items: &[(&[u8], usize, usize)],
) -> Result<Vec<RecognizeResult>> {
    let mut results = run_batch_on_session_unprocessed(
        session,
        input_name,
        output_name,
        input_w,
        input_h,
        charset,
        items,
    )?;
    for (result, &(rgb, width, height)) in results.iter_mut().zip(items) {
        result.text = super::visible_repetitions::sanitize_visible_single_line(
            &result.text,
            rgb,
            width,
            height,
            ParseqOrientation::Auto,
        );
    }
    Ok(results)
}

/// 共通の推論・デコード結果を、後処理を適用する前の状態で返す。
fn run_batch_on_session_unprocessed(
    session: &mut Session,
    input_name: &str,
    output_name: &str,
    input_w: usize,
    input_h: usize,
    charset: &[char],
    items: &[(&[u8], usize, usize)],
) -> Result<Vec<RecognizeResult>> {
    run_batch_on_session_with_orientation(
        session,
        input_name,
        output_name,
        input_w,
        input_h,
        charset,
        items,
        ParseqOrientation::Auto,
    )
}

/// 方向指定を前処理に渡し、既存の推論・デコードを共用する。
#[allow(clippy::too_many_arguments)]
fn run_batch_on_session_with_orientation(
    session: &mut Session,
    input_name: &str,
    output_name: &str,
    input_w: usize,
    input_h: usize,
    charset: &[char],
    items: &[(&[u8], usize, usize)],
    orientation: ParseqOrientation,
) -> Result<Vec<RecognizeResult>> {
    run_batch_on_session_with_decoder(
        session,
        input_name,
        output_name,
        input_w,
        input_h,
        charset,
        items,
        orientation,
        predict_text_from_flat_logits_with_confidence,
    )
}

/// 同じ前処理と一回の推論を共用し、呼び出し元が必要なデコードだけを行う。
#[allow(clippy::too_many_arguments)]
fn run_batch_on_session_with_decoder<R>(
    session: &mut Session,
    input_name: &str,
    output_name: &str,
    input_w: usize,
    input_h: usize,
    charset: &[char],
    items: &[(&[u8], usize, usize)],
    orientation: ParseqOrientation,
    decode: impl Fn(&[f32], usize, usize, &[char]) -> Result<R>,
) -> Result<Vec<R>> {
    use rayon::prelude::*;
    let n = items.len();
    let plane = 3 * input_h * input_w;
    let mut buf = vec![0.0f32; n * plane];
    // 各行の preprocess を rayon で並列化。小さい batch は direct write が
    // 有利だが、大きい batch は local Vec -> memcpy の方が速いケースがある
    // ため、bench に基づいて path を選ぶ。
    let plane_local = plane;
    let use_direct_slots =
        use_direct_batch_preprocess(items.len(), items.iter().any(|(_, w, h)| h > w));
    let preprocess_results: Result<()> = if use_direct_slots {
        buf.par_chunks_mut(plane_local)
            .zip(items.par_iter())
            .try_for_each_init(
                || PreprocessScratch::with_orientation(orientation),
                |scratch, (slot, (rgb, w, h))| -> Result<()> {
                    preprocess_rgb_u8_into_with_scratch(
                        slot, rgb, *w, *h, input_w, input_h, scratch,
                    )
                },
            )
    } else {
        buf.par_chunks_mut(plane_local)
            .zip(items.par_iter())
            .try_for_each(|(slot, (rgb, w, h))| -> Result<()> {
                let tensor =
                    preprocess_rgb_u8_with_orientation(rgb, *w, *h, input_w, input_h, orientation)?;
                slot.copy_from_slice(&tensor);
                Ok(())
            })
    };
    preprocess_results?;
    let arr = Array::from_shape_vec((n, 3, input_h, input_w), buf)?;
    let tensor = TensorRef::from_array_view(arr.view()).anyort()?;
    let outputs = session.run(inputs![input_name => tensor]).anyort()?;
    let (shape, data) = outputs[output_name].try_extract_tensor::<f32>().anyort()?;
    let shape: Vec<i64> = shape.to_vec();
    // 期待出力形状: [N, T, C]。古い ONNX で [T, C] が返る場合は N=1 のみ許容。
    let (t, c) = match shape.as_slice() {
        [bn, t, c] if *bn as usize == n => (*t as usize, *c as usize),
        [t, c] if n == 1 => (*t as usize, *c as usize),
        _ => bail!("unexpected batch output shape {:?} for n={n}", shape),
    };
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let off = i * t * c;
        let r = decode(&data[off..off + t * c], t, c, charset)?;
        out.push(r);
    }
    Ok(out)
}

fn use_direct_batch_preprocess(batch_len: usize, _has_vertical_crop: bool) -> bool {
    batch_len < 16
}

#[derive(Clone, Copy)]
enum ParseqTextPolicy {
    SingleLine,
    Fragment,
}

/// 同じモデルから複数の `Session` を作って round-robin に貸し出すプール。
pub struct ParseqPool {
    sessions: Vec<Mutex<SessionCell>>,
    next: AtomicUsize,
    input_name: String,
    output_name: String,
    input_w: usize,
    input_h: usize,
    batch_dim_dynamic: bool,
    charset: Vec<char>,
    postprocess: ParseqTextPolicy,
}

impl ParseqPool {
    pub fn load(model_path: &Path, charset_path: &Path, parallelism: usize) -> Result<Self> {
        if !model_path.is_file() {
            bail!("parseq model not found: {}", model_path.display());
        }
        if !charset_path.is_file() {
            bail!("charset not found: {}", charset_path.display());
        }
        let parallelism = parallelism.max(1);
        let yaml_body = std::fs::read_to_string(charset_path)
            .with_context(|| format!("failed to read {}", charset_path.display()))?;
        let charset = load_charset_from_yaml_str(&yaml_body)?;

        // pool 全体で「pool * intra ≒ 論理コア数」を狙う配分にする。各 Session
        // が intra=1 の旧挙動だと、Intel 8C/16T などで 4-12 コアぶんの計算
        // capacity を遊ばせていた。
        let intra_threads = auto_intra_threads(parallelism);
        let mut sessions = Vec::with_capacity(parallelism);
        let mut input_name = String::new();
        let mut output_name = String::new();
        let mut input_w = 0usize;
        let mut input_h = 0usize;
        let mut batch_dim_dynamic = false;
        for _ in 0..parallelism {
            let session = build_session(model_path, intra_threads)?;
            let (i_name, o_name, iw, ih, dyn_b) = extract_input_meta(&session)?;
            input_name = i_name;
            output_name = o_name;
            input_w = iw;
            input_h = ih;
            batch_dim_dynamic = dyn_b;
            sessions.push(Mutex::new(SessionCell(session)));
        }
        Ok(Self {
            sessions,
            next: AtomicUsize::new(0),
            input_name,
            output_name,
            input_w,
            input_h,
            batch_dim_dynamic,
            charset,
            postprocess: ParseqTextPolicy::SingleLine,
        })
    }

    /// ページの行・chunkに、文の途中の閉じ括弧を保持する後処理を使う。
    /// 同じRGBの独立した画線群が文字数を支持するときだけ反復制限を省く。
    pub(crate) fn load_for_fragments(
        model: &Path,
        charset: &Path,
        parallelism: usize,
    ) -> Result<Self> {
        Ok(Self::load(model, charset, parallelism)?.for_fragments())
    }

    pub(crate) fn for_fragments(mut self) -> Self {
        self.postprocess = ParseqTextPolicy::Fragment;
        self
    }

    /// 同じ推論結果にだけ方針を適用し、session選択とconfidenceを変えない。
    fn run_on_session(
        &self,
        session: &mut Session,
        items: &[(&[u8], usize, usize)],
    ) -> Result<Vec<RecognizeResult>> {
        self.run_on_session_oriented(session, items, ParseqOrientation::Auto)
    }

    fn run_on_session_oriented(
        &self,
        session: &mut Session,
        items: &[(&[u8], usize, usize)],
        orientation: ParseqOrientation,
    ) -> Result<Vec<RecognizeResult>> {
        let fragment_auto = matches!(self.postprocess, ParseqTextPolicy::Fragment)
            && matches!(orientation, ParseqOrientation::Auto);
        let frame_limit = if fragment_auto {
            super::output_capacity::selected_frame_limit(
                session.outputs().iter().map(|output| {
                    let shape = output.dtype().tensor_shape().map(|shape| {
                        let dimensions: &[i64] = shape;
                        dimensions
                    });
                    (output.name(), shape)
                }),
                &self.output_name,
                self.charset.len(),
            )
        } else {
            None
        };
        let (mut results, matching_frames): (Vec<RecognizeResult>, Vec<bool>) = if let Some(limit) =
            frame_limit
        {
            let decoded = run_batch_on_session_with_decoder(
                session,
                &self.input_name,
                &self.output_name,
                self.input_w,
                self.input_h,
                &self.charset,
                items,
                orientation,
                |logits, t, c, charset| {
                    let raw = predict_text_from_flat_logits_with_confidence(logits, t, c, charset)?;
                    Ok((raw, t == limit))
                },
            )?;
            decoded.into_iter().unzip()
        } else {
            (
                run_batch_on_session_with_orientation(
                    session,
                    &self.input_name,
                    &self.output_name,
                    self.input_w,
                    self.input_h,
                    &self.charset,
                    items,
                    orientation,
                )?,
                Vec::new(),
            )
        };
        for (index, (result, &(rgb, width, height))) in results.iter_mut().zip(items).enumerate() {
            let mut recovered_by_h = false;
            // Preserve the original raw whitespace when deciding whether a vertical
            // page fragment supports recovery. Chunks reuse this borrowed session.
            if matches!(self.postprocess, ParseqTextPolicy::Fragment)
                && matches!(orientation, ParseqOrientation::Auto)
                && let Some(recovered) = super::vertical_capacity::recover(
                    result,
                    rgb,
                    (width, height),
                    self.input_dimensions(),
                    |pixels, w, h| {
                        let mut parts = run_batch_on_session_with_orientation(
                            session,
                            &self.input_name,
                            &self.output_name,
                            self.input_w,
                            self.input_h,
                            &self.charset,
                            &[(pixels, w, h)],
                            ParseqOrientation::Horizontal,
                        )?;
                        parts
                            .pop()
                            .ok_or_else(|| anyhow!("empty vertical chunk result"))
                    },
                )
            {
                *result = recovered;
                recovered_by_h = true;
            }
            if !recovered_by_h
                && fragment_auto
                && matching_frames.get(index).copied().unwrap_or(false)
                && let Some(recovered) = super::vertical_capacity::recover_prefix(
                    result,
                    rgb,
                    (width, height),
                    self.input_dimensions(),
                    frame_limit,
                    |pixels, w, h| {
                        let mut parts = run_batch_on_session_with_orientation(
                            session,
                            &self.input_name,
                            &self.output_name,
                            self.input_w,
                            self.input_h,
                            &self.charset,
                            &[(pixels, w, h)],
                            ParseqOrientation::Horizontal,
                        )?;
                        parts
                            .pop()
                            .ok_or_else(|| anyhow!("empty prefix vertical chunk result"))
                    },
                )
            {
                *result = recovered;
            }
            result.text = match self.postprocess {
                ParseqTextPolicy::SingleLine => {
                    super::visible_repetitions::sanitize_visible_single_line(
                        &result.text,
                        rgb,
                        width,
                        height,
                        orientation,
                    )
                }
                ParseqTextPolicy::Fragment => {
                    super::visible_repetitions::sanitize_visible_repetitions(
                        &result.text,
                        rgb,
                        width,
                        height,
                        orientation,
                    )
                }
            };
        }
        Ok(results)
    }

    pub(crate) fn input_dimensions(&self) -> (usize, usize) {
        (self.input_w, self.input_h)
    }

    /// 横書きと確認した行の部分画像だけ方向を固定する。
    pub(crate) fn recognize_horizontal_rgb_u8(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
    ) -> Result<RecognizeResult> {
        self.recognize_rgb_u8_oriented(rgb, width, height, ParseqOrientation::Horizontal)
    }

    pub fn parallelism(&self) -> usize {
        self.sessions.len()
    }

    pub fn supports_batch(&self) -> bool {
        self.batch_dim_dynamic
    }

    pub fn recognize_rgb_u8(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
    ) -> Result<RecognizeResult> {
        self.recognize_rgb_u8_oriented(rgb, width, height, ParseqOrientation::Auto)
    }

    fn recognize_rgb_u8_oriented(
        &self,
        rgb: &[u8],
        width: usize,
        height: usize,
        orientation: ParseqOrientation,
    ) -> Result<RecognizeResult> {
        let n = self.sessions.len();
        let start = self.next.fetch_add(1, Ordering::Relaxed) % n;
        let mut acquired: Option<std::sync::MutexGuard<'_, SessionCell>> = None;
        for off in 0..n {
            let i = (start + off) % n;
            if let Ok(g) = self.sessions[i].try_lock() {
                acquired = Some(g);
                break;
            }
        }
        let mut guard = match acquired {
            Some(g) => g,
            None => self.sessions[start]
                .lock()
                .map_err(|_| anyhow!("parseq pool mutex poisoned"))?,
        };
        let single = [(rgb, width, height)];
        let mut out = self.run_on_session_oriented(&mut guard.0, &single, orientation)?;
        out.pop().ok_or_else(|| anyhow!("empty batch result"))
    }

    /// 並列度を使い切らずに **1 つの Session** だけを借りてバッチ推論する。
    ///
    /// `recognize_batch_rgb_u8` は内部で N 個の Session を全部使ってチャンク
    /// 並列実行する。このとき呼び出し元自身が複数スレッドから並列に呼ぶと、
    /// 全 Session が常に locked になって他スレッドが進めなくなる
    /// (worker > pool size でも実質的に直列化)。
    ///
    /// `PageRecognizer` のようにページ単位で並列ワーカーを走らせていて、
    /// 各ワーカーが「自分の 1 ページ分の行」だけをまとめて推論したい場合は
    /// こちらを使う。1 Session は専有するが、他の Session は他ワーカーが
    /// 同時に使えるので、ページ間並列が崩れない。
    pub fn recognize_batch_single_session_rgb_u8(
        &self,
        items: &[(&[u8], usize, usize)],
    ) -> Result<Vec<RecognizeResult>> {
        self.recognize_batch_single_session_oriented(items, ParseqOrientation::Auto)
    }

    pub(crate) fn recognize_batch_single_session_horizontal_rgb_u8(
        &self,
        items: &[(&[u8], usize, usize)],
    ) -> Result<Vec<RecognizeResult>> {
        self.recognize_batch_single_session_oriented(items, ParseqOrientation::Horizontal)
    }

    fn recognize_batch_single_session_oriented(
        &self,
        items: &[(&[u8], usize, usize)],
        orientation: ParseqOrientation,
    ) -> Result<Vec<RecognizeResult>> {
        if items.is_empty() {
            return Ok(vec![]);
        }
        let n = self.sessions.len();
        let start = self.next.fetch_add(1, Ordering::Relaxed) % n;
        let mut acquired: Option<std::sync::MutexGuard<'_, SessionCell>> = None;
        for off in 0..n {
            let i = (start + off) % n;
            if let Ok(g) = self.sessions[i].try_lock() {
                acquired = Some(g);
                break;
            }
        }
        let mut guard = match acquired {
            Some(g) => g,
            None => self.sessions[start]
                .lock()
                .map_err(|_| anyhow!("parseq pool mutex poisoned"))?,
        };
        if self.batch_dim_dynamic {
            self.run_on_session_oriented(&mut guard.0, items, orientation)
        } else {
            let mut out = Vec::with_capacity(items.len());
            for it in items {
                let single = [*it];
                out.extend(self.run_on_session_oriented(&mut guard.0, &single, orientation)?);
            }
            Ok(out)
        }
    }

    fn recognize_batch_indexed(
        &self,
        items: &[IndexedImage<'_>],
    ) -> Result<Vec<(usize, RecognizeResult)>> {
        if items.is_empty() {
            return Ok(vec![]);
        }
        let n_sessions = self.sessions.len();
        let chunk_size = items.len().div_ceil(n_sessions).max(1);
        let chunks: Vec<&[IndexedImage<'_>]> = items.chunks(chunk_size).collect();
        let n_chunks = chunks.len();

        // **Fast path** for the very common 1-chunk case (e.g. `parallelism=1`,
        // or a small batch that fits in a single session). `std::thread::scope`
        // would still spawn 1 worker thread, do a join, and pay all the
        // synchronization overhead even though there is no parallelism to
        // extract. Run it inline instead — same semantics, no spawn/join.
        //
        // This matters because `ParseqCascadePool` already fans out across
        // 30/50/100 buckets; downstream consumers tuning for that fan-out
        // routinely set the per-bucket pool size to 1, so we hit this path
        // on essentially every page.
        if n_chunks == 1 {
            let chunk = chunks[0];
            if chunk.is_empty() {
                return Ok(Vec::new());
            }
            return self.run_chunk_on_session(chunk, 0);
        }

        let mut chunk_results: Vec<Result<Vec<(usize, RecognizeResult)>>> =
            (0..n_chunks).map(|_| Ok(Vec::new())).collect();

        std::thread::scope(|scope| {
            let mut handles: Vec<(usize, std::thread::ScopedJoinHandle<'_, _>)> =
                Vec::with_capacity(n_chunks);
            for (ci, chunk) in chunks.iter().enumerate() {
                if chunk.is_empty() {
                    continue;
                }
                let chunk_ref: &[IndexedImage<'_>] = chunk;
                let h = scope.spawn(move || self.run_chunk_on_session(chunk_ref, ci % n_sessions));
                handles.push((ci, h));
            }
            for (ci, h) in handles {
                chunk_results[ci] = h
                    .join()
                    .unwrap_or_else(|_| Err(anyhow!("parseq batch worker panicked")));
            }
        });
        let mut out = Vec::with_capacity(items.len());
        for r in chunk_results {
            out.extend(r?);
        }
        Ok(out)
    }

    /// Single-session 版 `recognize_batch_indexed`: chunk 分割を行わず、
    /// `try_lock` で利用可能な 1 session を選び、batch 全体を 1 度に推論する。
    ///
    /// 用途: cascade pool のように **複数 N 並行な呼び出しが想定される文脈**
    /// で、各 call が pool の異なる session を独立に掴めるようにする。
    /// 旧 `recognize_batch_indexed` は items を `n_sessions` 個に分割して
    /// **全 session を 1 call で占有** する設計のため、N 個の concurrent
    /// caller が来ると全員が全 session を奪い合って真の並列にならなかった
    /// (downstream の OCR 並列が pool 並列度と独立にスケールできない)。
    ///
    /// 戻り値は `recognize_batch_indexed` と同形 (= `(input_idx,
    /// RecognizeResult)`)。空 batch は空 Vec。
    fn recognize_batch_indexed_single_session(
        &self,
        items: &[IndexedImage<'_>],
    ) -> Result<Vec<(usize, RecognizeResult)>> {
        if items.is_empty() {
            return Ok(Vec::new());
        }
        let n = self.sessions.len();
        let start = self.next.fetch_add(1, Ordering::Relaxed) % n.max(1);
        // try_lock で最初に空いた session を掴む。全部塞がっていたら start に
        // blocking lock。
        let mut acquired: Option<std::sync::MutexGuard<'_, SessionCell>> = None;
        let mut chosen_idx: usize = start;
        for off in 0..n {
            let i = (start + off) % n;
            if let Ok(g) = self.sessions[i].try_lock() {
                acquired = Some(g);
                chosen_idx = i;
                break;
            }
        }
        let mut guard = match acquired {
            Some(g) => g,
            None => self.sessions[start]
                .lock()
                .map_err(|_| anyhow!("parseq pool mutex poisoned"))?,
        };
        let session = &mut guard.0;
        let payload: Vec<(&[u8], usize, usize)> =
            items.iter().map(|(_, r, w, hh)| (*r, *w, *hh)).collect();
        let recs = if self.batch_dim_dynamic {
            self.run_on_session(session, &payload)?
        } else {
            let mut out = Vec::with_capacity(payload.len());
            for it in &payload {
                let single = [*it];
                out.extend(self.run_on_session(session, &single)?);
            }
            out
        };
        let _ = chosen_idx; // 可観測性が必要になったら tracing で使う
        Ok(items
            .iter()
            .zip(recs)
            .map(|((idx, _, _, _), r)| (*idx, r))
            .collect())
    }

    /// 1 つの session で 1 chunk ぶんを推論する内部ヘルパ。
    /// `recognize_batch_indexed` の inline path と spawn path の両方が呼ぶ。
    fn run_chunk_on_session(
        &self,
        chunk: &[IndexedImage<'_>],
        session_idx: usize,
    ) -> Result<Vec<(usize, RecognizeResult)>> {
        let session_mu = &self.sessions[session_idx % self.sessions.len().max(1)];
        let mut guard = session_mu
            .lock()
            .map_err(|_| anyhow!("parseq pool mutex poisoned"))?;
        let session = &mut guard.0;
        let payload: Vec<(&[u8], usize, usize)> =
            chunk.iter().map(|(_, r, w, hh)| (*r, *w, *hh)).collect();
        let recs = if self.batch_dim_dynamic {
            self.run_on_session(session, &payload)?
        } else {
            let mut out = Vec::with_capacity(payload.len());
            for it in &payload {
                let single = [*it];
                out.extend(self.run_on_session(session, &single)?);
            }
            out
        };
        Ok(chunk
            .iter()
            .zip(recs)
            .map(|((idx, _, _, _), r)| (*idx, r))
            .collect())
    }

    pub fn recognize_batch_rgb_u8(
        &self,
        items: &[(&[u8], usize, usize)],
    ) -> Result<Vec<RecognizeResult>> {
        if items.is_empty() {
            return Ok(vec![]);
        }
        let indexed: Vec<(usize, &[u8], usize, usize)> = items
            .iter()
            .enumerate()
            .map(|(i, (r, w, h))| (i, *r, *w, *h))
            .collect();
        let mut by_idx = self.recognize_batch_indexed_single_session(&indexed)?;
        by_idx.sort_by_key(|(i, _)| *i);
        Ok(by_idx.into_iter().map(|(_, r)| r).collect())
    }
}

/// 3 つの parseq モデル (16x256/16x384/16x768) を保持し、行ごとに最適な
/// モデルを選んで推論するカスケード。
pub struct ParseqCascadePool {
    pool30: ParseqPool,
    pool50: ParseqPool,
    pool100: ParseqPool,
}

impl ParseqCascadePool {
    pub fn load(
        model30: &Path,
        model50: &Path,
        model100: &Path,
        charset: &Path,
        parallelism: usize,
    ) -> Result<Self> {
        // 3 モデルを `thread::scope` で並列ロード (cold start ~3x 短縮)。
        let mut r30: Result<ParseqPool> = Err(anyhow!("not run"));
        let mut r50: Result<ParseqPool> = Err(anyhow!("not run"));
        let mut r100: Result<ParseqPool> = Err(anyhow!("not run"));
        std::thread::scope(|s| {
            let h30 = s.spawn(|| ParseqPool::load(model30, charset, parallelism));
            let h50 = s.spawn(|| ParseqPool::load(model50, charset, parallelism));
            let h100 = s.spawn(|| ParseqPool::load(model100, charset, parallelism));
            r30 = h30
                .join()
                .unwrap_or_else(|_| Err(anyhow!("pool30 load panicked")));
            r50 = h50
                .join()
                .unwrap_or_else(|_| Err(anyhow!("pool50 load panicked")));
            r100 = h100
                .join()
                .unwrap_or_else(|_| Err(anyhow!("pool100 load panicked")));
        });
        Ok(Self {
            pool30: r30?,
            pool50: r50?,
            pool100: r100?,
        })
    }

    pub fn parallelism(&self) -> usize {
        self.pool100.parallelism()
    }

    pub fn recognize_batch_with_buckets_rgb_u8(
        &self,
        items: &[(&[u8], usize, usize, Option<f32>)],
    ) -> Result<Vec<RecognizeResult>> {
        if items.is_empty() {
            return Ok(vec![]);
        }
        let mut idx30: Vec<(usize, &[u8], usize, usize)> = Vec::new();
        let mut idx50: Vec<(usize, &[u8], usize, usize)> = Vec::new();
        let mut idx100: Vec<(usize, &[u8], usize, usize)> = Vec::new();
        for (i, (rgb, w, h, pcc)) in items.iter().enumerate() {
            let bucket = bucket_from_pred_char_count(*pcc);
            match bucket {
                3 => idx30.push((i, rgb, *w, *h)),
                2 => idx50.push((i, rgb, *w, *h)),
                _ => idx100.push((i, rgb, *w, *h)),
            }
        }

        let (r30, r50, r100) = run_three_pools_skipping_empty(
            &self.pool30,
            &idx30,
            &self.pool50,
            &idx50,
            &self.pool100,
            &idx100,
        );
        let mut all: Vec<(usize, RecognizeResult)> = Vec::with_capacity(items.len());
        all.extend(r30?);
        all.extend(r50?);
        all.extend(r100?);
        all.sort_by_key(|(i, _)| *i);

        // フォールバック: 30 で >=25 字 → 50 へ、50 で >=45 字 → 100 へ。
        let mut redo50: Vec<(usize, &[u8], usize, usize)> = Vec::new();
        let mut redo100: Vec<(usize, &[u8], usize, usize)> = Vec::new();
        for (i, item) in items.iter().enumerate() {
            let bucket = bucket_from_pred_char_count(item.3);
            let len = all[i].1.text.chars().count();
            if bucket == 3 && len >= 25 {
                redo50.push((i, item.0, item.1, item.2));
            } else if bucket == 2 && len >= 45 {
                redo100.push((i, item.0, item.1, item.2));
            }
        }
        if !redo50.is_empty() || !redo100.is_empty() {
            let (rd50, rd100) =
                run_two_pools_skipping_empty(&self.pool50, &redo50, &self.pool100, &redo100);
            for (i, r) in rd50? {
                if r.text.chars().count() >= 45 {
                    let it = items[i];
                    let single = [(i, it.0, it.1, it.2)];
                    let r2 = self
                        .pool100
                        .recognize_batch_indexed_single_session(&single)?;
                    if let Some((_, rr)) = r2.into_iter().next() {
                        all[i].1 = rr;
                        continue;
                    }
                }
                all[i].1 = r;
            }
            for (i, r) in rd100? {
                all[i].1 = r;
            }
        }

        Ok(all.into_iter().map(|(_, r)| r).collect())
    }
}

/// `recognize_batch_with_buckets_rgb_u8` の thread fan-out 部分を、**非空
/// バケットだけ** スレッド起動するように切り出したヘルパ。
///
/// 旧実装は常に 3 つの `thread::scope` を立ち上げていたため、典型的な日本語
/// ページ (ほぼ全行が 30-bucket で 50/100 は空) でも 50/100 用のスレッドを
/// 空 Vec のためだけに spawn → join していた。downstream で N 並列の OCR
/// 呼び出しがあると、空ジョブのためのスレッド spawn だけで OS スケジューラ
/// が thrash し、軽いページでも数十秒かかる現象を引き起こしていた。
///
/// 動作:
///   - 全バケット空: そのまま `Ok(vec![])` を返す
///   - 1 バケットだけ非空: スレッドを spawn せず inline 実行
///   - 2-3 バケット非空: その数だけ spawn (空バケットはスキップ)
///
/// 計算結果の意味は不変。バケット結果の対応は `(usize, RecognizeResult)` の
/// タプルに index を載せる旧仕様のまま。
fn run_three_pools_skipping_empty(
    p30: &ParseqPool,
    items30: &[(usize, &[u8], usize, usize)],
    p50: &ParseqPool,
    items50: &[(usize, &[u8], usize, usize)],
    p100: &ParseqPool,
    items100: &[(usize, &[u8], usize, usize)],
) -> (
    Result<Vec<(usize, RecognizeResult)>>,
    Result<Vec<(usize, RecognizeResult)>>,
    Result<Vec<(usize, RecognizeResult)>>,
) {
    let active =
        (!items30.is_empty()) as u8 + (!items50.is_empty()) as u8 + (!items100.is_empty()) as u8;
    if active <= 1 {
        // 0 or 1 active: thread::scope を立てずに inline 実行する。
        let r30 = if items30.is_empty() {
            Ok(Vec::new())
        } else {
            p30.recognize_batch_indexed_single_session(items30)
        };
        let r50 = if items50.is_empty() {
            Ok(Vec::new())
        } else {
            p50.recognize_batch_indexed_single_session(items50)
        };
        let r100 = if items100.is_empty() {
            Ok(Vec::new())
        } else {
            p100.recognize_batch_indexed_single_session(items100)
        };
        return (r30, r50, r100);
    }
    // 2-3 active: thread::scope で並走させるが、空のバケットはスキップ。
    let mut r30: Result<Vec<(usize, RecognizeResult)>> = Ok(Vec::new());
    let mut r50: Result<Vec<(usize, RecognizeResult)>> = Ok(Vec::new());
    let mut r100: Result<Vec<(usize, RecognizeResult)>> = Ok(Vec::new());
    std::thread::scope(|s| {
        let h30 = if items30.is_empty() {
            None
        } else {
            Some(s.spawn(|| p30.recognize_batch_indexed_single_session(items30)))
        };
        let h50 = if items50.is_empty() {
            None
        } else {
            Some(s.spawn(|| p50.recognize_batch_indexed_single_session(items50)))
        };
        let h100 = if items100.is_empty() {
            None
        } else {
            Some(s.spawn(|| p100.recognize_batch_indexed_single_session(items100)))
        };
        if let Some(h) = h30 {
            r30 = h
                .join()
                .unwrap_or_else(|_| Err(anyhow!("cascade 30 worker panicked")));
        }
        if let Some(h) = h50 {
            r50 = h
                .join()
                .unwrap_or_else(|_| Err(anyhow!("cascade 50 worker panicked")));
        }
        if let Some(h) = h100 {
            r100 = h
                .join()
                .unwrap_or_else(|_| Err(anyhow!("cascade 100 worker panicked")));
        }
    });
    (r30, r50, r100)
}

/// 2 プールバージョン (フォールバック redo50 / redo100 用)。
fn run_two_pools_skipping_empty(
    p50: &ParseqPool,
    items50: &[(usize, &[u8], usize, usize)],
    p100: &ParseqPool,
    items100: &[(usize, &[u8], usize, usize)],
) -> (
    Result<Vec<(usize, RecognizeResult)>>,
    Result<Vec<(usize, RecognizeResult)>>,
) {
    let active = (!items50.is_empty()) as u8 + (!items100.is_empty()) as u8;
    if active <= 1 {
        let r50 = if items50.is_empty() {
            Ok(Vec::new())
        } else {
            p50.recognize_batch_indexed_single_session(items50)
        };
        let r100 = if items100.is_empty() {
            Ok(Vec::new())
        } else {
            p100.recognize_batch_indexed_single_session(items100)
        };
        return (r50, r100);
    }
    let mut r50: Result<Vec<(usize, RecognizeResult)>> = Ok(Vec::new());
    let mut r100: Result<Vec<(usize, RecognizeResult)>> = Ok(Vec::new());
    std::thread::scope(|s| {
        let h1 = s.spawn(|| p50.recognize_batch_indexed_single_session(items50));
        let h2 = s.spawn(|| p100.recognize_batch_indexed_single_session(items100));
        r50 = h1
            .join()
            .unwrap_or_else(|_| Err(anyhow!("cascade redo50 panicked")));
        r100 = h2
            .join()
            .unwrap_or_else(|_| Err(anyhow!("cascade redo100 panicked")));
    });
    (r50, r100)
}

fn bucket_from_pred_char_count(pcc: Option<f32>) -> u8 {
    match pcc {
        Some(v) if (v - 3.0).abs() < 0.2 => 3,
        Some(v) if (v - 2.0).abs() < 0.2 => 2,
        _ => 100,
    }
}

#[cfg(test)]
#[path = "../../tests/support/dense_pool_orientation.rs"]
mod dense_pool_orientation_tests;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn batch_preprocess_policy_prefers_direct_for_small_batches() {
        assert!(use_direct_batch_preprocess(8, false));
        assert!(use_direct_batch_preprocess(8, true));
    }

    #[test]
    fn batch_preprocess_policy_keeps_allocating_path_for_large_horizontal_batches() {
        assert!(!use_direct_batch_preprocess(32, false));
    }

    #[test]
    fn batch_preprocess_policy_keeps_allocating_path_for_large_vertical_batches() {
        assert!(!use_direct_batch_preprocess(32, true));
    }
}

#[cfg(test)]
#[path = "../../tests/support/visible_repetitions_model.rs"]
mod visible_repetition_model_tests;

#[cfg(test)]
#[path = "../../tests/support/single_pixel_bridge_model.rs"]
mod single_pixel_bridge_model_tests;

#[cfg(test)]
#[path = "../../tests/support/detached_body_model.rs"]
mod detached_body_model_tests;

#[cfg(test)]
#[path = "../../tests/support/internal_detached_model.rs"]
mod internal_detached_model_tests;

#[cfg(test)]
#[path = "../../tests/support/punctuation_context_model.rs"]
mod punctuation_context_model_tests;

#[cfg(test)]
#[path = "../../tests/support/punctuation_context_capture.rs"]
mod punctuation_context_capture;

#[cfg(test)]
#[path = "../../tests/support/owned_parts_bridge_model.rs"]
mod owned_parts_bridge_model_tests;

#[cfg(test)]
#[path = "../../tests/support/narrow_round_model.rs"]
mod narrow_round_model_tests;

#[cfg(test)]
#[path = "../../tests/support/latin_pair_model.rs"]
mod latin_pair_model_tests;

#[cfg(test)]
#[path = "../../tests/support/latin_dotted_model.rs"]
mod latin_dotted_model_tests;

#[cfg(test)]
#[path = "../../tests/support/output_capacity_metadata.rs"]
mod output_capacity_metadata;
