from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parent;repo=Path.cwd();variant=sys.argv[1];source=root/({'baseline':'baseline-source','candidate':'source'}[variant]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((root/'source-origin.json').read_text())['baseline_source_files'];names=set(base)|{'tests/vertical_model_agreement_cli_tests.rs','tests/fixtures/vertical_model_agreement_cli/column.png','tests/fixtures/vertical_model_agreement_cli/truth.txt','tests/fixtures/vertical_model_agreement_cli/case.json'}
if variant=='candidate':names|={'src/app/vertical_model_agreement.rs','tests/support/vertical_model_agreement.rs'}
files={n:sha(source/n) for n in sorted(names)}
for n,h in json.loads((root/'default-suite-fixtures-v1.json').read_text())['files'].items():assert sha(source/n)==h
for p in source.rglob('*.rs'):p.touch()
argv=['cargo','test','--locked','--manifest-path',str(source/'Cargo.toml'),'--features','onnx','--test','vertical_model_agreement_cli_tests','--no-run','--message-format=json']
env=os.environ|{'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_DEV_STRIP':'none','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_STRIP':'none','CARGO_BUILD_JOBS':'1'}
with (root/(variant+'-build.jsonl')).open('xb') as stdout,(root/(variant+'-build.stderr')).open('xb') as stderr:
 result=subprocess.run(argv,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==0,(variant,result.returncode)
events=[json.loads(s) for s in (root/(variant+'-build.jsonl')).read_text().splitlines() if s.startswith('{')];wanted={('lib','ndlocr_lite_rs'):'lib',('bin','ndlocr-lite-rs'):'cli',('test','vertical_model_agreement_cli_tests'):'test'};found={}
for event in events:
 if event.get('reason')!='compiler-artifact' or event.get('manifest_path')!=str(source/'Cargo.toml'):continue
 key=(event['target']['kind'][0],event['target']['name'])
 if key in wanted:
  assert event['fresh'] is False and 'onnx' in event['features'],(variant,key)
  found[wanted[key]]=event
assert set(found)=={'lib','cli','test'}
binaries={}
for key in ['cli','test']:
 original=Path(found[key]['executable']);frozen=root/('known-'+variant+'-'+key);assert not frozen.exists();shutil.copyfile(original,frozen);frozen.chmod(0o755);assert original.read_bytes()==frozen.read_bytes();binaries[key]={'path':str(frozen),'bytes':frozen.stat().st_size,'sha256':sha(frozen),'compiler_artifact':found[key]}
assert all(sha(source/n)==h for n,h in files.items())
receipt={'variant':variant,'source':str(source),'source_files':files,'binaries':binaries,'own_artifacts':found,'build_stdout_sha256':sha(root/(variant+'-build.jsonl')),'argv':argv,'driver_sha256':sha(Path(__file__)),'NN_calls':0,'model_loads':0}
(root/(variant+'-frozen.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'variant':variant,'frozen':{k:v['sha256'] for k,v in binaries.items()},'own_artifacts_fresh':[v['fresh'] for v in found.values()]}))
