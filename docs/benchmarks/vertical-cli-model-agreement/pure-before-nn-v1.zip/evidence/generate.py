from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import datetime,hashlib,json

root=Path(__file__).resolve().parent;out=root/'inputs';out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fonts=json.loads(Path('tmp/vertical-prefix-capacity/generation-before-render.json').read_text())['fonts']
paragraph='午後の資料室では新しい地図を机に広げ、川と山の位置を順番に確かめました。窓から届く風で頁がめくれたので、青い箱を重しにして続きを読みました。廊下には時計の音が響き、隣の部屋から静かな話し声が聞こえました。休憩の時間には白い紙に道順を書き、遠くの町から来る友人へ手紙を送りました。帰る前に道具を棚へ戻し、入口の小さな灯りを消して外へ出ました。夕方の橋には鳥が集まり、流れる水に街の明かりが映っていました。'
lengths=[47,57,67,77,87,97,107,117];assert len(paragraph)>=max(lengths)
config={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paragraph':paragraph,'lengths':lengths,'fonts':fonts,'font_size':45,'advance':53,'padding':[4,16],'glyph_placement':'center each scalar ink width and align ink top to the cell top; same family as Q/S synthetic controls','repeated_patterns':['光','山川'],'repeated_length':77,'portrait_patterns':['午後の窓','No.7'],'portrait_rows':[28,36],'portrait_row_advance':64,'shape_patterns':['notched_rhombus','paired_brackets'],'shape_groups':[32,64,96,128],'shape_advance':58,'shape_width':61,'backgrounds':{'white':[255,255,255],'warm':[249,240,227],'gray':[187,191,195]},'spec_sha256':sha('docs/vertical_cli_model_agreement_proposal.md'),'generator_sha256':sha(__file__),'Pillow':__import__('PIL').__version__,'NN_calls':0,'model_loads':0}
(root/'generation-before-render.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
rows=[];glyphs=0

def save(ident,image,truth,cohort,**meta):
 paths={k:out/(ident+ext) for k,ext in [('image','.png'),('rgb','.rgb'),('truth','.txt')]}
 image.save(paths['image']);paths['rgb'].write_bytes(image.tobytes());paths['truth'].write_bytes(truth.encode())
 assert Image.open(paths['image']).convert('RGB').tobytes()==paths['rgb'].read_bytes()
 rows.append({'id':ident,**{k:str(v) for k,v in paths.items()},**{k+'_sha256':sha(v) for k,v in paths.items()},'width':image.width,'height':image.height,'cohort':cohort,**meta})

def vertical(info,font,text,padding,ident,cohort):
 global glyphs
 w,h=55+padding*2,len(text)*53+20+padding*2
 image=Image.new('RGB',(w,h),'white');independent=image.copy();boxes=[];last=0
 for i,char in enumerate(text):
  bounds=font.getbbox(char);gw=bounds[2]-bounds[0];mask=Image.new('L',(w,100),0)
  ImageDraw.Draw(mask).text(((w-gw)//2-bounds[0],-bounds[1]),char,font=font,fill=255)
  actual=mask.getbbox();assert actual is not None and actual[3]<=53
  top=10+padding+i*53;box=[actual[0],top+actual[1],actual[2],top+actual[3]];assert box[1]>=last and box[3]<=h
  last=box[3];boxes.append(box);glyphs+=1;image.paste((0,0,0),(0,top),mask)
  direct=font.getmask(char,mode='L');direct=Image.frombytes('L',direct.size,bytes(direct));independent.paste((0,0,0),((w-gw)//2,top),direct)
 assert image.tobytes()==independent.tobytes()
 save(ident,image,text,cohort,glyph_boxes=boxes,font=info['label'],font_sha256=info['sha256'],font_size=45,advance=53,padding=padding)

for info in fonts:
 assert sha(info['path'])==info['sha256'];font=ImageFont.truetype(info['path'],45,index=info['index'])
 for length in lengths:
  for padding in config['padding']:vertical(info,font,paragraph[:length],padding,f'c1_{info["label"]}_{length}_pad{padding}','new_c1_vertical_text')
 for n,pattern in enumerate(config['repeated_patterns']):
  text=(pattern*77)[:77]
  for padding in config['padding']:vertical(info,font,text,padding,f'c1_repeat_{info["label"]}_{n}_pad{padding}','new_c1_repeated')
 for n,text in enumerate(config['portrait_patterns']):
  bbox=font.getbbox(text);tw=bbox[2]-bbox[0];th=bbox[3]-bbox[1]
  for count in config['portrait_rows']:
   w=tw+32;h=count*config['portrait_row_advance']+32;image=Image.new('RGB',(w,h),'white');draw=ImageDraw.Draw(image)
   assert h>=8*w
   for y in range(count):draw.text((16-bbox[0],16+y*config['portrait_row_advance']-bbox[1]),text,font=font,fill='black')
   save(f'c1_portrait_{info["label"]}_{n}_{count}',image,'\n'.join([text]*count),'new_c1_portrait_horizontal',font=info['label'],font_sha256=info['sha256'],rows=count,row_text=text,font_size=45)
for background,color in config['backgrounds'].items():
 for pattern in config['shape_patterns']:
  for groups in config['shape_groups']:
   image=Image.new('RGB',(61,groups*58+32),tuple(color));draw=ImageDraw.Draw(image)
   for i in range(groups):
    y=16+i*58;shift=(i%3)-1;color_ink=(29,36,52)
    if pattern=='notched_rhombus':
     draw.line([(10,y+9),(24,y+2),(43,y+5),(51,y+18),(44,y+37),(30,y+46),(14,y+36),(7,y+22)],fill=color_ink,width=2)
     draw.line([(20,y+12),(41,y+30+shift)],fill=color_ink,width=3);draw.ellipse((29,y+11,33,y+15),fill=color_ink)
    else:
     draw.line([(7,y+18),(22,y+3),(50,y+17),(38,y+46),(12,y+34)],fill=color_ink,width=2)
     draw.line([(12,y+9),(41,y+36)],fill=color_ink,width=2);draw.line([(10,y+43),(23,y+43+shift)],fill=color_ink,width=3)
   save(f'c1_shape_{background}_{pattern}_{groups}',image,'','new_c1_nonletter',background=background,pattern=pattern,groups=groups,truth_convention='empty for drawn nonletter diagnostics')
assert len(rows)==96
assert glyphs==4860
counts={key:sum(r['cohort']==key for r in rows) for key in {r['cohort'] for r in rows}}
assert sorted(counts.values())==[12,12,24,48]
known=json.loads(Path('docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['physical_inputs']
for name in ['vertical-unique-insertion','vertical-low-stop-recovery','vertical-cli-fallback']:
 known+=json.loads((Path('tmp')/name/'new-manifest.json').read_text())['inputs']
known+=json.loads(Path('tmp/real-vertical-additional-controls/additional-controls-manifest-v1.json').read_text())['inputs']
old={r[k] for r in known for k in ['image_sha256','rgb_sha256']};new=[r[k] for r in rows for k in ['image_sha256','rgb_sha256']]
assert len(set(new))==192 and not set(new).intersection(old)
(root/'new-manifest.json').write_text(json.dumps({'inputs':rows},ensure_ascii=False,indent=2)+'\n')
(root/'generation-complete.json').write_text(json.dumps({'new_inputs':96,'cohorts':counts,'independently_reconstructed_vertical_glyphs':glyphs,'all_PNG_RGB_byte_exact':True,'duplicates_against_known1143':0,'known_physical_inputs':len(known),'NN_calls':0,'model_loads':0,'spec_sha256':config['spec_sha256']},indent=2)+'\n')
print('96 fixed, cohorts',counts,'glyphs',glyphs,'NN0')
