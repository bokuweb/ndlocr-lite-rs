from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.path.insert(0,'tools')
from verify_vertical_cli_model_agreement import verify
repo=Path.cwd();root=repo/'tmp/vertical-cli-model-agreement';pub=repo/'docs/benchmarks/vertical-cli-model-agreement';verified=verify(pub);assert verified['NN_calls_at_packet_creation']==0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assets=json.loads((repo/'docs/benchmarks/vertical-page-fallback/bundle.json').read_text())['assets'];plans={v:json.loads((root/(v+'-frozen.json')).read_text()) for v in ['baseline','candidate']}
ci=json.loads((repo/'tmp/vertical-page-supported-output/root-refactor-CI1547-success.json').read_text());assert ci['conclusion']=='success' and len(ci['jobs'])==5 and all(j['conclusion']=='success' for j in ci['jobs'])
def check():
 for a in assets.values():assert sha(repo/'models'/a['name'])==a['sha256']
 for d in plans.values():
  for n,h in d['source_files'].items():assert sha(Path(d['source'])/n)==h
  for binary in d['binaries'].values():assert sha(Path(binary['path']))==binary['sha256']
 for row in json.loads((root/'new-manifest.json').read_text())['inputs']:
  for key in ['image','rgb','truth']:assert sha(Path(row[key]))==row[key+'_sha256']
check();out=root/'known-regression-v1';out.mkdir();receipt={'complete':False,'driver_sha256':sha(Path(__file__)),'pre_NN_packet_sha256':sha(pub/'pure-before-nn-v1.zip'),'pre_NN_registry_sha256':sha(pub/'known-inputs-before-nn-v1.json.gz'),'pure_reader':verified,'baseline_root_CI':ci,'assets':assets,'plans':plans,'runs':[],'target_CLI_processes':2,'internal_forward_calls':None,'model_session_loads':None,'known_case_only':True,'new_controls_gain_count':0}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();env=os.environ.copy();env.update({'NDLOCR_INTRA_THREADS':'1','NDLOCR_PARSEQ_PARALLELISM':'1','NDLOCR_TEST_PARSEQ_MODEL':str(repo/'models'/assets['100']['name']),'NDLOCR_TEST_PARSEQ30_MODEL':str(repo/'models'/assets['30']['name']),'NDLOCR_TEST_PARSEQ50_MODEL':str(repo/'models'/assets['50']['name']),'NDLOCR_TEST_DEIM_MODEL':str(repo/'models'/assets['deim']['name']),'NDLOCR_TEST_CHARSET':str(repo/'models'/assets['charset']['name'])});receipt['runtime_environment']={k:v for k,v in env.items() if k.startswith('NDLOCR_')}
try:
 for v,d in plans.items():
  env['NDLOCR_TEST_CLI_BINARY']=d['binaries']['cli']['path'];argv=[d['binaries']['test']['path'],'--include-ignored','--nocapture'];start=time.monotonic()
  with (out/(v+'.stdout')).open('wb') as stdout,(out/(v+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=d['source'],env=env,stdout=stdout,stderr=stderr)
  receipt['runs'].append({'variant':v,'argv':argv,'cwd':d['source'],'CLI_binary':env['NDLOCR_TEST_CLI_BINARY'],'exit_code':result.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(out/(v+'.stdout')),'stderr_sha256':sha(out/(v+'.stderr'))});save()
  assert result.returncode=={'baseline':101,'candidate':0}[v],(v,result.returncode)
  if v=='baseline':assert 'literal 71-scalar body' in (out/(v+'.stderr')).read_text()
 check();receipt.update(complete=True,frozen_materials_after_unchanged=True,known_Red_Green=True,candidate_body_and_stdout_verified_by_literal_test=True,candidate_raw_body_not_retained_by_test=True)
except Exception as error:receipt['error']=repr(error);raise
finally:save()
print(json.dumps({'complete':True,'runs':receipt['runs'],'known_case_only':True,'new_gain_count':0}))
