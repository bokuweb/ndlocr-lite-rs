from pathlib import Path
import json,hashlib,shutil,sys
r=Path('tmp/detached-body');phase=sys.argv[1];build=sys.argv[2];prefix=sys.argv[3];rows=[json.loads(s)for s in(r/build).read_text().splitlines()];xs=[x for x in rows if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='ndlocr_lite_rs'];assert len(xs)==1
b=r/(phase+'-binary');shutil.copy2(xs[0]['executable'],b);root=r/(phase+'-source');root.mkdir();hs={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),*Path('examples').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),Path('docs/detached_body_components.md')]:
 q=root/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
meta={'binary_sha256':sha(b),'source_sha256':hs,'models':{str(p):sha(p)for p in Path('models').iterdir()if p.suffix in['.onnx','.yaml']},'argv':[str(b.resolve()),prefix,'--exact','--ignored','--nocapture'],'env':{'NDLOCR_INTRA_THREADS':'1'},'fixture_sha256':sha('tests/fixtures/detached_body_components/info_round40.png')};(r/(phase+'-command.json')).write_text(json.dumps(meta,indent=2)+'\n');print('frozen',phase,flush=True)
