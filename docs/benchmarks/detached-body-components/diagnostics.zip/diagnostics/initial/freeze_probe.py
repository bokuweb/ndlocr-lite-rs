from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/detached-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((r/'manifest.json').read_text())
for p,h in m['rgb_sha256'].items():assert sha(p)==h,p
xs=[x for s in(r/'probe-build.jsonl').read_text().splitlines()if(x:=json.loads(s)).get('reason')=='compiler-artifact'and x.get('executable')];assert len(xs)==1;b=r/'probe-binary';shutil.copy2(xs[0]['executable'],b);root=r/'probe-source';root.mkdir();hs={}
for p in [*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),Path('docs/detached_body_components.md'),Path('tests/fixtures/detached_body_components/info_round40.png')]:
 q=root/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
meta={'source_base':'db25206 + staged single-pixel bridge;new detached-body module is cfg(test) only','source_sha256':hs,'binary_sha256':sha(b),'manifest_sha256':sha(r/'manifest.json'),'spec_sha256':sha('docs/detached_body_components.md'),'driver_sha256':sha(__file__),'argv':[str(b.resolve()),'infer::visible_repetitions::detached_body_components::tests::record_detached_body_policy','--exact','--ignored','--nocapture'],'env':{'NDLOCR_DETACHED_ROOT':str(r)},'scope':'fixed raw pairs through actual product baseline and test-only proposal;no NN forwards'};(r/'probe-command.json').write_text(json.dumps(meta,indent=2)+'\n');print('source/executable/33735 raw pairs/11117 RGB paths frozen',flush=True)
