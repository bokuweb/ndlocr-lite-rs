from pathlib import Path
import json,hashlib,shutil
r=Path('tmp/detached-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[json.loads(s)for s in(r/'tensor-build.jsonl').read_text().splitlines()];xs=[x for x in rows if x.get('reason')=='compiler-artifact'and x.get('executable')];assert len(xs)==1;b=r/'tensor-binary';shutil.copy2(xs[0]['executable'],b);root=r/'tensor-source';root.mkdir();hs={}
for p in[*Path('src').rglob('*.rs'),*Path('tests/support').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),Path('docs/detached_body_components.md')]:
 q=root/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);hs[str(p)]=sha(p)
m=json.loads((r/'fresh/evaluation-manifest.json').read_text());assert len(m['inputs'])==10944
for x in m['inputs']:
 for key in ['rgb','effective_rgb','truth','image','original']:assert sha(x[key])==x[key+'_sha256']
meta={'source_sha256':hs,'binary_sha256':sha(b),'manifest_sha256':sha(r/'fresh/evaluation-manifest.json'),'baseline_commit':'0127fe8ab78930cdd93a5b24b40bdd59a16f1bdc','qa':{'contact_sha256':sha(r/'fresh/contact.png'),'reviewed_samples':72,'observation':'three fonts and both new bodies readable;body-space variants and external noise retained'},'argv':[str(b.resolve()),'infer::visible_repetitions::detached_body_components::tests::verify_fresh_detached_auto_tensors','--exact','--ignored','--nocapture'],'env':{'NDLOCR_DETACHED_ROOT':str(r)}};(r/'tensor-command.json').write_text(json.dumps(meta,indent=2)+'\n')
