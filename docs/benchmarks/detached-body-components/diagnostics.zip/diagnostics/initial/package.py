from pathlib import Path
import json,hashlib,zipfile,sys
r=Path('tmp/detached-body');p=Path('tmp/detached-positive');out=Path(sys.argv[1]if len(sys.argv)>1 else'docs/benchmarks/detached-body-components');out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def packet(name,files):
 if len(sys.argv)>2 and name not in sys.argv[2:]:return
 seen={};members={};aliases={};path=out/(name+'.zip')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for key,source in sorted(files.items()):
   b=source if isinstance(source,bytes)else source.read_bytes();h=sha(b)
   if h in seen:aliases[key]={'source':seen[h],'sha256':h};continue
   seen[h]=key;members[key]=h;info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
  key=name+'-aliases.json';b=(json.dumps(aliases,indent=2)+'\n').encode();members[key]=sha(b);info=zipfile.ZipInfo(key,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 index={'sha256':sha(path.read_bytes()),'member_count':len(members),'logical_member_count':len(files),'members':members};(out/(name+'.json')).write_text(json.dumps(index,indent=2)+'\n');print(name,len(members),len(files),path.stat().st_size,flush=True)
for prefix,root in [('initial',r),('positive',p)]:
 images={};inputs={}
 for folder in ['fresh','horizontal']:
  directory=root/folder
  if not directory.exists():continue
  for part in ['native','original','png','rgb','effective','truth']:
   for f in(directory/part).rglob('*'):
    if f.is_file():images[prefix+'/'+str(f.relative_to(root))]=f
  for f in directory.iterdir():
   if f.is_file()and(f.name in['atlas.png','lines.json','evaluation-manifest.json']or f.name.startswith('contact')):images[prefix+'/'+str(f.relative_to(root))]=f
  for f in(directory/'whole-rgb-capture').rglob('*'):
   if f.is_file():inputs[prefix+'/'+str(f.relative_to(root))]=f
 packet(prefix+'-images',images);packet(prefix+'-inputs',inputs)
diag={};text={}
for prefix,root in [('initial',r),('positive',p)]:
 for f in root.iterdir():
  if f.is_file()and f.suffix in['.json','.jsonl','.py','.swift','.md','.log','.stdout','.stderr']and not f.name.startswith('package-'):
   diag['diagnostics/'+prefix+'/'+f.name]=f
 for folder in ['probe-source','tensor-source','integration-red-source','integration-green-source','verification-source']:
  for f in(root/folder).rglob('*'):
   if f.is_file():diag['diagnostics/'+prefix+'/'+str(f.relative_to(root))]=f
 for folder in ['fresh','horizontal']:
  directory=root/folder
  for f in(directory/'export-source').rglob('*'):
   if f.is_file():diag['diagnostics/'+prefix+'/'+str(f.relative_to(root))]=f
  for f in directory.glob('*'):
   if f.is_file()and f.suffix in['.json','.stdout','.stderr','.md']and f.name not in['lines.json','evaluation-manifest.json']and not f.name.startswith('contact'):diag['diagnostics/'+prefix+'/'+str(f.relative_to(root))]=f
 for folder in ['fresh-baseline','fresh-policy','previous-bridge-audit','horizontal-baseline','horizontal-policy','horizontal-previous-bridge-audit','geometry']:
  directory=root/folder
  for f in directory.glob('*'):
   if f.is_file()and f.suffix in['.json','.stdout','.stderr']:diag['diagnostics/'+prefix+'/'+str(f.relative_to(root))]=f
  for nested in ['replay','existing-replay']:
   f=directory/nested/'records.json'
   if f.exists():diag['diagnostics/'+prefix+'/'+str(f.relative_to(root))]=f
 for folder in ['scores','fresh-policy/scores','previous-bridge-audit/scores','horizontal-policy/scores','horizontal-previous-bridge-audit/scores']:
  for f in(root/folder).rglob('*'):
   if f.is_file():text['text/'+prefix+'/'+str(f.relative_to(root))]=f
for f in(r/'replay').glob('*.json'):diag['diagnostics/initial/replay/'+f.name]=f
for f in(r/'line-cli').rglob('*'):
 if f.is_file():text['text/initial/line-cli/'+str(f.relative_to(r/'line-cli'))]=f
cases=json.loads((r/'product-manifest.json').read_text())['cases'];portable=[]
for x in cases:
 if x['corpus']in['old','spaces','fresh','horizontal']:path='parent/data/rgb/'+x['corpus']+'/'+x['id']+'.rgb'
 elif x['corpus']=='new':path='initial/fresh/rgb/'+x['id']+'.rgb'
 else:
  assert x['corpus']in['positive','positive-horizontal'];path='positive/fresh/rgb/'+x['id']+'.rgb'
 portable.append(x|{'rgb':path})
diag['diagnostics/portable-cases.json']=(json.dumps({'cases':portable},ensure_ascii=False,indent=2)+'\n').encode();diag['diagnostics/source/eval_ocr_metrics.py']=Path('tools/eval_ocr_metrics.py');diag['diagnostics/dependencies/means.py']=Path('tmp/punct-matched/means.py')
for name in ['detached_body_components','detached_body_positive_controls','detached_body_integration','single_pixel_body_bridge_additional_controls']:diag['diagnostics/spec/'+name+'.md']=Path('docs/'+name+'.md')
for f in Path('tests/fixtures/detached_body_components').iterdir():
 if f.is_file():diag['diagnostics/fixtures/'+f.name]=f
parent=Path('docs/benchmarks/single-pixel-body-bridge');parents={'baseline_commit':'0127fe8ab78930cdd93a5b24b40bdd59a16f1bdc','packet':'single-pixel-body-bridge','archives':{name:json.loads((parent/(name+'.json')).read_text())['sha256']for name in['data','diagnostics','text']},'reproducer_sha256':sha((parent/'reproduce.py').read_bytes())};(out/'parents.json').write_text(json.dumps(parents,indent=2)+'\n');packet('diagnostics',diag);packet('text',text)
