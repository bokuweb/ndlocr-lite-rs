from pathlib import Path
import json,hashlib,struct,zipfile,sys,collections
sys.path.insert(0,'tmp/punct-matched');from means import emitted_means
r=Path('tmp/detached-body');pos=Path('tmp/detached-positive');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();batches=[(r/'manifest.json',r/'replay/records.json'),(r/'fresh-policy/manifest.json',r/'fresh-policy/replay/records.json'),(pos/'fresh-policy/manifest.json',pos/'fresh-policy/replay/records.json'),(pos/'horizontal-policy/manifest.json',pos/'horizontal-policy/replay/records.json')];cases=[];seen=set();rgb_hashes={}
for manifest,records in batches:
 refs={(x['corpus'],x['model'],x['id']):x for x in json.loads(records.read_text())}
 for x in json.loads(manifest.read_text())['cases']:
  key=x['corpus'],x['model'],x['id'];assert key not in seen;seen.add(key);y=refs[key];assert x['raw']==y['raw'];p=x['rgb']
  if p not in rgb_hashes:rgb_hashes[p]=sha(p)
  if x.get('rgb_sha256'):assert rgb_hashes[p]==x['rgb_sha256']
  cases.append(x|{'orientation':x.get('orientation','auto'),'rgb_sha256':rgb_hashes[p],'expected_before':y['baseline'],'expected_after':y['candidate'],'selected':y['selected']})
assert len(cases)==99591 and sum(x['selected']for x in cases)==394
(r/'product-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');by_key={(x['corpus'],x['model'],x['id']):x for x in cases};means={}
with zipfile.ZipFile('docs/benchmarks/contained-closer-components/diagnostics.zip')as z:old=json.loads(z.read('probe.json'))
for m in old['models']:
 for x in m['rows']:means['old',m['label'].removeprefix('single'),x['id']]=x['mean_confidence']
for corpus,folder in [('new',r/'fresh'),('positive',pos/'fresh'),('positive-horizontal',pos/'horizontal')]:
 for model in ['30','50','100']:
  for x in json.loads((folder/(model+'-export.json')).read_text()):means[corpus,model,x['id']]=emitted_means(x)[0]
selected={k for k,x in by_key.items()if x['selected']};matrix=set(selected);cli=set(selected);coverage={}
for corpus,folder in [('new',r/'fresh'),('positive',pos/'fresh')]:
 rows=json.loads((folder/'evaluation-manifest.json').read_text())['inputs'];ids=set();noise_cli=set()
 for fi,font in enumerate(['maru','gothic','mincho']):
  sizes=sorted({x['size']for x in rows})
  for si,size in enumerate(sizes):
   for sh,shape in enumerate(['none','thin','thick','dot']):
    for leading in [False,True]:
     for fm,fmt in enumerate(['png','jpeg75']):
      settings={'kind':'noise','font':font,'size':size,'shape':shape,'leading':leading,'format':fmt,'body_spaces':(fi+si+sh+int(leading)+fm)%3,'palt':(sh+int(leading))%2,'gap':(si+fm)%2,'body_id':(fi+sh)%2};matches=[x for x in rows if all(x[k]==v for k,v in settings.items())];assert len(matches)==1;ids.add(matches[0]['id'])
      if not leading:noise_cli.add(matches[0]['id'])
   for ci,closer in enumerate([')','）','」','』','】']):
    for leading in [False,True]:
     for fm,fmt in enumerate(['png','jpeg75']):
      settings={'kind':'text','font':font,'size':size,'closer':closer,'leading':leading,'format':fmt,'body_spaces':(fi+ci+int(leading))%3,'spaces':(si+ci+fm)%3,'palt':(ci+int(leading))%2,'body_id':(fi+si+ci)%2,'paper':[0,8][(ci+fm)%2]};matches=[x for x in rows if all(x[k]==v for k,v in settings.items())];assert len(matches)==1;ids.add(matches[0]['id'])
 assert len(ids)==216 and len(noise_cli)==48;coverage[corpus]={'boundary_ids':sorted(ids),'cli_noise_ids':sorted(noise_cli)}
 for id in ids:
  for model in ['30','50','100']:matrix.add((corpus,model,id))
 for id in noise_cli:
  for model in ['30','50','100']:cli.add((corpus,model,id))
for key in by_key:
 if key[0]=='positive-horizontal':matrix.add(key)
native=[]
for key in sorted(matrix):
 x=by_key[key];bits=struct.unpack('<I',struct.pack('<f',means[key]))[0];native.append(x|{'mean_bits':bits})
counts=dict(collections.Counter(x['model']for x in native));native_meta={'cases':native,'counts':counts,'coverage':coverage,'selected_model_pairs':394};(r/'native-manifest.json').write_text(json.dumps(native_meta,ensure_ascii=False,indent=2)+'\n');cli_cases=[by_key[k]for k in sorted(cli)];assert all(x['orientation']=='auto'for x in cli_cases);(r/'cli-manifest.json').write_text(json.dumps({'cases':cli_cases,'selected_model_pairs':394,'boundary_noise_model_pairs':288},ensure_ascii=False,indent=2)+'\n');print('99591 product pairs;native',len(native),counts,'CLI',len(cli_cases),'all394 changes included',flush=True)
