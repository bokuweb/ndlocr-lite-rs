use super::*;

const MODELS: [&str; 3] = [
    "parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx",
    "parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx",
    "parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx",
];

#[test]
#[ignore = "requires pinned PARSeq models"]
fn detached_parts_keep_the_model_closer_in_single_line_apis() {
    let image = crate::io::load_rgb_u8(Path::new(
        "tests/fixtures/detached_body_components/info_round40.png",
    ))
    .unwrap();
    let (rgb, w, h) = (&image.data, image.width, image.height);
    let untouched = rgb.clone();
    let input = [(rgb.as_slice(), w, h)];
    let charset = Path::new("models/NDLmoji.yaml");
    for file in MODELS {
        let model = Path::new("models").join(file);
        let session = ParseqSession::load(&model, charset).unwrap();
        let pool = ParseqPool::load(&model, charset, 2).unwrap();
        let fragments = ParseqPool::load_for_fragments(&model, charset, 1).unwrap();
        let raw = session.recognize_rgb_u8_unprocessed(rgb, w, h).unwrap();
        assert_eq!(
            raw.text, "情報)",
            "model itself already reads the closer: {file}"
        );
        let processed = session.recognize_rgb_u8(rgb, w, h).unwrap();
        assert_eq!(
            processed.text, "情報)",
            "preserve the supported model closer: {file}"
        );
        assert_eq!(
            processed.mean_confidence.to_bits(),
            raw.mean_confidence.to_bits()
        );
        for actual in [
            pool.recognize_rgb_u8(rgb, w, h).unwrap(),
            fragments.recognize_rgb_u8(rgb, w, h).unwrap(),
            session.recognize_batch_rgb_u8(&input).unwrap().remove(0),
            pool.recognize_batch_rgb_u8(&input).unwrap().remove(0),
            pool.recognize_batch_single_session_rgb_u8(&input)
                .unwrap()
                .remove(0),
            pool.recognize_batch_single_session_horizontal_rgb_u8(&input)
                .unwrap()
                .remove(0),
            crate::infer::parseq::recognize_rgb_u8_with_score(&model, rgb, w, h, charset).unwrap(),
        ] {
            assert_eq!(actual.text, raw.text, "{file}");
            assert_eq!(
                actual.mean_confidence.to_bits(),
                raw.mean_confidence.to_bits()
            );
        }
        let candidates = session
            .recognize_rgb_u8_candidates_with_orientation(rgb, w, h, ParseqOrientation::Auto, 2)
            .unwrap();
        assert_eq!(candidates.recognition.text, raw.text);
        assert_eq!(
            candidates.recognition.mean_confidence.to_bits(),
            raw.mean_confidence.to_bits()
        );
        assert!(session.recognize_rgb_u8(&[], w, h).is_err());
        assert_eq!(session.recognize_rgb_u8(rgb, w, h).unwrap().text, raw.text);
        assert_eq!(*rgb, untouched);
    }
    let cascade = ParseqCascadePool::load(
        &Path::new("models").join(MODELS[0]),
        &Path::new("models").join(MODELS[1]),
        &Path::new("models").join(MODELS[2]),
        charset,
        1,
    )
    .unwrap();
    let items: Vec<_> = [3.0, 2.0, 1.0]
        .into_iter()
        .map(|bucket| (rgb.as_slice(), w, h, Some(bucket)))
        .collect();
    assert_eq!(
        cascade
            .recognize_batch_with_buckets_rgb_u8(&items)
            .unwrap()
            .iter()
            .map(|x| x.text.as_str())
            .collect::<Vec<_>>(),
        ["情報)"; 3]
    );
}
