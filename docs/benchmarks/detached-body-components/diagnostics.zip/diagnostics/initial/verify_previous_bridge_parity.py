from pathlib import Path
import json,hashlib
r=Path('tmp/detached-body/previous-bridge-audit');current={(x['model'],x['id']):x['text']for x in json.loads((r/'actual-current.json').read_text())};records=json.loads((r/'existing-replay/records.json').read_text());assert len(records)==len(current)==32832
for x in records:assert x['candidate']==current[x['model'],x['id']],(x['model'],x['id'])
(r/'parity.json').write_text(json.dumps({'pairs':32832,'before_diagnostic_candidate_matches_actual_0127_policy':True,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n');print('32832 before-diagnostic candidate outputs match actual0127 product',flush=True)
