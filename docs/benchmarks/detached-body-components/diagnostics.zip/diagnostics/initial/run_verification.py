from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,os
r=Path('tmp/detached-body');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();meta=json.loads((r/'verification-command.json').read_text());b=r/'verification-binary';assert sha(b)==meta['binary_sha256']
for p,h in meta['models'].items():assert sha(p)==h
meta.update({'driver_sha256':sha(__file__),'product_manifest_sha256':sha(r/'product-manifest.json'),'native_manifest_sha256':sha(r/'native-manifest.json')});(r/'verification-command.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,test,extra):
 argv=[str(b.resolve()),test,'--exact','--ignored','--nocapture'];env={'NDLOCR_INTRA_THREADS':'1'}|extra;record={'argv':argv,'env':env};cmd=r/(name+'-command.json');assert not cmd.exists();cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as stdout,(r/(name+'.stderr')).open('wb')as stderr:done=subprocess.run(argv,env=os.environ|env,stdout=stdout,stderr=stderr)
 record['exit_code']=done.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name;print(name,'terminal success',flush=True)
run('product-replay','infer::visible_repetitions::detached_body_components::tests::verify_product_matches_frozen_detached_policy',{'NDLOCR_DETACHED_PRODUCT_MANIFEST':str(r/'product-manifest.json')})
def native(model):return run('native'+model,'infer::cached::detached_body_model_tests::verify_changed_and_boundary_cases_through_public_apis',{'NDLOCR_DETACHED_NATIVE_MANIFEST':str(r/'native-manifest.json'),'NDLOCR_DETACHED_MODEL':model,'NDLOCR_DETACHED_NATIVE_OUTPUT':str(r/('native'+model+'-results.json'))})
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(native,['30','50','100']))
