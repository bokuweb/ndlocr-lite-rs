from pathlib import Path
import json,hashlib,subprocess,os
r=Path('tmp/detached-positive');py='/Users/bokuweb/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();scripts=['assemble_horizontal.py','prepare_horizontal_previous_bridge.py','verify_horizontal_previous_parity.py','score_horizontal_previous.py','assemble_horizontal_candidate.py','score_horizontal.py'];(r/'horizontal-policy-evaluation-command.json').write_text(json.dumps({'driver_sha256':sha(__file__),'scripts':{s:sha(r/s)for s in scripts},'means_helper_sha256':sha('tmp/punct-matched/means.py'),'scorer_sha256':sha('tools/eval_ocr_metrics.py'),'scope':'fixed new NN outputs through before/current/prototype Rust policies;no additional NN forwards'},indent=2)+'\n')
def execute(name,argv,extra={}):
 record={'argv':argv,'env':extra};cmd=r/(name+'-command.json');assert not cmd.exists();cmd.write_text(json.dumps(record,indent=2)+'\n')
 with(r/(name+'.stdout')).open('wb')as stdout,(r/(name+'.stderr')).open('wb')as stderr:done=subprocess.run(argv,env=os.environ|extra,stdout=stdout,stderr=stderr)
 record['exit_code']=done.returncode;cmd.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name;print(name,'terminal success',flush=True)
def script(name):execute('horizontal-'+name,[py,str(r/(name+'.py'))])
def saved(name,path):
 meta=json.loads(path.read_text());execute(name,meta['argv'],meta['env'])
script('assemble_horizontal');saved('horizontal-current-baseline',r/'horizontal-baseline/baseline-command.json');script('prepare_horizontal_previous_bridge');saved('horizontal-before-bridge',r/'horizontal-previous-bridge-audit/before-command.json');script('verify_horizontal_previous_parity');script('score_horizontal_previous');script('assemble_horizontal_candidate');saved('horizontal-detached-candidate',r/'horizontal-policy/candidate-command.json');script('score_horizontal')
