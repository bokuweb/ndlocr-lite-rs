from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib
r=Path('tmp/detached-positive');f=r/'fresh';m=json.loads((f/'evaluation-manifest.json').read_text());rows=[]
for x in m['inputs']:
 if x['kind']!='noise' or x['format']!='png':continue
 key=f'd_t{x["body_id"]}_bs{x["body_spaces"]}_{x["font"]}_{x["size"]}_p{x["palt"]}_bare';native=Image.open(f/'native'/(key+'.png')).convert('RGB');box=ImageChops.difference(native,Image.new('RGB',native.size,'white')).getbbox();body=native.crop((box[0]-2,box[1]-2,box[2]+2,box[3]+2));sx,sy,ex,ey=x['shape_bounds'];mw=ex-sx;shift=mw+x['gap'];offset=shift if x['leading']else 0;overlap=sum(body.getpixel((xx,yy))!=(255,255,255)and sx<=xx+offset<ex and sy<=yy<ey for yy in range(body.height)for xx in range(body.width));assert overlap==0
 expected=Image.new('RGB',(body.width+shift,body.height),'white');expected.paste(body,(offset,0))
 if mw:expected.paste((0,0,0),(sx,sy,ex,ey))
 actual=Image.open(x['image']).convert('RGB');assert expected.size==actual.size and expected.tobytes()==actual.tobytes();rows.append({'id':x['id'],'native_body':key,'pre_jpeg_glyph_overlap_pixels':overlap,'reconstructed_png_rgb_sha256':hashlib.sha256(expected.tobytes()).hexdigest()})
assert len(rows)==1152;(r/'noise-pixel-audit.json').write_text(json.dumps({'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'png_and_jpeg_pairs':1152,'all_shape_glyph_overlap_counts_zero':True,'all_png_reconstructions_byte_equal':True,'rows':rows},indent=2)+'\n');print('1152 pre-JPEG controls reconstructed;all shape/glyph overlap counts0',flush=True)
