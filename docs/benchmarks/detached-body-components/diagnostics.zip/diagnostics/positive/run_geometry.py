from pathlib import Path
import json,hashlib,subprocess,os,shutil
r=Path('tmp/detached-positive');out=r/'geometry';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((r/'fresh/evaluation-manifest.json').read_text());cases=[]
for x in m['inputs']:
 assert sha(x['rgb'])==x['rgb_sha256']and sha(x['truth'])==x['truth_sha256'];cases.append({'corpus':'geometry','model':'geometry','id':x['id'],'raw':Path(x['truth']).read_text(),'truth':Path(x['truth']).read_text(),'rgb':x['rgb'],'rgb_sha256':x['rgb_sha256'],'width':x['width'],'height':x['height'],'expected_baseline':None})
assert len(cases)==10944;(out/'existing-manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');sources={'baseline':(Path('tmp/closer-bridge/verification-binary'),Path('tmp/closer-bridge/verification-command.json')),'candidate':(Path('tmp/detached-body/probe-binary'),Path('tmp/detached-body/probe-command.json'))};meta={'scope':'GEOMETRY ONLY: truth supplied as hypothetical raw;not model predictions or accuracy measurement','generator_sha256':sha(r/'prepare_fresh.py'),'driver_sha256':sha(__file__),'spec_sha256':sha('docs/detached_body_positive_controls.md'),'input_manifest_sha256':sha(r/'fresh/evaluation-manifest.json'),'binaries':{}}
for name,(p,record)in sources.items():
 expected=json.loads(record.read_text());assert sha(p)==expected['binary_sha256'];shutil.copy2(p,out/(name+'-binary'));meta['binaries'][name]={'binary_sha256':sha(p),'source_record_sha256':sha(record)}
(out/'freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
def execute(name,test,env):
 argv=[str((out/(name+'-binary')).resolve()),test,'--exact','--ignored','--nocapture'];record={'argv':argv,'env':env};p=out/(name+'-command.json');p.write_text(json.dumps(record,indent=2)+'\n')
 with(out/(name+'.stdout')).open('wb')as stdout,(out/(name+'.stderr')).open('wb')as stderr:done=subprocess.run(argv,env=os.environ|env,stdout=stdout,stderr=stderr)
 record['exit_code']=done.returncode;p.write_text(json.dumps(record,indent=2)+'\n');assert done.returncode==0,name
execute('baseline','infer::visible_repetitions::single_pixel_bridge::tests::record_existing_bridge_policy',{'NDLOCR_BRIDGE_ROOT':str(out)});rs={(x['model'],x['id']):x for x in json.loads((out/'existing-replay/records.json').read_text())}
for x in cases:
 y=rs[x['model'],x['id']];assert y['baseline']==y['candidate'];x['expected']=y['baseline']
(out/'manifest.json').write_text(json.dumps({'cases':cases},ensure_ascii=False,indent=2)+'\n');execute('candidate','infer::visible_repetitions::detached_body_components::tests::record_detached_body_policy',{'NDLOCR_DETACHED_ROOT':str(out)});rows=json.loads((out/'replay/records.json').read_text());selected=[x for x in rows if x['selected']];assert len(rows)==10944
truth={x['id']:x['truth']for x in cases}
for x in selected:assert x['candidate']==truth[x['id']]
result={'scope':meta['scope'],'images':10944,'hypothetical_correct_raw_changes':len(selected),'all_changed_outputs_equal_supplied_truth':True,'selected':selected};(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('hypothetical correct-raw geometry changes',len(selected),flush=True);assert selected,'no reachable positive geometry;do not run NN'
