# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `128`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 128 | 0 | 0.1406 | 0.4219 |
| candidate | 128 | 0 | 0.1406 | 0.4219 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
