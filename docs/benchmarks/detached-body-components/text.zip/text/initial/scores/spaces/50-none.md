# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `4598`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 4598 | 0 | 0.1209 | 0.7742 |
| candidate | 4598 | 0 | 0.1209 | 0.7742 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
