# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `10944`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 10944 | 0 | 0.2288 | 0.5310 |
| baseline | 10944 | 0 | 0.2313 | 0.5376 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
