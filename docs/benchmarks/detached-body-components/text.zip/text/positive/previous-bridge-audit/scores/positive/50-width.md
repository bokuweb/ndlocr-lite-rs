# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `10944`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| candidate | 10944 | 0 | 0.5184 | 0.9265 |
| baseline | 10944 | 0 | 0.5185 | 0.9266 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
