# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `10944`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 10944 | 0 | 0.3489 | 0.6696 |
| candidate | 10944 | 0 | 0.3489 | 0.6696 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
