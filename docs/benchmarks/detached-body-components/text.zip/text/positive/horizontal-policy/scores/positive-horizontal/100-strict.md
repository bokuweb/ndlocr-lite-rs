# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `64`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 64 | 0 | 0.2083 | 0.3750 |
| candidate | 64 | 0 | 0.2083 | 0.3750 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
