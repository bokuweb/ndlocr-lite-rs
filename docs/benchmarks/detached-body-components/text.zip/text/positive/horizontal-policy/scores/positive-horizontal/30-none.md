# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `64`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| baseline | 64 | 0 | 0.1979 | 0.5625 |
| candidate | 64 | 0 | 0.1979 | 0.5625 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
