from pathlib import Path
import json
r=Path('tmp/missing-context-recovery');out=Path('docs/benchmarks/missing-line-context');s=json.loads((r/'summary.json').read_text());t=json.loads((r/'tests-summary.json').read_text());a=json.loads((r/'audit.json').read_text());b=json.loads((r/'single-audit.json').read_text());assert not a['regressions']and not a['word_regressions']and not b['regressions']and not b['word_regressions'];improved=sum(x['raw_char_improved']for x in s.values());equal=sum(x['byte_equal']for x in s.values());ties=sum(x['raw_char_ties_changed']for x in s.values());assert(improved,equal,ties)==(51,2450,10)
labels={'deim':'CLI DEIM','bands':'CLI bands','runtime30_eval':'PageRecognizer30 評価設定','runtime30_default':'PageRecognizer30 既定設定','runtime100_eval':'PageRecognizer100 評価設定','runtime100_default':'PageRecognizer100 既定設定','single30':'単行30','single50':'単行50','single100':'単行100'};table='| 経路 | 画像数 | 生文字距離改善 | byte同一 | 距離同じで本文変更 |\n| --- | ---: | ---: | ---: | ---: |\n'+'\n'.join(f"| {labels[k]} | {x['images']} | {x['raw_char_improved']} | {x['byte_equal']} | {x['raw_char_ties_changed']} |"for k,x in s.items())
readme=f'''# 検出枠が覆わない横書き行の全体文脈を確認する

実装前仕様: `docs/missing_line_context_recovery.md`。比較元270f85a（製品sourceはbae38d3と同一）。
先行の `docs/benchmarks/missing-line-context-probe/` で、一律全体置換にはnative内/高confidenceでも
退行があることと、全文枠を欠く混合A1画像の既定APIに改善候補があることを分離した。
新しい資料/真値は追加せず、固定287画像と単行263画像を全件比較する。
既知資料・合成フォント/変形の開発回帰で、未知の独立文書holdoutではない。

既存の全認識・options・包含断片整理の後、非空結果のbbox和集合に覆われない220前景があり、
横書き帯が1本で文字画素支持を満たす場合だけ、原画像と全文前景を含む帯cropを調べる。
同じ供給primaryのnative比率内の候補だけをHorizontalで追加認識する。
元の非空白文字数で重み付けした平均confidenceを厳密に上回る候補だけを選ぶ。
固定.9のfloor、真値/文書種類/語句の条件、文字の推測置換は使わない。

候補のRGB・text・confidenceを保持し、採用候補bboxの1行として返す。
追加確認失敗時や元枠が全文前景を覆う場合は元結果を保持する。空出力から新たな行は追加しない。
単行/raw APIと辞書/ルールpackを変更せず、CLIでは外部辞書の前に適用する。
CLIの既存cascadeとprimaryのconfidence比較も、通過を仮定せず全574プロセスで評価した。

## 全件結果

ページ287×6×3=5166と単行263×3×3=2367、全7533画像別文字指標と単語指標が非悪化。
単行の全789本文は元出力とbyte同一。2511本文組の生文字距離51組が改善、2450組同一、10組同値変更。
同値の文字種誤読を改善に数えない。3正規化やモデル/cropの違いを独立資料とも数えない。

{table}

改善は既存長短行対照24本文組、追加反復対照27本文組。既存実資料20画像の本文は今回同一だった。
混合A1 JPEGのAPI既定出力は、30モデルが5断片の13誤り→1行4誤り、100モデルが9→4。
100候補のconfidence .893も既存平均 .737を上回るため扱えるが、1/l/I等の文字種誤読は残る。

先行の未検出行復旧には単語指標12件の退行があり、今回の非悪化がその過去の比較を取り消すものではない。
全27組のCSV/MD、cohort別件数と全単語指標を保存する。

## 追加確認と検証

API評価/既定の30モデルは各287ページ中28ページで37回、100モデルは各33ページで46回の追加認識を行った。
4設定合計122ページで166呼出。APIの本文変更は計38組で、bbox/confidenceだけの変更も別に記録する。
別途CLIのdet=.3でも構造補正false/trueを各前後実行し、15→4 / 8→4文字誤り、単語指標も非悪化だった。
診断archive内の `context-calls.json` はf64のdecimal再parseの微差を除くためconfidenceをf32へ戻してmetadataを比較する。
CLIの追加呼出数は計測していない。実行時間/メモリの統制比較もしていないため、高速化は主張しない。

通常全targetは{t['default_distinct_passed']}件（最終libを差し替え重複計上せず）、ONNX対象{t['onnx-tests.log']['passed']}件、example18件が成功。
純粋方針の境界/失敗/画素保存と40例の拡大・移動PBT、実モデルの既定回復・評価設定維持・confidence optionを検査した。
最初の合成Cは細すぎて帯検出0本になった。条件を満たす単一帯のfixtureへ直し、元の失敗とPBT seedも残した。
fmt/diff/対象Clippy成功（本体18＋example1の既存警告、新規警告なし）。

APIは全1148ページを新規実行し、test-only observerで全候補のbbox/寸法/平均confidence/結果/失敗を記録した。
モデルを含まない凍結した検証実行ファイルで、元RGBと全before結果に同じ製品選択を再適用し、
全1148ページの呼出順・crop画素・bbox/text/f32 confidenceが保存結果と一致した。
背景準備が画素を変える場合は、両既存準備経路でも選択が同じことを確認している。
候補を真値で選択する処理ではなく、記録済みモデル応答に対する製品方針の全件再生である。

CLIは全574ページを新規実行。その後の変更はtest-only observer/テスト/ドキュメントだけで、
最終sourceを再buildした別binaryでも、本文が変わった全CLI組と安定対照、計41実行がbyte一致した。
単行は3認識sourceとdispatchを照合し、全保存byteと最初の候補binaryによる30新規実行の一致も確認して再利用した。

比較元CLI・候補CLI・最終検証CLI・凍結policy再生binaryのSHAを分けて記録する。
元のAPI推論test実行ファイルは別のtest buildで置き換わる前にSHAを取得できなかったためnullと明示する。
当該driver、製品source、全モデル/input/output/候補応答と、凍結した検証binaryによる全件一致を別の根拠として保存する。
検証binaryのSHAを、元のAPI推論binaryのSHAとして扱わない。

## 証拠と再採点

`text-evidence.zip/.json` は前後全5022本文・真値・API metadata/全候補・CLI stderrと単行stdout、
`metrics.zip/.json` は27組54表、`diagnostic-evidence.zip/.json` はsource/全Red/Green/argv/再利用と検証ログ。
全archive/memberのSHAを検査して展開でき、モデルや元画像を使わず再採点できる。

```sh
python3 docs/benchmarks/missing-line-context/unpack_evidence.py --output tmp/missing-context-text-replay
NDLOCR_REPEAT_EVAL_ROOT=tmp/missing-context-text-replay python3 docs/benchmarks/missing-line-context/evaluate.py score
NDLOCR_REPEAT_EVAL_ROOT=tmp/missing-context-text-replay python3 docs/benchmarks/missing-line-context/single_cli.py score
```

モデル応答のpolicy再生には元入力も必要。repoの固定画像に加え、160画像を以下で復元する。
その後、同じtext展開rootに対して、ONNXなしの明示診断testを使える。

```sh
python3 -m zipfile -e tests/fixtures/repeated_glyph/corpus.zip tmp/repeated-glyph/fixtures
NDLOCR_MISSING_CONTEXT_REPLAY_ROOT=tmp/missing-context-text-replay cargo test --no-default-features --lib replay_missing_context_choices_from_recorded_model_outputs -- --include-ignored
```

今後の検討対象は、実際に印字された閉じ括弧を単行の旧sanitizerが落とす問題、
複数成分を持つ反復字形の未支持、文字種誤読、復旧bboxに含む余白と未知資料での汎化である。
'''
(out/'README.md').write_text(readme)
marker='## 2026-10-19: 未被覆画線を持つ単一横書き行の全体文脈確認'
plan=Path('docs/plan.md').read_text()
if marker not in plan:
 plan+='\n'+marker+f'''\n
- 先行仕様 `docs/missing_line_context_recovery.md`。元bbox和集合の外に画線があり横書き帯が1本の場合だけ、同じprimaryのnative内・全文被覆の原画像/帯をHorizontalで確認する。元結果の非空白文字数加重平均を厳密に上回る候補のみ採用し、文字置換・文書固有条件・追加モデルはない。
- 純粋方針6件（40例の拡大/移動PBTを含む）と実モデルRed→Green。混合A1 JPEGの既定APIは30モデル13→4誤り、100モデル9→4へ改善し、固定.9で除外していた.893候補も扱える。元の評価設定/空結果/optionは維持する。
- 270f85a比、全287×6×3＋単行263×3×3の7533文字/単語指標が非悪化。2511本文組は51生距離改善・2450byte同一・10同値変更。改善は既存合成対照24、新反復対照27で、既存実資料20画像は同一。未知実資料holdoutとは扱わない。
- API全1148ページとCLI全574プロセスを新規実行。APIでは122ページで166追加呼出を記録し、元RGB/既存結果と記録応答を製品方針へ戻す全1148件のpolicy再生も一致。最終CLIの変更した全本文と対照41件、単行30件の新規byte一致を検査し、単行789予測は全byte再利用した。
- 通常{t['default_distinct_passed']}件・ONNX対象{t['onnx-tests.log']['passed']}件・example18件、fmt/diff/対象Clippyが成功（既存本体18+example1、新規警告なし）。証拠は `docs/benchmarks/missing-line-context/`。元API推論binary SHAの未取得を明示し、検証binaryとdriver/source/model/input/output・全候補応答の根拠を区別する。
- 次は単行画像で物理的に存在する閉じ括弧の欠落、複数成分の反復文字、文字種、復旧bboxの余白を診断する。追加推論の統制速度/未知資料汎化は未確認。
'''
 Path('docs/plan.md').write_text(plan)
body=f'''欠けた画線や未検出行、同じ行の過剰な断片出力、後処理による正しい反復の欠落を改善する。検出枠の外に画線が残る単一横書き行は、同じprimaryモデルの全体文脈でも確認する。

## 変更内容

- 原RGBから欠けた横画線や孤立小画線をcropへ戻し、下線/囲み線の誤分割や長行の字形切断を抑える。実単語空白を保持する。
- 高密度長行と有効DEIM行のない帯を、同じ供給モデルの安全な部分認識・画素/認識支持で復旧する。図形/容量超過入力の誤追加を抑える。
- 近似同一検出や弱い外側の複数行領域、同baselineの全体と包含断片を整理する。検出scoreとPARSeq平均confidenceを混同しない。
- 画像付きstateless/Session/Poolとページ断片では、独立した画線群がraw文字数を支持する場合だけ反復上限を外す。
- 元枠に覆われない画線を持つ単一横書き帯は、native内・全文被覆の原画像/帯をprimaryのHorizontalで確認し、元結果の文字数加重平均を厳密に上回る候補だけ採用する。固定.9では除外する.893の回復候補も扱う。失敗時は元結果を保持し、空出力から追加しない。
- ページ断片の閉じ括弧、URL/パス末尾のliteral hyphenを保持する。短行の語順変更には複数モデル合意を要求する。

新しい文書固有置換や追加モデルは導入しない。text-only sanitizer/raw候補API、単行の括弧方針、Pool Autoとエラー/optionを維持する。外部辞書/ルールpackは後段で適用する。

## 最新変更の全件比較

比較元270f85a。固定287画像×ページ6経路と単行263画像×3モデルをnone/width/strictで比較し、**全7533画像別文字・単語指標が非悪化**。

{table}

2511本文組で51生距離改善・2450byte同一・10同値変更。改善は既存長短行対照24、新反復対照27で、実資料20画像は今回同一。合成・機械変形を含む開発回帰で、独立holdoutとは数えない。同値の文字種誤読を改善に数えない。

一律全体置換は高confidence/native内でも退行があるため棄却し、全候補と反例を保存した。元枠が覆わない画線と帯構造を確認してから、全287画像・CLIでも比較して採用した。

先行の反復保持（11b6118→bae38d3）では全7533文字/単語指標非悪化、392本文組改善。各変更の別baseline/全件結果は別benchmarkに保存する。さらに前の未検出行復旧には単語指標12件の1→2退行があり、今回の比較はその過去の退行を取り消す主張ではない。

## 検証と証拠

仕様→Red→Green、境界/負例/PBT/固定モデルで、通常{t['default_distinct_passed']}件、ONNX対象{t['onnx-tests.log']['passed']}件、example18件が成功。fmt/diff/対象Clippy成功（既存本体18+example1、新規警告なし）。直前270f85aの全5CIも成功。

API全1148ページとCLI574プロセスを新規実行した。APIは122ページで166追加呼出を記録し、元RGB/既存結果と記録応答による全1148件のpolicy再生もbbox/text/f32 confidenceまで一致した。最終CLIの変更した全本文＋対照41件、単行30件も新規byte一致し、単行789本文の認識source/dispatchと全保存byteを照合した。

全5022前後本文・truth・API枠/信頼度/全候補・CLI stdout/stderr、27組のCSV/MD、全Red/Green/途中案/source/SHAをarchiveへ保存する。元API推論test binaryは別build前のSHAを取得できなかったためnullとし、凍結したpolicy検証binaryのSHAと区別している。

単行の物理的な閉じ括弧欠落、複数成分の反復字形、1/I/l/O/0等、未検出領域、復旧bboxの余白と未知資料の汎化は残る。速度の統制比較はしていない。

主な仕様・全件証拠:

- `docs/missing_line_context_recovery.md` / `docs/benchmarks/missing-line-context/`
- `docs/missing_line_context_probe.md` / `docs/benchmarks/missing-line-context-probe/`
- `docs/visible_repetitions.md` / `docs/contained_line_context.md` / `docs/benchmarks/visible-repetitions/`
- `docs/page_band_fallback.md` / `docs/benchmarks/page-band-fallback/`
- `docs/dense_line_recovery.md` / `docs/isolated_trailing_mark.md` / `docs/long_line_split.md`
'''
(r/'pr22-body.md').write_text(body)
