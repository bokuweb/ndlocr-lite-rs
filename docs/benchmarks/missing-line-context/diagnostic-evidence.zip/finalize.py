from pathlib import Path
import hashlib,json,csv,re,subprocess,struct
r=Path('tmp/missing-context-recovery');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=json.loads((r/'evaluation-manifest.json').read_text());cli=json.loads((r/'after-runs.json').read_text());assert cli['binary_sha256']==sha(r/'candidate-ndlocr');m={k:old[k]for k in ['baseline_commit','baseline_cli_binary_sha256','models','charset_sha256','inputs','before_reused_files_sha256','before_evidence_index_sha256','before_parent_manifest_sha256','before_product_source_sha256']};m['candidate_cli_binary_sha256']=cli['binary_sha256'];m['candidate_final_verification']=json.loads((r/'final-cli-source.json').read_text());m['policy_replay_binary']=json.loads((r/'policy-replay-binary.json').read_text());m['api_forward_binary_sha256']=None;m['api_forward_binary_note']='The original running test executable was replaced by a subsequent test build before its SHA was captured. Source/model/input/output and all callback traces are recorded; all 1148 choices are replayed with the frozen verification executable.';m['cli_source_note']='After the matrix CLI build, only test-only tracing, tests, and documentation changed; final CLI freshly verifies every changed page and sampled unchanged pages.';m['driver_sha256']=sha('tests/support/missing_line_context_model.rs');m['source_sha256']={str(p):sha(p)for p in sorted(Path('src').rglob('*.rs'))};m['predictions_sha256']={p.relative_to(r).as_posix():sha(p)for phase in ['before','after']for p in sorted((r/phase).rglob('*.txt'))};assert len(m['predictions_sha256'])==5022
for name,digest in m['models'].items():assert sha(name)==digest
assert sha('models/NDLmoji.yaml')==m['charset_sha256']
for row in m['inputs']:assert sha(row['image'])==row['image_sha256']and sha(row['truth'])==row['truth_sha256']
(r/'evaluation-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
summary={};totals={};cohorts={};by_file={x['id']+'.txt':x['cohort']for x in m['inputs']}
for mode in ['deim','bands','runtime30_eval','runtime30_default','runtime100_eval','runtime100_default','single30','single50','single100']:
 data=list(csv.DictReader((r/(mode+'-none.csv')).open()));b={x['file']:x for x in data if x['system']=='before'};stats={'images':len(b),'raw_char_improved':0,'byte_equal':0,'raw_char_ties_changed':0,'raw_char_regressed':0};groups={}
 for row in data:
  if row['system']!='after':continue
  name=row['file'];old,new=int(b[name]['char_errors']),int(row['char_errors']);key='raw_char_improved'if new<old else'raw_char_regressed'if new>old else'byte_equal'if(r/'before'/mode/name).read_bytes()==(r/'after'/mode/name).read_bytes()else'raw_char_ties_changed';stats[key]+=1;group=groups.setdefault(by_file[name],{'pairs':0,'raw_char_improved':0,'raw_char_regressed':0,'byte_equal':0,'raw_char_ties_changed':0});group['pairs']+=1;group[key]+=1
 summary[mode]=stats;cohorts[mode]=groups
 for norm in ['none','width','strict']:
  data=list(csv.DictReader((r/(mode+'-'+norm+'.csv')).open()));totals[mode+'/'+norm]={}
  for phase in ['before','after']:
   values=[x for x in data if x['system']==phase];t={key:sum(int(x[key])for x in values)for key in['char_errors','char_total','word_errors','word_total']};t['cer']=t['char_errors']/t['char_total']if t['char_total']else 0;t['wer']=t['word_errors']/t['word_total']if t['word_total']else 0;totals[mode+'/'+norm][phase]=t
for name,data in [('summary.json',summary),('totals.json',totals),('cohort-summary.json',cohorts)]:(r/name).write_text(json.dumps(data,indent=2)+'\n')
canon=lambda lines:[(tuple(x['bbox']),x['text'],struct.pack('<f',x['confidence']).hex())for x in lines]
traces={}
for mode in ['runtime30_eval','runtime30_default','runtime100_eval','runtime100_default']:
 before={x['id']:x for x in json.loads((r/'before'/mode/'results.json').read_text())};after=json.loads((r/'after'/mode/'results.json').read_text());traces[mode]={'pages':len(after),'pages_checked':sum(bool(x['context_attempts'])for x in after),'extra_model_calls':sum(len(x['context_attempts'])for x in after),'text_changed':sum(x['text']!=before[x['id']]['text']for x in after),'metadata_changed_f32':sum(canon(x['lines'])!=canon(before[x['id']]['lines'])for x in after)}
(r/'context-calls.json').write_text(json.dumps(traces,indent=2)+'\n')
logs=['default-tests.log','default-lib-final.log','onnx-tests.log','example-tests.log','policy-replay.log','final-cli-parity.log'];tests={}
for name in logs:
 text=(r/name).read_text();assert 'FAILED'not in text,name;tests[name]={'passed':sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',text))),'sha256':sha(r/name)}
initial=int(re.search(r'test result: ok\. (\d+) passed;', (r/'default-tests.log').read_text())[1]);tests['default_distinct_passed']=tests['default-tests.log']['passed']-initial+tests['default-lib-final.log']['passed'];tests['final_cli_fresh_checks']=len(json.loads((r/'final-cli-parity.json').read_text()));tests['single_fresh_checks']=len(json.loads((r/'single-reuse.json').read_text())['fresh_checks']);tests['policy_replayed_pages']=len(json.loads((r/'policy-replay.json').read_text()));assert tests['policy_replayed_pages']==1148;tests['clippy']={'library_warnings':18,'example_warnings':1,'new_warnings':0,'sha256':sha(r/'clippy.log')};(r/'tests-summary.json').write_text(json.dumps(tests,indent=2)+'\n');print(json.dumps(summary,indent=2));print('traces',traces);print('tests',tests)
