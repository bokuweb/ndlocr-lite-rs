from pathlib import Path
import json,subprocess,os,hashlib,concurrent.futures
r=Path('tmp/missing-context-recovery');m=json.loads((r/'evaluation-manifest.json').read_text());jobs=[]
for mode in ['deim','bands']:
 for i,row in enumerate(m['inputs']):
  name=row['id']+'.txt'
  if (r/'before'/mode/name).read_bytes()!=(r/'after'/mode/name).read_bytes()or i%29==0:jobs.append((row,mode))
def run(job):
 row,mode=job;out=r/'final-verification'/mode/(row['id']+'.txt');out.parent.mkdir(parents=True,exist_ok=True);argv=[str((r/'final-verify-ndlocr').resolve()),'recognize-page','--image',row['image'],'--charset','models/NDLmoji.yaml','--use-deim-detection',str(mode=='deim').lower(),'--output-txt',str(out)];p=subprocess.run(argv,capture_output=True,env={**os.environ,'NDLOCR_INTRA_THREADS':'1'});out.with_suffix('.stdout').write_bytes(p.stdout);out.with_suffix('.stderr').write_bytes(p.stderr);assert p.returncode==0 and out.read_bytes()==(r/'after'/mode/out.name).read_bytes()and p.stdout==out.read_bytes()+b'\n',(row['id'],mode,p.stderr);return {'argv':argv,'exit_code':p.returncode,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'matches':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,jobs))
(r/'final-cli-parity.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),'new final binary matches')
