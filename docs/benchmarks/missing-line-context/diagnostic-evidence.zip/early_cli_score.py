from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
from eval_ocr_metrics import normalize_text,levenshtein
r=Path('tmp/missing-context-recovery');m=json.loads((r/'evaluation-manifest.json').read_text());reg=[];word=[];counts={}
for mode in ['deim','bands']:
 count=0
 for row in m['inputs']:
  id=row['id'];p=r/'after'/mode/(id+'.txt')
  if not p.with_suffix('.stderr').exists():continue
  before=(r/'before'/mode/(id+'.txt')).read_text();after=p.read_text();truth=(r/'truth'/(id+'.txt')).read_text();count+=1
  if before==after:continue
  for norm in ['none','width','strict']:
   t,b,a=[normalize_text(x,norm)for x in [truth,before,after]];old,new=[levenshtein(list(t),list(x))for x in [b,a]]
   if new>old:reg.append([mode,norm,id,old,new])
   old,new=[levenshtein(t.split(),x.split())for x in [b,a]]
   if new>old:word.append([mode,norm,id,old,new])
 counts[mode]=count
(r/'early-cli-audit.json').write_text(json.dumps({'completed_images':counts,'regressions':reg,'word_regressions':word},indent=2)+'\n');print('CLI completed',counts,'char regressions',reg,'word',word)
