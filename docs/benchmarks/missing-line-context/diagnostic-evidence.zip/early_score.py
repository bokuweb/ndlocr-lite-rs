from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
from eval_ocr_metrics import normalize_text,levenshtein
r=Path('tmp/missing-context-recovery');reg=[];word=[];changes=[];modes=[]
for mode in ['runtime30_eval','runtime30_default','runtime100_eval','runtime100_default']:
 path=r/'after'/mode/'results.json'
 if not path.exists():continue
 modes.append(mode);rows=json.loads(path.read_text());before={x['id']:x for x in json.loads((r/'before'/mode/'results.json').read_text())}
 for row in rows:
  truth=(r/'truth'/(row['id']+'.txt')).read_text()
  for norm in ['none','width','strict']:
   t,b,a=[normalize_text(x,norm)for x in [truth,before[row['id']]['text'],row['text']]];old,new=[levenshtein(list(t),list(x))for x in [b,a]];entry=[mode,norm,row['id'],old,new]
   if new!=old:changes.append(entry)
   if new>old:reg.append(entry)
   old,new=[levenshtein(t.split(),x.split())for x in [b,a]]
   if new>old:word.append([mode,norm,row['id'],old,new])
(r/'early-api-audit.json').write_text(json.dumps({'completed_modes':modes,'regressions':reg,'word_regressions':word,'changes':changes},indent=2)+'\n');print('modes',modes,'char regressions',reg,'word',word,'improvements',len(changes))
