from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('tmp/missing-context-recovery');parent=Path('tmp/repeated-glyph');bench=Path('docs/benchmarks/visible-repetitions');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((bench/'evaluation-manifest.json').read_text());index=json.loads((bench/'text-evidence.json').read_text());before={}
for p,digest in m['final_source_sha256'].items():assert hashlib.sha256(subprocess.check_output(['git','show','270f85a:'+p])).hexdigest()==digest
for p in (parent/'after').rglob('*'):
 if not p.is_file():continue
 member=p.relative_to(parent).as_posix();assert sha(p)==index['members'][member];out=r/'before'/p.relative_to(parent/'after');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());before[out.relative_to(r).as_posix()]=sha(p)
for d in ['truth','single-truth','single-stdout-truth']:
 shutil.copytree(parent/d,r/d,dirs_exist_ok=True)
for name in ['evaluate.py','single_cli.py','single_transport.py']:
 shutil.copyfile(bench/name,r/name)
assert sha(parent/'candidate-ndlocr')==m['candidate_cli_binary_sha256'];shutil.copyfile(parent/'candidate-ndlocr',r/'baseline-ndlocr');(r/'baseline-ndlocr').chmod(0o755)
m['baseline_commit']=subprocess.check_output(['git','rev-parse','270f85a'],text=True).strip();m['baseline_cli_binary_sha256']=sha(r/'baseline-ndlocr');m['before_reused_files_sha256']=before;m['before_evidence_index_sha256']=sha(bench/'text-evidence.json');m['before_parent_manifest_sha256']=sha(bench/'evaluation-manifest.json');m['before_product_source_sha256']=m.pop('final_source_sha256');m['inputs']=json.loads((parent/'evaluation-manifest.json').read_text())['inputs'];(r/'evaluation-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print('verified before',len(before),'files; predictions',sum(k.endswith('.txt')for k in before))
