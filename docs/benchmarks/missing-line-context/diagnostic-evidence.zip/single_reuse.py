from pathlib import Path
import hashlib,json,subprocess,concurrent.futures,os,shutil
r=Path('tmp/missing-context-recovery');m=json.loads((r/'evaluation-manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['src/infer/cached.rs','src/infer/parseq.rs','src/infer/visible_repetitions.rs']:assert sha(name)==m['before_product_source_sha256'][name]
branch=lambda s:s.split('Command::Recognize(args) => {',1)[1].split('Command::RecognizePage(args) => {',1)[0]
old=subprocess.check_output(['git','show','270f85a:src/app.rs'],text=True);assert branch(old)==branch(Path('src/app.rs').read_text())
models=[('single30','models/parseq-ndl-24x256-30-tiny-189epoch-tegaki3-r8data-202604.onnx'),('single50','models/parseq-ndl-24x384-50-tiny-300epoch-tegaki3-r8data-202604.onnx'),('single100','models/parseq-ndl-24x768-100-tiny-153epoch-tegaki3-r8data-202604.onnx')];reused={}
for mode,_ in models:
 shutil.copytree(r/'before'/mode,r/'after'/mode,dirs_exist_ok=True)
 for p in (r/'after'/mode).iterdir():assert sha(p)==sha(r/'before'/mode/p.name);reused[p.relative_to(r).as_posix()]=sha(p)
rows=[x for x in m['inputs']if x['cohort']in['repeated_glyph','long_line','dense_line','dense_crop','page_band_fallback']and not x['id'].startswith('fallback_two_rows_')];assert len(rows)==263
checks=rows[::29]
def run(job):
 row,(mode,model)=job;argv=[str((r/'candidate-ndlocr').resolve()),'recognize','--image',row['image'],'--charset','models/NDLmoji.yaml','--model',model];p=subprocess.run(argv,capture_output=True,env={**os.environ,'NDLOCR_INTRA_THREADS':'1'});assert p.returncode==0 and p.stdout==(r/'after'/mode/(row['id']+'.stdout')).read_bytes(),(mode,row['id'],p.stderr,p.stdout);return {'argv':argv,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:fresh=list(pool.map(run,[(row,model)for row in checks for model in models]))
(r/'single-reuse.json').write_text(json.dumps({'before_binary_sha256':m['baseline_cli_binary_sha256'],'candidate_binary_sha256':sha(r/'candidate-ndlocr'),'unchanged_dispatch_sha256':hashlib.sha256(branch(old).encode()).hexdigest(),'reused_files':reused,'fresh_checks':fresh},indent=2)+'\n');print(len(fresh),'fresh matches;',len(reused),'reused files')
