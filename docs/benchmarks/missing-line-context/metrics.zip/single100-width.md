# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `263`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| before | 263 | 0 | 0.7868 | 0.7747 |
| after | 263 | 0 | 0.7868 | 0.7747 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
