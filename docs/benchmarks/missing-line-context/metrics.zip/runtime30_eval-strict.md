# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 287 | 0 | 0.4086 | 0.7706 |
| before | 287 | 0 | 0.4103 | 0.7884 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
