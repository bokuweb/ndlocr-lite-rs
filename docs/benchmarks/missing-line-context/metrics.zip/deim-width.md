# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 287 | 0 | 0.2173 | 0.5791 |
| before | 287 | 0 | 0.2193 | 0.5871 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
