# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `287`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| after | 287 | 0 | 0.4174 | 0.7145 |
| before | 287 | 0 | 0.4193 | 0.7218 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
