# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.6457 | 0.8013 |
| no_space | 1239 | 0 | 0.6476 | 0.7887 |
| short_common | 1239 | 0 | 0.6563 | 0.8399 |
| closer_body | 1239 | 0 | 0.6563 | 0.8399 |
| baseline | 1239 | 0 | 0.6580 | 0.8529 |
| raw | 1239 | 0 | 0.6606 | 0.8195 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
