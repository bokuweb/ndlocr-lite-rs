# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| no_space | 1239 | 0 | 0.6542 | 0.8221 |
| fragment | 1239 | 0 | 0.6576 | 0.8419 |
| short_common | 1239 | 0 | 0.6608 | 0.8612 |
| closer_body | 1239 | 0 | 0.6608 | 0.8612 |
| baseline | 1239 | 0 | 0.6622 | 0.8722 |
| raw | 1239 | 0 | 0.6725 | 0.8602 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
