# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.7408 | 0.8858 |
| no_space | 1239 | 0 | 0.7411 | 0.8727 |
| short_common | 1239 | 0 | 0.7514 | 0.9191 |
| closer_body | 1239 | 0 | 0.7514 | 0.9191 |
| baseline | 1239 | 0 | 0.7524 | 0.9270 |
| raw | 1239 | 0 | 0.7578 | 0.9030 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
