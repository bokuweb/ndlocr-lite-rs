# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| no_space | 1239 | 0 | 0.7419 | 0.8399 |
| fragment | 1239 | 0 | 0.7450 | 0.8701 |
| short_common | 1239 | 0 | 0.7513 | 0.8941 |
| closer_body | 1239 | 0 | 0.7513 | 0.8941 |
| baseline | 1239 | 0 | 0.7532 | 0.9087 |
| raw | 1239 | 0 | 0.7716 | 0.8717 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
