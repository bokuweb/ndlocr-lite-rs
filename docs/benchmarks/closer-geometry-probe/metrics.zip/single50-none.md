# OCR Evaluation Report

- normalization: `none`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| no_space | 1239 | 0 | 0.7488 | 0.8972 |
| fragment | 1239 | 0 | 0.7527 | 0.9144 |
| short_common | 1239 | 0 | 0.7571 | 0.9327 |
| closer_body | 1239 | 0 | 0.7571 | 0.9327 |
| baseline | 1239 | 0 | 0.7582 | 0.9405 |
| raw | 1239 | 0 | 0.7698 | 0.9317 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
