# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.6440 | 0.6497 |
| no_space | 1239 | 0 | 0.6454 | 0.6602 |
| raw | 1239 | 0 | 0.6455 | 0.6497 |
| short_common | 1239 | 0 | 0.6481 | 0.6893 |
| closer_body | 1239 | 0 | 0.6481 | 0.6893 |
| baseline | 1239 | 0 | 0.6494 | 0.7046 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
