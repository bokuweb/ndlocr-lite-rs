# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.7272 | 0.6570 |
| no_space | 1239 | 0 | 0.7288 | 0.6667 |
| short_common | 1239 | 0 | 0.7331 | 0.7086 |
| closer_body | 1239 | 0 | 0.7331 | 0.7086 |
| baseline | 1239 | 0 | 0.7340 | 0.7191 |
| raw | 1239 | 0 | 0.7427 | 0.6570 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
