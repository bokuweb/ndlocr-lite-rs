# OCR Evaluation Report

- normalization: `width`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.7328 | 0.8326 |
| no_space | 1239 | 0 | 0.7345 | 0.8075 |
| short_common | 1239 | 0 | 0.7464 | 0.8764 |
| closer_body | 1239 | 0 | 0.7464 | 0.8764 |
| baseline | 1239 | 0 | 0.7484 | 0.8920 |
| raw | 1239 | 0 | 0.7595 | 0.8341 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
