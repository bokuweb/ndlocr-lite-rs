# OCR Evaluation Report

- normalization: `strict`
- truth files discovered: `1239`

## Aggregate Metrics

| system | matched_files | missing_files | CER | WER |
|---|---:|---:|---:|---:|
| fragment | 1239 | 0 | 0.7229 | 0.5738 |
| no_space | 1239 | 0 | 0.7281 | 0.6126 |
| short_common | 1239 | 0 | 0.7337 | 0.6683 |
| closer_body | 1239 | 0 | 0.7337 | 0.6683 |
| baseline | 1239 | 0 | 0.7355 | 0.6893 |
| raw | 1239 | 0 | 0.7406 | 0.5738 |

## Notes

- Lower is better for both CER and WER.
- Systems are compared only on files that exist in each prediction directory.
- Use `--require-all` to fail fast when prediction files are missing.

## Missing Files
