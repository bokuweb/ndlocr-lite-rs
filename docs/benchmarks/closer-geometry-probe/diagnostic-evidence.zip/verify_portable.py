from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();r=root/'tmp/closer-geometry';src=root/'docs/benchmarks/closer-geometry-probe';dest=r/'restored';subprocess.run(['python3',str(src/'unpack_evidence.py'),'--output',str(dest),'--diagnostics'],check=True);work=r/'portable-score-workspace';work.mkdir(exist_ok=True)
if not(work/'tools').exists():(work/'tools').symlink_to(root/'tools',target_is_directory=True)
assert not(work/'models').exists()and not(work/'tests').exists()and not(dest/'probe.json').exists()
p=subprocess.run(['python3',str(src/'evaluate.py')],cwd=work,env={**os.environ,'NDLOCR_GEOMETRY_EVAL_ROOT':str(dest)},capture_output=True);assert p.returncode==0,p.stderr
for file in(dest/'original-metrics').glob('*'):assert file.read_bytes()==(dest/'metrics'/file.name).read_bytes(),file.name
assert(dest/'audit.json').read_bytes()==(dest/'diagnostics/audit.json').read_bytes();print('9 CSV/MD + audit byte-identical without probe, models or original images',flush=True)
binary=r/'portable-replay-binary';meta=json.loads((r/'portable-replay-binary.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==meta['binary_sha256'];p=subprocess.run([str(binary),'infer::visible_repetitions::geometry_probe::replay_closer_geometry_from_frozen_pixels','--exact','--include-ignored'],cwd=work,env={**os.environ,'NDLOCR_GEOMETRY_REPLAY_ROOT':str(dest/'diagnostics')},capture_output=True);print(p.stdout.decode(),flush=True);assert p.returncode==0,p.stderr;assert(dest/'diagnostics/replay.json').read_bytes()==(r/'replay.json').read_bytes();print('3717 component boxes, baseline and candidate choices identical from separate raw/RGB root',flush=True)
