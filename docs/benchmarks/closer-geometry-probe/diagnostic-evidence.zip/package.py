from pathlib import Path
import json,hashlib,zipfile,subprocess,csv,collections,shutil
r=Path('tmp/closer-geometry');out=Path('docs/benchmarks/closer-geometry-probe');out.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def pack(stem,files):
 path=out/(stem+'.zip');members={}
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,p in sorted(files.items()):
   data=Path(p).read_bytes();members[name]=sha(data);info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data,compresslevel=9)
 (out/(stem+'.json')).write_text(json.dumps({'sha256':sha(path.read_bytes()),'members':members},indent=2)+'\n')
 with zipfile.ZipFile(path)as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(members)
  for name,h in members.items():assert sha(z.read(name))==h
 print(stem,len(members),'verified members',flush=True)
m=json.loads((r/'evaluation-manifest.json').read_text());capture=json.loads((r/'probe-binary.json').read_text());assert sha((r/'capture-manifest.json').read_bytes())==capture['manifest_sha256'];assert sha((r/'capture-driver.rs').read_bytes())==capture['driver_sha256'];assert sha((r/'capture-visible.rs').read_bytes())==capture['source_sha256']['src/infer/visible_repetitions.rs'];base=subprocess.check_output(['git','show',m['baseline_commit']+':src/infer/visible_repetitions.rs']);current=Path('src/infer/visible_repetitions.rs').read_bytes();suffix=b'\n#[cfg(test)]\n#[path = "../../tests/support/closer_geometry_probe.rs"]\nmod geometry_probe;\n';assert current==base+suffix
for p,h in m['baseline_product_source_sha256'].items():
 if p!='src/infer/visible_repetitions.rs':assert sha(Path(p).read_bytes())==h,p
for p,h in m['models'].items():assert sha(Path(p).read_bytes())==h,p
assert sha(Path('models/NDLmoji.yaml').read_bytes())==m['charset_sha256']
for x in m['inputs']:assert sha(Path(x['image']).read_bytes())==x['image_sha256']and sha(Path(x['truth']).read_bytes())==x['truth_sha256']
m['capture']=capture;m['portable_replay']=json.loads((r/'portable-replay-binary.json').read_text());m['production_functions_and_callers_unchanged']=True;m['score_script_sha256']=sha((r/'evaluate.py').read_bytes());(r/'evaluation-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');a=json.loads((r/'audit.json').read_text());summary={}
for policy in ['fragment','no_space','short_common','closer_body']:
 c=collections.Counter()
 for label,stats in a['stats'].items():c.update(stats[policy])
 c['char_regressed']+=0;summary[policy]=dict(c)
summary['comparisons_per_policy']=11151;summary['raw_exact_lost_before']=sum(x['raw_exact_lost_before']for x in a['raw_stats'].values());summary['remaining_selected']=265;summary['selected_for_next_product_validation']='closer_body';summary['product_behavior_changed']=False;(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['evaluation-manifest.json','summary.json','tests-summary.json','evaluate.py']:shutil.copy2(r/name,out/name)
def under(names):return {str(p.relative_to(r)):p for name in names for p in(r/name).rglob('*')if p.is_file()}
pack('text-evidence',under(['policies','truth']));metrics={p.name:p for p in(r/'metrics').glob('*')};assert len(metrics)==18;pack('metrics',metrics)
files=under(['inputs']);files.update({p.name:p for p in r.iterdir()if p.is_file()and p.suffix in ['.json','.jsonl','.log','.py','.rs','.md']and p.name not in ['evaluation-manifest.json','summary.json','tests-summary.json','package.log','package-final.log']})
for name in ['src/infer/visible_repetitions.rs','tests/support/closer_geometry_probe.rs','tests/closer_geometry_fixture_tests.rs','docs/closer_geometry_probe.md']:
 p=Path(name);files['source/'+name]=p
pack('diagnostic-evidence',files)
s=Path('docs/benchmarks/literal-closers/unpack_evidence.py').read_text().replace("for name in ['evaluation-manifest.json', 'evaluate.py']:","for name in ['evaluation-manifest.json', 'evaluate.py']:");(out/'unpack_evidence.py').write_text(s)
print(json.dumps(summary,indent=2))
